;window.COMPONENTS_BASE_URL='/shared/elements/';;!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var f;"undefined"!=typeof window?f=window:"undefined"!=typeof global?f=global:"undefined"!=typeof self&&(f=self),f.GaiaHeader=e()}}(function(){var define,module,exports;return(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){;(function(define){define(function(require,exports,module){'use strict';var textContent=Object.getOwnPropertyDescriptor(Node.prototype,'textContent');var removeAttribute=HTMLElement.prototype.removeAttribute;var setAttribute=HTMLElement.prototype.setAttribute;var noop=function(){};var hasShadowCSS=(function(){var div=document.createElement('div');try{div.querySelector(':host');return true;}
catch(e){return false;}})();module.exports.register=function(name,props){injectGlobalCss(props.globalCss);delete props.globalCSS;var proto=Object.assign(Object.create(base),props);var output=extractLightDomCSS(proto.template,name);var _attrs=Object.assign(props.attrs||{},attrs);proto.template=output.template;proto.lightCss=output.lightCss;Object.defineProperties(proto,_attrs);var El=document.registerElement(name,{prototype:proto});return El;};var base=Object.assign(Object.create(HTMLElement.prototype),{attributeChanged:noop,attached:noop,detached:noop,created:noop,template:'',createdCallback:function(){this.injectLightCss(this);this.created();},attributeChangedCallback:function(name,from,to){if(this.attrs&&this.attrs[name]){this[name]=to;}
this.attributeChanged(name,from,to);},attachedCallback:function(){this.attached();},detachedCallback:function(){this.detached();},setAttr:function(name,value){var internal=this.shadowRoot.firstElementChild;setAttribute.call(internal,name,value);setAttribute.call(this,name,value);},removeAttr:function(){var internal=this.shadowRoot.firstElementChild;removeAttribute.call(internal,name,value);removeAttribute.call(this,name,value);},injectLightCss:function(el){if(hasShadowCSS){return;}
this.lightStyle=document.createElement('style');this.lightStyle.setAttribute('scoped','');this.lightStyle.innerHTML=el.lightCss;el.appendChild(this.lightStyle);}});var attrs={textContent:{set:function(value){var node=firstChildTextNode(this);if(node){node.nodeValue=value;}},get:function(){var node=firstChildTextNode(this);return node&&node.nodeValue;}}};function firstChildTextNode(el){for(var i=0;i<el.childNodes.length;i++){var node=el.childNodes[i];if(node&&node.nodeType===3){return node;}}}
function extractLightDomCSS(template,name){var regex=/(?::host|::content)[^{]*\{[^}]*\}/g;var lightCss='';if(!hasShadowCSS){template=template.replace(regex,function(match){lightCss+=match.replace(/::content|:host/g,name);return'';});}
return{template:template,lightCss:lightCss};}
function injectGlobalCss(css){if(!css)return;var style=document.createElement('style');style.innerHTML=css;document.head.appendChild(style);}});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-component',this));},{}],2:[function(require,module,exports){(function(define){define(function(require,exports,module){var base=window.GAIA_ICONS_BASE_URL||window.COMPONENTS_BASE_URL||'bower_components/';if(!isLoaded()){load(base+'gaia-icons/gaia-icons.css');}
function load(href){var link=document.createElement('link');link.rel='stylesheet';link.type='text/css';link.href=href;document.head.appendChild(link);exports.loaded=true;}
function isLoaded(){return exports.loaded||document.querySelector('link[href*=gaia-icons]')||document.documentElement.classList.contains('gaia-icons-loaded');}});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-icons',this));},{}],3:[function(require,module,exports){;(function(define){'use strict';define(function(require,exports,module){var Component=require('gaia-component');var fontFit=require('./lib/font-fit');require('gaia-icons');var actionTypes={menu:1,back:1,close:1};module.exports=Component.register('gaia-header',{created:function(){this.createShadowRoot().innerHTML=this.template;this.els={actionButton:this.shadowRoot.querySelector('.action-button'),headings:this.querySelectorAll('h1,h2,h3,h4'),inner:this.shadowRoot.querySelector('.inner')};this.els.actionButton.addEventListener('click',e=>this.onActionButtonClick(e));this.configureActionButton();this.runFontFit();},attached:function(){this.rerunFontFit();},attributeChanged:function(attr){if(attr==='action'){this.configureActionButton();this.rerunFontFit();}},runFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);fontFit.observeHeadingChanges(this.els.headings[i]);}},rerunFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);}},triggerAction:function(){if(this.isSupportedAction(this.getAttribute('action'))){this.els.actionButton.click();}},configureActionButton:function(){var old=this.els.actionButton.getAttribute('icon');var type=this.getAttribute('action');var supported=this.isSupportedAction(type);this.els.actionButton.classList.remove('icon-'+old);this.els.actionButton.setAttribute('icon',type);this.els.inner.classList.toggle('supported-action',supported);if(supported){this.els.actionButton.classList.add('icon-'+type);}},isSupportedAction:function(action){return action&&actionTypes[action];},onActionButtonClick:function(e){var config={detail:{type:this.getAttribute('action')}};var actionEvent=new CustomEvent('action',config);setTimeout(this.dispatchEvent.bind(this,actionEvent));},template:`
  <style>

  :host {
    display: block;

    --gaia-header-button-color:
      var(--header-button-color,
      var(--header-color,
      var(--link-color,
      inherit)));
  }

  /**
   * [hidden]
   */

  :host[hidden] {
    display: none;
  }

  /** Reset
   ---------------------------------------------------------*/

  ::-moz-focus-inner { border: 0; }

  /** Inner
   ---------------------------------------------------------*/

  .inner {
    display: flex;
    min-height: 50px;
    direction: ltr;

    background:
      var(--header-background,
      var(--background,
      #fff));
  }

  /** Action Button
   ---------------------------------------------------------*/

  /**
   * 1. Hidden by default
   */

  .action-button {
    display: none; /* 1 */
    position: relative;
    width: 50px;
    font-size: 30px;
    margin: 0;
    padding: 0;
    border: 0;
    align-items: center;
    background: none;
    cursor: pointer;
    transition: opacity 200ms 280ms;

    color:
      var(--header-action-button-color,
      var(--header-icon-color,
      var(--gaia-header-button-color)));
  }

  /**
   * .action-supported
   *
   * 1. For icon vertical-alignment
   */

  .supported-action .action-button {
    display: flex; /* 1 */
  }

  /**
   * :active
   */

  .action-button:active {
    transition: none;
    opacity: 0.2;
  }

  /** Action Button Icon
   ---------------------------------------------------------*/

  /**
   * 1. To enable vertical alignment.
   */

  .action-button:before {
    display: block;
  }

  /** Action Button Text
   ---------------------------------------------------------*/

  /**
   * To provide custom localized content for
   * the action-button, we allow the user
   * to provide an element with the class
   * .l10n-action. This node is then
   * pulled inside the real action-button.
   *
   * Example:
   *
   *   <gaia-header action="back">
   *     <span class="l10n-action" aria-label="Back">Localized text</span>
   *     <h1>title</h1>
   *   </gaia-header>
   */

  ::content .l10n-action {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    font-size: 0;
  }

  /** Title
   ---------------------------------------------------------*/

  /**
   * 1. Vertically center text. We can't use flexbox
   *    here as it breaks text-overflow ellipsis
   *    without an inner div.
   */

  ::content h1 {
    flex: 1;
    margin: 0;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    text-align: center;
    line-height: 50px; /* 1 */
    font-weight: 300;
    font-style: italic;
    font-size: 24px;
    -moz-user-select: none;

    color:
      var(--header-title-color,
      var(--header-color,
      var(--title-color,
      var(--text-color,
      inherit))));
  }

  /**
   * .flush-left
   *
   * When the fitted text is flush with the
   * edge of the left edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-left {
    padding-left: 10px;
  }

  /**
   * .flush-right
   *
   * When the fitted text is flush with the
   * edge of the right edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-right {
    padding-right: 10px; /* 1 */
  }

  /** Buttons
   ---------------------------------------------------------*/

  ::content a,
  ::content button {
    box-sizing: border-box;
    display: flex;
    border: none;
    width: auto;
    height: auto;
    margin: 0;
    padding: 0 10px;
    font-size: 14px;
    line-height: 1;
    min-width: 50px;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    text-align: center;
    background: none;
    border-radius: 0;
    font-style: italic;
    cursor: pointer;

    transition: opacity 200ms 280ms;

    color:
      var(--gaia-header-button-color);
  }

  /**
   * :active
   */

  ::content a:active,
  ::content button:active {
    transition: none;
    opacity: 0.2;
  }

  /**
   * [hidden]
   */

  ::content a[hidden],
  ::content button[hidden] {
    display: none;
  }

  /**
   * [disabled]
   */

  ::content a[disabled],
  ::content button[disabled] {
    pointer-events: none;
    color: var(--header-disabled-button-color);
  }

  /** Icon Buttons
   ---------------------------------------------------------*/

  /**
   * Icons are a different color to text
   */

  ::content .icon,
  ::content [data-icon] {
    color:
      var(--header-icon-color,
      var(--gaia-header-button-color));
  }

  /** Icons
   ---------------------------------------------------------*/

  [class^="icon-"]:before,
  [class*="icon-"]:before {
    font-family: 'gaia-icons';
    font-style: normal;
    text-rendering: optimizeLegibility;
    font-weight: 500;
  }

  .icon-menu:before { content: 'menu'; }
  .icon-close:before { content: 'close'; }
  .icon-back:before { content: 'back'; }

  </style>

  <div class="inner">
    <button class="action-button">
      <content select=".l10n-action"></content>
    </button>
    <content select="h1,h2,h3,h4,a,button"></content>
  </div>`});});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-header',this));},{"./lib/font-fit":4,"gaia-component":1,"gaia-icons":2}],4:[function(require,module,exports){;(function(define){'use strict';define(function(require,exports,module){var GaiaHeaderFontFit={_HEADER_SIZES:[16,17,18,19,20,21,22,23,24],observeHeadingChanges:function(heading){var observer=this._getTextChangeObserver();observer.observe(heading,{childList:true});},reformatHeading:function(heading){if(!heading||heading.textContent.trim()===''){return;}
this._resetCentering(heading);var style=this._getStyleProperties(heading);if(!style){return;}
style.textWidth=this._autoResizeElement(heading,style);this._centerTextToScreen(heading,style);},resetCache:function(){this._cachedContexts={};},_cachedContexts:{},_getCachedContext:function(fontSize,fontFamily,fontStyle){fontStyle=fontStyle||'italic';var cache=this._cachedContexts;var ctx=cache[fontSize]&&cache[fontSize][fontFamily]?cache[fontSize][fontFamily][fontStyle]:null;if(!ctx){var canvas=document.createElement('canvas');canvas.setAttribute('moz-opaque','true');canvas.setAttribute('width','1');canvas.setAttribute('height','1');ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.font=fontStyle+' '+fontSize+'px '+fontFamily;if(!cache[fontSize]){cache[fontSize]={};}
if(!cache[fontSize][fontFamily]){cache[fontSize][fontFamily]={};}
cache[fontSize][fontFamily][fontStyle]=ctx;}
return ctx;},_textChangeObserver:null,_handleTextChanges:function(mutations){var targets=new Set();for(var i=0;i<mutations.length;i++){targets.add(mutations[i].target);}
for(var target of targets){this.reformatHeading(target);}},_getTextChangeObserver:function(){if(!this._textChangeObserver){this._textChangeObserver=new MutationObserver(this._handleTextChanges.bind(this));}
return this._textChangeObserver;},_getFontWidth:function(string,fontSize,fontFamily,fontStyle){var ctx=this._getCachedContext(fontSize,fontFamily,fontStyle);return ctx.measureText(string).width;},_getMaxFontSizeInfo:function(string,allowedSizes,fontFamily,maxWidth){var fontSize;var resultWidth;var i=allowedSizes.length-1;do{fontSize=allowedSizes[i];resultWidth=this._getFontWidth(string,fontSize,fontFamily);i--;}while(resultWidth>maxWidth&&i>=0);return{fontSize:fontSize,overflow:resultWidth>maxWidth,textWidth:resultWidth};},_getContentWidth:function(style){var width=parseInt(style.width,10);if(style.boxSizing==='border-box'){width-=(parseInt(style.paddingRight,10)+
parseInt(style.paddingLeft,10));}
return width;},_getStyleProperties:function(heading){var style=getComputedStyle(heading)||{};var contentWidth=this._getContentWidth(style);if(isNaN(contentWidth)){contentWidth=0;}
return{fontFamily:style.fontFamily||'unknown',contentWidth:contentWidth,paddingRight:parseInt(style.paddingRight,10),paddingLeft:parseInt(style.paddingLeft,10),offsetLeft:heading.offsetLeft};},_autoResizeElement:function(heading,styleOptions){var contentWidth=styleOptions.contentWidth||this._getContentWidth(heading);var fontFamily=styleOptions.fontFamily||getComputedStyle(heading).fontFamily;var text=heading.textContent.replace(/\s+/g,' ').trim();var info=this._getMaxFontSizeInfo(text,this._HEADER_SIZES,fontFamily,contentWidth);heading.style.fontSize=info.fontSize+'px';return info.textWidth;},_resetCentering:function(heading){heading.style.marginLeft=heading.style.marginRight='0';},_centerTextToScreen:function(heading,styleOptions){var minHeaderWidth=styleOptions.textWidth+styleOptions.paddingRight+
styleOptions.paddingLeft;var tightText=styleOptions.textWidth>(styleOptions.contentWidth-30);var sideSpaceLeft=styleOptions.offsetLeft;var sideSpaceRight=this._getWindowWidth()-sideSpaceLeft-
styleOptions.contentWidth-styleOptions.paddingRight-
styleOptions.paddingLeft;heading.classList.toggle('flush-left',tightText&&!sideSpaceLeft);heading.classList.toggle('flush-right',tightText&&!sideSpaceRight);if(sideSpaceLeft===sideSpaceRight){return;}
var margin=Math.max(sideSpaceLeft,sideSpaceRight);if(minHeaderWidth+(margin*2)<this._getWindowWidth()-1){if(sideSpaceLeft<sideSpaceRight){heading.style.marginLeft=(sideSpaceRight-sideSpaceLeft)+'px';}
if(sideSpaceRight<sideSpaceLeft){heading.style.marginRight=(sideSpaceLeft-sideSpaceRight)+'px';}}},_getWindowWidth:function(){return window.innerWidth;}};module.exports=GaiaHeaderFontFit;});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('./lib/font-fit',this));},{}]},{},[3])(3)});;'use strict';navigator.mozL10n.once(function showPanel(){var settings=window.navigator.mozSettings;var bluetooth=window.navigator.mozBluetooth;var defaultAdapter=null;var activity=null;var sendingFilesSchedule={};var _debug=false;navigator.mozSetMessageHandler('activity',function handler(activityRequest){activity=activityRequest;if(settings&&bluetooth&&(activity.source.name=='share')&&(activity.source.data.blobs&&activity.source.data.blobs.length>0)){observeBluetoothEnabled();isBluetoothEnabled();}else{var msg='Cannot transfer without blobs data!';cannotTransfer(msg);}});var dialogConfirmBluetooth=document.getElementById('enable-bluetooth-view');var bluetoothCancelButton=document.getElementById('enable-bluetooth-button-cancel');var bluetoothTurnOnButton=document.getElementById('enable-bluetooth-button-turn-on');var dialogAlertView=document.getElementById('alert-view');var alertOkButton=document.getElementById('alert-button-ok');function debug(msg){if(!_debug){return;}
console.log('[Bluetooth APP Send File]: '+msg);}
function observeBluetoothEnabled(){settings.addObserver('bluetooth.enabled',function(event){var enabled=event.settingValue;var msg='bluetooth.enabled = '+enabled;debug(msg);if(!enabled){msg='clear deviceList and defaultAdapter';debug(msg);gDeviceList.update(false);defaultAdapter=null;if(dialogConfirmBluetooth.hidden){msg='require user to confirm for turn Bluetooth on';debug(msg);confirmTurnBluetoothOn();}}});}
function isBluetoothEnabled(){var req=settings.createLock().get('bluetooth.enabled');req.onsuccess=function bt_EnabledSuccess(){if(req.result['bluetooth.enabled']){initialDefaultAdapter();}else{confirmTurnBluetoothOn();}};req.onerror=function bt_EnabledOnerror(){var msg='Can not get bluetooth.enabled from setting!';cannotTransfer(msg);};}
function confirmTurnBluetoothOn(){dialogConfirmBluetooth.hidden=false;bluetoothCancelButton.addEventListener('click',cancelTransfer);bluetoothTurnOnButton.addEventListener('click',turnOnBluetooth);}
function turnOnBluetooth(evt){if(evt){evt.preventDefault();}
dialogConfirmBluetooth.hidden=true;bluetooth.onadapteradded=function bt_adapterAdded(){initialDefaultAdapter();};settings.createLock().set({'bluetooth.enabled':true});}
function initialDefaultAdapter(callback){if(!bluetooth.enabled){return;}
var req=bluetooth.getDefaultAdapter();req.onsuccess=function bt_getAdapterSuccess(){defaultAdapter=req.result;if(defaultAdapter==null){settings.createLock().set({'bluetooth.enabled':false});var msg='Get null bluetooth adapter!';cannotTransfer(msg);return;}
if(callback){callback();}
defaultAdapter.ondevicefound=gDeviceList.onDeviceFound;gDeviceList.initWithAdapter(defaultAdapter,transferToDevice,cancelTransfer);gDeviceList.update(true);};req.onerror=function bt_getAdapterFailed(){settings.createLock().set({'bluetooth.enabled':false});var msg='Can not get bluetooth adapter!';cannotTransfer(msg);};}
function cancelTransfer(evt){if(evt){evt.preventDefault();}
dialogConfirmBluetooth.hidden=true;gDeviceList.uninit();activity.postError('cancelled');endTransfer();}
function cannotTransfer(msg){debug(msg);dialogAlertView.hidden=false;alertOkButton.addEventListener('click',closeAlert);}
function closeAlert(){dialogAlertView.hidden=true;alertOkButton.removeEventListener('click',closeAlert);activity.postError('cancelled');endTransfer();}
function endTransfer(){bluetoothCancelButton.removeEventListener('click',cancelTransfer);bluetoothTurnOnButton.removeEventListener('click',turnOnBluetooth);activity=null;}
function transferToDevice(device){var targetDevice=device;sendingFilesSchedule={numberOfFiles:activity.source.data.blobs.length,numSuccessful:0,numUnsuccessful:0};postMessageToSystemApp(sendingFilesSchedule);var blobs=activity.source.data.blobs;var numberOfTasks=blobs.length;blobs.forEach(function(blob,index){if(blob.name){defaultAdapter.sendFile(targetDevice.address,blob);var msg='blob is sending...';debug(msg);if(--numberOfTasks===0){transferred();}}else{var filepath=activity.source.data.filepaths[index];var storage=navigator.getDeviceStorage('sdcard');var getRequest=storage.get(filepath);getRequest.onsuccess=function(){defaultAdapter.sendFile(targetDevice.address,getRequest.result);var msg='getFile succeed & file is sending...';debug(msg);if(--numberOfTasks===0){transferred();}};getRequest.onerror=function(){defaultAdapter.sendFile(targetDevice.address,blob);var msg='getFile failed so that blob is sending without filename '+
getRequest.error&&getRequest.error.name;debug(msg);if(--numberOfTasks===0){transferred();}};}});}
function transferred(){activity.postResult('transferred');endTransfer();}
function postMessageToSystemApp(sendingFilesSchedule){navigator.mozApps.getSelf().onsuccess=function gotSelf(evt){var app=evt.target.result;if(!app.connect){sendingFilesSchedule={};return;}
app.connect('bluetoothTransfercomms').then(function(ports){ports.forEach(function(port){port.postMessage(sendingFilesSchedule);var msg='post message to system app...';debug(msg);});sendingFilesSchedule={};});};}});;'use strict';var gDeviceList=null;navigator.mozL10n.once(function deviceList(){var _=navigator.mozL10n.get;var settings=window.navigator.mozSettings;var bluetooth=window.navigator.mozBluetooth;var defaultAdapter=null;var _debug=false;if(!settings||!bluetooth){return;}
function debug(msg){if(!_debug){return;}
console.log('[Bluetooth APP Device List]: '+msg);}
gDeviceList=(function devicesList(){var deviceList=document.getElementById('devices-list-view');var bluetoothSearch=document.getElementById('bluetooth-search');var searchAgainBtn=document.getElementById('search-device');var searchingItem=document.getElementById('bluetooth-searching');var header=document.getElementById('devices-list-header');var pairingAddress=null;var connectingAddress=null;var connectedAddress=null;var discoverTimeoutTime=60000;var discoverTimeout=null;var onDeviceSelectedHandler=null;var onExitBtnClickedHandler=null;var isSendingFile=false;var pairList={title:document.getElementById('bluetooth-paired-title'),list:document.getElementById('bluetooth-paired-devices'),index:[],clear:function emptyList(){while(this.list.hasChildNodes()){this.list.removeChild(this.list.lastChild);}
this.index=[];},show:function showArea(isShown){if(!isShown){this.clear();}
this.title.hidden=!isShown;this.list.hidden=!isShown;}};var openList={title:document.getElementById('bluetooth-found-title'),list:document.getElementById('bluetooth-devices'),index:[],clear:function emptyList(){while(this.list.hasChildNodes()){this.list.removeChild(this.list.lastChild);}
this.index=[];},show:function showArea(isShown){if(!isShown){this.clear();}
this.title.hidden=!isShown;this.list.hidden=!isShown;}};searchAgainBtn.onclick=function searchAgainClicked(){if(isSendingFile||pairingAddress){return;}
updateDeviceList(true);openList.clear();startDiscovery();};function newListItem(device,descL10nId){var deviceName=document.createElement('span');var aName=(device.name==='')?_('unnamed-device'):device.name;var aL10nId=(device.name==='')?'unnamed-device':'';deviceName.textContent=aName;deviceName.dataset.l10nId=aL10nId;var deviceDesc=document.createElement('small');deviceDesc.textContent=(descL10nId==='')?'':_(descL10nId);deviceDesc.dataset.l10nId=descL10nId;var pairingProgress=document.createElement('progress');pairingProgress.classList.add('overlapping-icon');pairingProgress.classList.add('hidden');var a=document.createElement('a');a.appendChild(deviceName);a.appendChild(deviceDesc);var li=document.createElement('li');li.classList.add('bluetooth-device');li.classList.add('bluetooth-type-'+device.icon);li.appendChild(a);li.appendChild(pairingProgress);return li;}
function updateDeviceList(show){bluetoothSearch.hidden=!show;if(show){openList.show(true);searchingItem.hidden=false;}else{openList.show(false);pairList.show(false);searchingItem.hidden=true;pairingAddress=null;connectingAddress=null;connectedAddress=null;clearTimeout(discoverTimeout);discoverTimeout=null;}}
function initial(adapter,deviceSelectedCallback,exitBtnClickedCallback){deviceList.hidden=false;header.addEventListener('action',cancelActivity);defaultAdapter=adapter;defaultAdapter.onpairedstatuschanged=function bt_getPairedMessage(evt){showDevicePaired(evt.status,'Authentication Failed');};defaultAdapter.ondiscoverystatechanged=function bt_discoveryStateChanged(evt){if(!evt.discovering){searchAgainBtn.disabled=false;searchingItem.hidden=true;clearTimeout(discoverTimeout);discoverTimeout=null;}else{searchAgainBtn.disabled=true;searchingItem.hidden=false;}};onDeviceSelectedHandler=deviceSelectedCallback;onExitBtnClickedHandler=exitBtnClickedCallback;getPairedDevice();startDiscovery();}
function uninit(){deviceList.hidden=true;defaultAdapter=null;header.removeEventListener('action',cancelActivity);}
function getPairedDevice(){if(!bluetooth.enabled||!defaultAdapter){return;}
var req=defaultAdapter.getPairedDevices();req.onsuccess=function bt_getPairedSuccess(){var paired=req.result.slice();var length=paired.length;if(length===0){pairList.show(false);return;}
pairList.clear();paired.sort(function(a,b){return a.name>b.name;});function deviceStatus(){return(function(device){var stateL10nId=(device.address===connectedAddress)?'device-status-connected':'';var aItem=newListItem(device,stateL10nId);aItem.onclick=function(){if(isSendingFile||pairingAddress){return;}
stopDiscovery();var small=aItem.querySelector('small');small.textContent=_('device-status-connecting');small.dataset.l10nId='device-status-connecting';readyToSendFile(device);};pairList.list.appendChild(aItem);pairList.index[device.address]=[device,aItem];});}
for(var i=0;i<length;i++){deviceStatus()(paired[i]);}
pairList.show(true);};}
function onDeviceFound(evt){var device=evt.device;var existingDevice=openList.index[device.address]||pairList.index[device.address];if(existingDevice){var existingItem=existingDevice[1];if(device.name&&existingItem){var deviceName=existingItem.querySelector('a > span');if(deviceName){deviceName.dataset.l10nId='';deviceName.textContent=device.name;}}
return;}
var aItem=newListItem(device,'device-status-tap-connect');aItem.onclick=function(){stopDiscovery();if(isSendingFile||pairingAddress){return;}
var small=aItem.querySelector('small');small.textContent=_('device-status-pairing');small.dataset.l10nId='device-status-pairing';aItem.classList.add('icon-hidden');var progress=aItem.querySelector('progress');progress.classList.remove('hidden');var req=defaultAdapter.pair(device.address);pairingAddress=device.address;var msg='pairing with address = '+pairingAddress;debug(msg);req.onerror=function bt_pairError(error){showDevicePaired(false,req.error.name);};};openList.list.appendChild(aItem);openList.index[device.address]=[device,aItem];}
function showDevicePaired(paired,errorMessage){if(!pairingAddress){getPairedDevice();return;}
var workingAddress=pairingAddress;pairingAddress=null;if(paired){if(openList.index[workingAddress]){var device=openList.index[workingAddress][0];var item=openList.index[workingAddress][1];openList.list.removeChild(item);delete openList.index[workingAddress];connectingAddress=workingAddress;readyToSendFile(device);}}else{var msg=_('error-pair-title');if(errorMessage==='Repeated Attempts'){msg=msg+'\n'+_('error-pair-toofast');}else if(errorMessage==='Authentication Failed'){msg=msg+'\n'+_('error-pair-pincode');}
debug(msg);window.alert(msg);if(openList.index[workingAddress]){var small=openList.index[workingAddress][1].querySelector('small');small.textContent=_('device-status-tap-connect');small.dataset.l10nId='device-status-tap-connect';var li=openList.index[workingAddress][1];li.classList.remove('icon-hidden');var progress=openList.index[workingAddress][1].querySelector('progress');progress.classList.add('hidden');}}
getPairedDevice();}
function startDiscovery(){if(!bluetooth.enabled||!defaultAdapter||discoverTimeout){return;}
var req=defaultAdapter.startDiscovery();req.onsuccess=function bt_discoveryStart(){if(!discoverTimeout){discoverTimeout=setTimeout(stopDiscovery,discoverTimeoutTime);}};req.onerror=function bt_discoveryFailed(){console.error('Can not discover nearby device');};}
function stopDiscovery(){if(!bluetooth.enabled||!defaultAdapter||!discoverTimeout){return;}
var req=defaultAdapter.stopDiscovery();req.onerror=function bt_discoveryStopFailed(){console.error('Failed to stop discovery of nearby devices');};clearTimeout(discoverTimeout);discoverTimeout=null;}
function readyToSendFile(targetDevice){isSendingFile=true;if(onDeviceSelectedHandler){onDeviceSelectedHandler(targetDevice);}}
function cancelActivity(){if(onExitBtnClickedHandler){onExitBtnClickedHandler();}}
return{update:updateDeviceList,initWithAdapter:initial,uninit:uninit,startDiscovery:startDiscovery,onDeviceFound:onDeviceFound};})();});