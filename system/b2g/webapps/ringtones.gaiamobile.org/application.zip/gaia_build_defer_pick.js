;(function(exports){'use strict';var priv=new WeakMap();var rmatcher=/\$\{([^}]+)\}/g;var rentity=/[&<>"']/g;var rentities={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&apos;'};function extract(node){var nodeId;if(typeof node==='string'){nodeId=node;node=document.getElementById(node);}else if(node){nodeId=node.id;}
if(!node){console.error('Can not find the node passed to Template',nodeId);return'';}
if(!node.firstChild){console.error('Node passed to Template should have a comment node',nodeId);return'';}
node=node.firstChild;do{if(node.nodeType===Node.COMMENT_NODE){return(node.nodeValue||'').trim();}}while((node=node.nextSibling));console.error('Nodes passed to Template should have a comment node',nodeId);return'';}
function Template(idOrNode){if(!(this instanceof Template)){return new Template(idOrNode);}
priv.set(this,{idOrNode:idOrNode});}
Template.prototype.extract=function(){var members=priv.get(this);if(!members.tmpl){members.tmpl=extract(members.idOrNode);delete members.idOrNode;}
return members.tmpl;};Template.prototype.toString=function(){return this.extract().slice();};Template.prototype.interpolate=function(data,options){options=options||{};options.safe=options.safe||[];return this.extract().replace(rmatcher,function(match,property){property=property.trim();return options.safe.indexOf(property)===-1?Template.escape(data[property]):data[property];});};Template.prototype.prepare=function(data,options){var self=this;return{toString:function t_toString(){return self.interpolate(data,options);},toDocumentFragment:function t_toDocumentFragment(){var template=document.createElement('template');template.innerHTML=this.toString();return template.content.cloneNode(true);}};};Template.escape=function escape(str){if(typeof str!=='string'){return'';}
return str.replace(rentity,function(s){return rentities[s];});};exports.Template=Template;}(this));;'use strict';function enumerateAll(storages,dir,options){var storageIndex=0;var ds_cursor=null;var cursor={continue:function cursor_continue(){ds_cursor.continue();}};function onsuccess(e){cursor.result=e.target.result;if(!cursor.result){storageIndex++;if(storageIndex<storages.length){enumerateNextStorage();return;}}
if(cursor.onsuccess){try{cursor.onsuccess(e);}catch(err){console.warn('enumerateAll onsuccess threw',err);}}}
function onerror(e){cursor.error=e.target.error;if(cursor.error.name==='NotFoundError'&&storageIndex!==storages.length-1){storageIndex++;enumerateNextStorage();return;}
if(cursor.onerror){try{cursor.onerror(e);}catch(err){console.warn('enumerateAll onerror threw',err);}}}
function enumerateNextStorage(){ds_cursor=storages[storageIndex].enumerate(dir,options||{});ds_cursor.onsuccess=onsuccess;ds_cursor.onerror=onerror;}
enumerateNextStorage();return cursor;};window.COMPONENTS_BASE_URL='/shared/elements/';;!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var f;"undefined"!=typeof window?f=window:"undefined"!=typeof global?f=global:"undefined"!=typeof self&&(f=self),f.GaiaHeader=e()}}(function(){var define,module,exports;return(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){;(function(define){define(function(require,exports,module){'use strict';var textContent=Object.getOwnPropertyDescriptor(Node.prototype,'textContent');var removeAttribute=HTMLElement.prototype.removeAttribute;var setAttribute=HTMLElement.prototype.setAttribute;var noop=function(){};var hasShadowCSS=(function(){var div=document.createElement('div');try{div.querySelector(':host');return true;}
catch(e){return false;}})();module.exports.register=function(name,props){injectGlobalCss(props.globalCss);delete props.globalCSS;var proto=Object.assign(Object.create(base),props);var output=extractLightDomCSS(proto.template,name);var _attrs=Object.assign(props.attrs||{},attrs);proto.template=output.template;proto.lightCss=output.lightCss;Object.defineProperties(proto,_attrs);var El=document.registerElement(name,{prototype:proto});return El;};var base=Object.assign(Object.create(HTMLElement.prototype),{attributeChanged:noop,attached:noop,detached:noop,created:noop,template:'',createdCallback:function(){this.injectLightCss(this);this.created();},attributeChangedCallback:function(name,from,to){if(this.attrs&&this.attrs[name]){this[name]=to;}
this.attributeChanged(name,from,to);},attachedCallback:function(){this.attached();},detachedCallback:function(){this.detached();},setAttr:function(name,value){var internal=this.shadowRoot.firstElementChild;setAttribute.call(internal,name,value);setAttribute.call(this,name,value);},removeAttr:function(){var internal=this.shadowRoot.firstElementChild;removeAttribute.call(internal,name,value);removeAttribute.call(this,name,value);},injectLightCss:function(el){if(hasShadowCSS){return;}
this.lightStyle=document.createElement('style');this.lightStyle.setAttribute('scoped','');this.lightStyle.innerHTML=el.lightCss;el.appendChild(this.lightStyle);}});var attrs={textContent:{set:function(value){var node=firstChildTextNode(this);if(node){node.nodeValue=value;}},get:function(){var node=firstChildTextNode(this);return node&&node.nodeValue;}}};function firstChildTextNode(el){for(var i=0;i<el.childNodes.length;i++){var node=el.childNodes[i];if(node&&node.nodeType===3){return node;}}}
function extractLightDomCSS(template,name){var regex=/(?::host|::content)[^{]*\{[^}]*\}/g;var lightCss='';if(!hasShadowCSS){template=template.replace(regex,function(match){lightCss+=match.replace(/::content|:host/g,name);return'';});}
return{template:template,lightCss:lightCss};}
function injectGlobalCss(css){if(!css)return;var style=document.createElement('style');style.innerHTML=css;document.head.appendChild(style);}});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-component',this));},{}],2:[function(require,module,exports){(function(define){define(function(require,exports,module){var base=window.GAIA_ICONS_BASE_URL||window.COMPONENTS_BASE_URL||'bower_components/';if(!isLoaded()){load(base+'gaia-icons/gaia-icons.css');}
function load(href){var link=document.createElement('link');link.rel='stylesheet';link.type='text/css';link.href=href;document.head.appendChild(link);exports.loaded=true;}
function isLoaded(){return exports.loaded||document.querySelector('link[href*=gaia-icons]')||document.documentElement.classList.contains('gaia-icons-loaded');}});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-icons',this));},{}],3:[function(require,module,exports){;(function(define){'use strict';define(function(require,exports,module){var Component=require('gaia-component');var fontFit=require('./lib/font-fit');require('gaia-icons');var actionTypes={menu:1,back:1,close:1};module.exports=Component.register('gaia-header',{created:function(){this.createShadowRoot().innerHTML=this.template;this.els={actionButton:this.shadowRoot.querySelector('.action-button'),headings:this.querySelectorAll('h1,h2,h3,h4'),inner:this.shadowRoot.querySelector('.inner')};this.els.actionButton.addEventListener('click',e=>this.onActionButtonClick(e));this.configureActionButton();this.runFontFit();},attached:function(){this.rerunFontFit();},attributeChanged:function(attr){if(attr==='action'){this.configureActionButton();this.rerunFontFit();}},runFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);fontFit.observeHeadingChanges(this.els.headings[i]);}},rerunFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);}},triggerAction:function(){if(this.isSupportedAction(this.getAttribute('action'))){this.els.actionButton.click();}},configureActionButton:function(){var old=this.els.actionButton.getAttribute('icon');var type=this.getAttribute('action');var supported=this.isSupportedAction(type);this.els.actionButton.classList.remove('icon-'+old);this.els.actionButton.setAttribute('icon',type);this.els.inner.classList.toggle('supported-action',supported);if(supported){this.els.actionButton.classList.add('icon-'+type);}},isSupportedAction:function(action){return action&&actionTypes[action];},onActionButtonClick:function(e){var config={detail:{type:this.getAttribute('action')}};var actionEvent=new CustomEvent('action',config);setTimeout(this.dispatchEvent.bind(this,actionEvent));},template:`
  <style>

  :host {
    display: block;

    --gaia-header-button-color:
      var(--header-button-color,
      var(--header-color,
      var(--link-color,
      inherit)));
  }

  /**
   * [hidden]
   */

  :host[hidden] {
    display: none;
  }

  /** Reset
   ---------------------------------------------------------*/

  ::-moz-focus-inner { border: 0; }

  /** Inner
   ---------------------------------------------------------*/

  .inner {
    display: flex;
    min-height: 50px;
    direction: ltr;

    background:
      var(--header-background,
      var(--background,
      #fff));
  }

  /** Action Button
   ---------------------------------------------------------*/

  /**
   * 1. Hidden by default
   */

  .action-button {
    display: none; /* 1 */
    position: relative;
    width: 50px;
    font-size: 30px;
    margin: 0;
    padding: 0;
    border: 0;
    align-items: center;
    background: none;
    cursor: pointer;
    transition: opacity 200ms 280ms;

    color:
      var(--header-action-button-color,
      var(--header-icon-color,
      var(--gaia-header-button-color)));
  }

  /**
   * .action-supported
   *
   * 1. For icon vertical-alignment
   */

  .supported-action .action-button {
    display: flex; /* 1 */
  }

  /**
   * :active
   */

  .action-button:active {
    transition: none;
    opacity: 0.2;
  }

  /** Action Button Icon
   ---------------------------------------------------------*/

  /**
   * 1. To enable vertical alignment.
   */

  .action-button:before {
    display: block;
  }

  /** Action Button Text
   ---------------------------------------------------------*/

  /**
   * To provide custom localized content for
   * the action-button, we allow the user
   * to provide an element with the class
   * .l10n-action. This node is then
   * pulled inside the real action-button.
   *
   * Example:
   *
   *   <gaia-header action="back">
   *     <span class="l10n-action" aria-label="Back">Localized text</span>
   *     <h1>title</h1>
   *   </gaia-header>
   */

  ::content .l10n-action {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    font-size: 0;
  }

  /** Title
   ---------------------------------------------------------*/

  /**
   * 1. Vertically center text. We can't use flexbox
   *    here as it breaks text-overflow ellipsis
   *    without an inner div.
   */

  ::content h1 {
    flex: 1;
    margin: 0;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    text-align: center;
    line-height: 50px; /* 1 */
    font-weight: 300;
    font-style: italic;
    font-size: 24px;
    -moz-user-select: none;

    color:
      var(--header-title-color,
      var(--header-color,
      var(--title-color,
      var(--text-color,
      inherit))));
  }

  /**
   * .flush-left
   *
   * When the fitted text is flush with the
   * edge of the left edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-left {
    padding-left: 10px;
  }

  /**
   * .flush-right
   *
   * When the fitted text is flush with the
   * edge of the right edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-right {
    padding-right: 10px; /* 1 */
  }

  /** Buttons
   ---------------------------------------------------------*/

  ::content a,
  ::content button {
    box-sizing: border-box;
    display: flex;
    border: none;
    width: auto;
    height: auto;
    margin: 0;
    padding: 0 10px;
    font-size: 14px;
    line-height: 1;
    min-width: 50px;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    text-align: center;
    background: none;
    border-radius: 0;
    font-style: italic;
    cursor: pointer;

    transition: opacity 200ms 280ms;

    color:
      var(--gaia-header-button-color);
  }

  /**
   * :active
   */

  ::content a:active,
  ::content button:active {
    transition: none;
    opacity: 0.2;
  }

  /**
   * [hidden]
   */

  ::content a[hidden],
  ::content button[hidden] {
    display: none;
  }

  /**
   * [disabled]
   */

  ::content a[disabled],
  ::content button[disabled] {
    pointer-events: none;
    color: var(--header-disabled-button-color);
  }

  /** Icon Buttons
   ---------------------------------------------------------*/

  /**
   * Icons are a different color to text
   */

  ::content .icon,
  ::content [data-icon] {
    color:
      var(--header-icon-color,
      var(--gaia-header-button-color));
  }

  /** Icons
   ---------------------------------------------------------*/

  [class^="icon-"]:before,
  [class*="icon-"]:before {
    font-family: 'gaia-icons';
    font-style: normal;
    text-rendering: optimizeLegibility;
    font-weight: 500;
  }

  .icon-menu:before { content: 'menu'; }
  .icon-close:before { content: 'close'; }
  .icon-back:before { content: 'back'; }

  </style>

  <div class="inner">
    <button class="action-button">
      <content select=".l10n-action"></content>
    </button>
    <content select="h1,h2,h3,h4,a,button"></content>
  </div>`});});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-header',this));},{"./lib/font-fit":4,"gaia-component":1,"gaia-icons":2}],4:[function(require,module,exports){;(function(define){'use strict';define(function(require,exports,module){var GaiaHeaderFontFit={_HEADER_SIZES:[16,17,18,19,20,21,22,23,24],observeHeadingChanges:function(heading){var observer=this._getTextChangeObserver();observer.observe(heading,{childList:true});},reformatHeading:function(heading){if(!heading||heading.textContent.trim()===''){return;}
this._resetCentering(heading);var style=this._getStyleProperties(heading);if(!style){return;}
style.textWidth=this._autoResizeElement(heading,style);this._centerTextToScreen(heading,style);},resetCache:function(){this._cachedContexts={};},_cachedContexts:{},_getCachedContext:function(fontSize,fontFamily,fontStyle){fontStyle=fontStyle||'italic';var cache=this._cachedContexts;var ctx=cache[fontSize]&&cache[fontSize][fontFamily]?cache[fontSize][fontFamily][fontStyle]:null;if(!ctx){var canvas=document.createElement('canvas');canvas.setAttribute('moz-opaque','true');canvas.setAttribute('width','1');canvas.setAttribute('height','1');ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.font=fontStyle+' '+fontSize+'px '+fontFamily;if(!cache[fontSize]){cache[fontSize]={};}
if(!cache[fontSize][fontFamily]){cache[fontSize][fontFamily]={};}
cache[fontSize][fontFamily][fontStyle]=ctx;}
return ctx;},_textChangeObserver:null,_handleTextChanges:function(mutations){var targets=new Set();for(var i=0;i<mutations.length;i++){targets.add(mutations[i].target);}
for(var target of targets){this.reformatHeading(target);}},_getTextChangeObserver:function(){if(!this._textChangeObserver){this._textChangeObserver=new MutationObserver(this._handleTextChanges.bind(this));}
return this._textChangeObserver;},_getFontWidth:function(string,fontSize,fontFamily,fontStyle){var ctx=this._getCachedContext(fontSize,fontFamily,fontStyle);return ctx.measureText(string).width;},_getMaxFontSizeInfo:function(string,allowedSizes,fontFamily,maxWidth){var fontSize;var resultWidth;var i=allowedSizes.length-1;do{fontSize=allowedSizes[i];resultWidth=this._getFontWidth(string,fontSize,fontFamily);i--;}while(resultWidth>maxWidth&&i>=0);return{fontSize:fontSize,overflow:resultWidth>maxWidth,textWidth:resultWidth};},_getContentWidth:function(style){var width=parseInt(style.width,10);if(style.boxSizing==='border-box'){width-=(parseInt(style.paddingRight,10)+
parseInt(style.paddingLeft,10));}
return width;},_getStyleProperties:function(heading){var style=getComputedStyle(heading)||{};var contentWidth=this._getContentWidth(style);if(isNaN(contentWidth)){contentWidth=0;}
return{fontFamily:style.fontFamily||'unknown',contentWidth:contentWidth,paddingRight:parseInt(style.paddingRight,10),paddingLeft:parseInt(style.paddingLeft,10),offsetLeft:heading.offsetLeft};},_autoResizeElement:function(heading,styleOptions){var contentWidth=styleOptions.contentWidth||this._getContentWidth(heading);var fontFamily=styleOptions.fontFamily||getComputedStyle(heading).fontFamily;var text=heading.textContent.replace(/\s+/g,' ').trim();var info=this._getMaxFontSizeInfo(text,this._HEADER_SIZES,fontFamily,contentWidth);heading.style.fontSize=info.fontSize+'px';return info.textWidth;},_resetCentering:function(heading){heading.style.marginLeft=heading.style.marginRight='0';},_centerTextToScreen:function(heading,styleOptions){var minHeaderWidth=styleOptions.textWidth+styleOptions.paddingRight+
styleOptions.paddingLeft;var tightText=styleOptions.textWidth>(styleOptions.contentWidth-30);var sideSpaceLeft=styleOptions.offsetLeft;var sideSpaceRight=this._getWindowWidth()-sideSpaceLeft-
styleOptions.contentWidth-styleOptions.paddingRight-
styleOptions.paddingLeft;heading.classList.toggle('flush-left',tightText&&!sideSpaceLeft);heading.classList.toggle('flush-right',tightText&&!sideSpaceRight);if(sideSpaceLeft===sideSpaceRight){return;}
var margin=Math.max(sideSpaceLeft,sideSpaceRight);if(minHeaderWidth+(margin*2)<this._getWindowWidth()-1){if(sideSpaceLeft<sideSpaceRight){heading.style.marginLeft=(sideSpaceRight-sideSpaceLeft)+'px';}
if(sideSpaceRight<sideSpaceLeft){heading.style.marginRight=(sideSpaceLeft-sideSpaceRight)+'px';}}},_getWindowWidth:function(){return window.innerWidth;}};module.exports=GaiaHeaderFontFit;});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('./lib/font-fit',this));},{}]},{},[3])(3)});;(function(exports){'use strict';exports.ComponentUtils={style:function(baseUrl){var style=document.createElement('style');var url=baseUrl+'style.css';var self=this;style.setAttribute('scoped','');style.innerHTML='@import url('+url+');';this.appendChild(style);this.style.visibility='hidden';style.addEventListener('load',function(){if(self.shadowRoot){self.shadowRoot.appendChild(style.cloneNode(true));}
self.style.visibility='';});}};}(window));;'use strict';window.GaiaSubheader=(function(win){var proto=Object.create(HTMLElement.prototype);var baseurl=window.GaiaSubheaderBaseurl||'/shared/elements/gaia_subheader/';proto.createdCallback=function(){ComponentUtils.style.call(this,baseurl);};return document.registerElement('gaia-subheader',{prototype:proto});})(window);;'use strict';function NullRingtone(){}
NullRingtone.prototype={get name(){return navigator.mozL10n.get(this.l10nID);},get filename(){return null;},get l10nID(){return'ringtone-none';},get id(){return'none:none';},get type(){return null;},get url(){return null;},get shareable(){return false;},get deletable(){return false;},getBlob:function(){return new Promise(function(resolve,reject){resolve(null);});}};;'use strict';window.builtInRingtones=(function(){var ID_PREFIX='builtin:';var BASE_URLS={'ringtone':'/shared/resources/media/ringtones/','alerttone':'/shared/resources/media/notifications/'};var mimeTypeMap={'.mp3':'audio/mp3','.mp4':'audio/mp4','.ogg':'audio/ogg','.opus':'audio/ogg'};function inferMimeType(filename){var dot=filename.lastIndexOf('.');if(dot===-1){console.warn('Couldn\'t infer mimetype for '+filename);return'application/octet-stream';}
var ext=filename.substr(dot);return mimeTypeMap[ext]||'application/octet-stream';}
function BuiltInRingtone(toneType,filename,toneDef){this._toneType=toneType;this._filename=filename;this._l10nID=toneDef.l10nID;}
BuiltInRingtone.prototype={get _rootName(){return this._filename.replace(/\.\w+$/,'');},get name(){return navigator.mozL10n.get(this.l10nID);},get filename(){return this._filename;},get l10nID(){return this._l10nID;},get id(){return ID_PREFIX+this._toneType+'/'+this._rootName;},get type(){return this._toneType;},get url(){return BASE_URLS[this._toneType]+this._filename;},get shareable(){return true;},get deletable(){return false;},getBlob:function(){var url=this.url;return new Promise(function(resolve,reject){var xhr=new XMLHttpRequest();xhr.open('GET',url);xhr.overrideMimeType(inferMimeType(url));xhr.responseType='blob';xhr.send();xhr.onload=function(){resolve(xhr.response);};xhr.onerror=function(){var err=new Error('Could not read sound file: '+url+' (status: '+xhr.status+')');console.error(err);reject(err);};});}};function idToToneType(id){var slash=id.indexOf('/');if(id.indexOf(ID_PREFIX)!==0||slash===-1){throw new Error('invalid id: '+id);}
return id.substring(ID_PREFIX.length,slash);}
function idMatchesFilename(id,toneType,filename){return id===ID_PREFIX+toneType+'/'+filename.replace(/\.\w+$/,'');}
var toneDefsCache={};function getSoundFilenames(toneType){if(!(toneType in BASE_URLS)){throw new Error('tone type not supported: '+toneType);}
return new Promise(function(resolve,reject){if(toneType in toneDefsCache){resolve(toneDefsCache[toneType]);return;}
var xhr=new XMLHttpRequest();xhr.open('GET',BASE_URLS[toneType]+'list.json');xhr.responseType='json';xhr.send(null);xhr.onload=function(){toneDefsCache[toneType]=xhr.response;resolve(xhr.response);};xhr.onerror=function(){var err=new Error('Could not read sounds list for '+toneType+' (status: '+xhr.status+')');console.error(err);reject(err);};});}
function list(toneType){return getSoundFilenames(toneType).then(function(toneDefs){var tones=[];for(var filename in toneDefs){tones.push(new BuiltInRingtone(toneType,filename,toneDefs[filename]));}
return tones;});}
function get(id){return new Promise(function(resolve,reject){var toneType=idToToneType(id);resolve(getSoundFilenames(toneType).then(function(toneDefs){for(var filename in toneDefs){if(idMatchesFilename(id,toneType,filename)){return new BuiltInRingtone(toneType,filename,toneDefs[filename]);}}
var err=new Error('No '+toneType+' found with id = '+id);console.error(err);throw err;}));});}
return{list:list,get:get,get toneTypes(){return Object.keys(BASE_URLS);}};})();;'use strict';window.customRingtones=(function(){var ID_PREFIX='custom:';function CustomRingtone(info,dbKey){this._name=info.name;if(info.uniqueNum!==0||info.isExplicitNum){this._name+=' ('+info.uniqueNum+')';}
this._subtitle=info.subtitle||null;this._id=ID_PREFIX+dbKey;this._blob=info.blob;}
CustomRingtone.prototype={get name(){return this._name;},get filename(){return this._blob.name;},get subtitle(){return this._subtitle;},get id(){return this._id;},get type(){return'ringtone';},get url(){return this._url||(this._url=URL.createObjectURL(this._blob));},get shareable(){return true;},get deletable(){return true;},remove:function(){return remove(this.id);},getBlob:function(){return Promise.resolve(this._blob);}};function idToDBKey(id){if(id.indexOf(ID_PREFIX)!==0){throw new Error('invalid id: '+id);}
return parseInt(id.substr(ID_PREFIX.length));}
var DBNAME='customTones';var DBVERSION=1;var STORENAME='ringtones';var db=null;function withStore(type,callback){if(db){callback(null,db.transaction(STORENAME,type).objectStore(STORENAME));}else{var openreq=indexedDB.open(DBNAME,DBVERSION);openreq.onerror=function(){console.error('customRingtones: can\'t open database:',openreq.error.name);callback(openreq.error);};openreq.onupgradeneeded=function(){var objStore=openreq.result.createObjectStore(STORENAME,{autoIncrement:true});objStore.createIndex('fullname',['name','subtitle','uniqueNum'],{unique:false});};openreq.onsuccess=function(){db=openreq.result;callback(null,db.transaction(STORENAME,type).objectStore(STORENAME));};}}
function uniqueify(info){return new Promise(function(resolve,reject){withStore('readonly',function(err,store){if(err){reject(err);return;}
var nextUniqueNum=info.uniqueNum||0;var index=store.index('fullname');var req=index.openCursor(IDBKeyRange.bound([info.name,info.subtitle,0],[info.name,info.subtitle,Infinity]));req.onsuccess=function(event){var cursor=event.target.result;if(!cursor||nextUniqueNum<cursor.value.uniqueNum){resolve(nextUniqueNum);return;}
nextUniqueNum=cursor.value.uniqueNum+1;cursor.continue();};req.onerror=function(){console.error('Error in customRingtones.uniqueify(): ',req.error.name);reject(req.error);};});});}
function add(info){var cleanedInfo={name:info.name||'',subtitle:info.subtitle||'',blob:info.blob,uniqueNum:0};var m=/^(.*) \((\d+)\)$/.exec(cleanedInfo.name);if(m){cleanedInfo.name=m[1];cleanedInfo.uniqueNum=m[2];cleanedInfo.isExplicitNum=true;}
return uniqueify(cleanedInfo).then(function(uniqueNum){return new Promise(function(resolve,reject){withStore('readwrite',function(err,store){if(err){reject(err);return;}
cleanedInfo.uniqueNum=uniqueNum;var req=store.add(cleanedInfo);req.onsuccess=function(event){resolve(new CustomRingtone(cleanedInfo,event.target.result));};req.onerror=function(){console.error('Error in customRingtones.add(): ',req.error.name);reject(req.error);};});});});}
function remove(id){return new Promise(function(resolve,reject){withStore('readwrite',function(err,store){if(err){reject(err);return;}
var req=store.delete(idToDBKey(id));req.onsuccess=function(event){resolve();};req.onerror=function(){console.error('Error in customRingtones.remove(): ',req.error.name);reject(req.error);};});});}
function clear(){return new Promise(function(resolve,reject){withStore('readwrite',function(err,store){if(err){reject(err);return;}
var req=store.clear();req.onsuccess=function(event){resolve();};req.onerror=function(){console.error('Error in customRingtones.clear(): ',req.error.name);reject(req.error);};});});}
function get(id){return new Promise(function(resolve,reject){withStore('readonly',function(err,store){if(err){reject(err);return;}
var key=idToDBKey(id);var req=store.get(key);req.onsuccess=function(event){var data=event.target.result;if(!data){resolve(null);}else{resolve(new CustomRingtone(data,key));}};req.onerror=function(){console.error('Error in customRingtones.get(): ',req.error.name);reject(req.error);};});});}
function list(toneType){return new Promise(function(resolve,reject){if(toneType==='alerttone'){resolve([]);return;}
withStore('readonly',function(err,store){if(err){reject(err);return;}
var req=store.openCursor();var results=[];req.onsuccess=function listOnSuccess(event){var cursor=event.target.result;if(cursor){var value=cursor.value;results.push(new CustomRingtone(value,cursor.key));cursor.continue();}else{resolve(results);}};req.onerror=function listOnError(){console.error('Error in customRingtones.list(): ',req.error.name);reject(req.error);};});});}
return{add:add,remove:remove,clear:clear,get:get,list:list};})();;'use strict';window.sdCardRingtones=(function(){var ID_PREFIX='sdcard:';var BASE_DIRS={'ringtone':'Ringtones','alerttone':'Notifications'};function pathToType(path){var folder=new RegExp('^(/[^/]*/)?([^/]*)/').exec(path)[2];for(var type in BASE_DIRS){if(BASE_DIRS[type]===folder){return type;}}
throw new Error('unexpected SD card folder: '+folder);}
function SDCardRingtone(file){var leafname=file.name.substr(file.name.lastIndexOf('/')+1);this._name=leafname.replace(/\.\w+$/,'');this._blob=file;this._type=pathToType(this._blob.name);}
SDCardRingtone.prototype={get name(){return this._name;},get filename(){return this._blob.name;},get subtitle(){return navigator.mozL10n.get('sd-card-subtitle');},get id(){return ID_PREFIX+this._blob.name;},get type(){return this._type;},get url(){return this._url||(this._url=URL.createObjectURL(this._blob));},get shareable(){return true;},get deletable(){return true;},remove:function(){return remove(this.id);},getBlob:function(){return Promise.resolve(this._blob);}};function idToFilename(id){return id.substr(ID_PREFIX.length);}
var defaultStorage=navigator.getDeviceStorage('music');function remove(id){return new Promise(function(resolve,reject){var request=defaultStorage.delete(idToFilename(id));request.onsuccess=function(){resolve();};request.onerror=function(){console.error('Error in sdCardRingtones.remove(): ',this.error);reject(this.error);};});}
function get(id){return new Promise(function(resolve,reject){var request=defaultStorage.get(idToFilename(id));request.onsuccess=function(){resolve(new SDCardRingtone(this.result));};request.onerror=function(){console.error('Error in sdCardRingtones.get(): ',this.error);reject(this.error);};});}
function list(toneType){if(!(toneType in BASE_DIRS)){throw new Error('tone type not supported: '+toneType);}
return new Promise(function(resolve,reject){var results=[];var sdcards=navigator.getDeviceStorages('music');var cursor=enumerateAll(sdcards,BASE_DIRS[toneType]);cursor.onsuccess=function(){var file=this.result;if(file){if(file.name[0]!=='.'&&file.name.indexOf('/.')===-1){results.push(new SDCardRingtone(file));}
this.continue();}else{resolve(results);}};cursor.onerror=function(){if(this.error.name==='NotFoundError'||this.error.name==='TypeMismatchError'){resolve([]);}else{console.error('Error in sdCardRingtones.list(): ',this.error);reject(this.error);}};});}
return{remove:remove,get:get,list:list};})();;'use strict';function TonePlayer(){this._currentTone=null;this._isValid=true;this._player=new Audio();this._player.addEventListener('loadedmetadata',function(){if(this._player.src){this._isValid=true;this._player.dispatchEvent(new CustomEvent('validated',{detail:this._isValid}));}}.bind(this));this._player.addEventListener('error',function(){if(this._player.src){this._isValid=false;this._player.dispatchEvent(new CustomEvent('validated',{detail:this._isValid}));}}.bind(this));this._player.addEventListener('ended',function(){this._firePlayingCallback(false);}.bind(this));window.addEventListener('visibilitychange',function(){if(document.hidden){this.stop();this._setExclusiveMode(false);}}.bind(this));}
TonePlayer.prototype={setTone:function(tone,callback){if(tone!==this._currentTone){this._firePlayingCallback(false);this._currentTone=tone;this._playingCallback=callback;if(tone&&tone.url){this._isValid=undefined;this._player.src=tone.url;this._player.play();this._firePlayingCallback(true);this._setExclusiveMode(true);}else{this._isValid=true;this._player.removeAttribute('src');this._player.load();}}else{if(!this._isValid){return;}
if(this._player.paused||this._player.ended){this._player.currentTime=0;this._player.play();this._firePlayingCallback(true);this._setExclusiveMode(true);}else{this._player.pause();this._firePlayingCallback(false);}}},stop:function(){this._player.pause();this._firePlayingCallback(false);},get currentTone(){return this._currentTone;},isValid:function(callback){if(this._isValid!==undefined){callback(this._isValid);return;}
this._player.addEventListener('validated',function validated(event){this.removeEventListener('validated',validated);callback(event.detail);});},_firePlayingCallback:function(playing){if(this._playingCallback){this._playingCallback(playing);}},_setExclusiveMode:function(exclusive){if(exclusive){if(!this._source){this._context=new AudioContext('ringer');this._source=this._context.createMediaElementSource(this._player);this._source.connect(this._context.destination);}}else{if(this._source){this._source.disconnect();this._context=null;this._source=null;}}}};;'use strict';var ToneList=(function(){var listTemplate=new Template('sound-list-template');var itemTemplate=new Template('sound-item-template');var NONE_ID='none:none';function toneCompare(a,b){if(a.id===NONE_ID&&b.id===NONE_ID){return 0;}else if(a.id===NONE_ID){return-1;}else if(b.id===NONE_ID){return 1;}
var aName=a.name.toLocaleLowerCase();var bName=b.name.toLocaleLowerCase();var cmp=aName.localeCompare(bName);if(cmp){return cmp;}
var aSubtitle=(a.subtitle||'').toLocaleLowerCase();var bSubtitle=(b.subtitle||'').toLocaleLowerCase();return aSubtitle.localeCompare(bSubtitle);}
function domify(htmlText){var dummyDiv=document.createElement('div');dummyDiv.innerHTML=htmlText;var element=dummyDiv.firstElementChild;return element;}
function ToneList(titleID,parent){this.element=domify(listTemplate.interpolate({l10nID:titleID}));if(parent){parent.appendChild(this.element);}
this._ul=this.element.querySelector('ul');this._toneMap={};}
ToneList.prototype={makeItem:function(tone){var templateArgs={};if(tone.l10nID){templateArgs.l10nID=tone.l10nID;}else{templateArgs.name=tone.name;}
var item=domify(itemTemplate.interpolate(templateArgs));item.dataset.id=tone.id;if(tone.subtitle){var subtitle=document.createElement('p');subtitle.classList.add('subtitle');subtitle.textContent=tone.subtitle;item.querySelector('.name').parentNode.appendChild(subtitle);}
return item;},add:function(tones){if(this._ul.children.length===0){if(Array.isArray(tones)){tones.sort(toneCompare);tones.forEach(this._append.bind(this));}else{this._append(tones);}}else{if(Array.isArray(tones)){tones.forEach(this._insertSorted.bind(this));}else{this._insertSorted(tones);}}},remove:function(tone){this._ul.removeChild(this._toneMap[tone.id].element);if(!this._ul.firstChild){this.element.hidden=true;}},_append:function(tone){if(tone.id in this._toneMap){throw new Error('A tone with this ID is already in the list: '+
tone.id);}
var newItem=this.makeItem(tone);this._toneMap[tone.id]={tone:tone,element:newItem};this.element.hidden=false;this._ul.appendChild(newItem);},_insertSorted:function(tone){if(tone.id in this._toneMap){throw new Error('A tone with this ID is already in the list: '+
tone.id);}
var newItem=this.makeItem(tone);this._toneMap[tone.id]={tone:tone,element:newItem};this.element.hidden=false;var items=this._ul.querySelectorAll('li');for(var i=0;i<items.length;i++){var currTone=this._toneMap[items[i].dataset.id].tone;if(toneCompare(tone,currTone)<0){this._ul.insertBefore(newItem,items[i]);return;}}
this._ul.appendChild(newItem);}};return ToneList;})();;'use strict';navigator.mozSetMessageHandler('activity',function(activity){var tonePlayer=new TonePlayer();var toneTypes=activity.source.data.type;var allowNone=activity.source.data.allowNone;var currentToneID=activity.source.data.currentToneID;var allToneTypes=window.builtInRingtones.toneTypes;if(!Array.isArray(toneTypes)){toneTypes=[toneTypes];}
toneTypes=toneTypes.filter(function(x){return allToneTypes.indexOf(x)!==-1;});var otherToneTypes=allToneTypes.filter(function(x){return toneTypes.indexOf(x)===-1;});document.getElementById('header').addEventListener('action',function(){tonePlayer.stop();activity.postError('cancelled');});document.getElementById('set').addEventListener('click',function(){tonePlayer.stop();tonePlayer.isValid(function(valid){if(!valid){activity.postError('cancelled');}
var selectedTone=tonePlayer.currentTone;selectedTone.getBlob().then(function(blob){activity.postResult({name:selectedTone.name,l10nID:selectedTone.l10nID,id:selectedTone.id,blob:blob});});});});function PickerToneList(...args){ToneList.apply(this,args);}
PickerToneList.prototype=Object.create(ToneList.prototype);PickerToneList.prototype.constructor=PickerToneList;PickerToneList.prototype.makeItem=function(tone){var item=ToneList.prototype.makeItem.call(this,tone);var input=item.querySelector('input');input.checked=(tone.id===currentToneID);input.addEventListener('click',function(){tonePlayer.setTone(tone);document.getElementById('set').disabled=false;});return item;};navigator.mozL10n.once(function(){var promises=[];var listParent=document.getElementById('list-parent');function addToneLists(toneType,includeNone){var builtInList=new PickerToneList('section-title-builtin-'+toneType,listParent);promises.push(window.builtInRingtones.list(toneType).then(function(tones){builtInList.add(tones);if(includeNone){builtInList.add(new NullRingtone());}}));var customList=new PickerToneList('section-title-custom-'+toneType,listParent);promises.push(window.customRingtones.list(toneType).then(function(tones){customList.add(tones);}));promises.push(window.sdCardRingtones.list(toneType).then(function(tones){customList.add(tones);}));}
toneTypes.forEach(function(toneType,i){addToneLists(toneType,i===0&&allowNone);});otherToneTypes.forEach(function(toneType){addToneLists(toneType);});Promise.all(promises).then(function(listsData){document.querySelector('body').dataset.ready=true;});});});