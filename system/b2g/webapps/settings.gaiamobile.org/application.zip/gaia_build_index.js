;window.COMPONENTS_BASE_URL="/shared/elements/";;!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var f;"undefined"!=typeof window?f=window:"undefined"!=typeof global?f=global:"undefined"!=typeof self&&(f=self),f.GaiaHeader=e()}}(function(){var define,module,exports;return(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){;(function(define){define(function(require,exports,module){var textContent=Object.getOwnPropertyDescriptor(Node.prototype,'textContent');var removeAttribute=HTMLElement.prototype.removeAttribute;var setAttribute=HTMLElement.prototype.setAttribute;var noop=function(){};var hasShadowCSS=(function(){var div=document.createElement('div');try{div.querySelector(':host');return true;}
catch(e){return false;}})();module.exports.register=function(name,props){injectGlobalCss(props.globalCss);delete props.globalCSS;var proto=Object.assign(Object.create(base),props);var output=extractLightDomCSS(proto.template,name);var _attrs=Object.assign(props.attrs||{},attrs);proto.template=output.template;proto.lightCss=output.lightCss;Object.defineProperties(proto,_attrs);var El=document.registerElement(name,{prototype:proto});return El;};var base=Object.assign(Object.create(HTMLElement.prototype),{attributeChanged:noop,attached:noop,detached:noop,created:noop,template:'',createdCallback:function(){this.injectLightCss(this);this.created();},attributeChangedCallback:function(name,from,to){if(this.attrs&&this.attrs[name]){this[name]=to;}
this.attributeChanged(name,from,to);},attachedCallback:function(){this.attached();},detachedCallback:function(){this.detached();},setAttr:function(name,value){var internal=this.shadowRoot.firstElementChild;setAttribute.call(internal,name,value);setAttribute.call(this,name,value);},removeAttr:function(){var internal=this.shadowRoot.firstElementChild;removeAttribute.call(internal,name,value);removeAttribute.call(this,name,value);},injectLightCss:function(el){if(hasShadowCSS){return;}
this.lightStyle=document.createElement('style');this.lightStyle.setAttribute('scoped','');this.lightStyle.innerHTML=el.lightCss;el.appendChild(this.lightStyle);}});var attrs={textContent:{set:function(value){var node=firstChildTextNode(this);if(node){node.nodeValue=value;}},get:function(){var node=firstChildTextNode(this);return node&&node.nodeValue;}}};function firstChildTextNode(el){for(var i=0;i<el.childNodes.length;i++){var node=el.childNodes[i];if(node&&node.nodeType===3){return node;}}}
function extractLightDomCSS(template,name){var regex=/(?::host|::content)[^{]*\{[^}]*\}/g;var lightCss='';if(!hasShadowCSS){template=template.replace(regex,function(match){lightCss+=match.replace(/::content|:host/g,name);return'';});}
return{template:template,lightCss:lightCss};}
function injectGlobalCss(css){if(!css)return;var style=document.createElement('style');style.innerHTML=css;document.head.appendChild(style);}});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-component',this));},{}],2:[function(require,module,exports){(function(define){define(function(require,exports,module){var base=window.GAIA_ICONS_BASE_URL||window.COMPONENTS_BASE_URL||'bower_components/';if(!isLoaded()){load(base+'gaia-icons/gaia-icons.css');}
function load(href){var link=document.createElement('link');link.rel='stylesheet';link.type='text/css';link.href=href;document.head.appendChild(link);exports.loaded=true;}
function isLoaded(){return exports.loaded||document.querySelector('link[href*=gaia-icons]')||document.documentElement.classList.contains('gaia-icons-loaded');}});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-icons',this));},{}],3:[function(require,module,exports){;(function(define){define(function(require,exports,module){var Component=require('gaia-component');var fontFit=require('./lib/font-fit');require('gaia-icons');var actionTypes={menu:1,back:1,close:1};module.exports=Component.register('gaia-header',{created:function(){this.createShadowRoot().innerHTML=this.template;this.els={actionButton:this.shadowRoot.querySelector('.action-button'),headings:this.querySelectorAll('h1,h2,h3,h4'),inner:this.shadowRoot.querySelector('.inner')};this.els.actionButton.addEventListener('click',e=>this.onActionButtonClick(e));this.configureActionButton();this.runFontFit();},attached:function(){this.rerunFontFit();},attributeChanged:function(attr){if(attr==='action'){this.configureActionButton();this.rerunFontFit();}},runFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);fontFit.observeHeadingChanges(this.els.headings[i]);}},rerunFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);}},triggerAction:function(){if(this.isSupportedAction(this.getAttribute('action'))){this.els.actionButton.click();}},configureActionButton:function(){var old=this.els.actionButton.getAttribute('icon');var type=this.getAttribute('action');var supported=this.isSupportedAction(type);this.els.actionButton.classList.remove('icon-'+old);this.els.actionButton.setAttribute('icon',type);this.els.inner.classList.toggle('supported-action',supported);if(supported){this.els.actionButton.classList.add('icon-'+type);}},isSupportedAction:function(action){return action&&actionTypes[action];},onActionButtonClick:function(e){var config={detail:{type:this.getAttribute('action')}};var actionEvent=new CustomEvent('action',config);setTimeout(this.dispatchEvent.bind(this,actionEvent));},template:`
  <style>

  :host {
    display: block;

    --gaia-header-button-color:
      var(--header-button-color,
      var(--header-color,
      var(--link-color,
      inherit)));
  }

  /**
   * [hidden]
   */

  :host[hidden] {
    display: none;
  }

  /** Reset
   ---------------------------------------------------------*/

  ::-moz-focus-inner { border: 0; }

  /** Inner
   ---------------------------------------------------------*/

  .inner {
    display: flex;
    min-height: 50px;
    direction: ltr;

    background:
      var(--header-background,
      var(--background,
      #fff));
  }

  /** Action Button
   ---------------------------------------------------------*/

  /**
   * 1. Hidden by default
   */

  .action-button {
    display: none; /* 1 */
    position: relative;
    width: 50px;
    font-size: 30px;
    margin: 0;
    padding: 0;
    border: 0;
    align-items: center;
    background: none;
    cursor: pointer;
    transition: opacity 200ms 280ms;

    color:
      var(--header-action-button-color,
      var(--header-icon-color,
      var(--gaia-header-button-color)));
  }

  /**
   * .action-supported
   *
   * 1. For icon vertical-alignment
   */

  .supported-action .action-button {
    display: flex; /* 1 */
  }

  /**
   * :active
   */

  .action-button:active {
    transition: none;
    opacity: 0.2;
  }

  /** Action Button Icon
   ---------------------------------------------------------*/

  /**
   * 1. To enable vertical alignment.
   */

  .action-button:before {
    display: block;
  }

  /** Action Button Text
   ---------------------------------------------------------*/

  /**
   * To provide custom localized content for
   * the action-button, we allow the user
   * to provide an element with the class
   * .l10n-action. This node is then
   * pulled inside the real action-button.
   *
   * Example:
   *
   *   <gaia-header action="back">
   *     <span class="l10n-action" aria-label="Back">Localized text</span>
   *     <h1>title</h1>
   *   </gaia-header>
   */

  ::content .l10n-action {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    font-size: 0;
  }

  /** Title
   ---------------------------------------------------------*/

  /**
   * 1. Vertically center text. We can't use flexbox
   *    here as it breaks text-overflow ellipsis
   *    without an inner div.
   */

  ::content h1 {
    flex: 1;
    margin: 0;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    text-align: center;
    line-height: 50px; /* 1 */
    font-weight: 300;
    font-style: italic;
    font-size: 24px;
    -moz-user-select: none;

    color:
      var(--header-title-color,
      var(--header-color,
      var(--title-color,
      var(--text-color,
      inherit))));
  }

  /**
   * .flush-left
   *
   * When the fitted text is flush with the
   * edge of the left edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-left {
    padding-left: 10px;
  }

  /**
   * .flush-right
   *
   * When the fitted text is flush with the
   * edge of the right edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-right {
    padding-right: 10px; /* 1 */
  }

  /** Buttons
   ---------------------------------------------------------*/

  ::content a,
  ::content button {
    box-sizing: border-box;
    display: flex;
    border: none;
    width: auto;
    height: auto;
    margin: 0;
    padding: 0 10px;
    font-size: 14px;
    line-height: 1;
    min-width: 50px;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    text-align: center;
    background: none;
    border-radius: 0;
    font-style: italic;
    cursor: pointer;

    transition: opacity 200ms 280ms;

    color:
      var(--gaia-header-button-color);
  }

  /**
   * :active
   */

  ::content a:active,
  ::content button:active {
    transition: none;
    opacity: 0.2;
  }

  /**
   * [hidden]
   */

  ::content a[hidden],
  ::content button[hidden] {
    display: none;
  }

  /**
   * [disabled]
   */

  ::content a[disabled],
  ::content button[disabled] {
    pointer-events: none;
    color: var(--header-disabled-button-color);
  }

  /** Icon Buttons
   ---------------------------------------------------------*/

  /**
   * Icons are a different color to text
   */

  ::content .icon,
  ::content [data-icon] {
    color:
      var(--header-icon-color,
      var(--gaia-header-button-color));
  }

  /** Icons
   ---------------------------------------------------------*/

  [class^="icon-"]:before,
  [class*="icon-"]:before {
    font-family: 'gaia-icons';
    font-style: normal;
    text-rendering: optimizeLegibility;
    font-weight: 500;
  }

  .icon-menu:before { content: 'menu'; }
  .icon-close:before { content: 'close'; }
  .icon-back:before { content: 'back'; }

  </style>

  <div class="inner">
    <button class="action-button">
      <content select=".l10n-action"></content>
    </button>
    <content select="h1,h2,h3,h4,a,button"></content>
  </div>`});});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-header',this));},{"./lib/font-fit":4,"gaia-component":1,"gaia-icons":2}],4:[function(require,module,exports){;(function(define){define(function(require,exports,module){var GaiaHeaderFontFit={_HEADER_SIZES:[16,17,18,19,20,21,22,23,24],observeHeadingChanges:function(heading){var observer=this._getTextChangeObserver();observer.observe(heading,{childList:true});},reformatHeading:function(heading){if(!heading||heading.textContent.trim()===''){return;}
this._resetCentering(heading);var style=this._getStyleProperties(heading);if(!style){return;}
style.textWidth=this._autoResizeElement(heading,style);this._centerTextToScreen(heading,style);},resetCache:function(){this._cachedContexts={};},_cachedContexts:{},_getCachedContext:function(fontSize,fontFamily,fontStyle){fontStyle=fontStyle||'italic';var cache=this._cachedContexts;var ctx=cache[fontSize]&&cache[fontSize][fontFamily]?cache[fontSize][fontFamily][fontStyle]:null;if(!ctx){var canvas=document.createElement('canvas');canvas.setAttribute('moz-opaque','true');canvas.setAttribute('width','1');canvas.setAttribute('height','1');ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.font=fontStyle+' '+fontSize+'px '+fontFamily;if(!cache[fontSize]){cache[fontSize]={};}
if(!cache[fontSize][fontFamily]){cache[fontSize][fontFamily]={};}
cache[fontSize][fontFamily][fontStyle]=ctx;}
return ctx;},_textChangeObserver:null,_handleTextChanges:function(mutations){var targets=new Set();for(var i=0;i<mutations.length;i++){targets.add(mutations[i].target);}
for(var target of targets){this.reformatHeading(target);}},_getTextChangeObserver:function(){if(!this._textChangeObserver){this._textChangeObserver=new MutationObserver(this._handleTextChanges.bind(this));}
return this._textChangeObserver;},_getFontWidth:function(string,fontSize,fontFamily,fontStyle){var ctx=this._getCachedContext(fontSize,fontFamily,fontStyle);return ctx.measureText(string).width;},_getMaxFontSizeInfo:function(string,allowedSizes,fontFamily,maxWidth){var fontSize;var resultWidth;var i=allowedSizes.length-1;do{fontSize=allowedSizes[i];resultWidth=this._getFontWidth(string,fontSize,fontFamily);i--;}while(resultWidth>maxWidth&&i>=0);return{fontSize:fontSize,overflow:resultWidth>maxWidth,textWidth:resultWidth};},_getContentWidth:function(style){var width=parseInt(style.width,10);if(style.boxSizing==='border-box'){width-=(parseInt(style.paddingRight,10)+
parseInt(style.paddingLeft,10));}
return width;},_getStyleProperties:function(heading){var style=getComputedStyle(heading)||{};var contentWidth=this._getContentWidth(style);if(isNaN(contentWidth)){contentWidth=0;}
return{fontFamily:style.fontFamily||'unknown',contentWidth:contentWidth,paddingRight:parseInt(style.paddingRight,10),paddingLeft:parseInt(style.paddingLeft,10),offsetLeft:heading.offsetLeft};},_autoResizeElement:function(heading,styleOptions){var contentWidth=styleOptions.contentWidth||this._getContentWidth(heading);var fontFamily=styleOptions.fontFamily||getComputedStyle(heading).fontFamily;var text=heading.textContent.replace(/\s+/g,' ').trim();var info=this._getMaxFontSizeInfo(text,this._HEADER_SIZES,fontFamily,contentWidth);heading.style.fontSize=info.fontSize+'px';return info.textWidth;},_resetCentering:function(heading){heading.style.marginLeft=heading.style.marginRight='0';},_centerTextToScreen:function(heading,styleOptions){var minHeaderWidth=styleOptions.textWidth+styleOptions.paddingRight+
styleOptions.paddingLeft;var tightText=styleOptions.textWidth>(styleOptions.contentWidth-30);var sideSpaceLeft=styleOptions.offsetLeft;var sideSpaceRight=this._getWindowWidth()-sideSpaceLeft-
styleOptions.contentWidth-styleOptions.paddingRight-
styleOptions.paddingLeft;heading.classList.toggle('flush-left',tightText&&!sideSpaceLeft);heading.classList.toggle('flush-right',tightText&&!sideSpaceRight);if(sideSpaceLeft===sideSpaceRight){return;}
var margin=Math.max(sideSpaceLeft,sideSpaceRight);if(minHeaderWidth+(margin*2)<this._getWindowWidth()-1){if(sideSpaceLeft<sideSpaceRight){heading.style.marginLeft=(sideSpaceRight-sideSpaceLeft)+'px';}
if(sideSpaceRight<sideSpaceLeft){heading.style.marginRight=(sideSpaceLeft-sideSpaceRight)+'px';}}},_getWindowWidth:function(){return window.innerWidth;}};module.exports=GaiaHeaderFontFit;});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('./lib/font-fit',this));},{}]},{},[3])(3)});;!function(t,e){function n(t,e,n){this.name="L10nError",this.message=t,this.id=e,this.loc=n}function r(){}function i(t){function e(t,e){return-1!==e.indexOf(t)}function n(t,e,n){return typeof t==typeof e&&t>=e&&n>=t}var r={af:3,ak:4,am:4,ar:1,asa:3,az:0,be:11,bem:3,bez:3,bg:3,bh:4,bm:0,bn:3,bo:0,br:20,brx:3,bs:11,ca:3,cgg:3,chr:3,cs:12,cy:17,da:3,de:3,dv:3,dz:0,ee:3,el:3,en:3,eo:3,es:3,et:3,eu:3,fa:0,ff:5,fi:3,fil:4,fo:3,fr:5,fur:3,fy:3,ga:8,gd:24,gl:3,gsw:3,gu:3,guw:4,gv:23,ha:3,haw:3,he:2,hi:4,hr:11,hu:0,id:0,ig:0,ii:0,is:3,it:3,iu:7,ja:0,jmc:3,jv:0,ka:0,kab:5,kaj:3,kcg:3,kde:0,kea:0,kk:3,kl:3,km:0,kn:0,ko:0,ksb:3,ksh:21,ku:3,kw:7,lag:18,lb:3,lg:3,ln:4,lo:0,lt:10,lv:6,mas:3,mg:4,mk:16,ml:3,mn:3,mo:9,mr:3,ms:0,mt:15,my:0,nah:3,naq:7,nb:3,nd:3,ne:3,nl:3,nn:3,no:3,nr:3,nso:4,ny:3,nyn:3,om:3,or:3,pa:3,pap:3,pl:13,ps:3,pt:3,rm:3,ro:9,rof:3,ru:11,rwk:3,sah:0,saq:3,se:7,seh:3,ses:0,sg:0,sh:11,shi:19,sk:12,sl:14,sma:7,smi:7,smj:7,smn:7,sms:7,sn:3,so:3,sq:3,sr:11,ss:3,ssy:3,st:3,sv:3,sw:3,syr:3,ta:3,te:3,teo:3,th:0,ti:4,tig:3,tk:3,tl:4,tn:3,to:0,tr:0,ts:3,tzm:22,uk:11,ur:3,ve:3,vi:0,vun:3,wa:4,wae:3,wo:0,xh:3,xog:3,yo:0,zh:0,zu:3},i={0:function(){return"other"},1:function(t){return n(t%100,3,10)?"few":0===t?"zero":n(t%100,11,99)?"many":2===t?"two":1===t?"one":"other"},2:function(t){return 0!==t&&0===t%10?"many":2===t?"two":1===t?"one":"other"},3:function(t){return 1===t?"one":"other"},4:function(t){return n(t,0,1)?"one":"other"},5:function(t){return n(t,0,2)&&2!==t?"one":"other"},6:function(t){return 0===t?"zero":1===t%10&&11!==t%100?"one":"other"},7:function(t){return 2===t?"two":1===t?"one":"other"},8:function(t){return n(t,3,6)?"few":n(t,7,10)?"many":2===t?"two":1===t?"one":"other"},9:function(t){return 0===t||1!==t&&n(t%100,1,19)?"few":1===t?"one":"other"},10:function(t){return n(t%10,2,9)&&!n(t%100,11,19)?"few":1!==t%10||n(t%100,11,19)?"other":"one"},11:function(t){return n(t%10,2,4)&&!n(t%100,12,14)?"few":0===t%10||n(t%10,5,9)||n(t%100,11,14)?"many":1===t%10&&11!==t%100?"one":"other"},12:function(t){return n(t,2,4)?"few":1===t?"one":"other"},13:function(t){return n(t%10,2,4)&&!n(t%100,12,14)?"few":1!==t&&n(t%10,0,1)||n(t%10,5,9)||n(t%100,12,14)?"many":1===t?"one":"other"},14:function(t){return n(t%100,3,4)?"few":2===t%100?"two":1===t%100?"one":"other"},15:function(t){return 0===t||n(t%100,2,10)?"few":n(t%100,11,19)?"many":1===t?"one":"other"},16:function(t){return 1===t%10&&11!==t?"one":"other"},17:function(t){return 3===t?"few":0===t?"zero":6===t?"many":2===t?"two":1===t?"one":"other"},18:function(t){return 0===t?"zero":n(t,0,2)&&0!==t&&2!==t?"one":"other"},19:function(t){return n(t,2,10)?"few":n(t,0,1)?"one":"other"},20:function(t){return!n(t%10,3,4)&&9!==t%10||n(t%100,10,19)||n(t%100,70,79)||n(t%100,90,99)?0===t%1e6&&0!==t?"many":2!==t%10||e(t%100,[12,72,92])?1!==t%10||e(t%100,[11,71,91])?"other":"one":"two":"few"},21:function(t){return 0===t?"zero":1===t?"one":"other"},22:function(t){return n(t,0,1)||n(t,11,99)?"one":"other"},23:function(t){return n(t%10,1,2)||0===t%20?"one":"other"},24:function(t){return n(t,3,10)||n(t,13,19)?"few":e(t,[2,12])?"two":e(t,[1,11])?"one":"other"}},o=r[t.replace(/-.*$/,"")];return o in i?i[o]:function(){return"other"}}function o(t,n){var r=Object.keys(t);if("string"==typeof t.$v&&2===r.length)return t.$v;for(var i,o,s=0;o=r[s];s++)"$"!==o[0]&&(i||(i=Object.create(null)),i[o]=a(t[o],n,t.$i+"."+o));return{id:t.$i,value:t.$v===e?null:t.$v,index:t.$x||null,attrs:i||null,env:n,dirty:!1}}function a(t,e,n){if("string"==typeof t)return t;var r;return Array.isArray(t)&&(r=t),{id:n,value:r||t.$v||null,index:t.$x||null,env:e,dirty:!1}}function s(t,e){if("string"==typeof e)return e;if(e.dirty)throw new n("Cyclic reference detected: "+e.id);e.dirty=!0;var r;try{r=f(t,e.env,e.value,e.index)}finally{e.dirty=!1}return r}function u(t,e,r){if(te.indexOf(r)>-1)return e["__"+r];if(t&&t.hasOwnProperty(r)){if("string"==typeof t[r]||"number"==typeof t[r]&&!isNaN(t[r]))return t[r];throw new n("Arg must be a string or a number: "+r)}if(r in e&&"__proto__"!==r)return s(t,e[r]);throw new n("Unknown reference: "+r)}function l(t,e,r){var i;try{i=u(t,e,r)}catch(o){return"{{ "+r+" }}"}if("number"==typeof i)return i;if("string"==typeof i){if(i.length>=ee)throw new n("Too many characters in placeable ("+i.length+", max allowed is "+ee+")");return i}return"{{ "+r+" }}"}function c(t,e,n){return n.reduce(function(n,r){return"string"==typeof r?n+r:"idOrVar"===r.t?n+l(t,e,r.v):void 0},"")}function d(t,n,r,i){var o=i[0].v,a=u(t,n,o);if("function"!=typeof a)return a;var s=i[1]?u(t,n,i[1]):e;if(a===n.__plural){if(0===s&&"zero"in r)return"zero";if(1===s&&"one"in r)return"one";if(2===s&&"two"in r)return"two"}return a(s)}function f(t,e,r,i){if("string"==typeof r||"boolean"==typeof r||"number"==typeof r||!r)return r;if(Array.isArray(r))return c(t,e,r);if(i){var o=d(t,e,r,i);if(r.hasOwnProperty(o))return f(t,e,r[o])}if("other"in r)return f(t,e,r.other);throw new n("Unresolvable value")}function p(t,e){if("string"==typeof t)return e(t);if("idOrVar"===t.t)return t;for(var n,r=Array.isArray(t)?[]:{},i=Object.keys(t),o=0;n=i[o];o++)r[n]="$i"===n||"$x"===n?t[n]:p(t[n],e);return r}function h(t){return t.replace(oe,function(t){return t+t.toLowerCase()})}function m(t,e){return e.replace(ie,function(e){return t.charAt(e.charCodeAt(0)-65)})}function g(t){return t.replace(ue,function(t){return"‮"+t+"‬"})}function v(t,e){if(!e)return e;var n=e.split(le),r=n.map(function(e){return le.test(e)?e:t(e)});return r.join("")}function y(t,e,n,r){this.id=t,this.translate=v.bind(null,function(t){return m(n,r(t))}),this.name=this.translate(e)}function _(t,e){this.id=t,this.ctx=e,this.isReady=!1,this.isPseudo=ce.hasOwnProperty(t),this.entries=Object.create(null),this.entries.__plural=i(this.isPseudo?this.ctx.defaultLocale:t)}function E(t,e){return re.createEntry(p(t,ce[this.id].translate),e)}function b(t){this.id=t,this.isReady=!1,this.isLoading=!1,this.defaultLocale="en-US",this.availableLocales=[],this.supportedLocales=[],this.resLinks=[],this.locales={},this._emitter=new r,this._ready=new Promise(this.once.bind(this))}function w(t,e){return this._emitter.emit("notfounderror",e),t}function L(t){for(var r,i,o=0;r=this.supportedLocales[o];){i=this.getLocale(r),i.isReady||i.build(null);var a=i.entries[t];if(a!==e)return a;o++,w.call(this,t,new n('"'+t+'"'+" not found in "+r+" in "+this.id,t,r))}throw new n('"'+t+'"'+" missing from all supported locales in "+this.id,t)}function A(t,e){if("string"==typeof e)return e;try{return re.format(t,e)}catch(n){return this._emitter.emit("resolveerror",n),e.id}}function T(t,e){if(!e.attrs)return{value:A.call(this,t,e),attrs:null};var n={value:A.call(this,t,e),attrs:Object.create(null)};for(var r in e.attrs)n.attrs[r]=A.call(this,t,e.attrs[r]);return n}function N(t,e,n){return this._ready.then(L.bind(this,e)).then(t.bind(this,n),w.bind(this,e))}function S(t,e,r){if(!this.isReady)throw new n("Context not ready");var i;try{i=L.call(this,e)}catch(o){if(o.loc)throw o;return w.call(this,e,o),""}return t.call(this,r,i)}function I(t,e,n){return-1===t.indexOf(e[0])||e[0]===n?[n]:[e[0],n]}function O(t){var e=this.getLocale(t[0]);e.isReady?P.call(this,t):e.build(P.bind(this,t))}function P(t){this.supportedLocales=t,this.isReady=!0,this._emitter.emit("ready")}function D(t){return pe.indexOf(t)>=0?"rtl":"ltr"}function R(t,e){return t=ye[t],ye[document.readyState]>=t?(e(),void 0):(document.addEventListener("readystatechange",function n(){ye[document.readyState]>=t&&(document.removeEventListener("readystatechange",n),e())}),void 0)}function C(){he=new MutationObserver(j.bind(navigator.mozL10n)),he.observe(document,ve)}function z(e){e?k.call(navigator.mozL10n):(C(),t.setTimeout(k.bind(navigator.mozL10n)))}function k(){for(var t,e=document.head.querySelectorAll('link[rel="localization"],meta[name="availableLanguages"],meta[name="defaultLanguage"],script[type="application/l10n"]'),n=0;t=e[n];n++){var r=t.getAttribute("rel")||t.nodeName.toLowerCase();switch(r){case"localization":this.ctx.resLinks.push(t.getAttribute("href"));break;case"meta":U.call(this,t);break;case"script":M.call(this,t)}}return this.ctx.availableLocales.length||this.ctx.registerLocales(this.ctx.defaultLocale),F.call(this)}function x(t){return t.split(",").map(function(t){return t=t.trim().split(":"),t[0]})}function U(t){if(!this.ctx.availableLocales.length){switch(t.getAttribute("name")){case"availableLanguages":ge.availableLanguages=x(t.getAttribute("content"));break;case"defaultLanguage":ge.defaultLanguage=t.getAttribute("content")}2===Object.keys(ge).length&&(this.ctx.registerLocales(ge.defaultLanguage,ge.availableLanguages),ge={})}}function M(t){var e=t.getAttribute("lang"),n=this.ctx.getLocale(e);n.addAST(JSON.parse(t.textContent))}function F(){this.ctx.requestLocales.apply(this.ctx,navigator.languages||[navigator.language]),t.addEventListener("languagechange",function(){this.ctx.requestLocales.apply(this.ctx,navigator.languages||[navigator.language])}.bind(this))}function Y(t){for(var e,n=new Set,r=0;r<t.length;r++){if(e=t[r],"childList"===e.type)for(var i,o=0;o<e.addedNodes.length;o++)i=e.addedNodes[o],i.nodeType===Node.ELEMENT_NODE&&n.add(i);"attributes"===e.type&&n.add(e.target)}n.forEach(function(t){t.childElementCount?H.call(this,t):t.hasAttribute("data-l10n-id")&&W.call(this,t)},this)}function j(t,e){e.disconnect(),Y.call(this,t),e.observe(document,ve)}function $(){if(fe||V.call(this),fe=!1,me){for(var t,e=0;t=me[e];e++)W.call(this,t);me=null}he||C(),G.call(this)}function G(){var e=new CustomEvent("localized",{bubbles:!1,cancelable:!1,detail:{language:this.ctx.supportedLocales[0]}});t.dispatchEvent(e)}function V(){document.documentElement.lang=this.language.code,document.documentElement.dir=this.language.direction,H.call(this,document.documentElement)}function H(t){t.hasAttribute("data-l10n-id")&&W.call(this,t);for(var e=K(t),n=0;n<e.length;n++)W.call(this,e[n])}function B(t,e,n){t.setAttribute("data-l10n-id",e),n&&t.setAttribute("data-l10n-args",JSON.stringify(n))}function q(t){return{id:t.getAttribute("data-l10n-id"),args:JSON.parse(t.getAttribute("data-l10n-args"))}}function K(t){return t?t.querySelectorAll("*[data-l10n-id]"):[]}function W(t){if(!this.ctx.isReady)return me||(me=[]),me.push(t),void 0;var e=q(t);if(!e.id)return!1;var n=this.ctx.getEntity(e.id,e.args);if(!n)return!1;"string"==typeof n.value&&J.call(this,e.id,t,n.value);for(var r in n.attrs){var i=n.attrs[r];Ee.hasOwnProperty(r)?t.setAttribute(Ee[r],i):"innerHTML"===r?t.innerHTML=i:t.setAttribute(r,i)}return!0}function J(t,e,r){if(e.firstElementChild)throw new n('setTextContent is deprecated (https://bugzil.la/1053629). Setting text content of elements with child elements is no longer supported by l10n.js. Offending data-l10n-id: "'+t+'" on element '+e.outerHTML+" in "+this.ctx.id);e.textContent=r}n.prototype=Object.create(Error.prototype),n.prototype.constructor=n;var X={load:function(t,e,r){var i=new XMLHttpRequest;i.overrideMimeType&&i.overrideMimeType("text/plain"),i.open("GET",t,!r),i.addEventListener("load",function(r){200===r.target.status||0===r.target.status?e(null,r.target.responseText):e(new n("Not found: "+t))}),i.addEventListener("error",e),i.addEventListener("timeout",e);try{i.send(null)}catch(o){e(new n("Not found: "+t))}},loadJSON:function(t,e){var r=new XMLHttpRequest;r.overrideMimeType&&r.overrideMimeType("application/json"),r.open("GET",t),r.responseType="json",r.addEventListener("load",function(r){200===r.target.status||0===r.target.status?e(null,r.target.response):e(new n("Not found: "+t))}),r.addEventListener("error",e),r.addEventListener("timeout",e);try{r.send(null)}catch(i){e(new n("Not found: "+t))}}};r.prototype.emit=function(){if(this._listeners){var t=Array.prototype.slice.call(arguments),e=t.shift();if(this._listeners[e])for(var n=this._listeners[e].slice(),r=0;r<n.length;r++)n[r].apply(this,t)}},r.prototype.addEventListener=function(t,e){this._listeners||(this._listeners={}),t in this._listeners||(this._listeners[t]=[]),this._listeners[t].push(e)},r.prototype.removeEventListener=function(t,e){if(this._listeners){var n=this._listeners[t],r=n.indexOf(e);-1!==r&&n.splice(r,1)}};var Z=100,Q={patterns:null,entryIds:null,init:function(){this.patterns={comment:/^\s*#|^\s*$/,entity:/^([^=\s]+)\s*=\s*(.+)$/,multiline:/[^\\]\\$/,index:/\{\[\s*(\w+)(?:\(([^\)]*)\))?\s*\]\}/i,unicode:/\\u([0-9a-fA-F]{1,4})/g,entries:/[^\r\n]+/g,controlChars:/\\([\\\n\r\t\b\f\{\}\"\'])/g,placeables:/\{\{\s*([^\s]*?)\s*\}\}/}},parse:function(t,e){this.patterns||this.init();var n=[];this.entryIds=Object.create(null);var r=e.match(this.patterns.entries);if(!r)return n;for(var i=0;i<r.length;i++){var o=r[i];if(!this.patterns.comment.test(o)){for(;this.patterns.multiline.test(o)&&i<r.length;)o=o.slice(0,-1)+r[++i].trim();var a=o.match(this.patterns.entity);if(a)try{this.parseEntity(a[1],a[2],n)}catch(s){if(!t)throw s;t._emitter.emit("parseerror",s)}}}return n},parseEntity:function(t,e,r){var i,o,a=t.indexOf("[");-1!==a?(i=t.substr(0,a),o=t.substring(a+1,t.length-1)):(i=t,o=null);var s=i.split(".");if(s.length>2)throw new n('Error in ID: "'+i+'".'+" Nested attributes are not supported.");var u;if(s.length>1){if(i=s[0],u=s[1],"$"===u[0])throw new n('Attribute can\'t start with "$"',t)}else u=null;this.setEntityValue(i,u,o,this.unescapeString(e),r)},setEntityValue:function(t,n,r,i,o){var a,s;return-1!==i.indexOf("{{")&&(i=this.parseString(i)),n?(a=this.entryIds[t],a===e?(s={$i:t},r?(s[n]={},s[n][r]=i):s[n]=i,o.push(s),this.entryIds[t]=o.length-1,void 0):r?("string"==typeof o[a][n]&&(o[a][n]={$x:this.parseIndex(o[a][n]),$v:{}}),o[a][n].$v[r]=i,void 0):(o[a][n]=i,void 0)):r?(a=this.entryIds[t],a===e?(s={},s[r]=i,o.push({$i:t,$v:s}),this.entryIds[t]=o.length-1,void 0):("string"==typeof o[a].$v&&(o[a].$x=this.parseIndex(o[a].$v),o[a].$v={}),o[a].$v[r]=i,void 0)):(o.push({$i:t,$v:i}),this.entryIds[t]=o.length-1,void 0)},parseString:function(t){var e=t.split(this.patterns.placeables),r=[],i=e.length,o=(i-1)/2;if(o>=Z)throw new n("Too many placeables ("+o+", max allowed is "+Z+")");for(var a=0;a<e.length;a++)0!==e[a].length&&(1===a%2?r.push({t:"idOrVar",v:e[a]}):r.push(e[a]));return r},unescapeString:function(t){return-1!==t.lastIndexOf("\\")&&(t=t.replace(this.patterns.controlChars,"$1")),t.replace(this.patterns.unicode,function(t,e){return unescape("%u"+"0000".slice(e.length)+e)})},parseIndex:function(t){var e=t.match(this.patterns.index);if(!e)throw new n("Malformed index");return e[2]?[{t:"idOrVar",v:e[1]},e[2]]:[{t:"idOrVar",v:e[1]}]}},te=["plural"],ee=2500,ne=/\{\{\s*(.+?)\s*\}\}/g,re={createEntry:o,format:s,rePlaceables:ne},ie=/[a-zA-Z]/g,oe=/[aeiouAEIOU]/g,ae="ȦƁƇḒḖƑƓĦĪĴĶĿḾȠǾƤɊŘŞŦŬṼẆẊẎẐ[\\]^_`ȧƀƈḓḗƒɠħīĵķŀḿƞǿƥɋřşŧŭṽẇẋẏẑ",se="∀ԐↃpƎɟפHIſӼ˥WNOԀÒᴚS⊥∩ɅＭXʎZ[\\]ᵥ_,ɐqɔpǝɟƃɥıɾʞʅɯuodbɹsʇnʌʍxʎz",ue=/[^\W0-9_]+/g,le=/(%[EO]?\w|\{\s*.+?\s*\})/,ce={"qps-ploc":new y("qps-ploc","Accented English",ae,h),"qps-plocm":new y("qps-plocm","Mirrored English",se,g)};_.prototype.build=function(t){function e(e){e&&o._emitter.emit("fetcherror",e),--s<=0&&(a.isReady=!0,t&&t())}function n(t,n){!t&&n&&a.addAST(n),e(t)}function r(t,n){if(!t&&n){var r=Q.parse(o,n);a.addAST(r)}e(t)}var i=!t,o=this.ctx,a=this,s=o.resLinks.length;if(0===s)return e(),void 0;for(var u=this.isPseudo?o.defaultLocale:this.id,l=0;l<o.resLinks.length;l++){var c=decodeURI(o.resLinks[l]),d=c.replace("{locale}",u),f=d.substr(d.lastIndexOf(".")+1);switch(f){case"json":X.loadJSON(d,n,i);break;case"properties":X.load(d,r,i)}}},_.prototype.addAST=function(t){for(var e,n=this.isPseudo?E.bind(this):re.createEntry,r=0;e=t[r];r++)this.entries[e.$i]=n(e,this.entries)},b.prototype.formatValue=function(t,e){return N.call(this,A,t,e)},b.prototype.formatEntity=function(t,e){return N.call(this,T,t,e)},b.prototype.get=function(t,e){return S.call(this,A,t,e)},b.prototype.getEntity=function(t,e){return S.call(this,T,t,e)},b.prototype.getLocale=function(t){var e=this.locales;return e[t]?e[t]:e[t]=new _(t,this)},b.prototype.registerLocales=function(t,e){if(this.availableLocales=[this.defaultLocale=t],e)for(var n,r=0;n=e[r];r++)-1===this.availableLocales.indexOf(n)&&this.availableLocales.push(n)},b.prototype.requestLocales=function(){if(this.isLoading&&!this.isReady)throw new n("Context not ready");this.isLoading=!0;var t=Array.prototype.slice.call(arguments);if(0===t.length)throw new n("No locales requested");var e=t.filter(function(t){return t in ce}),r=I(this.availableLocales.concat(e),t,this.defaultLocale);O.call(this,r)},b.prototype.addEventListener=function(t,e){this._emitter.addEventListener(t,e)},b.prototype.removeEventListener=function(t,e){this._emitter.removeEventListener(t,e)},b.prototype.ready=function(t){this.isReady&&setTimeout(t),this.addEventListener("ready",t)},b.prototype.once=function(t){if(this.isReady)return setTimeout(t),void 0;var e=function(){this.removeEventListener("ready",e),t()}.bind(this);this.addEventListener("ready",e)};var de=!1,fe=!1,pe=["ar","he","fa","ps","qps-plocm","ur"],he=null,me=null,ge={},ve={attributes:!0,characterData:!1,childList:!0,subtree:!0,attributeFilter:["data-l10n-id","data-l10n-args"]};navigator.mozL10n={ctx:new b(t.document?document.URL:null),get:function(t,e){return navigator.mozL10n.ctx.get(t,e)},formatValue:function(t,e){return navigator.mozL10n.ctx.formatValue(t,e)},formatEntity:function(t,e){return navigator.mozL10n.ctx.formatEntity(t,e)},translateFragment:function(t){return H.call(navigator.mozL10n,t)},setAttributes:B,getAttributes:q,ready:function(t){return navigator.mozL10n.ctx.ready(t)},once:function(t){return navigator.mozL10n.ctx.once(t)},get readyState(){return navigator.mozL10n.ctx.isReady?"complete":"loading"},language:{set code(t){navigator.mozL10n.ctx.requestLocales(t)},get code(){return navigator.mozL10n.ctx.supportedLocales[0]},get direction(){return D(navigator.mozL10n.ctx.supportedLocales[0])}},qps:ce,_getInternalAPI:function(){return{Error:n,Context:b,Locale:_,Resolver:re,getPluralRule:i,rePlaceables:ne,translateDocument:V,onMetaInjected:U,PropertiesParser:Q,walkContent:p}}},navigator.mozL10n.ctx.ready($.bind(navigator.mozL10n)),navigator.mozL10n.ctx.addEventListener("notfounderror",function(t){(de||"en-US"===t.loc)&&console.warn(t.toString())}),de&&(navigator.mozL10n.ctx.addEventListener("manifesterror",console.error.bind(console)),navigator.mozL10n.ctx.addEventListener("fetcherror",console.error.bind(console)),navigator.mozL10n.ctx.addEventListener("parseerror",console.error.bind(console)),navigator.mozL10n.ctx.addEventListener("resolveerror",console.error.bind(console)));var ye={loading:0,interactive:1,complete:2};if(t.document){fe=!ce.hasOwnProperty(navigator.language)&&document.documentElement.lang===navigator.language;var _e=document.documentElement.dataset.noCompleteBug?!0:!fe;R("interactive",z.bind(navigator.mozL10n,_e))}var Ee={ariaLabel:"aria-label",ariaValueText:"aria-valuetext",ariaMozHint:"aria-moz-hint"}}(this);;var LazyLoader=(function(){function LazyLoader(){this._loaded={};this._isLoading={};}
LazyLoader.prototype={_js:function(file,callback){var script=document.createElement('script');script.src=file;script.async=false;script.addEventListener('load',callback);document.head.appendChild(script);this._isLoading[file]=script;},_css:function(file,callback){var style=document.createElement('link');style.type='text/css';style.rel='stylesheet';style.href=file;document.head.appendChild(style);callback();},_html:function(domNode,callback){if(domNode.getAttribute('is')){this.load(['/shared/js/html_imports.js'],function(){HtmlImports.populate(callback);}.bind(this));return;}
for(var i=0;i<domNode.childNodes.length;i++){if(domNode.childNodes[i].nodeType==document.COMMENT_NODE){domNode.innerHTML=domNode.childNodes[i].nodeValue;break;}}
window.dispatchEvent(new CustomEvent('lazyload',{detail:domNode}));callback();},getJSON:function(file){return new Promise(function(resolve,reject){var xhr=new XMLHttpRequest();xhr.open('GET',file,true);xhr.responseType='json';xhr.onerror=function(error){reject(error);};xhr.onload=function(){if(xhr.response!==null){resolve(xhr.response);}else{reject(new Error('No valid JSON object was found ('+
xhr.status+' '+xhr.statusText+')'));}};xhr.send();});},load:function(files,callback){var deferred={};deferred.promise=new Promise(resolve=>{deferred.resolve=resolve;});if(!Array.isArray(files)){files=[files];}
var loadsRemaining=files.length,self=this;function perFileCallback(file){if(self._isLoading[file]){delete self._isLoading[file];}
self._loaded[file]=true;if(--loadsRemaining===0){deferred.resolve();if(callback){callback();}}}
for(var i=0;i<files.length;i++){var file=files[i];if(this._loaded[file.id||file]){perFileCallback(file);}else if(this._isLoading[file]){this._isLoading[file].addEventListener('load',perFileCallback.bind(null,file));}else{var method,idx;if(typeof file==='string'){method=file.match(/\.([^.]+)$/)[1];idx=file;}else{method='html';idx=file.id;}
this['_'+method](file,perFileCallback.bind(null,idx));}}
return deferred.promise;}};return new LazyLoader();}());;!function(t){var e=t.performance,n=t.console;if("function"!=typeof e.mark){var o=function(t){setTimeout(function(){var e="Performance Entry: "+t.entryType+"|"+t.name+"|"+t.startTime+"|"+t.duration+"|"+(t.time||0);n.log(e)},0)},i={};e.mark=function(t){var n=e.now(),r=Date.now();if("undefined"==typeof t)throw new SyntaxError("Mark name must be specified");if(e.timing&&t in e.timing)throw new SyntaxError("Mark name is not allowed");i[t]||(i[t]=[]),i[t].push(n),o({entryType:"mark",name:t,startTime:n,duration:0,time:r})},e.measure=function(t,n,r){var a=e.now(),s=Date.now();if(!t)throw new Error("Measure must be specified");if(!n)return o({entryType:"measure",name:t,startTime:0,duration:a,time:s}),void 0;var c=0;if(e.timing&&n in e.timing){if("navigationStart"!==n&&0===e.timing[n])throw new Error(n+" has a timing of 0");c=e.timing[n]-e.timing.navigationStart}else{if(!(n in i))throw new Error(n+" mark not found");c=i[n][i[n].length-1]}var u=a;if(r)if(u=0,e.timing&&r in e.timing){if("navigationStart"!==r&&0===e.timing[r])throw new Error(r+" has a timing of 0");u=e.timing[r]-e.timing.navigationStart}else{if(!(r in i))throw new Error(r+" mark not found");u=i[r][i[r].length-1]}var l=u-c;o({entryType:"measure",name:t,startTime:c,duration:l,time:s})},"undefined"!=typeof define&&define.amd?define([],function(){return e}):"undefined"!=typeof module&&"undefined"!=typeof module.exports&&(module.exports=e)}}("undefined"!=typeof window?window:void 0);