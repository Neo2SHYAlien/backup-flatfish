;(function(){if(window.navigator.mozHour12||window.navigator.hour12){return;}
window.navigator.mozHour12=null;var _setMozHour12=function(result){if(window.navigator.mozHour12!==result){window.navigator.mozHour12=result;window.dispatchEvent(new CustomEvent('timeformatchange'));}};var _hour12Handler=function(event){_setMozHour12(event.settingValue);};var _kLocaleTime='locale.hour12';var req=window.navigator.mozSettings.createLock().get(_kLocaleTime);req.onsuccess=function(){_setMozHour12(req.result[_kLocaleTime]);};window.navigator.mozSettings.addObserver(_kLocaleTime,_hour12Handler);})();;(function(window,undefined){function L10nError(message,id,loc){this.name='L10nError';this.message=message;this.id=id;this.loc=loc;}
L10nError.prototype=Object.create(Error.prototype);L10nError.prototype.constructor=L10nError;var io={load:function load(url,callback,sync){var xhr=new XMLHttpRequest();if(xhr.overrideMimeType){xhr.overrideMimeType('text/plain');}
xhr.open('GET',url,!sync);xhr.addEventListener('load',function io_load(e){if(e.target.status===200||e.target.status===0){callback(null,e.target.responseText);}else{callback(new L10nError('Not found: '+url));}});xhr.addEventListener('error',callback);xhr.addEventListener('timeout',callback);try{xhr.send(null);}catch(e){callback(new L10nError('Not found: '+url));}},loadJSON:function loadJSON(url,callback){var xhr=new XMLHttpRequest();if(xhr.overrideMimeType){xhr.overrideMimeType('application/json');}
xhr.open('GET',url);xhr.responseType='json';xhr.addEventListener('load',function io_loadjson(e){if(e.target.status===200||e.target.status===0){callback(null,e.target.response);}else{callback(new L10nError('Not found: '+url));}});xhr.addEventListener('error',callback);xhr.addEventListener('timeout',callback);try{xhr.send(null);}catch(e){callback(new L10nError('Not found: '+url));}}};function EventEmitter(){}
EventEmitter.prototype.emit=function ee_emit(){if(!this._listeners){return;}
var args=Array.prototype.slice.call(arguments);var type=args.shift();if(!this._listeners[type]){return;}
var typeListeners=this._listeners[type].slice();for(var i=0;i<typeListeners.length;i++){typeListeners[i].apply(this,args);}};EventEmitter.prototype.addEventListener=function ee_add(type,listener){if(!this._listeners){this._listeners={};}
if(!(type in this._listeners)){this._listeners[type]=[];}
this._listeners[type].push(listener);};EventEmitter.prototype.removeEventListener=function ee_rm(type,listener){if(!this._listeners){return;}
var typeListeners=this._listeners[type];var pos=typeListeners.indexOf(listener);if(pos===-1){return;}
typeListeners.splice(pos,1);};function getPluralRule(lang){var locales2rules={'af':3,'ak':4,'am':4,'ar':1,'asa':3,'az':0,'be':11,'bem':3,'bez':3,'bg':3,'bh':4,'bm':0,'bn':3,'bo':0,'br':20,'brx':3,'bs':11,'ca':3,'cgg':3,'chr':3,'cs':12,'cy':17,'da':3,'de':3,'dv':3,'dz':0,'ee':3,'el':3,'en':3,'eo':3,'es':3,'et':3,'eu':3,'fa':0,'ff':5,'fi':3,'fil':4,'fo':3,'fr':5,'fur':3,'fy':3,'ga':8,'gd':24,'gl':3,'gsw':3,'gu':3,'guw':4,'gv':23,'ha':3,'haw':3,'he':2,'hi':4,'hr':11,'hu':0,'id':0,'ig':0,'ii':0,'is':3,'it':3,'iu':7,'ja':0,'jmc':3,'jv':0,'ka':0,'kab':5,'kaj':3,'kcg':3,'kde':0,'kea':0,'kk':3,'kl':3,'km':0,'kn':0,'ko':0,'ksb':3,'ksh':21,'ku':3,'kw':7,'lag':18,'lb':3,'lg':3,'ln':4,'lo':0,'lt':10,'lv':6,'mas':3,'mg':4,'mk':16,'ml':3,'mn':3,'mo':9,'mr':3,'ms':0,'mt':15,'my':0,'nah':3,'naq':7,'nb':3,'nd':3,'ne':3,'nl':3,'nn':3,'no':3,'nr':3,'nso':4,'ny':3,'nyn':3,'om':3,'or':3,'pa':3,'pap':3,'pl':13,'ps':3,'pt':3,'rm':3,'ro':9,'rof':3,'ru':11,'rwk':3,'sah':0,'saq':3,'se':7,'seh':3,'ses':0,'sg':0,'sh':11,'shi':19,'sk':12,'sl':14,'sma':7,'smi':7,'smj':7,'smn':7,'sms':7,'sn':3,'so':3,'sq':3,'sr':11,'ss':3,'ssy':3,'st':3,'sv':3,'sw':3,'syr':3,'ta':3,'te':3,'teo':3,'th':0,'ti':4,'tig':3,'tk':3,'tl':4,'tn':3,'to':0,'tr':0,'ts':3,'tzm':22,'uk':11,'ur':3,'ve':3,'vi':0,'vun':3,'wa':4,'wae':3,'wo':0,'xh':3,'xog':3,'yo':0,'zh':0,'zu':3};function isIn(n,list){return list.indexOf(n)!==-1;}
function isBetween(n,start,end){return typeof n===typeof start&&start<=n&&n<=end;}
var pluralRules={'0':function(){return'other';},'1':function(n){if((isBetween((n%100),3,10))){return'few';}
if(n===0){return'zero';}
if((isBetween((n%100),11,99))){return'many';}
if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'2':function(n){if(n!==0&&(n%10)===0){return'many';}
if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'3':function(n){if(n===1){return'one';}
return'other';},'4':function(n){if((isBetween(n,0,1))){return'one';}
return'other';},'5':function(n){if((isBetween(n,0,2))&&n!==2){return'one';}
return'other';},'6':function(n){if(n===0){return'zero';}
if((n%10)===1&&(n%100)!==11){return'one';}
return'other';},'7':function(n){if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'8':function(n){if((isBetween(n,3,6))){return'few';}
if((isBetween(n,7,10))){return'many';}
if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'9':function(n){if(n===0||n!==1&&(isBetween((n%100),1,19))){return'few';}
if(n===1){return'one';}
return'other';},'10':function(n){if((isBetween((n%10),2,9))&&!(isBetween((n%100),11,19))){return'few';}
if((n%10)===1&&!(isBetween((n%100),11,19))){return'one';}
return'other';},'11':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14))){return'few';}
if((n%10)===0||(isBetween((n%10),5,9))||(isBetween((n%100),11,14))){return'many';}
if((n%10)===1&&(n%100)!==11){return'one';}
return'other';},'12':function(n){if((isBetween(n,2,4))){return'few';}
if(n===1){return'one';}
return'other';},'13':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14))){return'few';}
if(n!==1&&(isBetween((n%10),0,1))||(isBetween((n%10),5,9))||(isBetween((n%100),12,14))){return'many';}
if(n===1){return'one';}
return'other';},'14':function(n){if((isBetween((n%100),3,4))){return'few';}
if((n%100)===2){return'two';}
if((n%100)===1){return'one';}
return'other';},'15':function(n){if(n===0||(isBetween((n%100),2,10))){return'few';}
if((isBetween((n%100),11,19))){return'many';}
if(n===1){return'one';}
return'other';},'16':function(n){if((n%10)===1&&n!==11){return'one';}
return'other';},'17':function(n){if(n===3){return'few';}
if(n===0){return'zero';}
if(n===6){return'many';}
if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'18':function(n){if(n===0){return'zero';}
if((isBetween(n,0,2))&&n!==0&&n!==2){return'one';}
return'other';},'19':function(n){if((isBetween(n,2,10))){return'few';}
if((isBetween(n,0,1))){return'one';}
return'other';},'20':function(n){if((isBetween((n%10),3,4)||((n%10)===9))&&!(isBetween((n%100),10,19)||isBetween((n%100),70,79)||isBetween((n%100),90,99))){return'few';}
if((n%1000000)===0&&n!==0){return'many';}
if((n%10)===2&&!isIn((n%100),[12,72,92])){return'two';}
if((n%10)===1&&!isIn((n%100),[11,71,91])){return'one';}
return'other';},'21':function(n){if(n===0){return'zero';}
if(n===1){return'one';}
return'other';},'22':function(n){if((isBetween(n,0,1))||(isBetween(n,11,99))){return'one';}
return'other';},'23':function(n){if((isBetween((n%10),1,2))||(n%20)===0){return'one';}
return'other';},'24':function(n){if((isBetween(n,3,10)||isBetween(n,13,19))){return'few';}
if(isIn(n,[2,12])){return'two';}
if(isIn(n,[1,11])){return'one';}
return'other';}};var index=locales2rules[lang.replace(/-.*$/,'')];if(!(index in pluralRules)){return function(){return'other';};}
return pluralRules[index];}
var MAX_PLACEABLES=100;var PropertiesParser={patterns:null,entryIds:null,init:function(){this.patterns={comment:/^\s*#|^\s*$/,entity:/^([^=\s]+)\s*=\s*(.+)$/,multiline:/[^\\]\\$/,index:/\{\[\s*(\w+)(?:\(([^\)]*)\))?\s*\]\}/i,unicode:/\\u([0-9a-fA-F]{1,4})/g,entries:/[^\r\n]+/g,controlChars:/\\([\\\n\r\t\b\f\{\}\"\'])/g,placeables:/\{\{\s*([^\s]*?)\s*\}\}/,};},parse:function(ctx,source){if(!this.patterns){this.init();}
var ast=[];this.entryIds=Object.create(null);var entries=source.match(this.patterns.entries);if(!entries){return ast;}
for(var i=0;i<entries.length;i++){var line=entries[i];if(this.patterns.comment.test(line)){continue;}
while(this.patterns.multiline.test(line)&&i<entries.length){line=line.slice(0,-1)+entries[++i].trim();}
var entityMatch=line.match(this.patterns.entity);if(entityMatch){try{this.parseEntity(entityMatch[1],entityMatch[2],ast);}catch(e){if(ctx){ctx._emitter.emit('parseerror',e);}else{throw e;}}}}
return ast;},parseEntity:function(id,value,ast){var name,key;var pos=id.indexOf('[');if(pos!==-1){name=id.substr(0,pos);key=id.substring(pos+1,id.length-1);}else{name=id;key=null;}
var nameElements=name.split('.');if(nameElements.length>2){throw new L10nError('Error in ID: "'+name+'".'+' Nested attributes are not supported.');}
var attr;if(nameElements.length>1){name=nameElements[0];attr=nameElements[1];if(attr[0]==='$'){throw new L10nError('Attribute can\'t start with "$"',id);}}else{attr=null;}
this.setEntityValue(name,attr,key,this.unescapeString(value),ast);},setEntityValue:function(id,attr,key,value,ast){var pos,v;if(value.indexOf('{{')!==-1){value=this.parseString(value);}
if(attr){pos=this.entryIds[id];if(pos===undefined){v={$i:id};if(key){v[attr]={};v[attr][key]=value;}else{v[attr]=value;}
ast.push(v);this.entryIds[id]=ast.length-1;return;}
if(key){if(typeof(ast[pos][attr])==='string'){ast[pos][attr]={$x:this.parseIndex(ast[pos][attr]),$v:{}};}
ast[pos][attr].$v[key]=value;return;}
ast[pos][attr]=value;return;}
if(key){pos=this.entryIds[id];if(pos===undefined){v={};v[key]=value;ast.push({$i:id,$v:v});this.entryIds[id]=ast.length-1;return;}
if(typeof(ast[pos].$v)==='string'){ast[pos].$x=this.parseIndex(ast[pos].$v);ast[pos].$v={};}
ast[pos].$v[key]=value;return;}
ast.push({$i:id,$v:value});this.entryIds[id]=ast.length-1;},parseString:function(str){var chunks=str.split(this.patterns.placeables);var complexStr=[];var len=chunks.length;var placeablesCount=(len-1)/2;if(placeablesCount>=MAX_PLACEABLES){throw new L10nError('Too many placeables ('+placeablesCount+', max allowed is '+MAX_PLACEABLES+')');}
for(var i=0;i<chunks.length;i++){if(chunks[i].length===0){continue;}
if(i%2===1){complexStr.push({t:'idOrVar',v:chunks[i]});}else{complexStr.push(chunks[i]);}}
return complexStr;},unescapeString:function(str){if(str.lastIndexOf('\\')!==-1){str=str.replace(this.patterns.controlChars,'$1');}
return str.replace(this.patterns.unicode,function(match,token){return unescape('%u'+'0000'.slice(token.length)+token);});},parseIndex:function(str){var match=str.match(this.patterns.index);if(!match){throw new L10nError('Malformed index');}
if(match[2]){return[{t:'idOrVar',v:match[1]},match[2]];}else{return[{t:'idOrVar',v:match[1]}];}}};var KNOWN_MACROS=['plural'];var MAX_PLACEABLE_LENGTH=2500;var rePlaceables=/\{\{\s*(.+?)\s*\}\}/g;function createEntry(node,env){var keys=Object.keys(node);if(typeof node.$v==='string'&&keys.length===2){return node.$v;}
var attrs;for(var i=0,key;key=keys[i];i++){if(key[0]==='$'){continue;}
if(!attrs){attrs=Object.create(null);}
attrs[key]=createAttribute(node[key],env,node.$i+'.'+key);}
return{id:node.$i,value:node.$v===undefined?null:node.$v,index:node.$x||null,attrs:attrs||null,env:env,dirty:false};}
function createAttribute(node,env,id){if(typeof node==='string'){return node;}
var value;if(Array.isArray(node)){value=node;}
return{id:id,value:value||node.$v||null,index:node.$x||null,env:env,dirty:false};}
function format(args,entity){if(typeof entity==='string'){return entity;}
if(entity.dirty){throw new L10nError('Cyclic reference detected: '+entity.id);}
entity.dirty=true;var val;try{val=resolveValue(args,entity.env,entity.value,entity.index);}finally{entity.dirty=false;}
return val;}
function resolveIdentifier(args,env,id){if(KNOWN_MACROS.indexOf(id)>-1){return env['__'+id];}
if(args&&args.hasOwnProperty(id)){if(typeof args[id]==='string'||(typeof args[id]==='number'&&!isNaN(args[id]))){return args[id];}else{throw new L10nError('Arg must be a string or a number: '+id);}}
if(id in env&&id!=='__proto__'){return format(args,env[id]);}
throw new L10nError('Unknown reference: '+id);}
function subPlaceable(args,env,id){var value;try{value=resolveIdentifier(args,env,id);}catch(err){return'{{ '+id+' }}';}
if(typeof value==='number'){return value;}
if(typeof value==='string'){if(value.length>=MAX_PLACEABLE_LENGTH){throw new L10nError('Too many characters in placeable ('+
value.length+', max allowed is '+
MAX_PLACEABLE_LENGTH+')');}
return value;}
return'{{ '+id+' }}';}
function interpolate(args,env,arr){return arr.reduce(function(prev,cur){if(typeof cur==='string'){return prev+cur;}else if(cur.t==='idOrVar'){return prev+subPlaceable(args,env,cur.v);}},'');}
function resolveSelector(args,env,expr,index){var selectorName=index[0].v;var selector=resolveIdentifier(args,env,selectorName);if(typeof selector!=='function'){return selector;}
var argValue=index[1]?resolveIdentifier(args,env,index[1]):undefined;if(selector===env.__plural){if(argValue===0&&'zero'in expr){return'zero';}
if(argValue===1&&'one'in expr){return'one';}
if(argValue===2&&'two'in expr){return'two';}}
return selector(argValue);}
function resolveValue(args,env,expr,index){if(typeof expr==='string'||typeof expr==='boolean'||typeof expr==='number'||!expr){return expr;}
if(Array.isArray(expr)){return interpolate(args,env,expr);}
if(index){var selector=resolveSelector(args,env,expr,index);if(expr.hasOwnProperty(selector)){return resolveValue(args,env,expr[selector]);}}
if('other'in expr){return resolveValue(args,env,expr.other);}
throw new L10nError('Unresolvable value');}
var Resolver={createEntry:createEntry,format:format,rePlaceables:rePlaceables};function walkContent(node,fn){if(typeof node==='string'){return fn(node);}
if(node.t==='idOrVar'){return node;}
var rv=Array.isArray(node)?[]:{};var keys=Object.keys(node);for(var i=0,key;key=keys[i];i++){if(key==='$i'||key==='$x'){rv[key]=node[key];}else{rv[key]=walkContent(node[key],fn);}}
return rv;}
var reAlphas=/[a-zA-Z]/g;var reVowels=/[aeiouAEIOU]/g;var ACCENTED_MAP='\u0226\u0181\u0187\u1E12\u1E16\u0191\u0193\u0126\u012A'+'\u0134\u0136\u013F\u1E3E\u0220\u01FE\u01A4\u024A\u0158'+'\u015E\u0166\u016C\u1E7C\u1E86\u1E8A\u1E8E\u1E90'+'[\\]^_`'+'\u0227\u0180\u0188\u1E13\u1E17\u0192\u0260\u0127\u012B'+'\u0135\u0137\u0140\u1E3F\u019E\u01FF\u01A5\u024B\u0159'+'\u015F\u0167\u016D\u1E7D\u1E87\u1E8B\u1E8F\u1E91';var FLIPPED_MAP='\u2200\u0510\u2183p\u018E\u025F\u05E4HI\u017F'+'\u04FC\u02E5WNO\u0500\xD2\u1D1AS\u22A5\u2229\u0245'+'\uFF2DX\u028EZ'+'[\\]\u1D65_,'+'\u0250q\u0254p\u01DD\u025F\u0183\u0265\u0131\u027E'+'\u029E\u0285\u026Fuodb\u0279s\u0287n\u028C\u028Dx\u028Ez';function makeLonger(val){return val.replace(reVowels,function(match){return match+match.toLowerCase();});}
function makeAccented(map,val){return val.replace(reAlphas,function(match){return map.charAt(match.charCodeAt(0)-65);});}
var reWords=/[^\W0-9_]+/g;function makeRTL(val){return val.replace(reWords,function(match){return'\u202e'+match+'\u202c';});}
var reExcluded=/(%[EO]?\w|\{\s*.+?\s*\})/;function mapContent(fn,val){if(!val){return val;}
var parts=val.split(reExcluded);var modified=parts.map(function(part){if(reExcluded.test(part)){return part;}
return fn(part);});return modified.join('');}
function Pseudo(id,name,charMap,modFn){this.id=id;this.translate=mapContent.bind(null,function(val){return makeAccented(charMap,modFn(val));});this.name=this.translate(name);}
var PSEUDO_STRATEGIES={'qps-ploc':new Pseudo('qps-ploc','Accented English',ACCENTED_MAP,makeLonger),'qps-plocm':new Pseudo('qps-plocm','Mirrored English',FLIPPED_MAP,makeRTL)};function Locale(id,ctx){this.id=id;this.ctx=ctx;this.isReady=false;this.isPseudo=PSEUDO_STRATEGIES.hasOwnProperty(id);this.entries=Object.create(null);this.entries.__plural=getPluralRule(this.isPseudo?this.ctx.defaultLocale:id);}
Locale.prototype.build=function L_build(callback){var sync=!callback;var ctx=this.ctx;var self=this;var l10nLoads=ctx.resLinks.length;function onL10nLoaded(err){if(err){ctx._emitter.emit('fetcherror',err);}
if(--l10nLoads<=0){self.isReady=true;if(callback){callback();}}}
if(l10nLoads===0){onL10nLoaded();return;}
function onJSONLoaded(err,json){if(!err&&json){self.addAST(json);}
onL10nLoaded(err);}
function onPropLoaded(err,source){if(!err&&source){var ast=PropertiesParser.parse(ctx,source);self.addAST(ast);}
onL10nLoaded(err);}
var idToFetch=this.isPseudo?ctx.defaultLocale:this.id;for(var i=0;i<ctx.resLinks.length;i++){var resLink=decodeURI(ctx.resLinks[i]);var path=resLink.replace('{locale}',idToFetch);var type=path.substr(path.lastIndexOf('.')+1);switch(type){case'json':io.loadJSON(path,onJSONLoaded,sync);break;case'properties':io.load(path,onPropLoaded,sync);break;}}};function createPseudoEntry(node,entries){return Resolver.createEntry(walkContent(node,PSEUDO_STRATEGIES[this.id].translate),entries);}
Locale.prototype.addAST=function(ast){var createEntry=this.isPseudo?createPseudoEntry.bind(this):Resolver.createEntry;for(var i=0,node;node=ast[i];i++){this.entries[node.$i]=createEntry(node,this.entries);}};function Context(id){this.id=id;this.isReady=false;this.isLoading=false;this.defaultLocale='en-US';this.availableLocales=[];this.supportedLocales=[];this.resLinks=[];this.locales={};this._emitter=new EventEmitter();this._ready=new Promise(this.once.bind(this));}
function reportMissing(id,err){this._emitter.emit('notfounderror',err);return id;}
function getWithFallback(id){var cur=0;var loc;var locale;while(loc=this.supportedLocales[cur]){locale=this.getLocale(loc);if(!locale.isReady){locale.build(null);}
var entry=locale.entries[id];if(entry===undefined){cur++;reportMissing.call(this,id,new L10nError('"'+id+'"'+' not found in '+loc+' in '+this.id,id,loc));continue;}
return entry;}
throw new L10nError('"'+id+'"'+' missing from all supported locales in '+this.id,id);}
function formatValue(args,entity){if(typeof entity==='string'){return entity;}
try{return Resolver.format(args,entity);}catch(err){this._emitter.emit('resolveerror',err);return entity.id;}}
function formatEntity(args,entity){if(!entity.attrs){return{value:formatValue.call(this,args,entity),attrs:null};}
var formatted={value:formatValue.call(this,args,entity),attrs:Object.create(null)};for(var key in entity.attrs){formatted.attrs[key]=formatValue.call(this,args,entity.attrs[key]);}
return formatted;}
function formatAsync(fn,id,args){return this._ready.then(getWithFallback.bind(this,id)).then(fn.bind(this,args),reportMissing.bind(this,id));}
Context.prototype.formatValue=function(id,args){return formatAsync.call(this,formatValue,id,args);};Context.prototype.formatEntity=function(id,args){return formatAsync.call(this,formatEntity,id,args);};function legacyGet(fn,id,args){if(!this.isReady){throw new L10nError('Context not ready');}
var entry;try{entry=getWithFallback.call(this,id);}catch(err){if(err.loc){throw err;}
reportMissing.call(this,id,err);return'';}
return fn.call(this,args,entry);}
Context.prototype.get=function(id,args){return legacyGet.call(this,formatValue,id,args);};Context.prototype.getEntity=function(id,args){return legacyGet.call(this,formatEntity,id,args);};Context.prototype.getLocale=function getLocale(code){var locales=this.locales;if(locales[code]){return locales[code];}
return locales[code]=new Locale(code,this);};function negotiate(available,requested,defaultLocale){if(available.indexOf(requested[0])===-1||requested[0]===defaultLocale){return[defaultLocale];}else{return[requested[0],defaultLocale];}}
function freeze(supported){var locale=this.getLocale(supported[0]);if(locale.isReady){setReady.call(this,supported);}else{locale.build(setReady.bind(this,supported));}}
function setReady(supported){this.supportedLocales=supported;this.isReady=true;this._emitter.emit('ready');}
Context.prototype.registerLocales=function(defLocale,available){this.availableLocales=[this.defaultLocale=defLocale];if(available){for(var i=0,loc;loc=available[i];i++){if(this.availableLocales.indexOf(loc)===-1){this.availableLocales.push(loc);}}}};Context.prototype.requestLocales=function requestLocales(){if(this.isLoading&&!this.isReady){throw new L10nError('Context not ready');}
this.isLoading=true;var requested=Array.prototype.slice.call(arguments);if(requested.length===0){throw new L10nError('No locales requested');}
var reqPseudo=requested.filter(function(loc){return loc in PSEUDO_STRATEGIES;});var supported=negotiate(this.availableLocales.concat(reqPseudo),requested,this.defaultLocale);freeze.call(this,supported);};Context.prototype.addEventListener=function(type,listener){this._emitter.addEventListener(type,listener);};Context.prototype.removeEventListener=function(type,listener){this._emitter.removeEventListener(type,listener);};Context.prototype.ready=function(callback){if(this.isReady){setTimeout(callback);}
this.addEventListener('ready',callback);};Context.prototype.once=function(callback){if(this.isReady){setTimeout(callback);return;}
var callAndRemove=(function(){this.removeEventListener('ready',callAndRemove);callback();}).bind(this);this.addEventListener('ready',callAndRemove);};var DEBUG=false;var isPretranslated=false;var rtlList=['ar','he','fa','ps','qps-plocm','ur'];var nodeObserver=null;var pendingElements=null;var meta={};var moConfig={attributes:true,characterData:false,childList:true,subtree:true,attributeFilter:['data-l10n-id','data-l10n-args']};navigator.mozL10n={ctx:new Context(window.document?document.URL:null),get:function get(id,ctxdata){return navigator.mozL10n.ctx.get(id,ctxdata);},formatValue:function(id,ctxdata){return navigator.mozL10n.ctx.formatValue(id,ctxdata);},formatEntity:function(id,ctxdata){return navigator.mozL10n.ctx.formatEntity(id,ctxdata);},translateFragment:function(fragment){return translateFragment.call(navigator.mozL10n,fragment);},setAttributes:setL10nAttributes,getAttributes:getL10nAttributes,ready:function ready(callback){return navigator.mozL10n.ctx.ready(callback);},once:function once(callback){return navigator.mozL10n.ctx.once(callback);},get readyState(){return navigator.mozL10n.ctx.isReady?'complete':'loading';},language:{set code(lang){navigator.mozL10n.ctx.requestLocales(lang);},get code(){return navigator.mozL10n.ctx.supportedLocales[0];},get direction(){return getDirection(navigator.mozL10n.ctx.supportedLocales[0]);}},qps:PSEUDO_STRATEGIES,_getInternalAPI:function(){return{Error:L10nError,Context:Context,Locale:Locale,Resolver:Resolver,getPluralRule:getPluralRule,rePlaceables:rePlaceables,translateDocument:translateDocument,onMetaInjected:onMetaInjected,PropertiesParser:PropertiesParser,walkContent:walkContent};}};navigator.mozL10n.ctx.ready(onReady.bind(navigator.mozL10n));navigator.mozL10n.ctx.addEventListener('notfounderror',function reportMissingEntity(e){if(DEBUG||e.loc==='en-US'){console.warn(e.toString());}});if(DEBUG){navigator.mozL10n.ctx.addEventListener('manifesterror',console.error.bind(console));navigator.mozL10n.ctx.addEventListener('fetcherror',console.error.bind(console));navigator.mozL10n.ctx.addEventListener('parseerror',console.error.bind(console));navigator.mozL10n.ctx.addEventListener('resolveerror',console.error.bind(console));}
function getDirection(lang){return(rtlList.indexOf(lang)>=0)?'rtl':'ltr';}
var readyStates={'loading':0,'interactive':1,'complete':2};function waitFor(state,callback){state=readyStates[state];if(readyStates[document.readyState]>=state){callback();return;}
document.addEventListener('readystatechange',function l10n_onrsc(){if(readyStates[document.readyState]>=state){document.removeEventListener('readystatechange',l10n_onrsc);callback();}});}
if(window.document){isPretranslated=!PSEUDO_STRATEGIES.hasOwnProperty(navigator.language)&&(document.documentElement.lang===navigator.language);var pretranslate=document.documentElement.dataset.noCompleteBug?true:!isPretranslated;waitFor('interactive',init.bind(navigator.mozL10n,pretranslate));}
function initObserver(){nodeObserver=new MutationObserver(onMutations.bind(navigator.mozL10n));nodeObserver.observe(document,moConfig);}
function init(pretranslate){if(pretranslate){initResources.call(navigator.mozL10n);}else{initObserver();window.setTimeout(initResources.bind(navigator.mozL10n));}}
function initResources(){var nodes=document.head.querySelectorAll('link[rel="localization"],'+'meta[name="availableLanguages"],'+'meta[name="defaultLanguage"],'+'script[type="application/l10n"]');for(var i=0,node;node=nodes[i];i++){var type=node.getAttribute('rel')||node.nodeName.toLowerCase();switch(type){case'localization':this.ctx.resLinks.push(node.getAttribute('href'));break;case'meta':onMetaInjected.call(this,node);break;case'script':onScriptInjected.call(this,node);break;}}
if(!this.ctx.availableLocales.length){this.ctx.registerLocales(this.ctx.defaultLocale);}
return initLocale.call(this);}
function splitAvailableLanguagesString(str){return str.split(',').map(function(lang){lang=lang.trim().split(':');return lang[0];});}
function onMetaInjected(node){if(this.ctx.availableLocales.length){return;}
switch(node.getAttribute('name')){case'availableLanguages':meta.availableLanguages=splitAvailableLanguagesString(node.getAttribute('content'));break;case'defaultLanguage':meta.defaultLanguage=node.getAttribute('content');break;}
if(Object.keys(meta).length===2){this.ctx.registerLocales(meta.defaultLanguage,meta.availableLanguages);meta={};}}
function onScriptInjected(node){var lang=node.getAttribute('lang');var locale=this.ctx.getLocale(lang);locale.addAST(JSON.parse(node.textContent));}
function initLocale(){this.ctx.requestLocales.apply(this.ctx,navigator.languages||[navigator.language]);window.addEventListener('languagechange',function l10n_langchange(){this.ctx.requestLocales.apply(this.ctx,navigator.languages||[navigator.language]);}.bind(this));}
function localizeMutations(mutations){var mutation;var targets=new Set();for(var i=0;i<mutations.length;i++){mutation=mutations[i];if(mutation.type==='childList'){var addedNode;for(var j=0;j<mutation.addedNodes.length;j++){addedNode=mutation.addedNodes[j];if(addedNode.nodeType!==Node.ELEMENT_NODE){continue;}
targets.add(addedNode);}}
if(mutation.type==='attributes'){targets.add(mutation.target);}}
targets.forEach(function(target){if(target.childElementCount){translateFragment.call(this,target);}else if(target.hasAttribute('data-l10n-id')){translateElement.call(this,target);}},this);}
function onMutations(mutations,self){self.disconnect();localizeMutations.call(this,mutations);self.observe(document,moConfig);}
function onReady(){if(!isPretranslated){translateDocument.call(this);}
isPretranslated=false;if(pendingElements){for(var i=0,element;element=pendingElements[i];i++){translateElement.call(this,element);}
pendingElements=null;}
if(!nodeObserver){initObserver();}
fireLocalizedEvent.call(this);}
function fireLocalizedEvent(){var event=new CustomEvent('localized',{'bubbles':false,'cancelable':false,'detail':{'language':this.ctx.supportedLocales[0]}});window.dispatchEvent(event);}
function translateDocument(){document.documentElement.lang=this.language.code;document.documentElement.dir=this.language.direction;translateFragment.call(this,document.documentElement);}
function translateFragment(element){if(element.hasAttribute('data-l10n-id')){translateElement.call(this,element);}
var nodes=getTranslatableChildren(element);for(var i=0;i<nodes.length;i++){translateElement.call(this,nodes[i]);}}
function setL10nAttributes(element,id,args){element.setAttribute('data-l10n-id',id);if(args){element.setAttribute('data-l10n-args',JSON.stringify(args));}}
function getL10nAttributes(element){return{id:element.getAttribute('data-l10n-id'),args:JSON.parse(element.getAttribute('data-l10n-args'))};}
function getTranslatableChildren(element){return element?element.querySelectorAll('*[data-l10n-id]'):[];}
var allowedHtmlAttrs={'ariaLabel':'aria-label','ariaValueText':'aria-valuetext','ariaMozHint':'aria-moz-hint'};function translateElement(element){if(!this.ctx.isReady){if(!pendingElements){pendingElements=[];}
pendingElements.push(element);return;}
var l10n=getL10nAttributes(element);if(!l10n.id){return false;}
var entity=this.ctx.getEntity(l10n.id,l10n.args);if(!entity){return false;}
if(typeof entity.value==='string'){setTextContent.call(this,l10n.id,element,entity.value);}
for(var key in entity.attrs){var attr=entity.attrs[key];if(allowedHtmlAttrs.hasOwnProperty(key)){element.setAttribute(allowedHtmlAttrs[key],attr);}else if(key==='innerHTML'){element.innerHTML=attr;}else{element.setAttribute(key,attr);}}
return true;}
function setTextContent(id,element,text){if(element.firstElementChild){throw new L10nError('setTextContent is deprecated (https://bugzil.la/1053629). '+'Setting text content of elements with child elements is no longer '+'supported by l10n.js. Offending data-l10n-id: "'+id+'" on element '+element.outerHTML+' in '+this.ctx.id);}
element.textContent=text;}})(this);;navigator.mozL10n.DateTimeFormat=function(locales,options){var _=navigator.mozL10n.get;function localeFormat(d,format){var tokens=format.match(/(%E.|%O.|%.)/g);for(var i=0;tokens&&i<tokens.length;i++){var value='';switch(tokens[i]){case'%a':value=_('weekday-'+d.getDay()+'-short');break;case'%A':value=_('weekday-'+d.getDay()+'-long');break;case'%b':case'%h':value=_('month-'+d.getMonth()+'-short');break;case'%B':value=_('month-'+d.getMonth()+'-long');break;case'%Eb':value=_('month-'+d.getMonth()+'-genitive');break;case'%I':value=d.getHours()%12||12;break;case'%e':value=d.getDate();break;case'%p':value=d.getHours()<12?_('time_am'):_('time_pm');break;case'%c':case'%x':case'%X':var tmp=_('dateTimeFormat_'+tokens[i]);if(tmp&&!(/(%c|%x|%X)/).test(tmp)){value=localeFormat(d,tmp);}
break;}
format=format.replace(tokens[i],value||d.toLocaleFormat(tokens[i]));}
return format;}
function relativeParts(seconds){seconds=Math.abs(seconds);var descriptors={};var units=['years',86400*365,'months',86400*30,'weeks',86400*7,'days',86400,'hours',3600,'minutes',60];if(seconds<60){return{minutes:Math.round(seconds/60)};}
for(var i=0,uLen=units.length;i<uLen;i+=2){var value=units[i+1];if(seconds>=value){descriptors[units[i]]=Math.floor(seconds/value);seconds-=descriptors[units[i]]*value;}}
return descriptors;}
function prettyDate(time,useCompactFormat,maxDiff){maxDiff=maxDiff||86400*10;switch(time.constructor){case String:time=parseInt(time);break;case Date:time=time.getTime();break;}
var secDiff=(Date.now()-time)/1000;if(isNaN(secDiff)){return _('incorrectDate');}
if(Math.abs(secDiff)>60){secDiff=secDiff>0?Math.ceil(secDiff):Math.floor(secDiff);}
if(secDiff>maxDiff){return localeFormat(new Date(time),'%x');}
var f=useCompactFormat?'-short':'-long';var parts=relativeParts(secDiff);var affix=secDiff>=0?'-ago':'-until';for(var i in parts){return _(i+affix+f,{value:parts[i]});}}
return{localeDateString:function localeDateString(d){return localeFormat(d,'%x');},localeTimeString:function localeTimeString(d){return localeFormat(d,'%X');},localeString:function localeString(d){return localeFormat(d,'%c');},localeFormat:localeFormat,fromNow:prettyDate,relativeParts:relativeParts};};;(function(window){var performance=window.performance;var console=window.console;if(typeof performance.mark==='function'){return;}
var logEntry=function(entry){setTimeout(function(){var message='Performance Entry: '+
entry.entryType+'|'+
entry.name+'|'+
entry.startTime+'|'+
entry.duration+'|'+
(entry.time||0);console.log(message);},0);};var marks={};performance.mark=function(markName){var now=performance.now();var epoch=Date.now();if(typeof markName==='undefined'){throw new SyntaxError('Mark name must be specified');}
if(performance.timing&&markName in performance.timing){throw new SyntaxError('Mark name is not allowed');}
if(!marks[markName]){marks[markName]=[];}
marks[markName].push(now);logEntry({entryType:'mark',name:markName,startTime:now,duration:0,time:epoch});};performance.measure=function(measureName,startMark,endMark){var now=performance.now();var epoch=Date.now();if(!measureName){throw new Error('Measure must be specified');}
if(!startMark){logEntry({entryType:'measure',name:measureName,startTime:0,duration:now,time:epoch});return;}
var startMarkTime=0;if(performance.timing&&startMark in performance.timing){if(startMark!=='navigationStart'&&performance.timing[startMark]===0){throw new Error(startMark+' has a timing of 0');}
startMarkTime=performance.timing[startMark]-
performance.timing.navigationStart;}else{if(startMark in marks){startMarkTime=marks[startMark][marks[startMark].length-1];}else{throw new Error(startMark+' mark not found');}}
var endMarkTime=now;if(endMark){endMarkTime=0;if(performance.timing&&endMark in performance.timing){if(endMark!=='navigationStart'&&performance.timing[endMark]===0){throw new Error(endMark+' has a timing of 0');}
endMarkTime=performance.timing[endMark]-
performance.timing.navigationStart;}else{if(endMark in marks){endMarkTime=marks[endMark][marks[endMark].length-1];}else{throw new Error(endMark+' mark not found');}}}
var duration=endMarkTime-startMarkTime;logEntry({entryType:'measure',name:measureName,startTime:startMarkTime,duration:duration,time:epoch});};if(typeof define!=='undefined'&&define.amd){define([],function(){return performance;});}else if(typeof module!=='undefined'&&typeof module.exports!=='undefined'){module.exports=performance;}}(typeof window!=='undefined'?window:undefined));;(function(exports){exports.ComponentUtils={style:function(baseUrl){var style=document.createElement('style');var url=baseUrl+'style.css';var self=this;style.setAttribute('scoped','');style.innerHTML='@import url('+url+');';this.appendChild(style);this.style.visibility='hidden';style.addEventListener('load',function(){if(self.shadowRoot){self.shadowRoot.appendChild(style.cloneNode(true));}
self.style.visibility='';});}};}(window));;window.GaiaSubheader=(function(win){var proto=Object.create(HTMLElement.prototype);var baseurl=window.GaiaSubheaderBaseurl||'/shared/elements/gaia_subheader/';proto.createdCallback=function(){ComponentUtils.style.call(this,baseurl);};return document.registerElement('gaia-subheader',{prototype:proto});})(window);;window.COMPONENTS_BASE_URL='/shared/elements/';;!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var f;"undefined"!=typeof window?f=window:"undefined"!=typeof global?f=global:"undefined"!=typeof self&&(f=self),f.GaiaHeader=e()}}(function(){var define,module,exports;return(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){;(function(define){define(function(require,exports,module){var textContent=Object.getOwnPropertyDescriptor(Node.prototype,'textContent');var removeAttribute=HTMLElement.prototype.removeAttribute;var setAttribute=HTMLElement.prototype.setAttribute;var noop=function(){};var hasShadowCSS=(function(){var div=document.createElement('div');try{div.querySelector(':host');return true;}
catch(e){return false;}})();module.exports.register=function(name,props){injectGlobalCss(props.globalCss);delete props.globalCSS;var proto=Object.assign(Object.create(base),props);var output=extractLightDomCSS(proto.template,name);var _attrs=Object.assign(props.attrs||{},attrs);proto.template=output.template;proto.lightCss=output.lightCss;Object.defineProperties(proto,_attrs);var El=document.registerElement(name,{prototype:proto});return El;};var base=Object.assign(Object.create(HTMLElement.prototype),{attributeChanged:noop,attached:noop,detached:noop,created:noop,template:'',createdCallback:function(){this.injectLightCss(this);this.created();},attributeChangedCallback:function(name,from,to){if(this.attrs&&this.attrs[name]){this[name]=to;}
this.attributeChanged(name,from,to);},attachedCallback:function(){this.attached();},detachedCallback:function(){this.detached();},setAttr:function(name,value){var internal=this.shadowRoot.firstElementChild;setAttribute.call(internal,name,value);setAttribute.call(this,name,value);},removeAttr:function(){var internal=this.shadowRoot.firstElementChild;removeAttribute.call(internal,name,value);removeAttribute.call(this,name,value);},injectLightCss:function(el){if(hasShadowCSS){return;}
this.lightStyle=document.createElement('style');this.lightStyle.setAttribute('scoped','');this.lightStyle.innerHTML=el.lightCss;el.appendChild(this.lightStyle);}});var attrs={textContent:{set:function(value){var node=firstChildTextNode(this);if(node){node.nodeValue=value;}},get:function(){var node=firstChildTextNode(this);return node&&node.nodeValue;}}};function firstChildTextNode(el){for(var i=0;i<el.childNodes.length;i++){var node=el.childNodes[i];if(node&&node.nodeType===3){return node;}}}
function extractLightDomCSS(template,name){var regex=/(?::host|::content)[^{]*\{[^}]*\}/g;var lightCss='';if(!hasShadowCSS){template=template.replace(regex,function(match){lightCss+=match.replace(/::content|:host/g,name);return'';});}
return{template:template,lightCss:lightCss};}
function injectGlobalCss(css){if(!css)return;var style=document.createElement('style');style.innerHTML=css;document.head.appendChild(style);}});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-component',this));},{}],2:[function(require,module,exports){(function(define){define(function(require,exports,module){var base=window.GAIA_ICONS_BASE_URL||window.COMPONENTS_BASE_URL||'bower_components/';if(!isLoaded()){load(base+'gaia-icons/gaia-icons.css');}
function load(href){var link=document.createElement('link');link.rel='stylesheet';link.type='text/css';link.href=href;document.head.appendChild(link);exports.loaded=true;}
function isLoaded(){return exports.loaded||document.querySelector('link[href*=gaia-icons]')||document.documentElement.classList.contains('gaia-icons-loaded');}});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-icons',this));},{}],3:[function(require,module,exports){;(function(define){define(function(require,exports,module){var Component=require('gaia-component');var fontFit=require('./lib/font-fit');require('gaia-icons');var actionTypes={menu:1,back:1,close:1};module.exports=Component.register('gaia-header',{created:function(){this.createShadowRoot().innerHTML=this.template;this.els={actionButton:this.shadowRoot.querySelector('.action-button'),headings:this.querySelectorAll('h1,h2,h3,h4'),inner:this.shadowRoot.querySelector('.inner')};this.els.actionButton.addEventListener('click',e=>this.onActionButtonClick(e));this.configureActionButton();this.runFontFit();},attached:function(){this.rerunFontFit();},attributeChanged:function(attr){if(attr==='action'){this.configureActionButton();this.rerunFontFit();}},runFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);fontFit.observeHeadingChanges(this.els.headings[i]);}},rerunFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);}},triggerAction:function(){if(this.isSupportedAction(this.getAttribute('action'))){this.els.actionButton.click();}},configureActionButton:function(){var old=this.els.actionButton.getAttribute('icon');var type=this.getAttribute('action');var supported=this.isSupportedAction(type);this.els.actionButton.classList.remove('icon-'+old);this.els.actionButton.setAttribute('icon',type);this.els.inner.classList.toggle('supported-action',supported);if(supported){this.els.actionButton.classList.add('icon-'+type);}},isSupportedAction:function(action){return action&&actionTypes[action];},onActionButtonClick:function(e){var config={detail:{type:this.getAttribute('action')}};var actionEvent=new CustomEvent('action',config);setTimeout(this.dispatchEvent.bind(this,actionEvent));},template:`
  <style>

  :host {
    display: block;

    --gaia-header-button-color:
      var(--header-button-color,
      var(--header-color,
      var(--link-color,
      inherit)));
  }

  /**
   * [hidden]
   */

  :host[hidden] {
    display: none;
  }

  /** Reset
   ---------------------------------------------------------*/

  ::-moz-focus-inner { border: 0; }

  /** Inner
   ---------------------------------------------------------*/

  .inner {
    display: flex;
    min-height: 50px;
    direction: ltr;

    background:
      var(--header-background,
      var(--background,
      #fff));
  }

  /** Action Button
   ---------------------------------------------------------*/

  /**
   * 1. Hidden by default
   */

  .action-button {
    display: none; /* 1 */
    position: relative;
    width: 50px;
    font-size: 30px;
    margin: 0;
    padding: 0;
    border: 0;
    align-items: center;
    background: none;
    cursor: pointer;
    transition: opacity 200ms 280ms;

    color:
      var(--header-action-button-color,
      var(--header-icon-color,
      var(--gaia-header-button-color)));
  }

  /**
   * .action-supported
   *
   * 1. For icon vertical-alignment
   */

  .supported-action .action-button {
    display: flex; /* 1 */
  }

  /**
   * :active
   */

  .action-button:active {
    transition: none;
    opacity: 0.2;
  }

  /** Action Button Icon
   ---------------------------------------------------------*/

  /**
   * 1. To enable vertical alignment.
   */

  .action-button:before {
    display: block;
  }

  /** Action Button Text
   ---------------------------------------------------------*/

  /**
   * To provide custom localized content for
   * the action-button, we allow the user
   * to provide an element with the class
   * .l10n-action. This node is then
   * pulled inside the real action-button.
   *
   * Example:
   *
   *   <gaia-header action="back">
   *     <span class="l10n-action" aria-label="Back">Localized text</span>
   *     <h1>title</h1>
   *   </gaia-header>
   */

  ::content .l10n-action {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    font-size: 0;
  }

  /** Title
   ---------------------------------------------------------*/

  /**
   * 1. Vertically center text. We can't use flexbox
   *    here as it breaks text-overflow ellipsis
   *    without an inner div.
   */

  ::content h1 {
    flex: 1;
    margin: 0;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    text-align: center;
    line-height: 50px; /* 1 */
    font-weight: 300;
    font-style: italic;
    font-size: 24px;
    -moz-user-select: none;

    color:
      var(--header-title-color,
      var(--header-color,
      var(--title-color,
      var(--text-color,
      inherit))));
  }

  /**
   * .flush-left
   *
   * When the fitted text is flush with the
   * edge of the left edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-left {
    padding-left: 10px;
  }

  /**
   * .flush-right
   *
   * When the fitted text is flush with the
   * edge of the right edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-right {
    padding-right: 10px; /* 1 */
  }

  /** Buttons
   ---------------------------------------------------------*/

  ::content a,
  ::content button {
    box-sizing: border-box;
    display: flex;
    border: none;
    width: auto;
    height: auto;
    margin: 0;
    padding: 0 10px;
    font-size: 14px;
    line-height: 1;
    min-width: 50px;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    text-align: center;
    background: none;
    border-radius: 0;
    font-style: italic;
    cursor: pointer;

    transition: opacity 200ms 280ms;

    color:
      var(--gaia-header-button-color);
  }

  /**
   * :active
   */

  ::content a:active,
  ::content button:active {
    transition: none;
    opacity: 0.2;
  }

  /**
   * [hidden]
   */

  ::content a[hidden],
  ::content button[hidden] {
    display: none;
  }

  /**
   * [disabled]
   */

  ::content a[disabled],
  ::content button[disabled] {
    pointer-events: none;
    color: var(--header-disabled-button-color);
  }

  /** Icon Buttons
   ---------------------------------------------------------*/

  /**
   * Icons are a different color to text
   */

  ::content .icon,
  ::content [data-icon] {
    color:
      var(--header-icon-color,
      var(--gaia-header-button-color));
  }

  /** Icons
   ---------------------------------------------------------*/

  [class^="icon-"]:before,
  [class*="icon-"]:before {
    font-family: 'gaia-icons';
    font-style: normal;
    text-rendering: optimizeLegibility;
    font-weight: 500;
  }

  .icon-menu:before { content: 'menu'; }
  .icon-close:before { content: 'close'; }
  .icon-back:before { content: 'back'; }

  </style>

  <div class="inner">
    <button class="action-button">
      <content select=".l10n-action"></content>
    </button>
    <content select="h1,h2,h3,h4,a,button"></content>
  </div>`});});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-header',this));},{"./lib/font-fit":4,"gaia-component":1,"gaia-icons":2}],4:[function(require,module,exports){;(function(define){define(function(require,exports,module){var GaiaHeaderFontFit={_HEADER_SIZES:[16,17,18,19,20,21,22,23,24],observeHeadingChanges:function(heading){var observer=this._getTextChangeObserver();observer.observe(heading,{childList:true});},reformatHeading:function(heading){if(!heading||heading.textContent.trim()===''){return;}
this._resetCentering(heading);var style=this._getStyleProperties(heading);if(!style){return;}
style.textWidth=this._autoResizeElement(heading,style);this._centerTextToScreen(heading,style);},resetCache:function(){this._cachedContexts={};},_cachedContexts:{},_getCachedContext:function(fontSize,fontFamily,fontStyle){fontStyle=fontStyle||'italic';var cache=this._cachedContexts;var ctx=cache[fontSize]&&cache[fontSize][fontFamily]?cache[fontSize][fontFamily][fontStyle]:null;if(!ctx){var canvas=document.createElement('canvas');canvas.setAttribute('moz-opaque','true');canvas.setAttribute('width','1');canvas.setAttribute('height','1');ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.font=fontStyle+' '+fontSize+'px '+fontFamily;if(!cache[fontSize]){cache[fontSize]={};}
if(!cache[fontSize][fontFamily]){cache[fontSize][fontFamily]={};}
cache[fontSize][fontFamily][fontStyle]=ctx;}
return ctx;},_textChangeObserver:null,_handleTextChanges:function(mutations){var targets=new Set();for(var i=0;i<mutations.length;i++){targets.add(mutations[i].target);}
for(var target of targets){this.reformatHeading(target);}},_getTextChangeObserver:function(){if(!this._textChangeObserver){this._textChangeObserver=new MutationObserver(this._handleTextChanges.bind(this));}
return this._textChangeObserver;},_getFontWidth:function(string,fontSize,fontFamily,fontStyle){var ctx=this._getCachedContext(fontSize,fontFamily,fontStyle);return ctx.measureText(string).width;},_getMaxFontSizeInfo:function(string,allowedSizes,fontFamily,maxWidth){var fontSize;var resultWidth;var i=allowedSizes.length-1;do{fontSize=allowedSizes[i];resultWidth=this._getFontWidth(string,fontSize,fontFamily);i--;}while(resultWidth>maxWidth&&i>=0);return{fontSize:fontSize,overflow:resultWidth>maxWidth,textWidth:resultWidth};},_getContentWidth:function(style){var width=parseInt(style.width,10);if(style.boxSizing==='border-box'){width-=(parseInt(style.paddingRight,10)+
parseInt(style.paddingLeft,10));}
return width;},_getStyleProperties:function(heading){var style=getComputedStyle(heading)||{};var contentWidth=this._getContentWidth(style);if(isNaN(contentWidth)){contentWidth=0;}
return{fontFamily:style.fontFamily||'unknown',contentWidth:contentWidth,paddingRight:parseInt(style.paddingRight,10),paddingLeft:parseInt(style.paddingLeft,10),offsetLeft:heading.offsetLeft};},_autoResizeElement:function(heading,styleOptions){var contentWidth=styleOptions.contentWidth||this._getContentWidth(heading);var fontFamily=styleOptions.fontFamily||getComputedStyle(heading).fontFamily;var text=heading.textContent.replace(/\s+/g,' ').trim();var info=this._getMaxFontSizeInfo(text,this._HEADER_SIZES,fontFamily,contentWidth);heading.style.fontSize=info.fontSize+'px';return info.textWidth;},_resetCentering:function(heading){heading.style.marginLeft=heading.style.marginRight='0';},_centerTextToScreen:function(heading,styleOptions){var minHeaderWidth=styleOptions.textWidth+styleOptions.paddingRight+
styleOptions.paddingLeft;var tightText=styleOptions.textWidth>(styleOptions.contentWidth-30);var sideSpaceLeft=styleOptions.offsetLeft;var sideSpaceRight=this._getWindowWidth()-sideSpaceLeft-
styleOptions.contentWidth-styleOptions.paddingRight-
styleOptions.paddingLeft;heading.classList.toggle('flush-left',tightText&&!sideSpaceLeft);heading.classList.toggle('flush-right',tightText&&!sideSpaceRight);if(sideSpaceLeft===sideSpaceRight){return;}
var margin=Math.max(sideSpaceLeft,sideSpaceRight);if(minHeaderWidth+(margin*2)<this._getWindowWidth()-1){if(sideSpaceLeft<sideSpaceRight){heading.style.marginLeft=(sideSpaceRight-sideSpaceLeft)+'px';}
if(sideSpaceRight<sideSpaceLeft){heading.style.marginRight=(sideSpaceLeft-sideSpaceRight)+'px';}}},_getWindowWidth:function(){return window.innerWidth;}};module.exports=GaiaHeaderFontFit;});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('./lib/font-fit',this));},{}]},{},[3])(3)});;var requirejs,require,define;(function(global,undef){var topReq,dataMain,src,subPath,bootstrapConfig=requirejs||require,hasOwn=Object.prototype.hasOwnProperty,contexts={},queue=[],currDirRegExp=/^\.\//,urlRegExp=/^\/|\:|\?|\.js$/,commentRegExp=/(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg,cjsRequireRegExp=/[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g,jsSuffixRegExp=/\.js$/;if(typeof requirejs==='function'){return;}
function hasProp(obj,prop){return hasOwn.call(obj,prop);}
function getOwn(obj,prop){return obj&&hasProp(obj,prop)&&obj[prop];}
function eachProp(obj,func){var prop;for(prop in obj){if(hasProp(obj,prop)){if(func(obj[prop],prop)){break;}}}}
function mixin(target,source,force,deepStringMixin){if(source){eachProp(source,function(value,prop){if(force||!hasProp(target,prop)){if(deepStringMixin&&typeof value==='object'&&value&&!Array.isArray(value)&&typeof value!=='function'&&!(value instanceof RegExp)){if(!target[prop]){target[prop]={};}
mixin(target[prop],value,force,deepStringMixin);}else{target[prop]=value;}}});}
return target;}
function getGlobal(value){if(!value){return value;}
var g=global;value.split('.').forEach(function(part){g=g[part];});return g;}
function newContext(contextName){var req,main,makeMap,callDep,handlers,checkingLater,load,context,defined={},waiting={},config={waitSeconds:7,baseUrl:'./',paths:{},bundles:{},pkgs:{},shim:{},config:{}},mapCache={},requireDeferreds=[],deferreds={},calledDefine={},calledPlugin={},loadCount=0,startTime=(new Date()).getTime(),errCount=0,trackedErrors={},urlFetched={},bundlesMap={};var nextMicroTaskPass;(function(){var waitingResolving,waiting=[];function callWaiting(){waitingResolving=null;var w=waiting;waiting=[];while(w.length){w.shift()();}}
nextMicroTaskPass=function(fn){waiting.push(fn);if(!waitingResolving){waitingResolving=new Promise(function(resolve,reject){resolve();}).then(callWaiting).catch(delayedError);}};}());function trimDots(ary){var i,part,length=ary.length;for(i=0;i<length;i++){part=ary[i];if(part==='.'){ary.splice(i,1);i-=1;}else if(part==='..'){if(i===1&&(ary[2]==='..'||ary[0]==='..')){break;}else if(i>0){ary.splice(i-1,2);i-=2;}}}}
function normalize(name,baseName,applyMap){var pkgMain,mapValue,nameParts,i,j,nameSegment,lastIndex,foundMap,foundI,foundStarMap,starI,baseParts=baseName&&baseName.split('/'),normalizedBaseParts=baseParts,map=config.map,starMap=map&&map['*'];if(name&&name.charAt(0)==='.'){if(baseName){normalizedBaseParts=baseParts.slice(0,baseParts.length-1);name=name.split('/');lastIndex=name.length-1;if(config.nodeIdCompat&&jsSuffixRegExp.test(name[lastIndex])){name[lastIndex]=name[lastIndex].replace(jsSuffixRegExp,'');}
name=normalizedBaseParts.concat(name);trimDots(name);name=name.join('/');}else if(name.indexOf('./')===0){name=name.substring(2);}}
if(applyMap&&map&&(baseParts||starMap)){nameParts=name.split('/');outerLoop:for(i=nameParts.length;i>0;i-=1){nameSegment=nameParts.slice(0,i).join('/');if(baseParts){for(j=baseParts.length;j>0;j-=1){mapValue=getOwn(map,baseParts.slice(0,j).join('/'));if(mapValue){mapValue=getOwn(mapValue,nameSegment);if(mapValue){foundMap=mapValue;foundI=i;break outerLoop;}}}}
if(!foundStarMap&&starMap&&getOwn(starMap,nameSegment)){foundStarMap=getOwn(starMap,nameSegment);starI=i;}}
if(!foundMap&&foundStarMap){foundMap=foundStarMap;foundI=starI;}
if(foundMap){nameParts.splice(0,foundI,foundMap);name=nameParts.join('/');}}
pkgMain=getOwn(config.pkgs,name);return pkgMain?pkgMain:name;}
function makeShimExports(value){function fn(){var ret;if(value.init){ret=value.init.apply(global,arguments);}
return ret||(value.exports&&getGlobal(value.exports));}
return fn;}
function takeQueue(anonId){var i,id,args,shim;for(i=0;i<queue.length;i+=1){if(typeof queue[i][0]!=='string'){if(anonId){queue[i].unshift(anonId);anonId=undef;}else{break;}}
args=queue.shift();id=args[0];i-=1;if(!hasProp(defined,id)&&!hasProp(waiting,id)){if(hasProp(deferreds,id)){main.apply(undef,args);}else{waiting[id]=args;}}}
if(anonId){shim=getOwn(config.shim,anonId)||{};main(anonId,shim.deps||[],shim.exportsFn);}}
function makeRequire(relName,topLevel){var req=function(deps,callback,errback,alt){var name,cfg;if(topLevel){takeQueue();}
if(typeof deps==="string"){if(handlers[deps]){return handlers[deps](relName);}
name=makeMap(deps,relName,true).id;if(!hasProp(defined,name)){throw new Error('Not loaded: '+name);}
return defined[name];}else if(deps&&!Array.isArray(deps)){cfg=deps;deps=undef;if(Array.isArray(callback)){deps=callback;callback=errback;errback=alt;}
if(topLevel){return req.config(cfg)(deps,callback,errback);}}
callback=callback||function(){};nextMicroTaskPass(function(){takeQueue();main(undef,deps||[],callback,errback,relName);});return req;};req.isBrowser=typeof document!=='undefined'&&typeof navigator!=='undefined';req.nameToUrl=function(moduleName,ext,skipExt){var paths,syms,i,parentModule,url,parentPath,bundleId,pkgMain=getOwn(config.pkgs,moduleName);if(pkgMain){moduleName=pkgMain;}
bundleId=getOwn(bundlesMap,moduleName);if(bundleId){return req.nameToUrl(bundleId,ext,skipExt);}
if(urlRegExp.test(moduleName)){url=moduleName+(ext||'');}else{paths=config.paths;syms=moduleName.split('/');for(i=syms.length;i>0;i-=1){parentModule=syms.slice(0,i).join('/');parentPath=getOwn(paths,parentModule);if(parentPath){if(Array.isArray(parentPath)){parentPath=parentPath[0];}
syms.splice(0,i,parentPath);break;}}
url=syms.join('/');url+=(ext||(/^data\:|\?/.test(url)||skipExt?'':'.js'));url=(url.charAt(0)==='/'||url.match(/^[\w\+\.\-]+:/)?'':config.baseUrl)+url;}
return config.urlArgs?url+
((url.indexOf('?')===-1?'?':'&')+
config.urlArgs):url;};req.toUrl=function(moduleNamePlusExt){var ext,index=moduleNamePlusExt.lastIndexOf('.'),segment=moduleNamePlusExt.split('/')[0],isRelative=segment==='.'||segment==='..';if(index!==-1&&(!isRelative||index>1)){ext=moduleNamePlusExt.substring(index,moduleNamePlusExt.length);moduleNamePlusExt=moduleNamePlusExt.substring(0,index);}
return req.nameToUrl(normalize(moduleNamePlusExt,relName),ext,true);};req.defined=function(id){return hasProp(defined,makeMap(id,relName,true).id);};req.specified=function(id){id=makeMap(id,relName,true).id;return hasProp(defined,id)||hasProp(deferreds,id);};return req;}
function resolve(name,d,value){if(name){defined[name]=value;if(requirejs.onResourceLoad){requirejs.onResourceLoad(context,d.map,d.deps);}}
d.finished=true;d.resolve(value);}
function reject(d,err){d.finished=true;d.rejected=true;d.reject(err);}
function makeNormalize(relName){return function(name){return normalize(name,relName,true);};}
function defineModule(d){var name=d.map.id,ret=d.factory.apply(defined[name],d.values);if(name){if(ret===undef){if(d.cjsModule){ret=d.cjsModule.exports;}else if(d.usingExports){ret=defined[name];}}}else{requireDeferreds.splice(requireDeferreds.indexOf(d),1);}
resolve(name,d,ret);}
function depFinished(val,i){if(!this.rejected&&!this.depDefined[i]){this.depDefined[i]=true;this.depCount+=1;this.values[i]=val;if(!this.depending&&this.depCount===this.depMax){defineModule(this);}}}
function makeDefer(name){var d={};d.promise=new Promise(function(resolve,reject){d.resolve=resolve;d.reject=reject;});d.map=name?makeMap(name,null,true):{};d.depCount=0;d.depMax=0;d.values=[];d.depDefined=[];d.depFinished=depFinished;if(d.map.pr){d.deps=[makeMap(d.map.pr)];}
return d;}
function getDefer(name){var d;if(name){d=hasProp(deferreds,name)&&deferreds[name];if(!d){d=deferreds[name]=makeDefer(name);}}else{d=makeDefer();requireDeferreds.push(d);}
return d;}
function makeErrback(d,name){return function(err){if(!d.rejected){if(!err.dynaId){err.dynaId='id'+(errCount+=1);err.requireModules=[name];}
reject(d,err);}};}
function waitForDep(depMap,relName,d,i){d.depMax+=1;callDep(depMap,relName).then(function(val){d.depFinished(val,i);},makeErrback(d,depMap.id)).catch(makeErrback(d,d.map.id));}
function makeLoad(id){var fromTextCalled;function load(value){if(!fromTextCalled){resolve(id,getDefer(id),value);}}
load.error=function(err){getDefer(id).reject(err);};load.fromText=function(text,textAlt){var d=getDefer(id),map=makeMap(makeMap(id).n),plainId=map.id;fromTextCalled=true;d.factory=function(p,val){return val;};if(textAlt){text=textAlt;}
if(hasProp(config.config,id)){config.config[plainId]=config.config[id];}
try{req.exec(text);}catch(e){reject(d,new Error('fromText eval for '+plainId+' failed: '+e));}
takeQueue(plainId);d.deps=[map];waitForDep(map,null,d,d.deps.length);};return load;}
load=typeof importScripts==='function'?function(map){var url=map.url;if(urlFetched[url]){return;}
urlFetched[url]=true;getDefer(map.id);importScripts(url);takeQueue(map.id);}:function(map){var script,id=map.id,url=map.url;if(urlFetched[url]){return;}
urlFetched[url]=true;script=document.createElement('script');script.setAttribute('data-requiremodule',id);script.type=config.scriptType||'text/javascript';script.charset='utf-8';script.async=true;loadCount+=1;script.addEventListener('load',function(){loadCount-=1;takeQueue(id);},false);script.addEventListener('error',function(){loadCount-=1;var err,pathConfig=getOwn(config.paths,id),d=getOwn(deferreds,id);if(pathConfig&&Array.isArray(pathConfig)&&pathConfig.length>1){script.parentNode.removeChild(script);pathConfig.shift();d.map=makeMap(id);load(d.map);}else{err=new Error('Load failed: '+id+': '+script.src);err.requireModules=[id];getDefer(id).reject(err);}},false);script.src=url;document.head.appendChild(script);};function callPlugin(plugin,map,relName){plugin.load(map.n,makeRequire(relName),makeLoad(map.id),{});}
callDep=function(map,relName){var args,bundleId,name=map.id,shim=config.shim[name];if(hasProp(waiting,name)){args=waiting[name];delete waiting[name];main.apply(undef,args);}else if(!hasProp(deferreds,name)){if(map.pr){if((bundleId=getOwn(bundlesMap,name))){map.url=req.nameToUrl(bundleId);load(map);}else{return callDep(makeMap(map.pr)).then(function(plugin){var newMap=makeMap(name,relName,true),newId=newMap.id,shim=getOwn(config.shim,newId);if(!hasProp(calledPlugin,newId)){calledPlugin[newId]=true;if(shim&&shim.deps){req(shim.deps,function(){callPlugin(plugin,newMap,relName);});}else{callPlugin(plugin,newMap,relName);}}
return getDefer(newId).promise;});}}else if(shim&&shim.deps){req(shim.deps,function(){load(map);});}else{load(map);}}
return getDefer(name).promise;};function splitPrefix(name){var prefix,index=name?name.indexOf('!'):-1;if(index>-1){prefix=name.substring(0,index);name=name.substring(index+1,name.length);}
return[prefix,name];}
makeMap=function(name,relName,applyMap){if(typeof name!=='string'){return name;}
var plugin,url,parts,prefix,result,cacheKey=name+' & '+(relName||'')+' & '+!!applyMap;parts=splitPrefix(name);prefix=parts[0];name=parts[1];if(!prefix&&hasProp(mapCache,cacheKey)){return mapCache[cacheKey];}
if(prefix){prefix=normalize(prefix,relName,applyMap);plugin=hasProp(defined,prefix)&&defined[prefix];}
if(prefix){if(plugin&&plugin.normalize){name=plugin.normalize(name,makeNormalize(relName));}else{name=normalize(name,relName,applyMap);}}else{name=normalize(name,relName,applyMap);parts=splitPrefix(name);prefix=parts[0];name=parts[1];url=req.nameToUrl(name);}
result={id:prefix?prefix+'!'+name:name,n:name,pr:prefix,url:url};if(!prefix){mapCache[cacheKey]=result;}
return result;};handlers={require:function(name){return makeRequire(name);},exports:function(name){var e=defined[name];if(typeof e!=='undefined'){return e;}else{return(defined[name]={});}},module:function(name){return{id:name,uri:'',exports:handlers.exports(name),config:function(){return getOwn(config.config,name)||{};}};}};function breakCycle(d,traced,processed){var id=d.map.id;traced[id]=true;if(!d.finished&&d.deps){d.deps.forEach(function(depMap){var depId=depMap.id,dep=!hasProp(handlers,depId)&&getDefer(depId);if(dep&&!dep.finished&&!processed[depId]){if(hasProp(traced,depId)){d.deps.forEach(function(depMap,i){if(depMap.id===depId){d.depFinished(defined[depId],i);}});}else{breakCycle(dep,traced,processed);}}});}
processed[id]=true;}
function check(d){var err,notFinished=[],waitInterval=config.waitSeconds*1000,expired=waitInterval&&(startTime+waitInterval)<(new Date()).getTime();if(loadCount===0){if(d){if(!d.finished){breakCycle(d,{},{});}}else if(requireDeferreds.length){requireDeferreds.forEach(function(d){breakCycle(d,{},{});});}}
if(expired){eachProp(deferreds,function(d){if(!d.finished){notFinished.push(d.map.id);}});err=new Error('Timeout for modules: '+notFinished);err.requireModules=notFinished;req.onError(err);}else if(loadCount||requireDeferreds.length){if(!checkingLater){checkingLater=true;setTimeout(function(){checkingLater=false;check();},70);}}}
function delayedError(e){setTimeout(function(){if(!e.dynaId||!trackedErrors[e.dynaId]){trackedErrors[e.dynaId]=true;req.onError(e);}});}
main=function(name,deps,factory,errback,relName){if(name&&hasProp(calledDefine,name)){return;}
calledDefine[name]=true;var d=getDefer(name);if(deps&&!Array.isArray(deps)){factory=deps;deps=[];}
d.promise.catch(errback||delayedError);relName=relName||name;if(typeof factory==='function'){if(!deps.length&&factory.length){factory.toString().replace(commentRegExp,'').replace(cjsRequireRegExp,function(match,dep){deps.push(dep);});deps=(factory.length===1?['require']:['require','exports','module']).concat(deps);}
d.factory=factory;d.deps=deps;d.depending=true;deps.forEach(function(depName,i){var depMap;deps[i]=depMap=makeMap(depName,relName,true);depName=depMap.id;if(depName==="require"){d.values[i]=handlers.require(name);}else if(depName==="exports"){d.values[i]=handlers.exports(name);d.usingExports=true;}else if(depName==="module"){d.values[i]=d.cjsModule=handlers.module(name);}else if(depName===undefined){d.values[i]=undefined;}else{waitForDep(depMap,relName,d,i);}});d.depending=false;if(d.depCount===d.depMax){defineModule(d);}}else if(name){resolve(name,d,factory);}
startTime=(new Date()).getTime();if(!name){check(d);}};req=makeRequire(null,true);req.config=function(cfg){if(cfg.context&&cfg.context!==contextName){return newContext(cfg.context).config(cfg);}
mapCache={};if(cfg.baseUrl){if(cfg.baseUrl.charAt(cfg.baseUrl.length-1)!=='/'){cfg.baseUrl+='/';}}
var shim=config.shim,objs={paths:true,bundles:true,config:true,map:true};eachProp(cfg,function(value,prop){if(objs[prop]){if(!config[prop]){config[prop]={};}
mixin(config[prop],value,true,true);}else{config[prop]=value;}});if(cfg.bundles){eachProp(cfg.bundles,function(value,prop){value.forEach(function(v){if(v!==prop){bundlesMap[v]=prop;}});});}
if(cfg.shim){eachProp(cfg.shim,function(value,id){if(Array.isArray(value)){value={deps:value};}
if((value.exports||value.init)&&!value.exportsFn){value.exportsFn=makeShimExports(value);}
shim[id]=value;});config.shim=shim;}
if(cfg.packages){cfg.packages.forEach(function(pkgObj){var location,name;pkgObj=typeof pkgObj==='string'?{name:pkgObj}:pkgObj;name=pkgObj.name;location=pkgObj.location;if(location){config.paths[name]=pkgObj.location;}
config.pkgs[name]=pkgObj.name+'/'+(pkgObj.main||'main').replace(currDirRegExp,'').replace(jsSuffixRegExp,'');});}
if(cfg.deps||cfg.callback){req(cfg.deps,cfg.callback);}
return req;};req.onError=function(err){throw err;};context={id:contextName,defined:defined,waiting:waiting,config:config,deferreds:deferreds};contexts[contextName]=context;return req;}
requirejs=topReq=newContext('_');if(typeof require!=='function'){require=topReq;}
topReq.exec=function(text){return eval(text);};topReq.contexts=contexts;define=function(){queue.push([].slice.call(arguments,0));};define.amd={jQuery:true};if(bootstrapConfig){topReq.config(bootstrapConfig);}
if(topReq.isBrowser&&!contexts._.config.skipDataMain){dataMain=document.querySelectorAll('script[data-main]')[0];dataMain=dataMain&&dataMain.getAttribute('data-main');if(dataMain){dataMain=dataMain.replace(jsSuffixRegExp,'');if(!bootstrapConfig||!bootstrapConfig.baseUrl){src=dataMain.split('/');dataMain=src.pop();subPath=src.length?src.join('/')+'/':'./';topReq.config({baseUrl:subPath});}
topReq([dataMain]);}}}(this));define("ext/alameda",function(){});(function(exports){var AccessibilityHelper={setAriaSelected:function ah_setAriaSelected(selectedTab,tabs){Array.prototype.forEach.call(tabs,function setAriaSelectedAttr(tab){tab.setAttribute('aria-selected',tab===selectedTab?'true':'false');});}};exports.AccessibilityHelper=AccessibilityHelper;})(window);define("shared/accessibility_helper",(function(global){return function(){var ret,fn;return ret||global.AccessibilityHelper;};}(this)));define('timespan',['require','exports','module'],function(require,exports,module){function Timespan(startDate,endDate){this.start=startDate.valueOf();this.end=endDate.valueOf();}
module.exports=Timespan;Timespan.prototype={isEqual:function(inputSpan){return(this.start===inputSpan.start&&this.end===inputSpan.end);},trimOverlap:function(span){if(this.contains(span)||span.contains(this)){return null;}
var start=span.start;var end=span.end;var ourEnd=this.end;var ourStart=this.start;var overlapsBefore=start>=ourStart&&start<ourEnd;var overlapsAfter=ourStart>=start&&ourStart<end;var newStart=span.start;var newEnd=span.end;if(overlapsBefore){newStart=ourEnd+1;}
if(overlapsAfter){newEnd=ourStart-1;}
return new Timespan(newStart,newEnd);},overlaps:function(start,end){var ourStart=this.start;var ourEnd=this.end;if(start instanceof Timespan){end=start.end;start=start.start;}else{start=(start instanceof Date)?start.valueOf():start;end=(end instanceof Date)?end.valueOf():end;}
return(start>=ourStart&&start<ourEnd||ourStart>=start&&ourStart<end);},contains:function(date){var start=this.start;var end=this.end;if(date instanceof Date){return start<=date&&end>=date;}else if(date instanceof Timespan){return start<=date.start&&end>=date.end;}else{return this.containsNumeric(date);}},containsNumeric:function(timestamp){var start=this.start;var end=this.end;return start<=timestamp&&end>=timestamp;}};});define('calc',['require','exports','module','timespan'],function(require,exports){var Timespan=require('timespan');const SECOND=1000;const MINUTE=(SECOND*60);const HOUR=MINUTE*60;exports._hourDate=new Date();exports.startsOnMonday=false;exports.FLOATING='floating';exports.ALLDAY='allday';exports.SECOND=SECOND;exports.MINUTE=MINUTE;exports.HOUR=HOUR;exports.PAST='past';exports.NEXT_MONTH='next-month';exports.OTHER_MONTH='other-month';exports.PRESENT='present';exports.FUTURE='future';Object.defineProperty(exports,'today',{get:function(){return new Date();}});exports.getTimeL10nLabel=function(timeLabel){return timeLabel+(navigator.mozHour12?'12':'24');};exports.daysInWeek=function(){return 7;};exports.dayOfWeekFromMonday=function(numeric){var day=numeric-1;if(day<0){return 6;}
return day;};exports.dayOfWeekFromSunday=function(numeric){return numeric;};exports.isToday=function(date){return exports.isSameDate(date,exports.today);};exports.isOnlyDate=function(date){if(date.getHours()===0&&date.getMinutes()===0&&date.getSeconds()===0){return true;}
return false;};exports.hourDiff=function(start,end){start=(start instanceof Date)?start.valueOf():start;end=(end instanceof Date)?end.valueOf():end;start=start/HOUR;end=end/HOUR;return end-start;};exports.spanOfDay=function(date,includeTime){if(typeof(includeTime)==='undefined'){date=exports.createDay(date);}
var end=exports.createDay(date);end.setDate(end.getDate()+1);return new Timespan(date,end);};exports.spanOfMonth=function(month){month=exports.monthStart(month);var startDay=exports.getWeekStartDate(month);var endDay=exports.monthEnd(month);endDay=exports.getWeekEndDate(endDay);return new Timespan(startDay,endDay);};exports.monthEnd=function(date,diff=0){var endDay=new Date(date.getFullYear(),date.getMonth()+diff+1,1);endDay.setMilliseconds(-1);return endDay;};exports.getUTC=function(date){return new Date(date.getUTCFullYear(),date.getUTCMonth(),date.getUTCDate(),date.getUTCHours(),date.getUTCMinutes(),date.getUTCSeconds(),date.getUTCMilliseconds());};exports.dateFromTransport=function(transport){var utc=transport.utc;var offset=transport.offset;var zone=transport.tzid;var date=new Date(parseInt(utc)-parseInt(offset));if(zone&&zone===exports.FLOATING){return exports.getUTC(date);}
return date;};exports.dateToTransport=function(date,tzid,isDate){var result=Object.create(null);if(isDate){result.isDate=isDate;}
if(tzid){result.tzid=tzid;}
var utc=Date.UTC(date.getFullYear(),date.getMonth(),date.getDate(),date.getHours(),date.getMinutes(),date.getSeconds(),date.getMilliseconds());if(isDate||tzid&&tzid===exports.FLOATING){result.utc=utc;result.offset=0;result.tzid=exports.FLOATING;}else{var localUtc=date.valueOf();var offset=utc-localUtc;result.utc=utc;result.offset=offset;}
return result;};exports.isSameDate=function(first,second){return first.getMonth()==second.getMonth()&&first.getDate()==second.getDate()&&first.getFullYear()==second.getFullYear();};exports.getDayId=function(date){return['d',date.getFullYear(),date.getMonth(),date.getDate()].join('-');};exports.dateFromId=function(id){var parts=id.split('-'),date,type;if(parts.length>1){type=parts.shift();switch(type){case'd':date=new Date(parts[0],parts[1],parts[2]);break;case'm':date=new Date(parts[0],parts[1]);break;}}
return date;};exports.getMonthId=function(date){return['m',date.getFullYear(),date.getMonth()].join('-');};exports.createDay=function(date,day,month,year){return new Date(year!=null?year:date.getFullYear(),month!=null?month:date.getMonth(),day!=null?day:date.getDate());};exports.endOfDay=function(date){var day=exports.createDay(date,date.getDate()+1);day.setMilliseconds(-1);return day;};exports.monthStart=function(date,diff=0){return new Date(date.getFullYear(),date.getMonth()+diff,1);};exports.dayOfWeek=function(date){var number=date;if(typeof(date)!=='number'){number=date.getDay();}
if(exports.startsOnMonday){return exports.dayOfWeekFromMonday(number);}
return exports.dayOfWeekFromSunday(number);};exports.getWeekStartDate=function(date){var currentDay=exports.dayOfWeek(date);var startDay=(date.getDate()-currentDay);return exports.createDay(date,startDay);};exports.getWeekEndDate=function(date){var start=exports.getWeekStartDate(date);start.setDate(start.getDate()+7);start.setMilliseconds(-1);return start;};exports.daysBetween=function(start,end,includeTime){if(start instanceof Timespan){if(end){includeTime=end;}
end=new Date(start.end);start=new Date(start.start);}
if(start>end){var tmp=end;end=start;start=tmp;tmp=null;}
var list=[];var last=start.getDate();if(exports.isSameDate(start,end)){if(includeTime){list.push(end);}else{list.push(exports.createDay(start));}
return list;}
while(true){var next=new Date(start.getFullYear(),start.getMonth(),++last);if(next>end){throw new Error('sanity fails next is greater then end');}
if(!exports.isSameDate(next,end)){list.push(next);continue;}
break;}
if(includeTime){list.unshift(start);list.push(end);}else{list.unshift(exports.createDay(start));list.push(exports.createDay(end));}
return list;},exports.getWeeksDays=function(startDate){var weeksDayStart=exports.getWeekStartDate(startDate);var result=[weeksDayStart];for(var i=1;i<7;i++){result.push(exports.createDay(weeksDayStart,weeksDayStart.getDate()+i));}
return result;};exports.isPast=function(date){return(date.valueOf()<exports.today.valueOf());};exports.isFuture=function(date){return!exports.isPast(date);};exports.relativeState=function(day,month){var states;if(exports.isToday(day)){return exports.PRESENT;}
if(exports.isPast(day)){states=exports.PAST;}else{states=exports.FUTURE;}
if(day.getMonth()!==month.getMonth()){states+=' '+exports.OTHER_MONTH;}
return states;};exports.relativeOffset=function(baseDate,date){if(exports.isSameDate(baseDate,date)){return date.getHours()+(date.getMinutes()/60);}
return 0;};exports.relativeDuration=function(baseDate,startDate,endDate){if(!exports.isSameDate(startDate,endDate)){if(exports.isSameDate(baseDate,startDate)){endDate=exports.endOfDay(baseDate);}else if(exports.isSameDate(baseDate,endDate)){startDate=exports.createDay(endDate);}else{return 24;}}
return exports.hourDiff(startDate,endDate);};exports.isAllDay=function(baseDate,startDate,endDate){var refStart=exports.createDay(baseDate);var refEnd=exports.endOfDay(baseDate);var startBefore=startDate<=refStart;var endsAfter=endDate>=refEnd;return(startBefore&&endsAfter)||Number(startDate)===Number(endDate);};window.addEventListener('localized',function changeStartDay(){var startDay=navigator.mozL10n.get('weekStartsOnMonday');if(startDay&&parseInt(startDay,10)){exports.startsOnMonday=true;}else{exports.startsOnMonday=false;}});});define('date_format',['require','exports','module'],function(require,exports,module){module.exports=navigator.mozL10n.DateTimeFormat();});define('date_l10n',['require','exports','module','date_format'],function(require,exports){var dateFormat=require('date_format');exports.localizeElements=function(){var elements=document.querySelectorAll('[data-l10n-date-format]');for(var i=0;i<elements.length;i++){exports.localizeElement(elements[i]);}};exports.changeElementsHourFormat=function(){var isHour12=navigator.mozHour12;var previousFormat=isHour12?24:12;var currentFormat=isHour12?12:24;var elements=document.querySelectorAll(`[data-l10n-date-format*="${previousFormat}"]`);Array.prototype.forEach.call(elements,(element)=>{var format=element.dataset.l10nDateFormat.replace(previousFormat,currentFormat);element.dataset.l10nDateFormat=format;exports.localizeElement(element,{addAmPmClass:format==='week-hour-format12',removeLeadingZero:format.contains('hour-format')});});};exports.localizeElement=function(element,options){var date=element.dataset.date;if(!date){return;}
var l10n=navigator.mozL10n;var format=l10n.get(element.dataset.l10nDateFormat);if(options&&options.addAmPmClass){format=format.replace(/\s*%p\s*/,'<span class="ampm">%p</span>');}
var text=dateFormat.localeFormat(new Date(date),format);if(options&&options.removeLeadingZero){text=text.replace(/^0/,'');}
element.textContent=text;};});define('models/account',['require','exports','module'],function(require,exports,module){function Account(options){var key;if(typeof(options)==='undefined'){options={};}
for(key in options){if(options.hasOwnProperty(key)){this[key]=options[key];}}}
module.exports=Account;Account.prototype={providerType:null,id:null,preset:null,domain:'',entrypoint:'',calendarHome:'',user:'',password:'',get fullUrl(){return this.domain+this.entrypoint;},set fullUrl(value){var protocolIdx=value.indexOf('://');this.domain=value;this.entrypoint='/';if(protocolIdx!==-1){protocolIdx+=3;var domainChunk=value.substr(protocolIdx);var pathIdx=domainChunk.indexOf('/');if(pathIdx!==-1){pathIdx=pathIdx+protocolIdx;this.entrypoint=value.substr(pathIdx);this.domain=value.substr(0,pathIdx);}}},toJSON:function(){var output={};var fields=['entrypoint','calendarHome','domain','password','user','providerType','preset','oauth','error'];fields.forEach(function(key){output[key]=this[key];},this);if(this._id||this._id===0){output._id=this._id;}
return output;}};});define('presets',{"google":{"providerType":"Caldav","group":"remote","authenticationType":"oauth2","apiCredentials":{"tokenUrl":"https://accounts.google.com/o/oauth2/token","authorizationUrl":"https://accounts.google.com/o/oauth2/auth","user_info":{"url":"https://www.googleapis.com/oauth2/v3/userinfo","field":"email"},"client_secret":"jQTKlOhF-RclGaGJot3HIcVf","client_id":"605300196874-1ki833poa7uqabmh3hq6u1onlqlsi54h.apps.googleusercontent.com","scope":"https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/userinfo.email","redirect_uri":"https://oauth.gaiamobile.org/authenticated"},"options":{"domain":"https://apidata.googleusercontent.com","entrypoint":"/caldav/v2/","providerType":"Caldav"}},"yahoo":{"providerType":"Caldav","group":"remote","options":{"domain":"https://caldav.calendar.yahoo.com","entrypoint":"/","providerType":"Caldav","user":"@yahoo.com","usernameType":"email"}},"caldav":{"providerType":"Caldav","group":"remote","options":{"domain":"","entrypoint":"","providerType":"Caldav"}},"local":{"singleUse":true,"providerType":"Local","group":"local","options":{"providerType":"Local"}}});define('promise',['require','exports','module'],function(require,exports){function denodeify(fn){return function(){var args=Array.slice(arguments);var callback=args[args.length-1];if(typeof callback==='function'){return fn.apply(this,args);}
var deferred=defer();args.push((err,result)=>{if(err){return deferred.reject(err);}
deferred.resolve(result);});var returnValue=fn.apply(this,args);return typeof returnValue==='object'?returnValue:deferred.promise;};}
exports.denodeify=denodeify;function denodeifyAll(object,methods){methods.forEach((method)=>{object[method]=exports.denodeify(object[method]);});}
exports.denodeifyAll=denodeifyAll;function defer(){var deferred={};var promise=new Promise((resolve,reject)=>{deferred.resolve=resolve;deferred.reject=reject;});deferred.promise=promise;return deferred;}});define('next_tick',['require','exports','module'],function(require,exports,module){var NEXT_TICK='calendar-next-tick';var nextTickStack=[];module.exports=function(callback){nextTickStack.push(callback);window.postMessage(NEXT_TICK,'*');};window.addEventListener('message',(event)=>{if(event.source===window&&event.data===NEXT_TICK){event.stopPropagation();if(nextTickStack.length){(nextTickStack.shift())();}}});});define('provider/abstract',['require','exports','module','promise','next_tick'],function(require,exports,module){var denodeifyAll=require('promise').denodeifyAll;var nextTick=require('next_tick');function Abstract(options){var key;for(key in options){if(options.hasOwnProperty(key)){this[key]=options[key];}}
denodeifyAll(this,['eventCapabilities','getAccount','findCalendars','syncEvents','ensureRecurrencesExpanded','createEvent','updateEvent','deleteEvent']);}
module.exports=Abstract;Abstract.prototype={defaultColor:'#F97C17',useCredentials:false,useUrl:false,canSync:false,canExpandRecurringEvents:false,getAccount:function(account,callback){},findCalendars:function(){},syncEvents:function(account,calendar,callback){},ensureRecurrencesExpanded:function(date,callback){},updateEvent:function(event,busytime,callback){},deleteEvent:function(event,busytime,callback){},createEvent:function(event,callback){},calendarCapabilities:function(calendar){return{canCreateEvent:true,canUpdateEvent:true,canDeleteEvent:true};},eventCapabilities:function(event,callback){var caps=this.calendarCapabilities();nextTick(function(){callback(null,{canCreate:caps.canCreateEvent,canUpdate:caps.canUpdateEvent,canDelete:caps.canDeleteEvent});});}};});(function(){var _global=this;var _rng;if(typeof(_global.require)=='function'&&typeof(module)!='undefined'&&module.exports){try{var _rb=_global.require('crypto').randomBytes;_rng=_rb&&function(){return _rb(16);};}catch(e){}}
if(!_rng&&_global.crypto&&crypto.getRandomValues){var _rnds8=new Uint8Array(16);_rng=function whatwgRNG(){crypto.getRandomValues(_rnds8);return _rnds8;};}
if(!_rng){var _rnds=new Array(16);_rng=function(){for(var i=0,r;i<16;i++){if((i&0x03)===0)r=Math.random()*0x100000000;_rnds[i]=r>>>((i&0x03)<<3)&0xff;}
return _rnds;};}
var BufferClass=typeof(_global.Buffer)=='function'?_global.Buffer:Array;var _byteToHex=[];var _hexToByte={};for(var i=0;i<256;i++){_byteToHex[i]=(i+0x100).toString(16).substr(1);_hexToByte[_byteToHex[i]]=i;}
function parse(s,buf,offset){var i=(buf&&offset)||0,ii=0;buf=buf||[];s.toLowerCase().replace(/[0-9a-f]{2}/g,function(oct){if(ii<16){buf[i+ii++]=_hexToByte[oct];}});while(ii<16){buf[i+ii++]=0;}
return buf;}
function unparse(buf,offset){var i=offset||0,bth=_byteToHex;return bth[buf[i++]]+bth[buf[i++]]+
bth[buf[i++]]+bth[buf[i++]]+'-'+
bth[buf[i++]]+bth[buf[i++]]+'-'+
bth[buf[i++]]+bth[buf[i++]]+'-'+
bth[buf[i++]]+bth[buf[i++]]+'-'+
bth[buf[i++]]+bth[buf[i++]]+
bth[buf[i++]]+bth[buf[i++]]+
bth[buf[i++]]+bth[buf[i++]];}
var _seedBytes=_rng();var _nodeId=[_seedBytes[0]|0x01,_seedBytes[1],_seedBytes[2],_seedBytes[3],_seedBytes[4],_seedBytes[5]];var _clockseq=(_seedBytes[6]<<8|_seedBytes[7])&0x3fff;var _lastMSecs=0,_lastNSecs=0;function v1(options,buf,offset){var i=buf&&offset||0;var b=buf||[];options=options||{};var clockseq=options.clockseq!=null?options.clockseq:_clockseq;var msecs=options.msecs!=null?options.msecs:new Date().getTime();var nsecs=options.nsecs!=null?options.nsecs:_lastNSecs+1;var dt=(msecs-_lastMSecs)+(nsecs-_lastNSecs)/10000;if(dt<0&&options.clockseq==null){clockseq=clockseq+1&0x3fff;}
if((dt<0||msecs>_lastMSecs)&&options.nsecs==null){nsecs=0;}
if(nsecs>=10000){throw new Error('uuid.v1(): Can\'t create more than 10M uuids/sec');}
_lastMSecs=msecs;_lastNSecs=nsecs;_clockseq=clockseq;msecs+=12219292800000;var tl=((msecs&0xfffffff)*10000+nsecs)%0x100000000;b[i++]=tl>>>24&0xff;b[i++]=tl>>>16&0xff;b[i++]=tl>>>8&0xff;b[i++]=tl&0xff;var tmh=(msecs/0x100000000*10000)&0xfffffff;b[i++]=tmh>>>8&0xff;b[i++]=tmh&0xff;b[i++]=tmh>>>24&0xf|0x10;b[i++]=tmh>>>16&0xff;b[i++]=clockseq>>>8|0x80;b[i++]=clockseq&0xff;var node=options.node||_nodeId;for(var n=0;n<6;n++){b[i+n]=node[n];}
return buf?buf:unparse(b);}
function v4(options,buf,offset){var i=buf&&offset||0;if(typeof(options)=='string'){buf=options=='binary'?new BufferClass(16):null;options=null;}
options=options||{};var rnds=options.random||(options.rng||_rng)();rnds[6]=(rnds[6]&0x0f)|0x40;rnds[8]=(rnds[8]&0x3f)|0x80;if(buf){for(var ii=0;ii<16;ii++){buf[i+ii]=rnds[ii];}}
return buf||unparse(rnds);}
var uuid=v4;uuid.v1=v1;uuid.v4=v4;uuid.parse=parse;uuid.unparse=unparse;uuid.BufferClass=BufferClass;if(typeof define==='function'&&define.amd){define('ext/uuid',[],function(){return uuid;});}else if(typeof(module)!='undefined'&&module.exports){module.exports=uuid;}else{var _previousRoot=_global.uuid;uuid.noConflict=function(){_global.uuid=_previousRoot;return uuid;};_global.uuid=uuid;}}).call(this);define('event_mutations',['require','exports','module','calc','ext/uuid'],function(require,exports){var Calc=require('calc');var uuid=require('ext/uuid');function createBusytime(event){return{_id:event._id+'-'+uuid.v4(),eventId:event._id,calendarId:event.calendarId,start:event.remote.start,end:event.remote.end};}
function Create(options){if(options){for(var key in options){if(options.hasOwnProperty(key)){this[key]=options[key];}}}}
Create.prototype={commit:function(callback){var app=exports.app;var alarmStore=app.store('Alarm');var eventStore=app.store('Event');var busytimeStore=app.store('Busytime');var componentStore=app.store('IcalComponent');var trans=eventStore.db.transaction(eventStore._dependentStores,'readwrite');trans.oncomplete=function commitComplete(){callback(null);};trans.onerror=function commitError(e){callback(e.target.error);};eventStore.persist(this.event,trans);if(!this.busytime){this.busytime=createBusytime(this.event);}
busytimeStore.persist(this.busytime,trans);if(this.icalComponent){componentStore.persist(this.icalComponent,trans);}
var alarms=this.event.remote.alarms;if(alarms&&alarms.length){var i=0;var len=alarms.length;var now=Date.now();var alarmTrans=alarmStore.db.transaction(['alarms'],'readwrite');for(;i<len;i++){var alarm={startDate:{offset:this.busytime.start.offset,utc:this.busytime.start.utc+(alarms[i].trigger*1000)},eventId:this.busytime.eventId,busytimeId:this.busytime._id};var alarmDate=Calc.dateFromTransport(this.busytime.end).valueOf();if(alarmDate<now){continue;}
alarmStore.persist(alarm,alarmTrans);}}}};function Update(){Create.apply(this,arguments);}
Update.prototype={commit:function(callback){var app=exports.app;var busytimeStore=app.store('Busytime');var self=this;busytimeStore.removeEvent(this.event._id,function(err){if(err){callback(err);return;}
Create.prototype.commit.call(self,callback);});}};exports.app=null;exports.create=function createMutation(option){return new Create(option);};exports.update=function updateMutation(option){return new Update(option);};});define('provider/local',['require','exports','module','./abstract','event_mutations','ext/uuid'],function(require,exports,module){var Abstract=require('./abstract');var mutations=require('event_mutations');var uuid=require('ext/uuid');var LOCAL_CALENDAR_ID='local-first';function Local(){Abstract.apply(this,arguments);mutations.app=this.app;this.events=this.app.store('Event');this.busytimes=this.app.store('Busytime');this.alarms=this.app.store('Alarm');}
module.exports=Local;Local.calendarId=LOCAL_CALENDAR_ID;Local.defaultCalendar=function(){var l10nId='calendar-local';var name;if('mozL10n'in window.navigator){name=window.navigator.mozL10n.get(l10nId);if(name===l10nId){name=null;}}
if(!name){name='Offline calendar';}
return{name:name,id:LOCAL_CALENDAR_ID,color:Local.prototype.defaultColor};};Local.prototype={__proto__:Abstract.prototype,canExpandRecurringEvents:false,getAccount:function(account,callback){callback(null,{});},findCalendars:function(account,callback){var list={};list[LOCAL_CALENDAR_ID]=Local.defaultCalendar();callback(null,list);},syncEvents:function(account,calendar,cb){cb(null);},createEvent:function(event,callback){if(!event.remote.id){event.remote.id=uuid();}
var create=mutations.create({event:event});create.commit(function(err){if(err){return callback(err);}
callback(null,create.busytime,create.event);});return create;},deleteEvent:function(event,busytime,callback){if(typeof(busytime)==='function'){callback=busytime;busytime=null;}
this.app.store('Event').remove(event._id,callback);},updateEvent:function(event,busytime,callback){if(typeof(busytime)==='function'){callback=busytime;busytime=null;}
var update=mutations.update({event:event});update.commit(function(err){if(err){return callback(err);}
callback(null,update.busytime,update.event);});return update;}};});define('responder',['require','exports','module'],function(require,exports,module){function Responder(events){this._$events=Object.create(null);this.buffer={};if(typeof(events)!=='undefined'){this.addEventListener(events);}}
module.exports=Responder;Responder.stringify=function stringify(command,data){return JSON.stringify([command,data]);};Responder.parse=function parse(json){var data;try{data=(json.forEach)?json:JSON.parse(json);}catch(e){throw new Error('Could not parse json: "'+json+'"');}
return data;};Responder.prototype={parse:Responder.parse,stringify:Responder.stringify,events:null,respond:function respond(json){var event=Responder.parse(json);var args=Array.prototype.slice.call(arguments).slice(1);this.emit.apply(this,event.concat(args));return event;},addEventListener:function addEventListener(type,callback){var event;if(typeof(callback)==='undefined'&&typeof(type)==='object'){for(event in type){if(type.hasOwnProperty(event)){this.addEventListener(event,type[event]);}}
return this;}
if(!(type in this._$events)){this._$events[type]=[];}
this._$events[type].push(callback);return this.flushTopicBuffer(type);},once:function once(type,callback){var self=this;function onceCb(){self.removeEventListener(type,onceCb);callback.apply(this,arguments);}
this.addEventListener(type,onceCb);return this.flushTopicBuffer(type);},flushTopicBuffer:function flushTopicBuffer(topic){if(!(topic in this.buffer)){return this;}
this.buffer[topic].forEach(args=>{args.unshift(topic);this.emit.apply(this,args);});return this;},emit:function emit(){var args=Array.prototype.slice.call(arguments),event=args.shift(),eventList,self=this;if(event in this._$events){eventList=this._$events[event];eventList.forEach(function(callback){if(typeof(callback)==='object'&&callback.handleEvent){callback.handleEvent({type:event,data:args});}else{callback.apply(self,args);}});}
return this;},emitWhenListener:function emitWhenListener(){var args=Array.prototype.slice.call(arguments);var event=args.shift();if(event in this._$events&&this._$events[event].length){return this.emit.apply(this,arguments);}
if(!(event in this.buffer)){this.buffer[event]=[];}
this.buffer[event].push(args);return this;},removeAllEventListeners:function removeAllEventListeners(name){if(name in this._$events){this._$events[name].length=0;}
return this;},removeEventListener:function removeEventListener(name,callback){var i,length,events;if(!(name in this._$events)){return false;}
events=this._$events[name];for(i=0,length=events.length;i<length;i++){if(events[i]&&events[i]===callback){events.splice(i,1);return true;}}
return false;}};Responder.prototype.on=Responder.prototype.addEventListener;Responder.prototype.off=Responder.prototype.removeEventListener;});define('store/abstract',['require','exports','module','responder','promise','next_tick'],function(require,exports,module){var Responder=require('responder');var denodeifyAll=require('promise').denodeifyAll;var nextTick=require('next_tick');function Abstract(db,app){this.db=db;this.app=app;this._cached=Object.create(null);Responder.call(this);denodeifyAll(this,['persist','all','_allCached','removeByIndex','get','remove','count']);}
module.exports=Abstract;Abstract.prototype={__proto__:Responder.prototype,_store:null,_dependentStores:null,_createModel:function(object,id){if(typeof(id)!=='undefined'){object._id=id;}
return object;},_addToCache:function(object){this._cached[object._id]=object;},_removeFromCache:function(id){if(id in this._cached){delete this._cached[id];}},_transactionCallback:function(trans,callback){if(callback){trans.addEventListener('error',function(e){callback(e);});trans.addEventListener('complete',function(){callback(null);});}},persist:function(object,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=undefined;}
if(!trans){trans=this.db.transaction(this._dependentStores||this._store,'readwrite');}
var self=this;var store=trans.objectStore(this._store);var data=this._objectData(object);var id;var model;var putReq;var reqType=this._detectPersistType(object);if(reqType==='update'){putReq=store.put(data);}else{this._assignId(data);putReq=store.add(data);}
trans.addEventListener('error',function(event){if(callback){callback(event);}});this._addDependents(object,trans);if(data._id){id=data._id;model=self._createModel(object,id);self._addToCache(model);}
trans.addEventListener('complete',function(data){if(!model){id=putReq.result;model=self._createModel(object,id);self._addToCache(model);}
if(callback){callback(null,id,model);}
self.emit(reqType,id,model);self.emit('persist',id,model);});},_allCached:function(callback){var list=this._cached;nextTick(function(){callback(null,list);});},all:function(callback){if(this._allCallbacks){this._allCallbacks.push(callback);return;}
this._allCallbacks=[callback];var self=this;var trans=this.db.transaction(this._store);var store=trans.objectStore(this._store);function process(data){return self._addToCache(self._createModel(data));}
function fireQueue(err,value){var callback;while((callback=self._allCallbacks.shift())){callback(err,value);}}
store.mozGetAll().onsuccess=function(event){event.target.result.forEach(process);};trans.onerror=function(event){fireQueue(event.target.error.name);};trans.oncomplete=function(){fireQueue(null,self._cached);self.all=self._allCached;};},_addDependents:function(){},_removeDependents:function(trans){},_detectPersistType:function(object){return('_id'in object)?'update':'add';},_parseId:function(id){return id;},_assignId:function(obj){},removeByIndex:function(indexName,indexValue,trans,callback){var self=this;if(typeof(trans)==='function'){callback=trans;trans=undefined;}
if(!trans){trans=this.db.transaction(this._dependentStores||this._store,'readwrite');}
if(callback){trans.addEventListener('complete',function(){callback(null);});trans.addEventListener('error',function(event){callback(event);});}
var index=trans.objectStore(this._store).index(indexName);var req=index.openCursor(IDBKeyRange.only(indexValue));req.onsuccess=function(event){var cursor=event.target.result;if(cursor){self._removeDependents(cursor.primaryKey,trans);self._removeFromCache(cursor.primaryKey);cursor.delete();cursor.continue();}};return req;},get:function(id,trans,callback){var self=this;if(typeof(trans)==='function'){callback=trans;trans=null;}
if(!trans){trans=this.db.transaction(this._store);}
var store=trans.objectStore(this._store);var req=store.get(this._parseId(id));req.onsuccess=function(){var model;if(req.result){model=self._createModel(req.result);}
callback(null,model);};req.onerror=function(event){callback(event);};},remove:function(id,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=undefined;}
if(!trans){trans=this.db.transaction(this._dependentStores||this._store,'readwrite');}
var self=this;var store=trans.objectStore(this._store);id=this._parseId(id);store.delete(id);this._removeDependents(id,trans);self.emit('preRemove',id);trans.addEventListener('error',function(event){if(callback){callback(event);}});trans.addEventListener('complete',function(){if(callback){callback(null,id);}
self.emit('remove',id);self._removeFromCache(id);});},count:function(callback){var trans=this.db.transaction(this._store);var store=trans.objectStore(this._store);var req=store.count();req.onsuccess=function(){callback(null,req.result);};req.onerror=function(e){callback(e);};},_objectData:function(data){if('toJSON'in data){return data.toJSON();}
return data;}};});define('debug',['require','exports','module'],function(require,exports,module){module.exports=function(name){return function(){var args=Array.prototype.slice.call(arguments).map(JSON.stringify);args.unshift('[calendar] ');args.unshift(name);console.log.apply(console,args);};};});define('extend',['require','exports','module'],function(require,exports,module){module.exports=function(target,input){for(var key in input){if(hasOwnProperty.call(input,key)){target[key]=input[key];}}
return target;};});define('probably_parse_int',['require','exports','module'],function(require,exports,module){var NUMERIC=/^[0-9]+$/;module.exports=function(id){if(typeof id==='string'&&id.match(NUMERIC)){return parseInt(id,10);}
return id;};});define('error',['require','exports','module'],function(require,exports,module){function Base(name,detail){this.message='oops... why did you throw this?';this.name=name;this.detail=detail;}
module.exports=Base;Base.prototype=Object.create(Error.prototype);function errorFactory(name,l10nID){var error=function(detail){this.name=name;this.detail=detail;this.l10nID=l10nID||name;};error.prototype=Object.create(Base.prototype);return error;}
Base.Authentication=errorFactory('authentication','unauthenticated');Base.InvalidServer=errorFactory('invalid-server','internal-server-error');Base.ServerFailure=errorFactory('server-failure','internal-server-error');});define('provider/caldav_pull_events',['require','exports','module','calc','debug','ext/uuid'],function(require,exports,module){var Calc=require('calc');var debug=require('debug')('pull events');var uuid=require('ext/uuid');function PullEvents(stream,options){if(options.calendar){this.calendar=options.calendar;}else{throw new Error('.calendar option must be given');}
if(options.account){this.account=options.account;}else{throw new Error('.account option must be given');}
this.app=options.app;stream.on('event',this);stream.on('component',this);stream.on('occurrence',this);stream.on('missingEvents',this);this.icalQueue=[];this.eventQueue=[];this.busytimeQueue=[];this.alarmQueue=[];this._busytimeStore=this.app.store('Busytime');this._accountStore=this.app.store('Account');this._accountStore.on('remove',this._onRemoveAccount.bind(this));this._aborted=false;this._trans=null;}
module.exports=PullEvents;PullEvents.prototype={eventQueue:null,busytimeQueue:null,busytimeIdFromRemote:function(busytime){var eventId=this.eventIdFromRemote(busytime,!busytime.isException);return busytime.start.utc+'-'+
busytime.end.utc+'-'+
eventId;},eventIdFromRemote:function(event,ignoreException){var id=event.eventId||event.id;if(!ignoreException&&event.recurrenceId){id+='-'+event.recurrenceId.utc;}
return this.calendar._id+'-'+id;},formatEvent:function(event){var id=this.eventIdFromRemote(event,true);var result=Object.create(null);result.calendarId=this.calendar._id;result.remote=event;if(event.recurrenceId){result.parentId=id;result._id=this.eventIdFromRemote(event);}else{result._id=id;}
return result;},formatBusytime:function(time){var eventId=this.eventIdFromRemote(time,!time.isException);var id=eventId+'-'+uuid.v4();var calendarId=this.calendar._id;time._id=id;time.calendarId=calendarId;time.eventId=eventId;if(time.alarms){var i=0;var len=time.alarms.length;var alarm;for(;i<len;i++){alarm=time.alarms[i];alarm.eventId=eventId;alarm.busytimeId=id;}}
return this._busytimeStore.initRecord(time);},handleOccurrenceSync:function(item){var alarms;if('alarms'in item){alarms=item.alarms;delete item.alarms;if(alarms.length){var i=0;var len=alarms.length;var now=Date.now();for(;i<len;i++){var alarm={startDate:{},eventId:item.eventId,busytimeId:item._id};for(var j in item.start){alarm.startDate[j]=item.start[j];}
alarm.startDate.utc+=(alarms[i].trigger*1000);var alarmDate=Calc.dateFromTransport(item.end);if(alarmDate.valueOf()<now){continue;}
this.alarmQueue.push(alarm);}}}
this.busytimeQueue.push(item);},handleComponentSync:function(component){component.eventId=this.eventIdFromRemote(component);component.calendarId=this.calendar._id;if(!component.lastRecurrenceId){delete component.lastRecurrenceId;}
this.icalQueue.push(component);},handleEventSync:function(event){var exceptions=event.remote.exceptions;delete event.remote.exceptions;var id=event._id;this._busytimeStore.removeEvent(id);this.eventQueue.push(event);var component=event.remote.icalComponent;delete event.remote.icalComponent;if(!event.remote.recurrenceId){this.icalQueue.push({data:component,eventId:event._id});}
if(exceptions){for(var i=0;i<exceptions.length;i++){this.handleEventSync(this.formatEvent(exceptions[i]));}}},_onRemoveAccount:function(id){if(id===this.account._id){this.abort();}},abort:function(){if(this._aborted){return;}
this._aborted=true;if(this._trans){this._trans.abort();}},handleEvent:function(event){if(this._aborted){return;}
var data=event.data;switch(event.type){case'missingEvents':this.removeList=data[0];break;case'occurrence':var occur=this.formatBusytime(data[0]);this.handleOccurrenceSync(occur);break;case'component':this.handleComponentSync(data[0]);break;case'event':var e=this.formatEvent(data[0]);this.handleEventSync(e);break;}},commit:function(trans,callback){var eventStore=this.app.store('Event');var icalComponentStore=this.app.store('IcalComponent');var calendarStore=this.app.store('Calendar');var busytimeStore=this.app.store('Busytime');var alarmStore=this.app.store('Alarm');if(typeof(trans)==='function'){callback=trans;trans=calendarStore.db.transaction(['calendars','events','busytimes','alarms','icalComponents'],'readwrite');}
if(this._aborted){return callback&&callback(null);}
this._trans=trans;var self=this;this.eventQueue.forEach(function(event){debug('add event',event);eventStore.persist(event,trans);});this.icalQueue.forEach(function(ical){debug('add component',ical);icalComponentStore.persist(ical,trans);});this.busytimeQueue.forEach(function(busy){debug('add busytime',busy);busytimeStore.persist(busy,trans);});this.alarmQueue.forEach(function(alarm){debug('add alarm',alarm);alarmStore.persist(alarm,trans);});if(this.removeList){this.removeList.forEach(function(id){eventStore.remove(id,trans);});}
function handleError(e){if(e&&e.type!=='abort'){console.error('Error persisting sync results',e);}
if(e&&e.preventDefault){e.preventDefault();}
self._trans=null;callback&&callback(e);}
trans.addEventListener('error',handleError);trans.addEventListener('abort',handleError);trans.addEventListener('complete',function(){self._trans=null;callback&&callback(null);});return trans;}};});define('provider/caldav',['require','exports','module','./abstract','error','calc','./caldav_pull_events','error','error','./local','error','event_mutations','next_tick'],function(require,exports,module){var Abstract=require('./abstract');var Authentication=require('error').Authentication;var Calc=require('calc');var CaldavPullEvents=require('./caldav_pull_events');var CalendarError=require('error');var InvalidServer=require('error').InvalidServer;var Local=require('./local');var ServerFailure=require('error').ServerFailure;var mutations=require('event_mutations');var nextTick=require('next_tick');var CALDAV_ERROR_MAP={'caldav-authentication':Authentication,'caldav-invalid-entrypoint':InvalidServer,'caldav-server-failure':ServerFailure};function mapError(error,detail){console.error('Error with name:',error.name);var calError=CALDAV_ERROR_MAP[error.name];if(!calError){calError=new CalendarError(error.name,detail);}else{calError=new calError(detail);}
return calError;}
function CaldavProvider(){Abstract.apply(this,arguments);mutations.app=this.app;this.service=this.app.serviceController;this.accounts=this.app.store('Account');this.busytimes=this.app.store('Busytime');this.events=this.app.store('Event');this.icalComponents=this.app.store('IcalComponent');}
module.exports=CaldavProvider;CaldavProvider.prototype={__proto__:Abstract.prototype,role:'caldav',useUrl:true,useCredentials:true,canSync:true,canExpandRecurringEvents:true,daysToSyncInPast:30,canCreateEvent:true,canUpdateEvent:true,canDeleteEvent:true,hasAccountSettings:true,_handleServiceError:function(rawErr,detail){var calendarErr=mapError(rawErr,detail);if(calendarErr instanceof Authentication||calendarErr instanceof InvalidServer){if(detail.account){if(detail.account._id){this.accounts.markWithError(detail.account,calendarErr);}}else{console.error('Permanent server error without an account!');}}
return calendarErr;},calendarCapabilities:function(calendar){var remote=calendar.remote;if(!remote.privilegeSet){return{canUpdateEvent:true,canDeleteEvent:true,canCreateEvent:true};}
var privilegeSet=remote.privilegeSet;var canWriteConent=privilegeSet.indexOf('write-content')!==-1;return{canUpdateEvent:canWriteConent,canCreateEvent:canWriteConent,canDeleteEvent:privilegeSet.indexOf('unbind')!==-1};},eventCapabilities:function(event,callback){if(event.remote.isRecurring){nextTick(function(){callback(null,{canUpdate:false,canDelete:false,canCreate:false});});}else{var calendarStore=this.app.store('Calendar');calendarStore.get(event.calendarId,function(err,calendar){if(err){return callback(err);}
var caps=this.calendarCapabilities(calendar);callback(null,{canCreate:caps.canCreateEvent,canUpdate:caps.canUpdateEvent,canDelete:caps.canDeleteEvent});}.bind(this));}},getAccount:function(account,callback){if(this.bailWhenOffline(callback)){return;}
var self=this;this.service.request('caldav','getAccount',account,function(err,data){if(err){return callback(self._handleServiceError(err,{account:account}));}
callback(null,data);});},formatRemoteCalendar:function(calendar){if(!calendar.color){calendar.color=this.defaultColor;}
return calendar;},findCalendars:function(account,callback){if(this.bailWhenOffline(callback)){return;}
var self=this;function formatCalendars(err,data){if(err){return callback(self._handleServiceError(err,{account:account}));}
if(data){for(var key in data){data[key]=self.formatRemoteCalendar(data[key]);}}
callback(err,data);}
this.service.request('caldav','findCalendars',account.toJSON(),formatCalendars);},_syncEvents:function(account,calendar,cached,callback){var startDate;if(!calendar.firstEventSyncDate){startDate=Calc.createDay(new Date());calendar.firstEventSyncDate=new Date(startDate.valueOf());}else{startDate=new Date(calendar.firstEventSyncDate.valueOf());}
startDate.setDate(startDate.getDate()-this.daysToSyncInPast);var options={startDate:startDate,cached:cached};var stream=this.service.stream('caldav','streamEvents',account.toJSON(),calendar.remote,options);var pull=new CaldavPullEvents(stream,{app:this.app,account:account,calendar:calendar});var calendarStore=this.app.store('Calendar');var syncStart=new Date();var self=this;stream.request(function(err){if(err){return callback(self._handleServiceError(err,{account:account,calendar:calendar}));}
var trans=pull.commit(function(commitErr){if(commitErr){callback(err);return;}
callback(null);});calendar.error=undefined;calendar.lastEventSyncToken=calendar.remote.syncToken;calendar.lastEventSyncDate=syncStart;calendarStore.persist(calendar,trans);});return pull;},_cachedEventsFor:function(calendar,callback){var store=this.app.store('Event');store.eventsForCalendar(calendar._id,function(err,results){if(err){callback(err);return;}
var list=Object.create(null);var i=0;var len=results.length;var item;for(;i<len;i++){item=results[i];list[item.remote.url]={syncToken:item.remote.syncToken,id:item._id};}
callback(null,list);});},syncEvents:function(account,calendar,callback){var self=this;if(this.bailWhenOffline(callback)){return;}
if(!calendar._id){throw new Error('calendar must be assigned an _id');}
if((calendar.lastEventSyncToken&&calendar.lastEventSyncToken===calendar.remote.syncToken)){return nextTick(callback);}
this._cachedEventsFor(calendar,function(err,results){if(err){callback(err);return;}
self._syncEvents(account,calendar,results,callback);});},ensureRecurrencesExpanded:function(maxDate,callback){var self=this;this.icalComponents.findRecurrencesBefore(maxDate,function(err,results){if(err){callback(err);return;}
if(!results.length){callback(null,false);return;}
var groups=Object.create(null);results.forEach(function(comp){var calendarId=comp.calendarId;if(!(calendarId in groups)){groups[calendarId]=[];}
groups[calendarId].push(comp);});var pullGroups=[];var pending=0;var options={maxDate:Calc.dateToTransport(maxDate)};function next(err,pull){pullGroups.push(pull);if(!(--pending)){var trans=self.app.db.transaction(['icalComponents','alarms','busytimes'],'readwrite');trans.oncomplete=function(){callback(null,true);};trans.onerror=function(event){callback(event.result.error.name);};pullGroups.forEach(function(pull){pull.commit(trans);});}}
for(var calendarId in groups){pending++;self._expandComponents(calendarId,groups[calendarId],options,next);}});},_expandComponents:function(calendarId,comps,options,callback){var calStore=this.app.store('Calendar');calStore.ownersOf(calendarId,function(err,owners){if(err){return callback(err);}
var calendar=owners.calendar;var account=owners.account;var stream=this.service.stream('caldav','expandComponents',comps,options);var pull=new CaldavPullEvents(stream,{account:account,calendar:calendar,app:this.app,stores:['busytimes','alarms','icalComponents']});stream.request(function(err){if(err){callback(err);return;}
callback(null,pull);});}.bind(this));},createEvent:function(event,busytime,callback){if(typeof(busytime)==='function'){callback=busytime;busytime=null;}
if(this.bailWhenOffline(callback)){return;}
this.events.ownersOf(event,fetchOwners);var self=this;var calendar;var account;function fetchOwners(err,owners){calendar=owners.calendar;account=owners.account;self.service.request('caldav','createEvent',account,calendar.remote,event.remote,handleRequest);}
function handleRequest(err,remote){if(err){return callback(self._handleServiceError(err,{account:account,calendar:calendar}));}
var event={_id:calendar._id+'-'+remote.id,calendarId:calendar._id};var component={eventId:event._id,ical:remote.icalComponent};delete remote.icalComponent;event.remote=remote;var create=mutations.create({event:event,icalComponent:component});create.commit(function(err){if(err){callback(err);return;}
callback(null,create.busytime,create.event);});}},updateEvent:function(event,busytime,callback){if(typeof(busytime)==='function'){callback=busytime;busytime=null;}
if(this.bailWhenOffline(callback)){return;}
this.events.ownersOf(event,fetchOwners);var self=this;var calendar;var account;function fetchOwners(err,owners){calendar=owners.calendar;account=owners.account;self.icalComponents.get(event._id,fetchComponent);}
function fetchComponent(err,ical){if(err){callback(err);return;}
var details={event:event.remote,icalComponent:ical.ical};self.service.request('caldav','updateEvent',account,calendar.remote,details,handleUpdate);}
function handleUpdate(err,remote){if(err){callback(self._handleServiceError(err,{account:account,calendar:calendar}));return;}
var component={eventId:event._id,ical:remote.icalComponent};delete remote.icalComponent;event.remote=remote;var update=mutations.update({event:event,icalComponent:component});update.commit(function(err){if(err){callback(err);return;}
callback(null,update.busytime,update.event);});}},deleteEvent:function(event,busytime,callback){if(typeof(busytime)==='function'){callback=busytime;busytime=null;}
if(this.bailWhenOffline(callback)){return;}
this.events.ownersOf(event,fetchOwners);var calendar;var account;var self=this;function fetchOwners(err,owners){calendar=owners.calendar;account=owners.account;self.service.request('caldav','deleteEvent',account,calendar.remote,event.remote,handleRequest);}
function handleRequest(err){if(err){callback(self._handleServiceError(err,{account:account,calendar:calendar}));return;}
Local.prototype.deleteEvent.call(self,event,busytime,callback);}},bailWhenOffline:function(callback){if(!this.offlineMessage&&'mozL10n'in window.navigator){this.offlineMessage=window.navigator.mozL10n.get('error-offline');}
var ret=this.app.offline()&&callback;if(ret){var error=new Error();error.name='offline';error.message=this.offlineMessage;callback(error);}
return ret;}};});define('provider/caldav_visual_log',['require','exports','module','calc'],function(require,exports,module){var Calc=require('calc');function EventLogger(){this.events=Object.create(null);this.occurs=Object.create(null);this.richLog={};}
module.exports=EventLogger;EventLogger.prototype={displayLog:function(id,string){if(!(id in this.richLog)){this.richLog[id]=[];}
this.richLog[id].push(string);},addEvent:function(event){var id=event.id;this.events[id]=event;var log=this.formatEvent(event);this.displayLog(id,log);},addBusytime:function(busy){var id=busy.eventId;this.occurs[id]=busy;this.displayLog(id,this.formatBusytime(busy));},formatEvent:function(event){var format=['add event: ('+event.id+')','title:'+event.title,'start:'+(Calc.dateFromTransport(event.start)).toString(),'end:'+(Calc.dateFromTransport(event.end)).toString(),'isException:'+event.isException];return format.join(' || ');},formatBusytime:function(busy){var event=this.events[busy.eventId];var title='busytime for event: '+busy.eventId;if(event){title='busytime for event: '+event.title;}
var format=[title,'start:'+(Calc.dateFromTransport(busy.start)).toString(),'end:'+(Calc.dateFromTransport(busy.end)).toString(),'isException:'+busy.isException];return format.join(' || ');}};});define('provider/provider',['require','exports','module','./abstract','./caldav','./caldav_pull_events','./caldav_visual_log','./local'],function(require,exports){exports.Abstract=require('./abstract');exports.Caldav=require('./caldav');exports.CaldavPullEvents=require('./caldav_pull_events');exports.CaldavVisualLog=require('./caldav_visual_log');exports.Local=require('./local');});define('provider/provider_factory',['require','exports','module','./provider'],function(require,exports){var Provider=require('./provider');var providers=exports.providers={};exports.app=null;exports.get=function(name){if(!providers[name]){providers[name]=new Provider[name]({app:exports.app});}
return providers[name];};});define('store/account',['require','exports','module','models/account','./abstract','debug','promise','extend','next_tick','probably_parse_int','provider/provider_factory'],function(require,exports,module){var AccountModel=require('models/account');var Abstract=require('./abstract');var debug=require('debug')('store/account');var denodeifyAll=require('promise').denodeifyAll;var extend=require('extend');var nextTick=require('next_tick');var probablyParseInt=require('probably_parse_int');var providerFactory=require('provider/provider_factory');function Account(){Abstract.apply(this,arguments);denodeifyAll(this,['verifyAndPersist','sync','markWithError','syncableAccounts','availablePresets']);}
module.exports=Account;Account.prototype={__proto__:Abstract.prototype,_store:'accounts',_parseId:probablyParseInt,_validateModel:function(model,callback){this.all(function(err,allAccounts){if(err){callback(err);return;}
for(var index in allAccounts){if(allAccounts[index].user===model.user&&allAccounts[index].fullUrl===model.fullUrl&&allAccounts[index]._id!==model._id){var dupErr=new Error('Cannot add two accounts with the same url / entry point');dupErr.name='account-exist';callback(dupErr);return;}}
callback();});},verifyAndPersist:function(model,callback){var self=this;var provider=providerFactory.get(model.providerType);provider.getAccount(model.toJSON(),function(err,data){if(err){callback(err);return;}
model.error=undefined;model.calendarHome=data.calendarHome;extend(model,data);self._validateModel(model,function(err){if(err){return callback(err);}
self.persist(model,callback);});});},_dependentStores:['accounts','calendars','events','busytimes','alarms','icalComponents'],_removeDependents:function(id,trans){var store=this.db.getStore('Calendar');store.remotesByAccount(id,trans,function(err,related){if(err){return console.error('Error removing deps for account: ',id);}
var key;for(key in related){store.remove(related[key]._id,trans);}});},sync:function(account,callback){var self=this;var provider=providerFactory.get(account.providerType);var calendarStore=this.db.getStore('Calendar');var persist=[];var calendars;var originalIds;function fetchExistingCalendars(err,results){if(err){return callback(err);}
calendars=results;originalIds=Object.keys(calendars);provider.findCalendars(account,persistCalendars);}
function persistCalendars(err,remoteCals){var key;if(err){callback(err);return;}
for(key in remoteCals){if(remoteCals.hasOwnProperty(key)){var cal=remoteCals[key];var idx=originalIds.indexOf(key);if(idx!==-1){originalIds.splice(idx,1);var original=calendars[key];original.remote=cal;original.error=undefined;persist.push(original);}else{persist.push(calendarStore._createModel({remote:new Object(cal),accountId:account._id}));}}}
if(persist.length||originalIds.length){var trans=self.db.transaction(self._dependentStores,'readwrite');originalIds.forEach(function(id){calendarStore.remove(calendars[id]._id,trans);});persist.forEach(function(object){calendarStore.persist(object,trans);});trans.addEventListener('error',function(err){callback(err);});trans.addEventListener('complete',function(){callback(null);});}else{callback(null);}}
calendarStore.remotesByAccount(account._id,fetchExistingCalendars);},_createModel:function(obj,id){if(!(obj instanceof AccountModel)){obj=new AccountModel(obj);}
if(typeof(id)!=='undefined'){obj._id=id;}
return obj;},markWithError:function(account,error,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=null;}
if(!account._id){throw new Error('given account must be persisted');}
if(!account.error){account.error={name:error.name,date:new Date(),count:0};}
account.error.count++;var calendarStore=this.db.getStore('Calendar');var self=this;function fetchedCalendars(err,calendars){if(!trans){trans=self.db.transaction(self._dependentStores,'readwrite');}
if(err){console.error('Cannot fetch all calendars',err);return self.persist(account,trans,callback);}
for(var id in calendars){calendarStore.markWithError(calendars[id],error,trans);}
self.persist(account,trans);self._transactionCallback(trans,callback);}
calendarStore.remotesByAccount(account._id,fetchedCalendars);},syncableAccounts:function(callback){debug('Will find syncable accounts...');this.all((err,list)=>{if(err){return callback(err);}
var results=[];for(var key in list){var account=list[key];var provider=providerFactory.get(account.providerType);if(provider.canSync){results.push(account);}}
callback(null,results);});},availablePresets:function(presetList,callback){var results=[];var singleUse={};var hasSingleUses=false;for(var preset in presetList){if(presetList[preset].singleUse){hasSingleUses=true;singleUse[preset]=true;}else{results.push(preset);}}
if(!hasSingleUses){return nextTick(function(){callback(null,results);});}
this.all(function(err,list){if(err){callback(err);return;}
for(var id in list){var preset=list[id].preset;if(singleUse[preset]){delete singleUse[preset];}}
callback(null,results.concat(Object.keys(singleUse)));});}};});define('create_dom_promise',['require','exports','module'],function(require,exports,module){module.exports=function createDOMPromise(request){return new Promise((resolve,reject)=>{request.onsuccess=resolve;request.onerror=reject;});};});(function(window){window.NotificationHelper={getIconURI:function nh_getIconURI(app,entryPoint){var icons=app.manifest.icons;if(entryPoint){icons=app.manifest.entry_points[entryPoint].icons;}
if(!icons){return null;}
var sizes=Object.keys(icons).map(function parse(str){return parseInt(str,10);});sizes.sort(function(x,y){return y-x;});var HVGA=document.documentElement.clientWidth<480;var index=sizes[HVGA?sizes.length-1:0];return app.installOrigin+icons[index];},send:function nh_send(titleL10n,options){return new Promise(function(resolve,reject){navigator.mozL10n.once(function(){var title=getL10n(titleL10n);if(options.bodyL10n){options.body=getL10n(options.bodyL10n);}
options.dir=navigator.mozL10n.language.direction;options.lang=navigator.mozL10n.language.code;var notification=new window.Notification(title,options);if(options.closeOnClick!==false){notification.addEventListener('click',function nh_click(){notification.removeEventListener('click',nh_click);notification.close();});}
resolve(notification);});});},};function getL10n(l10nAttrs){if(typeof l10nAttrs==='string'){return navigator.mozL10n.get(l10nAttrs);}
if(l10nAttrs.raw){return l10nAttrs.raw;}
return navigator.mozL10n.get(l10nAttrs.id,l10nAttrs.args);}})(this);define("shared/notification_helper",(function(global){return function(){var ret,fn;return ret||global.NotificationHelper;};}(this)));(function(window){window.mozPerformance={timing:{}};function dispatch(name){if(!window.mozPerfHasListener){return;}
var now=window.performance.now();var epoch=Date.now();setTimeout(function(){var detail={name:name,timestamp:now,epoch:epoch};var event=new CustomEvent('x-moz-perf',{detail:detail});window.dispatchEvent(event);});}
['moz-chrome-dom-loaded','moz-chrome-interactive','moz-app-visually-complete','moz-content-interactive','moz-app-loaded'].forEach(function(eventName){window.addEventListener(eventName,function mozPerfLoadHandler(){dispatch(eventName);},false);});window.PerformanceTestingHelper={dispatch:dispatch};})(window);define("shared/performance_testing_helper",(function(global){return function(){var ret,fn;return ret||global.PerformanceTestingHelper;};}(this)));define('performance',['require','exports','module','shared/performance_testing_helper'],function(require,exports){require('shared/performance_testing_helper');exports._isMonthAgendaInteractive=false;exports._isMonthReady=false;exports._isVisuallyActive=false;exports._isPendingReady=false;var dispatched={};function dispatch(eventType){dispatched[eventType]=true;window.dispatchEvent(new CustomEvent(eventType));}
exports.isComplete=function(eventType){return dispatched[eventType];};exports.domLoaded=function(){window.performance.mark('navigationLoaded');dispatch('moz-chrome-dom-loaded');};exports.chromeInteractive=function(){window.performance.mark('navigationInteractive');dispatch('moz-chrome-interactive');};exports.monthsDayReady=function(){if(exports._isMonthAgendaInteractive){return;}
exports._isMonthAgendaInteractive=true;dispatchVisuallyCompleteAndInteractive();};exports.monthReady=function(){if(exports._isMonthReady){return;}
exports._isMonthReady=true;dispatchVisuallyCompleteAndInteractive();};function dispatchVisuallyCompleteAndInteractive(){if(exports._isVisuallyActive||!exports._isMonthAgendaInteractive||!exports._isMonthReady){return;}
exports._isVisuallyActive=true;window.performance.mark('visuallyLoaded');dispatch('moz-app-visually-complete');window.performance.mark('contentInteractive');dispatch('moz-content-interactive');dispatchAppLoad();}
exports.pendingReady=function(){if(exports._isPendingReady){return;}
exports._isPendingReady=true;dispatchAppLoad();};function dispatchAppLoad(){if(!exports._isVisuallyActive||!exports._isPendingReady){return;}
window.performance.mark('fullyLoaded');dispatch('moz-app-loaded');}});define('notification',['require','exports','module','shared/notification_helper','debug','performance'],function(require,exports,module){var NotificationHelper=require('shared/notification_helper');var debug=require('debug')('notification');var performance=require('performance');var cachedSelf;exports.app=null;exports.sendNotification=function(title,body,url){return getSelf().then(app=>{if(!app){debug('mozApps.getSelf gave us lemons!');return Promise.resolve();}
var icon=NotificationHelper.getIconURI(app);icon+='?';icon+=url;var notification=new Notification(title,{body:body,icon:icon});return new Promise((resolve,reject)=>{notification.onshow=resolve;notification.onerror=reject;notification.onclick=function(){notification.close();launch(url);};});});};function getSelf(){if(!cachedSelf){cachedSelf=new Promise((resolve,reject)=>{var request=navigator.mozApps.getSelf();request.onsuccess=(event)=>{resolve(event.target.result);};request.onerror=()=>{reject(new Error('mozApps.getSelf failed!'));};});}
return cachedSelf;}
function launch(url){if(performance.isComplete('moz-app-loaded')){return foreground(url);}
window.addEventListener('moz-app-loaded',function onMozAppLoaded(){window.removeEventListener('moz-app-loaded',onMozAppLoaded);return foreground(url);});}
exports.launch=launch;function foreground(url){return getSelf().then(app=>{exports.app.go(url);return app&&app.launch();});}});define('message_handler',['require','exports','module','responder','debug','notification'],function(require,exports,module){var Responder=require('responder');var debug=require('debug')('message_handler');var notification=require('notification');exports.app=null;var responder=exports.responder=new Responder();exports.start=function(){if(!('mozSetMessageHandler'in navigator)){debug('mozSetMessageHandler is missing!');return;}
debug('Will listen for alarm messages...');navigator.mozSetMessageHandler('alarm',message=>{debug('Received alarm message!');var data=message.data;switch(data.type){case'sync':responder.emitWhenListener('sync');break;default:responder.emitWhenListener('alarm',data);break;}});debug('Will listen for notification messages...');navigator.mozSetMessageHandler('notification',message=>{debug('Received notification message!');if(!message.clicked){return debug('Notification was not clicked?');}
var url=message.imageURL.split('?')[1];notification.launch(url);});};});define('controllers/notifications',['require','exports','module','calc','date_format','debug','message_handler','notification'],function(require,exports){var calc=require('calc');var dateFormat=require('date_format');var debug=require('debug')('controllers/notifications');var messageHandler=require('message_handler');var notification=require('notification');exports.app=null;exports.observe=function(){debug('Will start notifications controller...');messageHandler.responder.on('alarm',exports.onAlarm);};exports.unobserve=function(){messageHandler.responder.off('alarm',exports.onAlarm);};exports.onAlarm=function(alarm){debug('Will request cpu wake lock...');var lock=navigator.requestWakeLock('cpu');debug('Received cpu lock. Will issue notification...');return issueNotification(alarm).then(()=>{debug('Will release cpu wake lock...');lock.unlock();});};function issueNotification(alarm){var app=exports.app;var eventStore=app.store('Event');var busytimeStore=app.store('Busytime');var trans=app.db.transaction(['busytimes','events']);return Promise.all([eventStore.get(alarm.eventId,trans),busytimeStore.get(alarm.busytimeId,trans)]).then(values=>{var[event,busytime]=values;var begins=calc.dateFromTransport(busytime.start);var distance=dateFormat.fromNow(begins);var now=new Date();var alarmType=begins>now?'alarm-start-notice':'alarm-started-notice';var l10n=navigator.mozL10n;var title=l10n.get(alarmType,{title:event.remote.title,distance:distance});var body=event.remote.description||'';debug('Will send event notification with title:',title,'body:',body);notification.app=exports.app;return notification.sendNotification(title,body,`/alarm-display/${busytime._id}`);});}});define('object',['require','exports','module'],function(require,exports,module){exports.filter=function(obj,fn,thisArg){var results=[];exports.forEach(obj,function(key,value){if(fn.call(thisArg,key,value)){results.push(value);}});return results;};exports.forEach=function(obj,fn,thisArg){exports.map(obj,fn,thisArg);};exports.map=function(obj,fn,thisArg){var results=[];Object.keys(obj).forEach((key)=>{var value=obj[key];var result=fn.call(thisArg,key,value);results.push(result);});return results;};exports.values=function(obj){return exports.map(obj,(key,value)=>{return value;});};});define('store/alarm',['require','exports','module','./abstract','calc','create_dom_promise','debug','promise','controllers/notifications','object'],function(require,exports,module){var Abstract=require('./abstract');var Calc=require('calc');var createDOMPromise=require('create_dom_promise');var debug=require('debug')('store/alarm');var denodeifyAll=require('promise').denodeifyAll;var notificationsController=require('controllers/notifications');var object=require('object');function Alarm(){Abstract.apply(this,arguments);this._processQueue=this._processQueue.bind(this);denodeifyAll(this,['findAllByBusytimeId','workQueue']);}
module.exports=Alarm;Alarm.prototype={__proto__:Abstract.prototype,_store:'alarms',_dependentStores:['alarms'],_alarmAddThresholdHours:48,_addToCache:function(){},_removeFromCache:function(){},autoQueue:false,_processQueue:function(){this.workQueue();},_objectData:function(object){var data=Abstract.prototype._objectData.call(this,object);if(data.startDate){data.trigger=data.startDate;}
return data;},_addDependents:function(obj,trans){if(!this.autoQueue){return;}
trans.addEventListener('complete',this._processQueue);},_moveAlarms:function(now,requiresAlarm,callback){var time=Calc.dateToTransport(now);var utc=time.utc;var minimum=utc+(this._alarmAddThresholdHours*Calc.HOUR);var request=this.db.transaction('alarms','readwrite').objectStore('alarms').index('trigger').openCursor();request.onerror=function(){callback(new Error('Alarm cursor failed to open.'));};var past=[];var future=[];request.onsuccess=function(event){var cursor=event.target.result;if(!cursor||(cursor.key>=minimum&&(!requiresAlarm||future.length))){return dispatchAlarms(past,future).then(callback).catch(error=>debug('Error dispatching alarms:',error));}
var record=cursor.value;var date=Calc.dateFromTransport(record.trigger);var bucket=date<Date.now()?past:future;bucket.push(record);record.triggered=record.trigger;delete record.trigger;cursor.update(record);cursor.continue();};},findAllByBusytimeId:function(busytimeId,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=null;}
if(!trans){trans=this.db.transaction(this._dependentStores);}
var store=trans.objectStore(this._store);var index=store.index('busytimeId');var key=IDBKeyRange.only(busytimeId);index.mozGetAll(key).onsuccess=function(e){callback(null,e.target.result);};},workQueue:function(now,callback){if(typeof(now)==='function'){callback=now;now=null;}
now=now||new Date();var alarms=navigator.mozAlarms;if(!alarms){if(callback){callback(null);}
return;}
var self=this;var requiresAlarm=false;var req=alarms.getAll();req.onsuccess=function(e){var data=e.target.result;var len=data.length;var mozAlarm;requiresAlarm=true;for(var i=0;i<len;i++){mozAlarm=data[i].data;if(mozAlarm&&'eventId'in mozAlarm&&'trigger'in mozAlarm){requiresAlarm=false;break;}}
callback=callback||function(){};self._moveAlarms(now,requiresAlarm,callback);};req.onerror=function(){var msg='failed to get alarms';console.error('CALENDAR:',msg);if(callback){callback(new Error(msg));}};}};function dispatchAlarms(past,future){var eventToAlarm={};past.forEach(alarm=>{var event=alarm.eventId;if(!event||event in eventToAlarm){return;}
eventToAlarm[event]=alarm;});object.forEach(eventToAlarm,(event,alarm)=>{notificationsController.onAlarm(alarm);});var alarms=navigator.mozAlarms;return Promise.all(future.map(alarm=>{var timezone=alarm.triggered.tzid===Calc.FLOATING?'ignoreTimezone':'honorTimezone';return createDOMPromise(alarms.add(Calc.dateFromTransport(alarm.triggered),timezone,alarm));}));}});define('time_observer',['require','exports','module','timespan'],function(require,exports,module){var Timespan=require('timespan');function TimeObserver(){this._timeObservers=[];}
module.exports=TimeObserver;TimeObserver.enhance=function(given){var key;var proto=TimeObserver.prototype;for(key in proto){if(proto.hasOwnProperty(key)){given[key]=proto[key];}}};TimeObserver.prototype={observeTime:function(timespan,callback){if(!(timespan instanceof Timespan)){throw new Error('must pass an instance of Timespan as first argument');}
this._timeObservers.push([timespan,callback]);},findTimeObserver:function(timespan,callback){var len=this._timeObservers.length;var field;var i=0;for(;i<len;i++){field=this._timeObservers[i];if(field[0]===timespan&&field[1]===callback){return i;}}
return-1;},removeTimeObserver:function(timespan,callback){var idx=this.findTimeObserver(timespan,callback);if(idx!==-1){this._timeObservers.splice(idx,1);return true;}else{return false;}},fireTimeEvent:function(type,start,end,data){var i=0;var len=this._timeObservers.length;var observer;var event={time:true,data:data,type:type};for(;i<len;i++){observer=this._timeObservers[i];if(observer[0].overlaps(start,end)){if(typeof(observer[1])==='object'){observer[1].handleEvent(event);}else{observer[1](event);}}}}};});define('binsearch',['require','exports','module'],function(require,exports){exports.find=function(list,seekVal,cmpfunc,aLow,aHigh){var low=((aLow===undefined)?0:aLow),high=((aHigh===undefined)?(list.length-1):aHigh),mid,cmpval;while(low<=high){mid=low+Math.floor((high-low)/2);cmpval=cmpfunc(seekVal,list[mid]);if(cmpval<0){high=mid-1;}else if(cmpval>0){low=mid+1;}else{return mid;}}
return null;};exports.insert=function(list,seekVal,cmpfunc){if(!list.length){return 0;}
var low=0,high=list.length-1,mid,cmpval;while(low<=high){mid=low+Math.floor((high-low)/2);cmpval=cmpfunc(seekVal,list[mid]);if(cmpval<0){high=mid-1;}else if(cmpval>0){low=mid+1;}else{break;}}
if(cmpval<0){return mid;}else if(cmpval>0){return mid+1;}else{return mid;}};});define('compare',['require','exports','module'],function(require,exports,module){module.exports=function(a,b){if(a>b){return 1;}
if(a<b){return-1;}
return 0;};});define('store/busytime',['require','exports','module','./abstract','calc','time_observer','binsearch','compare','promise'],function(require,exports,module){var Abstract=require('./abstract');var Calc=require('calc');var TimeObserver=require('time_observer');var binsearch=require('binsearch');var compare=require('compare');var denodeifyAll=require('promise').denodeifyAll;function Busytime(){Abstract.apply(this,arguments);this._setupCache();denodeifyAll(this,['removeEvent','loadSpan']);}
module.exports=Busytime;Busytime.prototype={__proto__:Abstract.prototype,_store:'busytimes',_dependentStores:['alarms','busytimes'],_setupCache:function(){TimeObserver.call(this);this._byEventId=Object.create(null);},_createModel:function(input,id){return this.initRecord(input,id);},initRecord:function(input,id){var _super=Abstract.prototype._createModel;var model=_super.apply(this,arguments);model.startDate=Calc.dateFromTransport(model.start);model.endDate=Calc.dateFromTransport(model.end);return model;},_removeDependents:function(id,trans){this.db.getStore('Alarm').removeByIndex('busytimeId',id,trans);},removeEvent:function(id,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=undefined;}
if(typeof(trans)==='undefined'){trans=this.db.transaction(this._dependentStores,'readwrite');}
var req=this.removeByIndex('eventId',id,trans);var success=req.onsuccess;var self=this;req.onsuccess=function(e){var cursor=e.target.result;if(cursor){var id=cursor.primaryKey;self.emit('remove',id);}
success(e);};this._transactionCallback(trans,callback);},_startCompare:function(aObj,bObj){var a=aObj.start.utc;var b=bObj.start.utc;return compare(a,b);},loadSpan:function(span,callback){var trans=this.db.transaction(this._store);var store=trans.objectStore(this._store);var startPoint=Calc.dateToTransport(new Date(span.start));var endPoint=Calc.dateToTransport(new Date(span.end));var keyRange=IDBKeyRange.lowerBound(startPoint.utc);var index=store.index('end');var self=this;index.mozGetAll(keyRange).onsuccess=function(e){var data=e.target.result;data=data.sort(self._startCompare);var idx=binsearch.insert(data,{start:{utc:endPoint.utc+1}},self._startCompare);data=data.slice(0,idx);if(callback){callback(null,data.map(function(item){return self.initRecord(item);}));}};},_addToCache:function(){},_removeFromCache:function(){}};});define('models/calendar',['require','exports','module'],function(require,exports,module){function Cal(options){if(typeof(options)==='undefined'){options={};}
this.remote={};for(var key in options){if(options.hasOwnProperty(key)){this[key]=options[key];}}}
module.exports=Cal;Cal.prototype={remote:null,firstEventSyncDate:null,lastEventSyncToken:'',lastEventSyncDate:'',localDisplayed:true,accountId:'',updateRemote:function(provider){var data=provider;if('toJSON'in provider){data=provider.toJSON();}
this.remote=data;},eventSyncNeeded:function(){var local=this.lastEventSyncToken;var remote=this.remote.syncToken;return local!=remote;},set name(name){this.remote.name=name;return this.remote.name;},set color(color){this.remote.color=color;return this.remote.color;},set description(description){this.remote.description=description;return this.remote.description;},get name(){return this.remote.name;},get color(){var color=this.remote.color;if(color){if(color.substr(0,1)==='#'){return color.substr(0,7);}}
return this.remote.color;},get description(){return this.remote.description;},toJSON:function(){var result={error:this.error,remote:this.remote,accountId:this.accountId,localDisplayed:this.localDisplayed,lastEventSyncDate:this.lastEventSyncDate,lastEventSyncToken:this.lastEventSyncToken,firstEventSyncDate:this.firstEventSyncDate};if(this._id||this._id===0){result._id=this._id;}
return result;}};});define('store/calendar',['require','exports','module','./abstract','models/calendar','provider/local','promise','probably_parse_int','provider/provider_factory'],function(require,exports,module){var Abstract=require('./abstract');var CalendarModel=require('models/calendar');var Local=require('provider/local');var denodeifyAll=require('promise').denodeifyAll;var probablyParseInt=require('probably_parse_int');var providerFactory=require('provider/provider_factory');function Store(){Abstract.apply(this,arguments);this._usedColors=[];denodeifyAll(this,['markWithError','remotesByAccount','sync','providerFor','ownersOf']);}
module.exports=Store;Store.REMOTE_COLORS=['#00aacc','#bad600','#df4784','#f9bc17','#0766b7','#76a408','#33a185'];Store.LOCAL_COLOR='#f97c17',Store.capabilities={createEvent:'canCreateEvent',updateEvent:'canUpdateEvent',deleteEvent:'canDeleteEvent'};Store.prototype={__proto__:Abstract.prototype,_store:'calendars',_dependentStores:['calendars','events','busytimes','alarms','icalComponents'],_parseId:probablyParseInt,_createModel:function(obj,id){if(!(obj instanceof CalendarModel)){obj=new CalendarModel(obj);}
if(typeof(id)!=='undefined'){obj._id=id;}
return obj;},_removeDependents:function(id,trans){var store=this.db.getStore('Event');store.removeByIndex('calendarId',id,trans);},markWithError:function(calendar,error,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=null;}
if(!calendar._id){throw new Error('given calendar must be persisted.');}
calendar.error={name:error.name,date:new Date()};this.persist(calendar,trans,callback);},persist:function(calendar,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=undefined;}
this._updateCalendarColor(calendar);var cb=callback;var cached=this._cached[calendar._id];if(cached&&cached.localDisplayed!==calendar.localDisplayed){cb=function(err,id,model){this.emit('calendarVisibilityChange',id,model);callback(err,id,model);}.bind(this);}
Abstract.prototype.persist.call(this,calendar,trans,cb);},remove:function(id,trans,callback){this._removeCalendarColorFromCache(id);Abstract.prototype.remove.apply(this,arguments);},_updateCalendarColor:function(calendar){this._removeCalendarColorFromCache(calendar._id);this._setCalendarColor(calendar);this._usedColors.push(calendar.color);},_removeCalendarColorFromCache:function(id){var color=this._getCachedColorByCalendarId(id);var index=this._usedColors.indexOf(color);if(index!==-1){this._usedColors.splice(index,1);}},_getCachedColorByCalendarId:function(id){return this._cached[id]&&this._cached[id].color;},_setCalendarColor:function(calendar){if(calendar._id===Local.calendarId){calendar.color=Store.LOCAL_COLOR;return;}
var prevColor=this._getCachedColorByCalendarId(calendar._id);if(prevColor&&Store.REMOTE_COLORS.indexOf(prevColor)!==-1){calendar.color=prevColor;}else{calendar.color=this._getNextColor();}},_getNextColor:function(){var available=Store.REMOTE_COLORS.filter(function(color){return this._usedColors.indexOf(color)===-1;},this);return available.length?available[0]:this._getLeastUsedColor();},_getLeastUsedColor:function(){var counter={};this._usedColors.forEach(function(color){counter[color]=(counter[color]||0)+1;});var leastUsedColor;var leastUsedCount=Infinity;for(var color in counter){if(counter[color]<leastUsedCount){leastUsedCount=counter[color];leastUsedColor=color;}}
return leastUsedColor;},shouldDisplayCalendar:function(calendarId){var calendar=this._cached[calendarId];return calendar&&calendar.localDisplayed;},remotesByAccount:function(accountId,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=null;}
if(!trans){trans=this.db.transaction(this._store);}
var store=trans.objectStore(this._store);var reqKey=IDBKeyRange.only(accountId);var req=store.index('accountId').mozGetAll(reqKey);req.onerror=function remotesError(e){callback(e.target.error);};var self=this;req.onsuccess=function remotesSuccess(e){var result=Object.create(null);e.target.result.forEach(function(calendar){result[calendar.remote.id]=self._createModel(calendar,calendar._id);});callback(null,result);};},sync:function(account,calendar,callback){var provider=providerFactory.get(account.providerType);provider.syncEvents(account,calendar,callback);},providerFor:function(calendar,callback){this.ownersOf(calendar,function(err,owners){if(err){return callback(err);}
callback(null,providerFactory.get(owners.account.providerType));});},ownersOf:function(objectOrId,callback){var result={};var accountStore=this.db.getStore('Account');if(objectOrId instanceof CalendarModel){result.calendar=objectOrId;accountStore.get(objectOrId.accountId,fetchAccount);return;}
if(typeof(objectOrId)==='object'){objectOrId=objectOrId.calendarId;}
var calendarStore=this.db.getStore('Calendar');calendarStore.get(objectOrId,fetchCalendar);function fetchCalendar(err,calendar){if(err){return callback(err);}
result.calendar=calendar;accountStore.get(calendar.accountId,fetchAccount);}
function fetchAccount(err,account){if(err){return callback(err);}
result.account=account;callback(null,result);}}};});define('store/event',['require','exports','module','./abstract','calc','./calendar','promise','provider/provider_factory'],function(require,exports,module){var Abstract=require('./abstract');var Calc=require('calc');var Calendar=require('./calendar');var denodeifyAll=require('promise').denodeifyAll;var providerFactory=require('provider/provider_factory');function Events(){Abstract.apply(this,arguments);denodeifyAll(this,['providerFor','findByIds','ownersOf','eventsForCalendar']);}
module.exports=Events;Events.prototype={__proto__:Abstract.prototype,_store:'events',_dependentStores:['events','busytimes','alarms','icalComponents'],_addToCache:function(){},_removeFromCache:function(){},_createModel:function(input,id){var _super=Abstract.prototype._createModel;var model=_super.apply(this,arguments);model.remote.startDate=Calc.dateFromTransport(model.remote.start);model.remote.endDate=Calc.dateFromTransport(model.remote.end);return model;},_removeDependents:function(id,trans){this.removeByIndex('parentId',id,trans);var busy=this.db.getStore('Busytime');busy.removeEvent(id,trans);var component=this.db.getStore('IcalComponent');component.remove(id,trans);},_assignId:function(obj){var id=obj.calendarId+'-'+obj.remote.id;obj._id=id;return id;},providerFor:function(event,callback){this.ownersOf(event,function(err,owners){callback(null,providerFactory.get(owners.account.providerType));});},findByIds:function(ids,callback){var results={};var pending=ids.length;var self=this;if(!pending){callback(null,results);}
function next(){if(!(--pending)){callback(null,results);}}
function success(e){var item=e.target.result;if(item){results[item._id]=self._createModel(item);}
next();}
function error(){next();}
ids.forEach(function(id){var trans=this.db.transaction('events');var store=trans.objectStore('events');var req=store.get(id);req.onsuccess=success;req.onerror=error;},this);},ownersOf:Calendar.prototype.ownersOf,eventsForCalendar:function(calendarId,callback){var trans=this.db.transaction('events');var store=trans.objectStore('events');var index=store.index('calendarId');var key=IDBKeyRange.only(calendarId);var req=index.mozGetAll(key);req.onsuccess=function(e){callback(null,e.target.result);};req.onerror=function(e){callback(e);};}};});define('store/ical_component',['require','exports','module','./abstract','calc','promise'],function(require,exports,module){var Abstract=require('./abstract');var Calc=require('calc');var denodeifyAll=require('promise').denodeifyAll;function IcalComponent(){Abstract.apply(this,arguments);denodeifyAll(this,['findRecurrencesBefore']);}
module.exports=IcalComponent;IcalComponent.prototype={__proto__:Abstract.prototype,_store:'icalComponents',_addToCache:function(){},_removeFromCache:function(){},_createModel:function(object){return object;},_detectPersistType:function(object){return'update';},findRecurrencesBefore:function(maxDate,callback){var trans=this.db.transaction(this._store,'readwrite');trans.onerror=function(event){callback(event.target.error.name);};var time=Calc.dateToTransport(maxDate);var utc=time.utc;var range=IDBKeyRange.bound(0,utc);var store=trans.objectStore(this._store);var idx=store.index('lastRecurrenceId');var req=idx.mozGetAll(range);req.onsuccess=function(event){callback(null,event.target.result);};}};});define('store/setting',['require','exports','module','./abstract','promise','next_tick'],function(require,exports,module){var Abstract=require('./abstract');var denodeifyAll=require('promise').denodeifyAll;var nextTick=require('next_tick');function Setting(){Abstract.apply(this,arguments);denodeifyAll(this,['getValue','set']);}
module.exports=Setting;Setting.prototype={__proto__:Abstract.prototype,_store:'settings',defaults:{standardAlarmDefault:-300,alldayAlarmDefault:32400,syncFrequency:15,syncAlarm:{alarmId:null,start:null,end:null}},_addToCache:function(){},_removeFromCache:function(){},getValue:function(key,callback){var self=this;if(key in this._cached){nextTick(function handleCached(){callback(null,self._cached[key].value);});return;}
this.get(key,function handleStored(err,value){if(err){return callback(err);}
if(value===undefined&&self.defaults[key]!==undefined){value={value:self.defaults[key]};}
self._cached[key]=value;callback(null,value.value);});},set:function(key,value,trans,callback){if(typeof(trans)==='function'){callback=trans;trans=null;}
var cached=this._cached[key];var record;if(cached&&cached._id){cached.value=value;cached.updatedAt=new Date();record=cached;}else{var created=new Date();this._cached[key]=record={_id:key,createdAt:created,updatedAt:created,value:value};}
this.emit(key+'Change',value,record);this.persist(record,trans,callback);}};});define('store/store',['require','exports','module','./abstract','./account','./alarm','./busytime','./calendar','./event','./ical_component','./setting'],function(require,exports){exports.Abstract=require('./abstract');exports.Account=require('./account');exports.Alarm=require('./alarm');exports.Busytime=require('./busytime');exports.Calendar=require('./calendar');exports.Event=require('./event');exports.IcalComponent=require('./ical_component');exports.Setting=require('./setting');});define('db',['require','exports','module','models/account','presets','provider/local','responder','store/store','debug','next_tick','probably_parse_int','ext/uuid'],function(require,exports,module){var Account=require('models/account');var Presets=require('presets');var Local=require('provider/local');var Responder=require('responder');var Store=require('store/store');var debug=require('debug')('db');var nextTick=require('next_tick');var probablyParseInt=require('probably_parse_int');var uuid=require('ext/uuid');var idb=window.indexedDB;const VERSION=15;var store=Object.freeze({events:'events',accounts:'accounts',calendars:'calendars',busytimes:'busytimes',settings:'settings',alarms:'alarms',icalComponents:'icalComponents'});function Db(name,app){this.app=app;this.name=name;this._stores=Object.create(null);Responder.call(this);this._upgradeOperations=[];}
module.exports=Db;Db.prototype={__proto__:Responder.prototype,connection:null,getStore:function(name){if(!(name in this._stores)){try{this._stores[name]=new Store[name](this,this.app);}catch(e){console.error('Error',e.name,e.message);console.error('Failed to load store',name,e.stack);}}
return this._stores[name];},load:function(callback){debug('Will load b2g-calendar db.');var self=this;function setupDefaults(){if(self.oldVersion<8){self._setupDefaults(callback);}else{nextTick(callback);}}
if(this.isOpen){return setupDefaults();}
this.open(VERSION,setupDefaults);},open:function(version,callback){if(typeof(version)==='function'){callback=version;version=VERSION;}
var req=idb.open(this.name,version);this.version=version;var self=this;req.onsuccess=function(){self.isOpen=true;self.connection=req.result;if(self._upgradeOperations.length){var pending=self._upgradeOperations.length;var operation;while((operation=self._upgradeOperations.shift())){operation.call(self,function next(){if(!(--pending)){callback(null,self);self.emit('open',self);}});}}else{callback(null,self);self.emit('open',self);}};req.onblocked=function(error){callback(error,null);self.emit('error',error);};req.onupgradeneeded=function(event){self._handleVersionChange(req.result,event);};req.onerror=function(error){callback(error,null);self.emit('error',error);};},transaction:function(list,state){var names;var self=this;if(typeof(list)==='string'){names=[];names.push(this.store[list]||list);}else{names=list.map(function(name){return self.store[name]||name;});}
return this.connection.transaction(names,state||'readonly');},_handleVersionChange:function(db,event){var newVersion=event.newVersion;var curVersion=event.oldVersion;var transaction=event.currentTarget.transaction;this.hasUpgraded=true;this.oldVersion=curVersion;this.upgradedVersion=newVersion;for(;curVersion<newVersion;curVersion++){if(curVersion<6){var existingNames=db.objectStoreNames;for(var i=0;i<existingNames.length;i++){db.deleteObjectStore(existingNames[i]);}
curVersion=6;var busytimes=db.createObjectStore(store.busytimes,{keyPath:'_id'});busytimes.createIndex('end','end.utc',{unique:false,multiEntry:false});busytimes.createIndex('eventId','eventId',{unique:false,multiEntry:false});var events=db.createObjectStore(store.events,{keyPath:'_id'});events.createIndex('calendarId','calendarId',{unique:false,multiEntry:false});events.createIndex('parentId','parentId',{unique:false,multiEntry:false});db.createObjectStore(store.accounts,{keyPath:'_id',autoIncrement:true});db.createObjectStore(store.calendars,{keyPath:'_id',autoIncrement:true});}else if(curVersion===7){db.createObjectStore(store.settings,{keyPath:'_id'});}else if(curVersion===8){var alarms=db.createObjectStore(store.alarms,{keyPath:'_id',autoIncrement:true});alarms.createIndex('trigger','trigger.utc',{unique:false,multiEntry:false});alarms.createIndex('busytimeId','busytimeId',{unique:false,multiEntry:false});}else if(curVersion===12){var icalComponents=db.createObjectStore(store.icalComponents,{keyPath:'eventId',autoIncrement:false});icalComponents.createIndex('lastRecurrenceId','lastRecurrenceId.utc',{unique:false,multiEntry:false});}else if(curVersion===13){var calendarStore=transaction.objectStore(store.calendars);calendarStore.createIndex('accountId','accountId',{unique:false,multiEntry:false});}else if(curVersion===14){this.sanitizeEvents(transaction);}}},sanitizeEvents:function(trans){var badCalendarIdToEventIds={};var objectStore=trans.objectStore(store.events);objectStore.openCursor().onsuccess=(function(evt){var cursor=evt.target.result;if(!cursor){return this._updateXorDeleteEvents(badCalendarIdToEventIds,trans);}
var calendarId=cursor.value.calendarId;if(typeof(calendarId)==='number'){return cursor.continue();}
var eventIds=badCalendarIdToEventIds[calendarId]||[];eventIds.push(cursor.key);badCalendarIdToEventIds[calendarId]=eventIds;cursor.continue();}).bind(this);},_updateXorDeleteEvents:function(badCalendarIdToEventIds,trans){var calendarIds=Object.keys(badCalendarIdToEventIds);calendarIds.forEach(function(calendarId){calendarId=probablyParseInt(calendarId);var eventIds=badCalendarIdToEventIds[calendarId];var calendars=trans.objectStore(store.calendars);calendars.get(calendarId).onsuccess=(function(evt){var result=evt.target.result;if(result){this._updateEvents(eventIds,calendarId,trans);}else{this._deleteEvents(eventIds,trans);}}).bind(this);},this);},_updateEvents:function(eventIds,calendarId,trans){var eventStore=trans.objectStore(store.events);var busytimeStore=trans.objectStore(store.busytimes);var busytimeStoreIndexedByEventId=busytimeStore.index('eventId');eventIds.forEach(function(eventId){eventStore.get(eventId).onsuccess=function(evt){var result=evt.target.result;result.calendarId=calendarId;eventStore.put(result);};busytimeStoreIndexedByEventId.get(eventId).onsuccess=function(evt){var result=evt.target.result;result.calendarId=calendarId;busytimeStore.put(result);};});},_deleteEvents:function(eventIds,trans){var events=this.getStore('Event');eventIds.forEach(function(eventId){events.remove(eventId,trans);});},get store(){return store;},close:function(){if(this.connection){this.isOpen=false;this.connection.close();this.connection=null;}},clearNonCredentials:function(callback){var stores=['events','busytimes'];var trans=this.transaction(stores,'readwrite');trans.addEventListener('complete',callback);stores.forEach(function(store){store=trans.objectStore(store);store.clear();});},_setupDefaults:function(callback){debug('Will setup defaults.');var calendarStore=this.getStore('Calendar');var accountStore=this.getStore('Account');var trans=calendarStore.db.transaction(['accounts','calendars'],'readwrite');if(callback){trans.addEventListener('error',function(err){callback(err);});trans.addEventListener('complete',function(){callback();});}
var options=Presets.local.options;debug('Creating local calendar with options:',options);var account=new Account(options);account.preset='local';account._id=uuid();var calendar={_id:Local.calendarId,accountId:account._id,remote:Local.defaultCalendar()};accountStore.persist(account,trans);calendarStore.persist(calendar,trans);},deleteDatabase:function(callback){var req=idb.deleteDatabase(this.name);req.onblocked=function(){callback(new Error('blocked'));};req.onsuccess=function(event){callback(null,event);};req.onerror=function(event){callback(event,null);};}};});define('controllers/error',['require','exports','module','error','error','responder','next_tick','notification'],function(require,exports,module){var Authentication=require('error').Authentication;var InvalidServer=require('error').InvalidServer;var Responder=require('responder');var nextTick=require('next_tick');var notification=require('notification');function ErrorController(app){Responder.call(this);this.app=app;this._handlers=Object.create(null);}
module.exports=ErrorController;ErrorController.prototype={__proto__:Responder.prototype,accountErrorUrl:'/update-account/',dispatch:function(error){if(error instanceof Authentication||error instanceof InvalidServer){this.handleAuthenticate(error.detail.account);}
this.emit('error',error);},handleAuthenticate:function(account,callback){if(!account){return console.error('attempting to trigger reauth without an account');}
if(!account.error||account.error.count!==1){return nextTick(callback);}
var lock=navigator.requestWakeLock('cpu');var l10n=navigator.mozL10n;var title=l10n.get('notification-error-sync-title');var description=l10n.get('notification-error-sync-description');var url=this.accountErrorUrl+account._id;notification.app=this.app;notification.sendNotification(title,description,url).then(()=>{callback&&callback();lock.unlock();});}};});define('pending_manager',['require','exports','module'],function(require,exports,module){function PendingManager(){this.objects=[];this.pending=0;this.onstart=this.onstart.bind(this);this.onend=this.onend.bind(this);}
module.exports=PendingManager;PendingManager.prototype={register:function(object){object.on(object.startEvent,this.onstart);object.on(object.completeEvent,this.onend);var wasPending=this.isPending();this.objects.push(object);if(object.pending){this.pending++;if(!wasPending){this.onpending&&this.onpending();}}},unregister:function(object){var idx=this.objects.indexOf(object);if(idx!==-1){this.objects.splice(idx,1);return true;}
return false;},isPending:function(){return this.objects.some((object)=>{return object.pending;});},onstart:function(){if(!this.pending){this.onpending&&this.onpending();}
this.pending++;},onend:function(){this.pending--;if(!this.pending){this.oncomplete&&this.oncomplete();}}};});define('controllers/recurring_events',['require','exports','module','responder','debug','next_tick','provider/provider_factory'],function(require,exports,module){var Responder=require('responder');var debug=require('debug')('controllers/recurring_events');var nextTick=require('next_tick');var providerFactory=require('provider/provider_factory');function RecurringEvents(app){this.app=app;this.accounts=app.store('Account');Responder.call(this);}
module.exports=RecurringEvents;RecurringEvents.prototype={__proto__:Responder.prototype,startEvent:'expandStart',completeEvent:'expandComplete',paddingInDays:85,waitBeforeMove:750,maximumExpansions:25,_moveTimeout:null,pending:false,unobserve:function(){this.app.timeController.removeEventListener('monthChange',this);this.app.syncController.removeEventListener('syncComplete',this);},observe:function(){var time=this.app.timeController;if(time.position){this.queueExpand(time.position);}
time.on('monthChange',this);this.app.syncController.on('syncComplete',this);},handleEvent:function(event){switch(event.type){case'syncComplete':this.queueExpand(this.app.timeController.position);break;case'monthChange':if(this._moveTimeout!==null){clearTimeout(this._moveTimeout);this._moveTimeout=null;}
this._moveTimeout=setTimeout(this.queueExpand.bind(this,event.data[0]),this.waitBeforeMove);break;}},_expandProvider:function(expandDate,provider,callback){debug('Will attempt to expand provider until:',expandDate);var tries=0;var max=this.maximumExpansions;function attemptCompleteExpand(){debug('Will try to complete expansion (tries = '+tries+')');if(tries>=max){return callback(new Error('could not complete expansion after "'+tries+'"'));}
provider.ensureRecurrencesExpanded(expandDate,function(err,didExpand){if(err){return callback(err);}
debug('Expansion attempt did expand:',didExpand);if(!didExpand){callback();}else{tries++;nextTick(attemptCompleteExpand);}});}
attemptCompleteExpand();},queueExpand:function(expandTo){if(this.pending){if(!this._next){this._next=expandTo;}else if(expandTo>this._next){this._next=expandTo;}
return;}
this.pending=true;this.emit('expandStart');var self=this;function expandNext(date){self.expand(date,function(){if(date===self._next){self._next=null;}
var next=self._next;if(!next){self.pending=false;self.emit('expandComplete');return;}
expandNext(next);});}
expandNext(expandTo);},expand:function(expandTo,callback){debug('expand',expandTo);this.accounts.all((err,accounts)=>{if(err){return callback(err);}
var expandDate=new Date(expandTo.valueOf());expandDate.setDate(expandDate.getDate()+this.paddingInDays);var providers=this._getExpandableProviders(accounts);var pending=providers.length;if(!pending){return nextTick(callback);}
providers.forEach(provider=>{this._expandProvider(expandDate,provider,()=>{if(--pending<=0){callback();}});});});},_getExpandableProviders:function(accounts){var providers=[];Object.keys(accounts).forEach(key=>{var account=accounts[key];var provider=providerFactory.get(account.providerType);if(provider&&provider.canExpandRecurringEvents&&providers.indexOf(provider)===-1){providers.push(provider);}});return providers;}};});define('router',['require','exports','module'],function(require,exports,module){var COPY_METHODS=['start','stop','show'];function Router(page){var i=0;var len=COPY_METHODS.length;this.page=page;this._activeObjects=[];for(;i<len;i++){this[COPY_METHODS[i]]=this.page[COPY_METHODS[i]].bind(this.page);}
this._lastState=this._lastState.bind(this);}
module.exports=Router;Router.prototype={mangeObject:function(){var args=Array.prototype.slice.call(arguments);var object=args.shift();this._activeObjects.push(object);if('onactive'in object){object.onactive.apply(object,args);}},clearObjects:function(){var item;while((item=this._activeObjects.pop())){if('oninactive'in item){item.oninactive();}}},_lastState:function(ctx){this.last=ctx;},resetState:function(){if(!this.currentPath){this.currentPath='/month/';}
this.show(this.currentPath);},state:function(path,views,options){options=options||{};if(!Array.isArray(views)){views=[views];}
var self=this;var viewObjs=[];function loadAllViews(ctx,next){var len=views.length;var numViews=len;var i;viewObjs=[];for(i=0;i<numViews;i++){self.app.view(views[i],function(view){viewObjs.push(view);len--;if(!len){next();}});}}
function setPath(ctx,next){if(options.path!==false){document.body.dataset.path=ctx.canonicalPath;document.body.clientWidth;}
next();}
function handleViews(ctx,next){if(options.clear!==false){self.clearObjects();}
for(var i=0;i<viewObjs.length;i++){self.mangeObject(viewObjs[i],ctx);}
if(options.appPath!==false){self.currentPath=ctx.canonicalPath;}
next();}
this.page(path,loadAllViews,setPath,handleViews,this._lastState);},modifier:function(path,view,options){options=options||{};options.appPath=false;options.clear=false;this.state(path,view,options);}};});define('worker/manager',['require','exports','module','responder','debug'],function(require,exports,module){var Responder=require('responder');var debug=require('debug')('worker/manager');const IDLE_CLEANUP_TIME=5000;function Manager(){this._lastId=0;Responder.call(this);this.roles=Object.create(null);this.workers=[];}
module.exports=Manager;Manager.prototype={Worker:Worker,__proto__:Responder.prototype,_onLog:debug,_formatData:function(data){if(data[1]&&data[1].stack&&data[1].constructorName){var err=data[1];var builtErr;if(window[err.constructorName]){builtErr=Object.create(window[err.constructorName].prototype);}else{builtErr=Object.create(Error.prototype);}
var key;for(key in err){if(err.hasOwnProperty(key)){builtErr[key]=err[key];}}
data[1]=builtErr;}
return data;},_onWorkerError:function(worker,err){if(/reference to undefined property/.test(err.message)){return;}
if(worker.instance){worker.instance.terminate();worker.instance=null;}
var pending=worker.pending;worker.pending=Object.create(null);for(var id in pending){if(pending[id].stream){pending[id].stream.emit('error',err);}
pending[id].callback(err);}},_onWorkerMessage:function(worker,event){var data=this._formatData(event.data);var type=data.shift();var match=type.match(/^(\d+) (end|stream)$/);if(type=='log'){this._onLog.apply(this,data);}else if(match){var pending=worker.pending[match[1]];if(pending){this._dispatchMessage(worker,pending,match[2],data);}else{throw new Error('Message arrived for unknown consumer: '+
type+' '+JSON.stringify(data));}}else{this.respond([type].concat(data));}},_dispatchMessage:function(worker,pending,type,data){if(type=='stream'){pending.stream.respond(data);}else{pending.callback.apply(null,data);delete worker.pending[pending.id];if(Object.keys(worker.pending).length){return;}
this._scheduleCleanup(worker);}},_addPending:function(worker,pending){worker.pending[pending.id]=pending;clearTimeout(worker.cleanup);},_scheduleCleanup:function(worker){clearTimeout(worker.cleanup);worker.cleanup=setTimeout(function(){if(Object.keys(worker.pending).length){return;}
if(!worker.instance){return;}
worker.instance.terminate();worker.instance=null;},IDLE_CLEANUP_TIME);},add:function(role,workerURL){debug('Will add',role,'worker at',workerURL);var worker={instance:null,pending:Object.create(null),url:workerURL,cleanup:null};this.workers.push(worker);[].concat(role).forEach(function(role){if(!(role in this.roles)){this.roles[role]=[worker];}else{this.roles[role].push(worker);}},this);},_ensureActiveWorker:function(role){if(role in this.roles){var workers=this.roles[role];var worker=workers[Math.floor(Math.random()*workers.length)];if(worker.instance){return worker;}else{this._startWorker(worker);return worker;}}else{throw new Error('no worker with role "'+role+'" active');}},_startWorker:function(worker){worker.instance=new this.Worker(worker.url+'?time='+Date.now());worker.instance.onerror=this._onWorkerError.bind(this,worker);worker.instance.onmessage=this._onWorkerMessage.bind(this,worker);this._scheduleCleanup(worker);},request:function(role){var args=Array.prototype.slice.call(arguments,1);var callback=args.pop();var worker=null;try{worker=this._ensureActiveWorker(role);}catch(e){callback(e);return;}
var data={id:this._lastId++,role:role,payload:args};this._addPending(worker,{id:data.id,callback:callback});worker.instance.postMessage(['_dispatch',data]);},stream:function(role){var args=Array.prototype.slice.call(arguments,1);var stream=new Responder();var self=this;var data={id:this._lastId++,role:role,payload:args,type:'stream'};stream.request=function(callback){var worker=null;stream.request=function(){throw new Error('stream request has been sent');};try{worker=self._ensureActiveWorker(role);}catch(e){callback(e);return;}
self._addPending(worker,{id:data.id,stream:stream,callback:callback});worker.instance.postMessage(['_dispatch',data]);};return stream;}};});define('controllers/service',['require','exports','module','worker/manager','debug'],function(require,exports,module){var Manager=require('worker/manager');var debug=require('debug')('controllers/service');function Service(){Manager.call(this);}
module.exports=Service;Service.prototype={__proto__:Manager.prototype,start:function(){debug('Will load and initialize worker...');this.add('caldav','/js/caldav_worker.js');}};});define('controllers/sync',['require','exports','module','responder'],function(require,exports,module){var Responder=require('responder');function Sync(app){this.app=app;this.pending=0;Responder.call(this);}
module.exports=Sync;Sync.prototype={__proto__:Responder.prototype,startEvent:'syncStart',completeEvent:'syncComplete',_incrementPending:function(){if(!this.pending){this.emit('syncStart');}
this.pending++;},_resolvePending:function(){if(!(--this.pending)){this.emit('syncComplete');}
if(this.pending<0){dump('\n\n Error calendar sync .pending is < 0 \n\n');}},all:function(callback){if(callback){this.once('syncComplete',callback);}
if(this.app.offline()){this.emit('offline');this.emit('syncComplete');return;}
var account=this.app.store('Account');account.all(function(err,list){for(var key in list){this.account(list[key]);}
if(!this.pending){this.emit('syncComplete');}}.bind(this));},calendar:function(account,calendar,callback){var store=this.app.store('Calendar');var self=this;this._incrementPending();store.sync(account,calendar,err=>{self._resolvePending();this.handleError(err,callback);});},account:function(account,callback){var accountStore=this.app.store('Account');var calendarStore=this.app.store('Calendar');var self=this;this._incrementPending();accountStore.sync(account,err=>{if(err){self._resolvePending();return this.handleError(err,callback);}
var pending=0;function next(){if(!(--pending)){self._resolvePending();if(callback){callback();}}}
function fetchCalendars(err,calendars){if(err){self._resolvePending();return self.handleError(err,callback);}
for(var key in calendars){pending++;self.calendar(account,calendars[key],next);}}
calendarStore.remotesByAccount(account._id,fetchCalendars);});},handleError:function(err,callback){if(callback){return callback(err);}
this.app.errorController.dispatch(err);}};});define('controllers/time',['require','exports','module','calc','responder'],function(require,exports,module){var isSameDate=require('calc').isSameDate;var Responder=require('responder');function Time(app){this.app=app;Responder.call(this);this._timeCache=Object.create(null);}
module.exports=Time;Time.prototype={__proto__:Responder.prototype,_position:null,_currentTimespan:null,_timeCache:null,_scale:null,_mostRecentDayType:'day',cacheLocked:false,get mostRecentDayType(){return this._mostRecentDayType;},get mostRecentDay(){if(this.mostRecentDayType==='selectedDay'){return this.selectedDay;}else{return this.position;}},get timespan(){return this._currentTimespan;},get scale(){return this._scale;},set scale(value){var oldValue=this._scale;if(value!==oldValue){this._scale=value;this.emit('scaleChange',value,oldValue);}},get selectedDay(){return this._selectedDay;},set selectedDay(value){var day=this._selectedDay;this._mostRecentDayType='selectedDay';if(!day||!isSameDate(day,value)){this._selectedDay=value;this.emit('selectedDayChange',value,day);}},moveToMostRecentDay:function(){if(this.mostRecentDayType==='selectedDay'){this.move(this.selectedDay);}},_updateCache:function(type,value){var old=this._timeCache[type];if(!old||!isSameDate(value,old)){this._timeCache[type]=value;this.emit(type+'Change',value,old);}},get month(){return this._timeCache.month;},get day(){return this._timeCache.day;},get year(){return this._timeCache.year;},get position(){return this._position;},move:function(date){var year=date.getFullYear();var month=date.getMonth();var yearDate=new Date(year,0,1);var monthDate=new Date(year,month,1);this._position=date;this._mostRecentDayType='day';this._updateCache('year',yearDate);this._updateCache('month',monthDate);this._updateCache('day',date);}};});;!function(undefined){var isArray=Array.isArray?Array.isArray:function _isArray(obj){return Object.prototype.toString.call(obj)==="[object Array]";};var defaultMaxListeners=10;function init(){this._events={};if(this._conf){configure.call(this,this._conf);}}
function configure(conf){if(conf){this._conf=conf;conf.delimiter&&(this.delimiter=conf.delimiter);conf.maxListeners&&(this._events.maxListeners=conf.maxListeners);conf.wildcard&&(this.wildcard=conf.wildcard);conf.newListener&&(this.newListener=conf.newListener);if(this.wildcard){this.listenerTree={};}}}
function EventEmitter(conf){this._events={};this.newListener=false;configure.call(this,conf);}
function searchListenerTree(handlers,type,tree,i){if(!tree){return[];}
var listeners=[],leaf,len,branch,xTree,xxTree,isolatedBranch,endReached,typeLength=type.length,currentType=type[i],nextType=type[i+1];if(i===typeLength&&tree._listeners){if(typeof tree._listeners==='function'){handlers&&handlers.push(tree._listeners);return[tree];}else{for(leaf=0,len=tree._listeners.length;leaf<len;leaf++){handlers&&handlers.push(tree._listeners[leaf]);}
return[tree];}}
if((currentType==='*'||currentType==='**')||tree[currentType]){if(currentType==='*'){for(branch in tree){if(branch!=='_listeners'&&tree.hasOwnProperty(branch)){listeners=listeners.concat(searchListenerTree(handlers,type,tree[branch],i+1));}}
return listeners;}else if(currentType==='**'){endReached=(i+1===typeLength||(i+2===typeLength&&nextType==='*'));if(endReached&&tree._listeners){listeners=listeners.concat(searchListenerTree(handlers,type,tree,typeLength));}
for(branch in tree){if(branch!=='_listeners'&&tree.hasOwnProperty(branch)){if(branch==='*'||branch==='**'){if(tree[branch]._listeners&&!endReached){listeners=listeners.concat(searchListenerTree(handlers,type,tree[branch],typeLength));}
listeners=listeners.concat(searchListenerTree(handlers,type,tree[branch],i));}else if(branch===nextType){listeners=listeners.concat(searchListenerTree(handlers,type,tree[branch],i+2));}else{listeners=listeners.concat(searchListenerTree(handlers,type,tree[branch],i));}}}
return listeners;}
listeners=listeners.concat(searchListenerTree(handlers,type,tree[currentType],i+1));}
xTree=tree['*'];if(xTree){searchListenerTree(handlers,type,xTree,i+1);}
xxTree=tree['**'];if(xxTree){if(i<typeLength){if(xxTree._listeners){searchListenerTree(handlers,type,xxTree,typeLength);}
for(branch in xxTree){if(branch!=='_listeners'&&xxTree.hasOwnProperty(branch)){if(branch===nextType){searchListenerTree(handlers,type,xxTree[branch],i+2);}else if(branch===currentType){searchListenerTree(handlers,type,xxTree[branch],i+1);}else{isolatedBranch={};isolatedBranch[branch]=xxTree[branch];searchListenerTree(handlers,type,{'**':isolatedBranch},i+1);}}}}else if(xxTree._listeners){searchListenerTree(handlers,type,xxTree,typeLength);}else if(xxTree['*']&&xxTree['*']._listeners){searchListenerTree(handlers,type,xxTree['*'],typeLength);}}
return listeners;}
function growListenerTree(type,listener){type=typeof type==='string'?type.split(this.delimiter):type.slice();for(var i=0,len=type.length;i+1<len;i++){if(type[i]==='**'&&type[i+1]==='**'){return;}}
var tree=this.listenerTree;var name=type.shift();while(name){if(!tree[name]){tree[name]={};}
tree=tree[name];if(type.length===0){if(!tree._listeners){tree._listeners=listener;}
else if(typeof tree._listeners==='function'){tree._listeners=[tree._listeners,listener];}
else if(isArray(tree._listeners)){tree._listeners.push(listener);if(!tree._listeners.warned){var m=defaultMaxListeners;if(typeof this._events.maxListeners!=='undefined'){m=this._events.maxListeners;}
if(m>0&&tree._listeners.length>m){tree._listeners.warned=true;console.error('(node) warning: possible EventEmitter memory '+'leak detected. %d listeners added. '+'Use emitter.setMaxListeners() to increase limit.',tree._listeners.length);console.trace();}}}
return true;}
name=type.shift();}
return true;}
EventEmitter.prototype.delimiter='.';EventEmitter.prototype.setMaxListeners=function(n){this._events||init.call(this);this._events.maxListeners=n;if(!this._conf)this._conf={};this._conf.maxListeners=n;};EventEmitter.prototype.event='';EventEmitter.prototype.once=function(event,fn){this.many(event,1,fn);return this;};EventEmitter.prototype.many=function(event,ttl,fn){var self=this;if(typeof fn!=='function'){throw new Error('many only accepts instances of Function');}
function listener(){if(--ttl===0){self.off(event,listener);}
fn.apply(this,arguments);}
listener._origin=fn;this.on(event,listener);return self;};EventEmitter.prototype.emit=function(){this._events||init.call(this);var type=arguments[0];if(type==='newListener'&&!this.newListener){if(!this._events.newListener){return false;}}
if(this._all){var l=arguments.length;var args=new Array(l-1);for(var i=1;i<l;i++)args[i-1]=arguments[i];for(i=0,l=this._all.length;i<l;i++){this.event=type;this._all[i].apply(this,args);}}
if(type==='error'){if(!this._all&&!this._events.error&&!(this.wildcard&&this.listenerTree.error)){if(arguments[1]instanceof Error){throw arguments[1];}else{throw new Error("Uncaught, unspecified 'error' event.");}
return false;}}
var handler;if(this.wildcard){handler=[];var ns=typeof type==='string'?type.split(this.delimiter):type.slice();searchListenerTree.call(this,handler,ns,this.listenerTree,0);}
else{handler=this._events[type];}
if(typeof handler==='function'){this.event=type;if(arguments.length===1){handler.call(this);}
else if(arguments.length>1)
switch(arguments.length){case 2:handler.call(this,arguments[1]);break;case 3:handler.call(this,arguments[1],arguments[2]);break;default:var l=arguments.length;var args=new Array(l-1);for(var i=1;i<l;i++)args[i-1]=arguments[i];handler.apply(this,args);}
return true;}
else if(handler){var l=arguments.length;var args=new Array(l-1);for(var i=1;i<l;i++)args[i-1]=arguments[i];var listeners=handler.slice();for(var i=0,l=listeners.length;i<l;i++){this.event=type;listeners[i].apply(this,args);}
return(listeners.length>0)||!!this._all;}
else{return!!this._all;}};EventEmitter.prototype.on=function(type,listener){if(typeof type==='function'){this.onAny(type);return this;}
if(typeof listener!=='function'){throw new Error('on only accepts instances of Function');}
this._events||init.call(this);this.emit('newListener',type,listener);if(this.wildcard){growListenerTree.call(this,type,listener);return this;}
if(!this._events[type]){this._events[type]=listener;}
else if(typeof this._events[type]==='function'){this._events[type]=[this._events[type],listener];}
else if(isArray(this._events[type])){this._events[type].push(listener);if(!this._events[type].warned){var m=defaultMaxListeners;if(typeof this._events.maxListeners!=='undefined'){m=this._events.maxListeners;}
if(m>0&&this._events[type].length>m){this._events[type].warned=true;console.error('(node) warning: possible EventEmitter memory '+'leak detected. %d listeners added. '+'Use emitter.setMaxListeners() to increase limit.',this._events[type].length);console.trace();}}}
return this;};EventEmitter.prototype.onAny=function(fn){if(typeof fn!=='function'){throw new Error('onAny only accepts instances of Function');}
if(!this._all){this._all=[];}
this._all.push(fn);return this;};EventEmitter.prototype.addListener=EventEmitter.prototype.on;EventEmitter.prototype.off=function(type,listener){if(typeof listener!=='function'){throw new Error('removeListener only takes instances of Function');}
var handlers,leafs=[];if(this.wildcard){var ns=typeof type==='string'?type.split(this.delimiter):type.slice();leafs=searchListenerTree.call(this,null,ns,this.listenerTree,0);}
else{if(!this._events[type])return this;handlers=this._events[type];leafs.push({_listeners:handlers});}
for(var iLeaf=0;iLeaf<leafs.length;iLeaf++){var leaf=leafs[iLeaf];handlers=leaf._listeners;if(isArray(handlers)){var position=-1;for(var i=0,length=handlers.length;i<length;i++){if(handlers[i]===listener||(handlers[i].listener&&handlers[i].listener===listener)||(handlers[i]._origin&&handlers[i]._origin===listener)){position=i;break;}}
if(position<0){continue;}
if(this.wildcard){leaf._listeners.splice(position,1);}
else{this._events[type].splice(position,1);}
if(handlers.length===0){if(this.wildcard){delete leaf._listeners;}
else{delete this._events[type];}}
return this;}
else if(handlers===listener||(handlers.listener&&handlers.listener===listener)||(handlers._origin&&handlers._origin===listener)){if(this.wildcard){delete leaf._listeners;}
else{delete this._events[type];}}}
return this;};EventEmitter.prototype.offAny=function(fn){var i=0,l=0,fns;if(fn&&this._all&&this._all.length>0){fns=this._all;for(i=0,l=fns.length;i<l;i++){if(fn===fns[i]){fns.splice(i,1);return this;}}}else{this._all=[];}
return this;};EventEmitter.prototype.removeListener=EventEmitter.prototype.off;EventEmitter.prototype.removeAllListeners=function(type){if(arguments.length===0){!this._events||init.call(this);return this;}
if(this.wildcard){var ns=typeof type==='string'?type.split(this.delimiter):type.slice();var leafs=searchListenerTree.call(this,null,ns,this.listenerTree,0);for(var iLeaf=0;iLeaf<leafs.length;iLeaf++){var leaf=leafs[iLeaf];leaf._listeners=null;}}
else{if(!this._events[type])return this;this._events[type]=null;}
return this;};EventEmitter.prototype.listeners=function(type){if(this.wildcard){var handlers=[];var ns=typeof type==='string'?type.split(this.delimiter):type.slice();searchListenerTree.call(this,handlers,ns,this.listenerTree,0);return handlers;}
this._events||init.call(this);if(!this._events[type])this._events[type]=[];if(!isArray(this._events[type])){this._events[type]=[this._events[type]];}
return this._events[type];};EventEmitter.prototype.listenersAny=function(){if(this._all){return this._all;}
else{return[];}};if(typeof define==='function'&&define.amd){define('ext/eventemitter2',[],function(){return EventEmitter;});}else if(typeof exports==='object'){exports.EventEmitter2=EventEmitter;}
else{window.EventEmitter2=EventEmitter;}}();define('utils/mout',['require','exports','module'],function(require,exports){exports.norm=function norm(val,min,max){if(val===min&&min===max){return 1;}
return(val-min)/(max-min);};exports.clamp=function clamp(val,min,max){return val<min?min:(val>max?max:val);};exports.round=function round(value,radix){radix=radix||1;return Math.round(value/radix)*radix;};exports.floor=function floor(val,step){step=Math.abs(step||1);return Math.floor(val/step)*step;};exports.ceil=function ceil(val,step){step=Math.abs(step||1);return Math.ceil(val/step)*step;};exports.lerp=function lerp(ratio,start,end){return start+(end-start)*ratio;};exports.debounce=function debounce(fn,threshold,isAsap){var timeout,result;function debounced(){var args=arguments,context=this;function delayed(){if(!isAsap){result=fn.apply(context,args);}
timeout=null;}
if(timeout){clearTimeout(timeout);}else if(isAsap){result=fn.apply(context,args);}
timeout=setTimeout(delayed,threshold);return result;}
debounced.cancel=function(){clearTimeout(timeout);};return debounced;};exports.throttle=function throttle(fn,delay){var context,timeout,result,args,diff,prevCall=0;function delayed(){prevCall=Date.now();timeout=null;result=fn.apply(context,args);}
function throttled(){context=this;args=arguments;diff=delay-(Date.now()-prevCall);if(diff<=0){clearTimeout(timeout);delayed();}else if(!timeout){timeout=setTimeout(delayed,diff);}
return result;}
throttled.cancel=function(){clearTimeout(timeout);};return throttled;};});define('day_observer',['require','exports','module','calc','ext/eventemitter2','binsearch','compare','utils/mout'],function(require,exports){var Calc=require('calc');var EventEmitter2=require('ext/eventemitter2');var binsearch=require('binsearch');var compare=require('compare');var daysBetween=Calc.daysBetween;var debounce=require('utils/mout').debounce;var getDayId=Calc.getDayId;var isAllDay=Calc.isAllDay;var spanOfMonth=Calc.spanOfMonth;var DISPATCH_DELAY=25;var MAX_CACHED_MONTHS=5;var busytimes=new Map();var events=new Map();var eventsToBusytimes=new Map();var cache=new Map();var dayQueue=new Set();var cachedSpans=[];var cacheLocked=false;var emitter=exports.emitter=new EventEmitter2();exports.busytimeStore=null;exports.calendarStore=null;exports.eventStore=null;exports.syncController=null;exports.timeController=null;exports.init=function(){this.eventStore.on('persist',(id,event)=>cacheEvent(event));this.eventStore.on('remove',removeEventById);this.busytimeStore.on('persist',(id,busy)=>cacheBusytime(busy));this.busytimeStore.on('remove',removeBusytimeById);this.syncController.on('syncStart',()=>{cacheLocked=true;});this.syncController.on('syncComplete',()=>{cacheLocked=false;pruneCache();dispatch();});this.calendarStore.on('calendarVisibilityChange',(id,calendar)=>{var type=calendar.localDisplayed?'add':'remove';busytimes.forEach((busy,busyId)=>{if(busy.calendarId===id){registerBusytimeChange(busyId,type);}});});this.timeController.on('monthChange',loadMonth);var month=this.timeController.month;if(month){loadMonth(month);}};exports.on=function(date,callback){var dayId=getDayId(date);callback(getDay(dayId,date));emitter.on(dayId,callback);};function getDay(dayId,date){if(cache.has(dayId)){return cache.get(dayId);}
var day={dayId:dayId,date:date,amount:0,basic:[],allday:[]};cache.set(dayId,day);return day;}
exports.off=function(date,callback){emitter.off(getDayId(date),callback);};exports.removeAllListeners=function(){emitter.removeAllListeners();};exports.findAssociated=function(busytimeId){return queryBusytime(busytimeId).then(busytime=>{return queryEvent(busytime.eventId).then(event=>{return{busytime:busytime,event:event};});});};function queryBusytime(busytimeId){if(busytimes.has(busytimeId)){return Promise.resolve(busytimes.get(busytimeId));}
return exports.busytimeStore.get(busytimeId);}
function queryEvent(eventId){if(events.has(eventId)){return Promise.resolve(events.get(eventId));}
return exports.eventStore.get(eventId);}
function cacheBusytime(busy){var{_id,startDate,endDate,eventId}=busy;if(outsideSpans(startDate)&&outsideSpans(endDate)){return;}
busytimes.set(_id,busy);eventsToBusytimes.get(eventId).push(_id);registerBusytimeChange(_id);}
function removeBusytimeById(id){var busy=busytimes.get(id);if(!busy){return;}
var eventId=busy.eventId;var ids=eventsToBusytimes.get(eventId).filter(i=>i!==id);eventsToBusytimes.set(eventId,ids);removeEventIfNoBusytimes(ids,eventId);registerBusytimeChange(id,'remove');busytimes.delete(id);}
function cacheEvent(event){var id=event._id;events.set(id,event);if(!eventsToBusytimes.has(id)){eventsToBusytimes.set(id,[]);}}
function removeEventById(id){events.delete(id);eventsToBusytimes.delete(id);}
function registerBusytimeChange(id,type){var busy=busytimes.get(id);var{startDate,endDate}=busy;var end=new Date(endDate.getTime()-1);var isRemove=type==='remove'||!exports.calendarStore.shouldDisplayCalendar(busy.calendarId);daysBetween(startDate,end).forEach(date=>{if(outsideSpans(date)){return;}
var dayId=getDayId(date);if(isRemove&&!cache.has(dayId)){return;}
var day=getDay(dayId,date);day.basic=day.basic.filter(r=>r.busytime._id!==id);day.allday=day.allday.filter(r=>r.busytime._id!==id);if(!isRemove){var group=isAllDay(date,startDate,endDate)?day.allday:day.basic;sortedInsert(group,busy);}
day.amount=day.basic.length+day.allday.length;dayQueue.add(dayId);});dispatch();}
function sortedInsert(group,busy){var index=binsearch.insert(group,busy.startDate,(date,record)=>{return compare(date,record.busytime.startDate);});group.splice(index,0,{event:events.get(busy.eventId),busytime:busy});}
var dispatch=debounce(function(){dayQueue.forEach(id=>{dayQueue.delete(id);if(cache.has(id)){emitter.emit(id,cache.get(id));}});},DISPATCH_DELAY);function loadMonth(newMonth){var span=spanOfMonth(newMonth);var toLoad=span;cachedSpans.every(cached=>toLoad=cached.trimOverlap(toLoad));if(!toLoad){return;}
cachedSpans.push(span);exports.busytimeStore.loadSpan(toLoad,onBusytimeSpanLoad);}
function onBusytimeSpanLoad(err,busytimes){if(err){console.error('Error loading Busytimes from TimeSpan:',err.toString());return;}
var eventIds=Array.from(new Set(busytimes.map(b=>b.eventId).filter(id=>!events.has(id))));exports.eventStore.findByIds(eventIds).then(events=>{Object.keys(events).forEach(key=>cacheEvent(events[key]));busytimes.forEach(cacheBusytime);pruneCache();});}
function pruneCache(){if(cacheLocked){return;}
trimCachedSpans();cache.forEach(removeDayFromCacheIfOutsideSpans);eventsToBusytimes.forEach(removeEventIfNoBusytimes);}
function trimCachedSpans(){while(cachedSpans.length>MAX_CACHED_MONTHS){var baseDate=exports.timeController.month;var maxDiff=0;var maxDiffIndex=0;cachedSpans.forEach((span,i)=>{var diff=Math.abs(span.start-baseDate);if(diff>maxDiff){maxDiff=diff;maxDiffIndex=i;}});cachedSpans.splice(maxDiffIndex,1);}}
function removeDayFromCacheIfOutsideSpans(day,id){if(outsideSpans(day.date)){day.basic.forEach(removeRecordIfOutsideSpans);day.allday.forEach(removeRecordIfOutsideSpans);cache.delete(id);}}
function outsideSpans(date){return!cachedSpans.some(timespan=>timespan.contains(date));}
function removeRecordIfOutsideSpans(record){removeBusytimeIfOutsideSpans(record.busytime);}
function removeBusytimeIfOutsideSpans(busytime){var{_id,startDate,endDate}=busytime;if(outsideSpans(startDate)&&outsideSpans(endDate)){removeBusytimeById(_id);}}
function removeEventIfNoBusytimes(ids,eventId){if(!ids.length){removeEventById(eventId);}}});define('controllers/periodic_sync',['require','exports','module','responder','debug','message_handler'],function(require,exports){var Responder=require('responder');var debug=require('debug')('controllers/periodic_sync');var messageHandler=require('message_handler');var syncAlarm;var prevSyncFrequency;var syncFrequency;var syncing;var scheduling;var events=new Responder();exports.events=events;var accounts;var settings;exports.app=null;exports.observe=function(){debug('Will start periodic sync controller...');var app=exports.app;accounts=app.store('Account');settings=app.store('Setting');return Promise.all([settings.getValue('syncAlarm'),settings.getValue('syncFrequency')]).then(values=>{[syncAlarm,syncFrequency]=values;accounts.on('persist',onAccountsChange);accounts.on('remove',onAccountsChange);debug('Will listen for syncFrequencyChange...');settings.on('syncFrequencyChange',exports);messageHandler.responder.on('sync',exports);return scheduleSync();});};exports.unobserve=function(){syncAlarm=null;prevSyncFrequency=null;syncFrequency=null;syncing=null;scheduling=null;accounts.off('persist',onAccountsChange);accounts.off('remove',onAccountsChange);settings.off('syncFrequencyChange',exports);messageHandler.responder.off('sync',exports);};exports.handleEvent=function(event){switch(event.type){case'sync':return onSync();case'syncFrequencyChange':debug('Received syncFrequencyChange!');return onSyncFrequencyChange(event.data[0]);}};function onSync(){return sync().then(scheduleSync);}
function onSyncFrequencyChange(value){debug('Sync frequency changed to',value);syncFrequency=value;return maybeScheduleSync();}
function onAccountsChange(){debug('Looking up syncable accounts...');return accounts.syncableAccounts().then(syncable=>{if(!syncable||!syncable.length){debug('There are no syncable accounts!');revokePreviousAlarm();events.emit('pause');return;}
debug('There are',syncable.length,'syncable accounts');if(!syncAlarmIssued()){debug('The first syncable account was just added.');return scheduleSync();}});}
function sync(){if(!syncing){syncing=new Promise((resolve,reject)=>{debug('Will request cpu and wifi wake locks...');var cpuLock=navigator.requestWakeLock('cpu');var wifiLock=navigator.requestWakeLock('wifi');debug('Will start periodic sync...');var app=exports.app;app.syncController.all(()=>{debug('Sync complete! Will release cpu and wifi wake locks...');cpuLock.unlock();wifiLock.unlock();events.emit('sync');syncing=null;resolve();});});}
return syncing;}
function scheduleSync(){if(scheduling){return scheduling;}
scheduling=accounts.syncableAccounts().then(syncable=>{if(!syncable||!syncable.length){debug('There seem to be no syncable accounts, will defer scheduling...');return Promise.resolve();}
debug('Will schedule periodic sync in:',syncFrequency);prevSyncFrequency=syncFrequency;revokePreviousAlarm();return issueSyncAlarm().then(cacheSyncAlarm).then(maybeScheduleSync);}).then(()=>{events.emit('schedule');scheduling=null;}).catch(error=>{debug('Error scheduling sync:',error);console.error(error.toString());scheduling=null;});return scheduling;}
function revokePreviousAlarm(){if(!syncAlarmIssued()){debug('No sync alarms issued, nothing to revoke...');return;}
debug('Will revoke alarm',syncAlarm.alarmId);var alarms=navigator.mozAlarms;alarms.remove(syncAlarm.alarmId);}
function issueSyncAlarm(){if(!prevSyncFrequency){debug('Periodic sync disabled!');return Promise.resolve({alarmId:null,start:null,end:null});}
var start=new Date();var end=new Date(start.getTime()+
prevSyncFrequency*60*1000);var alarms=navigator.mozAlarms;var request=alarms.add(end,'ignoreTimezone',{type:'sync'});return new Promise((resolve,reject)=>{request.onsuccess=function(){resolve({alarmId:this.result,start:start,end:end});};request.onerror=function(){reject(this.error);};});}
function cacheSyncAlarm(alarm){debug('Will save alarm:',alarm);syncAlarm=alarm;return settings.set('syncAlarm',syncAlarm);}
function maybeScheduleSync(){if(syncFrequency===prevSyncFrequency){return Promise.resolve();}
if(scheduling){return scheduling.then(scheduleSync);}
return scheduleSync();}
function syncAlarmIssued(){return syncAlarm&&!!syncAlarm.alarmId;}});;(function(){var dispatch=true;var base='';var running;function page(path,fn){if('function'==typeof path){return page('*',path);}
if('function'==typeof fn){var route=new Route(path);for(var i=1;i<arguments.length;++i){page.callbacks.push(route.middleware(arguments[i]));}}else if('string'==typeof path){page.show(path,fn);}else{page.start(path);}}
page.callbacks=[];page.base=function(path){if(0==arguments.length)return base;base=path;};page.start=function(options){options=options||{};if(running)return;running=true;if(false===options.dispatch)dispatch=false;if(false!==options.popstate)window.addEventListener('popstate',onpopstate,false);if(false!==options.click)window.addEventListener('click',onclick,false);if(!dispatch)return;page.replace(location.pathname+location.search,null,true,dispatch);};page.stop=function(){running=false;removeEventListener('click',onclick,false);removeEventListener('popstate',onpopstate,false);};page.show=function(path,state){var ctx=new Context(path,state);page.dispatch(ctx);if(!ctx.unhandled)ctx.pushState();return ctx;};page.replace=function(path,state,init,dispatch){var ctx=new Context(path,state);ctx.init=init;if(null==dispatch)dispatch=true;if(dispatch)page.dispatch(ctx);ctx.save();return ctx;};page.dispatch=function(ctx){var i=0;function next(){var fn=page.callbacks[i++];if(!fn)return unhandled(ctx);fn(ctx,next);}
next();};function unhandled(ctx){if(window.location.pathname+window.location.search==ctx.canonicalPath)return;page.stop();ctx.unhandled=true;window.location=ctx.canonicalPath;}
function Context(path,state){if('/'==path[0]&&0!=path.indexOf(base))path=base+path;var i=path.indexOf('?');this.canonicalPath=path;this.path=path.replace(base,'')||'/';this.title=document.title;this.state=state||{};this.state.path=path;this.querystring=~i?path.slice(i+1):'';this.pathname=~i?path.slice(0,i):path;this.params=[];}
page.Context=Context;Context.prototype.pushState=function(){history.pushState(this.state,this.title,this.canonicalPath);};Context.prototype.save=function(){history.replaceState(this.state,this.title,this.canonicalPath);};function Route(path,options){options=options||{};this.path=path;this.method='GET';this.regexp=pathtoRegexp(path,this.keys=[],options.sensitive,options.strict);}
page.Route=Route;Route.prototype.middleware=function(fn){var self=this;return function(ctx,next){if(self.match(ctx.path,ctx.params))return fn(ctx,next);next();}};Route.prototype.match=function(path,params){var keys=this.keys,qsIndex=path.indexOf('?'),pathname=~qsIndex?path.slice(0,qsIndex):path,m=this.regexp.exec(pathname);if(!m)return false;for(var i=1,len=m.length;i<len;++i){var key=keys[i-1];var val='string'==typeof m[i]?decodeURIComponent(m[i]):m[i];if(key){params[key.name]=undefined!==params[key.name]?params[key.name]:val;}else{params.push(val);}}
return true;};function pathtoRegexp(path,keys,sensitive,strict){if(path instanceof RegExp)return path;if(path instanceof Array)path='('+path.join('|')+')';path=path.concat(strict?'':'/?').replace(/\/\(/g,'(?:/').replace(/\+/g,'__plus__').replace(/(\/)?(\.)?:(\w+)(?:(\(.*?\)))?(\?)?/g,function(_,slash,format,key,capture,optional){keys.push({name:key,optional:!!optional});slash=slash||'';return''
+(optional?'':slash)
+'(?:'
+(optional?slash:'')
+(format||'')+(capture||(format&&'([^/.]+?)'||'([^/]+?)'))+')'
+(optional||'');}).replace(/([\/.])/g,'\\$1').replace(/__plus__/g,'(.+)').replace(/\*/g,'(.*)');return new RegExp('^'+path+'$',sensitive?'':'i');};function onpopstate(e){if(e.state){var path=e.state.path;page.replace(path,e.state);}}
function onclick(e){if(1!=which(e))return;if(e.defaultPrevented)return;var el=e.target;while(el&&'A'!=el.nodeName)el=el.parentNode;if(!el||'A'!=el.nodeName)return;var href=el.href;var path=el.pathname+el.search;if(el.hash||'#'==el.getAttribute('href'))return;if(!sameOrigin(href))return;var orig=path;path=path.replace(base,'');if(base&&orig==path)return;e.preventDefault();page.show(orig);}
function which(e){e=e||window.event;return null==e.which?e.button:e.which;}
function sameOrigin(href){var origin=location.protocol+'//'+location.hostname;if(location.port)origin+=':'+location.port;return 0==href.indexOf(origin);}
if('undefined'==typeof module){window.page=page;}else{module.exports=page;}})();define("ext/page",(function(global){return function(){var ret,fn;return ret||global.page;};}(this)));define('snake_case',['require','exports','module'],function(require,exports,module){module.exports=function(name){return name.replace(/^./,chr=>chr.toLowerCase()).replace(/[A-Z]/g,chr=>'_'+chr.toLowerCase());};});define('app',['require','exports','module','shared/accessibility_helper','calc','date_l10n','db','controllers/error','pending_manager','controllers/recurring_events','router','controllers/service','controllers/sync','controllers/time','day_observer','debug','message_handler','next_tick','controllers/notifications','controllers/periodic_sync','ext/page','performance','provider/provider_factory','snake_case'],function(require,exports,module){var AccessibilityHelper=require('shared/accessibility_helper');var Calc=require('calc');var DateL10n=require('date_l10n');var Db=require('db');var ErrorController=require('controllers/error');var PendingManager=require('pending_manager');var RecurringEventsController=require('controllers/recurring_events');var Router=require('router');var ServiceController=require('controllers/service');var SyncController=require('controllers/sync');var TimeController=require('controllers/time');var Views={};var dayObserver=require('day_observer');var debug=require('debug')('app');var messageHandler=require('message_handler');var nextTick=require('next_tick');var notificationsController=require('controllers/notifications');var periodicSyncController=require('controllers/periodic_sync');var page=require('ext/page');var performance=require('performance');var providerFactory=require('provider/provider_factory');var snakeCase=require('snake_case');var pendingClass='pending-operation';module.exports={_mozTimeRefreshTimeout:3000,configure:function(db,router){debug('Configure calendar with db and router.');this.db=db;this.router=router;this.router.app=this;providerFactory.app=this;this._views=Object.create(null);this._routeViewFn=Object.create(null);this._pendingManager=new PendingManager();this._pendingManager.oncomplete=function onpending(){document.body.classList.remove(pendingClass);performance.pendingReady();};this._pendingManager.onpending=function oncomplete(){document.body.classList.add(pendingClass);};messageHandler.app=this;messageHandler.start();this.timeController=new TimeController(this);this.syncController=new SyncController(this);this.serviceController=new ServiceController(this);this.errorController=new ErrorController(this);notificationsController.app=this;periodicSyncController.app=this;dayObserver.busytimeStore=this.store('Busytime');dayObserver.calendarStore=this.store('Calendar');dayObserver.eventStore=this.store('Event');dayObserver.syncController=this.syncController;dayObserver.timeController=this.timeController;this.observePendingObject(this.syncController);if(navigator.mozAudioChannelManager){navigator.mozAudioChannelManager.volumeControlChannel='notification';}},observeDateLocalization:function(){window.addEventListener('localized',DateL10n.localizeElements);window.addEventListener('timeformatchange',()=>{this.setCurrentTimeFormat();DateL10n.changeElementsHourFormat();});},setCurrentTimeFormat:function(){document.body.dataset.timeFormat=navigator.mozHour12?'12':'24';},observePendingObject:function(object){this._pendingManager.register(object);},isPending:function(){return this._pendingManager.isPending();},forceRestart:function(){if(!this.restartPending){this.restartPending=true;this._location.href=this.startingURL;}},go:function(url){this.router.show(url);},state:function(){this.router.state.apply(this.router,arguments);},modifier:function(){this.router.modifier.apply(this.router,arguments);},resetState:function(){this.router.resetState();},_routes:function(){this.state('/week/','Week');this.state('/day/','Day');this.state('/month/',['Month','MonthDayAgenda']);this.modifier('/settings/','Settings',{clear:false});this.modifier('/advanced-settings/','AdvancedSettings');this.state('/alarm-display/:id','ViewEvent',{path:false});this.state('/event/add/','ModifyEvent');this.state('/event/edit/:id','ModifyEvent');this.state('/event/show/:id','ViewEvent');this.modifier('/select-preset/','CreateAccount');this.modifier('/create-account/:preset','ModifyAccount');this.modifier('/update-account/:id','ModifyAccount');this.router.start();performance.chromeInteractive();var pathname=window.location.pathname;if(pathname==='/index.html'||pathname==='/'){this.go('/month/');}},_init:function(){var tablist=document.querySelector('#view-selector');var today=tablist.querySelector('.today a');var tabs=tablist.querySelectorAll('[role="tab"]');this._showTodayDate();this._syncTodayDate();today.addEventListener('click',(e)=>{var date=new Date();this.timeController.move(date);this.timeController.selectedDay=date;e.preventDefault();});tablist.addEventListener('click',(event)=>{if(event.target!==today){AccessibilityHelper.setAriaSelected(event.target,tabs);}});this.setCurrentTimeFormat();this.observeDateLocalization();notificationsController.observe();periodicSyncController.observe();this.store('Alarm').autoQueue=true;this.timeController.move(new Date());this.view('TimeHeader',(header)=>header.render());this.view('CalendarColors',(colors)=>colors.render());document.body.classList.remove('loading');performance.domLoaded();this._routes();var recurringEventsController=new RecurringEventsController(this);this.observePendingObject(recurringEventsController);recurringEventsController.observe();this.recurringEventsController=recurringEventsController;nextTick(()=>this.view('Errors'));},_setPresentDate:function(){var id=Calc.getDayId(new Date());var presentDate=document.querySelector('#month-view [data-date="'+id+'"]');var previousDate=document.querySelector('#month-view .present');previousDate.classList.remove('present');previousDate.classList.add('past');presentDate.classList.add('present');},_showTodayDate:function(){var element=document.querySelector('#today .icon-calendar-today');element.innerHTML=new Date().getDate();},_syncTodayDate:function(){var now=new Date();var midnight=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1,0,0,0);var timeout=midnight.getTime()-now.getTime();setTimeout(()=>{this._showTodayDate();this._setPresentDate();this._syncTodayDate();},timeout);},init:function(){debug('Will initialize calendar app...');var self=this;var pending=2;function next(){pending--;if(!pending){self._init();}}
if(!this.db){this.configure(new Db('b2g-calendar',this),new Router(page));}
this.serviceController.start(false);navigator.mozL10n.once(next);this.db.load(()=>{next();this.store('Calendar').all(()=>dayObserver.init());});},_initView:function(name){var view=new Views[name]({app:this});this._views[name]=view;},view:function(name,cb){if(name in this._views){debug('Found view named ',name);var view=this._views[name];return cb&&nextTick(()=>cb.call(this,view));}
if(name in Views){debug('Must initialize view',name);this._initView(name);return this.view(name,cb);}
var snake=snakeCase(name);debug('Will try to load view',name);require(['views/'+snake],(aView)=>{debug('Loaded view',name);Views[name]=aView;return this.view(name,cb);});},store:function(name){return this.db.getStore(name);},offline:function(){return(navigator&&'onLine'in navigator)?!navigator.onLine:true;}};});(function(){function waitForLoad(){return new Promise(accept=>{if(document.readyState==='complete'){return accept();}
window.addEventListener('load',function onLoad(){window.removeEventListener('load',onLoad);return accept();});});}
console.log('Will configure rjs...');require.config({baseUrl:'/js',waitSeconds:60,paths:{shared:'/shared/js'},shim:{'ext/caldav':{exports:'Caldav'},'ext/ical':{exports:'ICAL'},'ext/page':{exports:'page'},'shared/accessibility_helper':{exports:'AccessibilityHelper'},'shared/gesture_detector':{exports:'GestureDetector'},'shared/input_parser':{exports:'InputParser'},'shared/lazy_loader':{exports:'LazyLoader'},'shared/notification_helper':{exports:'NotificationHelper'},'shared/performance_testing_helper':{exports:'PerformanceTestingHelper'}}});require(['app','debug','next_tick'],(app,debug,nextTick)=>{debug=debug('main');debug('Will wait for window load...');waitForLoad().then(()=>{debug('Window loaded!');debug('Will listen for timezone change...');window.addEventListener('moztimechange',()=>{debug('Noticed timezone change!');nextTick(()=>app.forceRestart(),app._mozTimeRefreshTimeout);});app.init();});});}());define("main",function(){});