define([ "require", "l10n!", "cards" ], function(e) {
    var t = e("l10n!"), n = e("cards");
    return {
        extraClasses: [ "anim-fade", "anim-overlay" ],
        onArgs: function(e) {
            this.account = e.account, this.whichSide = e.whichSide, this.restoreCard = e.restoreCard;
            var n = this.account.type;
            if ("imap+smtp" === n || "pop3+smtp" === n) {
                var i = null;
                i = "incoming" === this.whichSide ? "imap+smtp" === n ? "settings-account-clarify-imap" : "settings-account-clarify-pop3" : "settings-account-clarify-smtp", 
                t.setAttributes(this.accountNode, i, {
                    "account-name": this.account.name
                });
            }
        },
        onUsePassword: function() {
            var e = this.passwordNode.value;
            e ? this.account.modifyAccount("incoming" === this.whichSide ? {
                password: e
            } : {
                outgoingPassword: e
            }, this.proceed.bind(this)) : this.proceed();
        },
        proceed: function() {
            this.account.clearProblems(), n.removeCardAndSuccessors(this, "animate", 1, this.restoreCard);
        },
        die: function() {}
    };
});