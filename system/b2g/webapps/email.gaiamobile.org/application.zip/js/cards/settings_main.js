define([ "require", "tmpl!./tng/account_item.html", "api", "cards", "./base", "template!./settings_main.html" ], function(e) {
    var t = e("tmpl!./tng/account_item.html"), n = e("api"), i = e("cards");
    return [ e("./base")(e("template!./settings_main.html")), {
        createdCallback: function() {
            this.acctsSlice = n.viewAccounts(!1), this.acctsSlice.onsplice = this.onAccountsSplice.bind(this), 
            this._secretButtonClickCount = 0, this._secretButtonTimer = null;
        },
        extraClasses: [ "anim-fade", "anim-overlay" ],
        onClose: function() {
            i.removeCardAndSuccessors(this, "animate", 1, 1);
        },
        onAccountsSplice: function(e, n, i) {
            var o, s = this.accountsContainer;
            if (n) for (var r = e + n - 1; r >= e; r--) o = this.acctsSlice.items[r], s.removeChild(o.element);
            var a = e >= s.childElementCount ? null : s.children[e], c = this;
            i.forEach(function(e) {
                var n = e.element = t.cloneNode(!0);
                n.account = e, c.updateAccountDom(e, !0), s.insertBefore(n, a);
            });
        },
        updateAccountDom: function(e, t) {
            var n = e.element;
            if (t) {
                var i = n.querySelector(".tng-account-item-label");
                i.textContent = e.name, n.setAttribute("aria-label", e.name), n.addEventListener("click", this.onClickEnterAccount.bind(this, e), !1);
            }
        },
        onClickAddAccount: function() {
            i.pushCard("setup_account_info", "animate", {
                allowBack: !0
            }, "right");
        },
        onClickEnterAccount: function(e) {
            i.pushCard("settings_account", "animate", {
                account: e
            }, "right");
        },
        onClickSecretButton: function() {
            null === this._secretButtonTimer && (this._secretButtonTimer = window.setTimeout(function() {
                this._secretButtonTimer = null, this._secretButtonClickCount = 0;
            }.bind(this), 2e3)), ++this._secretButtonClickCount >= 5 && (window.clearTimeout(this._secretButtonTimer), 
            this._secretButtonTimer = null, this._secretButtonClickCount = 0, i.pushCard("settings_debug", "animate", {}, "right"));
        },
        die: function() {
            this.acctsSlice.die();
        }
    } ];
});