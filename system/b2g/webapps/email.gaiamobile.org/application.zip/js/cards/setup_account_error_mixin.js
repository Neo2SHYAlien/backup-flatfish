define([ "require", "./setup_l10n_map", "l10n!" ], function(e) {
    var t = e("./setup_l10n_map"), n = e("l10n!");
    return {
        showError: function(e, i) {
            this.errorRegionNode.classList.remove("collapsed");
            var o = t.hasOwnProperty(e) ? t[e] : t.unknown;
            n.setAttributes(this.errorMessageNode, o, i), this.scrollBelowNode.scrollTop = 0;
        }
    };
});