define("tmpl!cards/cmp/attachment_item.html", [ "tmpl" ], function(e) {
    return e.toDom('<li class="cmp-attachment-item">\n  <span class="cmp-attachment-icon"></span>\n  <span class="cmp-attachment-fileinfo">\n    <span dir="auto" class="cmp-attachment-filename"></span>\n    <span class="cmp-attachment-filesize"></span>\n  </span>\n  <span class="cmp-attachment-remove"></span>\n</li>');
}), define("tmpl!cards/cmp/contact_menu.html", [ "tmpl" ], function(e) {
    return e.toDom('<form class="cmp-contact-menu" role="dialog" data-type="action">\n  <header></header>\n   <menu>\n     <button class="cmp-contact-menu-edit" data-l10n-id="message-edit-menu-edit">\n      EdiT\n    </button>\n     <button class="cmp-contact-menu-delete" data-l10n-id="message-edit-menu-delete">\n      DeletE\n    </button>\n     <button class="cmp-contact-menu-cancel" data-l10n-id="message-multiedit-cancel">\n      CanceL\n    </button>\n  </menu>\n</form>\n');
}), define("tmpl!cards/cmp/draft_menu.html", [ "tmpl" ], function(e) {
    return e.toDom('<form role="dialog" class="cmp-draft-menu" data-type="action">\n  <menu>\n    <button id="cmp-draft-save" data-l10n-id="compose-draft-save">SaVe DrAft</button>\n    <button id="cmp-draft-discard" class="danger" data-l10n-id="compose-discard-confirm">DisCarD</button>\n    <button id="cmp-draft-cancel" data-l10n-id="message-multiedit-cancel">CanCeL</button>\n  </menu>\n</form>');
}), define("tmpl!cards/cmp/peep_bubble.html", [ "tmpl" ], function(e) {
    return e.toDom('<div class="cmp-peep-bubble peep-bubble" dir="auto">\n  <span class="cmp-peep-name"></span>\n  <span class="cmp-peep-address collapsed"></span>\n</div>\n');
}), define("tmpl!cards/cmp/invalid_addresses.html", [ "tmpl" ], function(e) {
    return e.toDom('<form role="dialog" data-type="confirm">\n  <section>\n    <h1 data-l10n-id="compose-invalid-addresses-title">ConfirmatioN</h1>\n    <p data-l10n-id="compose-invalid-addresses-description"></p>\n  </section>\n  <menu>\n    <button id="cmp-confirm-invalid-addresses"\n            class="confirm-dialog-ok full recommend"\n            data-l10n-id="dialog-button-ok">OK</button>\n  </menu>\n</form>\n');
}), define("tmpl!cards/msg/attach_confirm.html", [ "tmpl" ], function(e) {
    return e.toDom('<form role="dialog" class="msg-attach-confirm" data-type="confirm">\n  <section>\n    <h1></h1>\n    <p></p>\n  </section>\n  <menu>\n    <button id="msg-attach-ok" class="full" data-l10n-id="dialog-button-ok">OK</button>\n  </menu>\n</form>');
}), define("marquee", [], function() {
    var e = {
        timingFunction: [ "linear", "ease" ],
        setup: function(e, t) {
            this._headerNode = t, this._headerWrapper = document.getElementById("marquee-h-wrapper"), 
            this._headerWrapper || (this._headerWrapper = document.createElement("div"), this._headerWrapper.id = "marquee-h-wrapper", 
            this._headerNode.appendChild(this._headerWrapper));
            var n = document.getElementById("marquee-h-text");
            n || (n = document.createElement("div"), n.id = "marquee-h-text", this._headerWrapper.appendChild(n)), 
            n.textContent = e;
        },
        activate: function(t, n) {
            if (this._headerNode && this._headerWrapper) {
                var i, o, s = t || "scroll", a = n || null, r = e.timingFunction.indexOf(a) >= 0 ? a : "linear", c = "marquee", l = document.getElementById("marquee-h-text");
                if (this._headerWrapper.clientWidth < this._headerWrapper.scrollWidth) switch (this._marqueeCssClassList = [], 
                s) {
                  case "scroll":
                    i = c + "-rtl", o = this._headerWrapper.scrollWidth, l.style.width = o + "px", l.classList.add(i + "-start-" + r), 
                    this._marqueeCssClassList.push(i + "-start-" + r);
                    var d = this;
                    l.addEventListener("animationend", function() {
                        l.classList.remove(i + "-start-" + r), this._marqueeCssClassList.pop();
                        var e = d._headerWrapper.clientWidth + "px";
                        l.style.transform = "translateX(" + e + ")", l.classList.add(i), this._marqueeCssClassList.push(i);
                    });
                    break;

                  case "alternate":
                    i = c + "-alt-", o = this._headerWrapper.scrollWidth - this._headerWrapper.clientWidth, 
                    l.style.width = o + "px", l.classList.add(i + r);
                } else {
                    if (!this._marqueeCssClassList) return;
                    for (var u in this._marqueeCssClassList) l.classList.remove(u);
                    l.style.transform = "";
                }
            }
        }
    };
    return e;
}), define("mime_to_class", [], function() {
    return function(e) {
        return e = e || "", "mime-" + (e.split("/")[0] || "");
    };
}), define("file_display", [ "require", "l10n!" ], function(e) {
    var t = e("l10n!");
    return {
        fileSize: function(e, n) {
            var i = Math.ceil(n / 1024);
            t.setAttributes(e, "attachment-size-kib", {
                kilobytes: i
            });
        }
    };
}), define("template!cards/compose.html", [ "template" ], function(e) {
    return {
        createdCallback: e.templateCreatedCallback,
        template: e.objToFn({
            id: "cards/compose.html",
            deps: [],
            text: '<section class="cmp-compose-header" role="region" data-statuscolor="default">\n  <header data-prop="headerNode">\n    <a data-event="click:onBack" href="#" class="cmp-back-btn">\n      <span class="icon icon-back">BacK</span>\n    </a>\n    <menu type="toolbar">\n      <a href="#" data-event="click:onAttachmentAdd"\n         class="cmp-attachment-btn">\n        <span class="icon icon-attachment">AttachmenT</span>\n      </a>\n      <a data-prop="sendButton" data-event="click:onSend"\n         href="#" class="cmp-send-btn">\n      <span class="icon icon-send">SenD</span>\n      </a>\n    </menu>\n    <h1 class="cmp-compose-header-label"\n      data-l10n-id="compose-header-short">ComposE MessagE</h1>\n  </header>\n</section>\n<div data-prop="scrollContainer" class="scrollregion-below-header">\n  <div data-prop="addrBar" class="cmp-envelope-bar">\n    <div class="cmp-addr-bar">\n      <div data-event="click:onContainerClick"\n           class="cmp-envelope-line cmp-combo">\n        <span class="cmp-to-label cmp-addr-label"\n               data-l10n-id="compose-to">tO:</span>\n        <div class="cmp-to-container cmp-addr-container">\n          <div class="cmp-bubble-container">\n              <input data-prop="toNode"\n                     data-event="keydown:onAddressKeydown,input:onAddressInput"\n                     dir="auto"\n                     class="cmp-to-text cmp-addr-text" type="email" />\n          </div>\n        </div>\n        <div data-event="click:onContactAdd"\n             class="cmp-to-add cmp-contact-add"></div>\n      </div>\n      <!-- XXX: spec calls for showing cc/bcc merged until selected,\n           but there is also the case where replying itself might need\n           to expand, so we are deferring that feature -->\n      <div data-event="click:onContainerClick"\n           class="cmp-envelope-line cmp-combo">\n        <span class="cmp-cc-label cmp-addr-label"\n               data-l10n-id="compose-cc">cC:</span>\n        <div class="cmp-cc-container cmp-addr-container">\n          <div class="cmp-bubble-container">\n            <input data-prop="ccNode"\n                   data-event="keydown:onAddressKeydown,input:onAddressInput"\n                   dir="auto"\n                   class="cmp-cc-text cmp-addr-text" type="email" />\n          </div>\n        </div>\n        <div data-event="click:onContactAdd"\n             class="cmp-cc-add cmp-contact-add"></div>\n      </div>\n      <div data-event="click:onContainerClick"\n           class="cmp-envelope-line cmp-combo">\n        <span class="cmp-bcc-label cmp-addr-label"\n               data-l10n-id="compose-bcc">BcC:</span>\n        <div class="cmp-bcc-container cmp-addr-container">\n          <div class="cmp-bubble-container">\n            <input data-prop="bccNode"\n                   data-event="keydown:onAddressKeydown,input:onAddressInput"\n                   dir="auto"\n                   class="cmp-bcc-text cmp-addr-text" type="email" />\n          </div>\n        </div>\n        <div data-event="click:onContactAdd"\n             class="cmp-bcc-add cmp-contact-add"></div>\n      </div>\n    </div>\n    <div class="cmp-envelope-line cmp-subject">\n      <span class="cmp-subject-label"\n             data-l10n-id="compose-subject">SubjecT:</span>\n      <input data-prop="subjectNode"\n             dir="auto"\n             class="cmp-subject-text" type="text" />\n    </div>\n    <div data-prop="errorMessage" class="cmp-error-message collapsed"></div>\n    <div data-prop="attachmentTotal"\n         class="cmp-envelope-line cmp-attachment-total collapsed">\n      <span data-prop="attachmentLabel"\n            class="cmp-attachment-label cmp-addr-label"\n            data-l10n-id="compose-attachments[zero]">AttachmentS:</span>\n      <span data-prop="attachmentsSize" class="cmp-attachment-size"></span>\n    </div>\n    <ul data-prop="attachmentsContainer" class="cmp-attachment-container">\n    </ul>\n  </div>\n  <div data-prop="textBodyNode" class="cmp-body-text" contenteditable="true" role="textbox" aria-multiline="true"></div>\n  <div data-prop="htmlBodyContainer"\n       data-event="click:_focusEditorWithCursorAtEnd"\n       dir="auto"\n       class="cmp-body-html">\n  </div>\n</div>\n'
        })
    };
}), define("cards/compose", [ "require", "exports", "module", "tmpl!./cmp/attachment_item.html", "tmpl!./cmp/contact_menu.html", "tmpl!./cmp/draft_menu.html", "tmpl!./cmp/peep_bubble.html", "tmpl!./cmp/invalid_addresses.html", "tmpl!./msg/attach_confirm.html", "evt", "toaster", "model", "iframe_shims", "marquee", "l10n!", "cards", "confirm_dialog", "mime_to_class", "file_display", "./base", "template!./compose.html", "./editor_mixins" ], function(e, t, n) {
    function i(e, t) {
        if (e.explicitOriginalTarget !== t) {
            e.stopPropagation();
            var n = t.getBoundingClientRect(), i = n.left + n.width / 2;
            t.focus();
            var o = 0;
            e.clientX >= i && (o = t.value.length), t.setSelectionRange(o, o);
        }
    }
    var o = e("tmpl!./cmp/attachment_item.html"), s = e("tmpl!./cmp/contact_menu.html"), a = e("tmpl!./cmp/draft_menu.html"), r = e("tmpl!./cmp/peep_bubble.html"), c = e("tmpl!./cmp/invalid_addresses.html"), l = e("tmpl!./msg/attach_confirm.html"), d = e("evt"), u = e("toaster"), p = e("model"), h = e("iframe_shims"), f = e("marquee"), m = e("l10n!"), g = e("cards"), v = e("confirm_dialog"), _ = e("mime_to_class"), y = e("file_display"), b = 0, x = 512e4;
    return [ e("./base")(e("template!./compose.html")), e("./editor_mixins"), {
        createdCallback: function() {
            this.sending = !1, this._totalAttachmentsFinishing = 0, this._totalAttachmentsDone = 0, 
            this._wantAttachment = !1, this._onAttachmentDone = this._onAttachmentDone.bind(this), 
            this._bindEditor(this.textBodyNode);
            var e = this.querySelector(".cmp-subject");
            e.addEventListener("click", function(t) {
                i(t, e.querySelector("input"));
            }), this.scrollContainer.addEventListener("click", function(e) {
                var t = this.textBodyNode.getBoundingClientRect();
                e.clientY > t.bottom && this._focusEditorWithCursorAtEnd(e);
            }.bind(this)), this._selfClosed = !1;
            var t = n.id + "-" + (b += 1);
            this._dataIdSaveDraft = t + "-saveDraft", this._dataIdSendEmail = t + "-sendEmail";
        },
        onArgs: function(e) {
            this.composer = e.composer, this.composerData = e.composerData || {}, this.activity = e.activity;
        },
        skipEmitContentEvents: !0,
        _focusEditorWithCursorAtEnd: function(e) {
            e && e.stopPropagation();
            var t = this.textBodyNode.lastChild, n = document.createRange();
            n.setStartAfter(t), n.setEndAfter(t), this.textBodyNode.focus();
            var i = window.getSelection();
            i.removeAllRanges(), i.addRange(n);
        },
        postInsert: function() {
            e([ "iframe_shims" ], function() {
                if (this.composer) this._loadStateFromComposer(); else {
                    var e = this.composerData;
                    p.latestOnce("folder", function(t) {
                        this.composer = p.api.beginMessageComposition(e.message, t, e.options, function() {
                            e.onComposer && e.onComposer(this.composer, this), this._loadStateFromComposer();
                        }.bind(this));
                    }.bind(this));
                }
            }.bind(this));
        },
        _loadStateFromComposer: function() {
            function e(e, n) {
                return n ? (n.forEach(function(n) {
                    var i, o;
                    "string" == typeof n ? i = o = n : (i = n.name, o = n.address), t.insertBubble(e, i, o);
                }), void 0) : "";
            }
            var t = this;
            if (e(this.toNode, this.composer.to), e(this.ccNode, this.composer.cc), e(this.bccNode, this.composer.bcc), 
            this.validateAddresses(), this.renderSendStatus(), this.renderAttachments(), this.subjectNode.value = this.composer.subject, 
            this.origText = this.composer.body.text, this.populateEditor(this.composer.body.text), 
            this.composer.body.html) {
                var n = h.createAndInsertIframeForContent(this.composer.body.html, this.scrollContainer, this.htmlBodyContainer, null, "noninteractive", null);
                this.htmlIframeNode = n.iframe;
            }
            this._emittedContentEvents || (d.emit("metrics:contentDone"), this._emittedContentEvents = !0);
        },
        renderSendStatus: function() {
            var e = this.composer.sendStatus || {};
            if ("error" === e.state) {
                var t = e.badAddresses || [];
                console.log("Editing a failed outbox message. Details:", JSON.stringify({
                    err: e.err,
                    badAddressCount: t.length,
                    sendFailures: e.sendFailures
                }, null, " "));
                var n;
                n = t.length || "bad-recipient" === e.err ? "send-failure-recipients" : "send-failure-unknown", 
                this.errorMessage.setAttribute("data-l10n-id", n), this.errorMessage.classList.remove("collapsed");
            } else this.errorMessage.classList.add("collapsed");
        },
        isValidAddress: function(e) {
            var t = p.api.parseMailbox(e);
            return t && t.address;
        },
        extractAddresses: function() {
            var e = [], t = [], n = function(n) {
                for (var i = n.parentNode.querySelectorAll(".cmp-peep-bubble"), o = [], s = 0; s < i.length; s++) {
                    var a = i[s].dataset;
                    o.push({
                        name: a.name,
                        address: a.address
                    });
                }
                if (0 !== n.value.trim().length) {
                    var r = p.api.parseMailbox(n.value);
                    o.push({
                        name: r.name,
                        address: r.address
                    });
                }
                return o.forEach(function(n) {
                    e.push(n), this.isValidAddress(n.address) || t.push(n);
                }.bind(this)), o;
            }.bind(this);
            return {
                to: n(this.toNode),
                cc: n(this.ccNode),
                bcc: n(this.bccNode),
                all: e,
                invalid: t
            };
        },
        _saveStateToComposer: function() {
            var e = this.extractAddresses();
            this.composer.to = e.to, this.composer.cc = e.cc, this.composer.bcc = e.bcc, this.composer.subject = this.subjectNode.value, 
            this.composer.body.text = this.fromEditor();
        },
        _closeCard: function() {
            this._selfClosed = !0, g.removeCardAndSuccessors(this, "animate");
        },
        _saveNeeded: function() {
            var e = this, t = function() {
                var t = e.querySelectorAll(".cmp-peep-bubble");
                return 0 !== t.length || e.toNode.value || e.ccNode.value || e.bccNode.value ? !1 : !0;
            };
            if (!this.composer) return !1;
            var n = this.fromEditor() !== this.composer.body.text;
            return this.subjectNode.value || n || !t() || this.composer.attachments.length || this.composer.hasDraft;
        },
        _saveDraft: function(e, t) {
            return this.sending && "automatic" === e ? (console.log("compose: skipping autosave because send in progress"), 
            void 0) : (this._saveStateToComposer(), d.emit("uiDataOperationStart", this._dataIdSaveDraft), 
            this.composer.saveDraft(function() {
                d.emit("uiDataOperationStop", this._dataIdSaveDraft), t && t();
            }.bind(this)), void 0);
        },
        createBubbleNode: function(e, t) {
            var n = r.cloneNode(!0);
            n.classList.add("peep-bubble"), n.classList.add("msg-peep-bubble"), n.setAttribute("data-address", t), 
            n.querySelector(".cmp-peep-address").textContent = t;
            var i = n.querySelector(".cmp-peep-name");
            return e ? (i.textContent = e, n.setAttribute("data-name", e)) : i.textContent = -1 !== t.indexOf("@") ? t.split("@")[0] : t, 
            n;
        },
        insertBubble: function(e, t, n) {
            var i = e.parentNode, o = this.createBubbleNode(t || n, n);
            i.insertBefore(o, e), this.validateAddresses();
        },
        deleteBubble: function(e) {
            if (e) {
                var t = e.parentNode;
                e.classList.contains("cmp-peep-bubble") && t.removeChild(e), this.validateAddresses();
            }
        },
        editBubble: function(e) {
            if (e) {
                var t = e.parentNode;
                if (e.classList.contains("cmp-peep-bubble")) {
                    t.removeChild(e);
                    var n = t.querySelector(".cmp-addr-text");
                    n.value.length > 0 && (n.value = n.value + ",", this.onAddressInput({
                        target: n
                    }));
                    var i = e.dataset.address, o = n.value.length, s = o + i.length;
                    n.value += i, n.focus(), this.onAddressInput({
                        target: n
                    }), n.setSelectionRange(o, s);
                }
                this.validateAddresses();
            }
        },
        onAddressKeydown: function(e) {
            var t = e.target;
            if (8 === e.keyCode && "" === t.value) {
                var n = t.previousElementSibling;
                this.deleteBubble(n);
            }
        },
        onAddressInput: function(e) {
            var t = e.target, n = !1;
            switch (t.value.slice(-1)) {
              case " ":
                n = -1 !== t.value.indexOf("@");
                break;

              case ",":
              case ";":
                n = !0;
            }
            if (n) {
                t.style.width = "0.5rem";
                var i = p.api.parseMailbox(t.value);
                this.insertBubble(t, i.name, i.address), t.value = "";
            }
            if (!this.stringContainer) {
                this.stringContainer = document.createElement("div"), this.appendChild(this.stringContainer);
                var o = window.getComputedStyle(t);
                this.stringContainer.style.fontSize = o.fontSize;
            }
            this.stringContainer.style.display = "inline-block", this.stringContainer.textContent = t.value, 
            t.style.width = this.stringContainer.clientWidth + 2 + "px", this.validateAddresses();
        },
        onContainerClick: function(e) {
            var t = e.target;
            if (t.classList.contains("cmp-peep-bubble")) {
                var n = s.cloneNode(!0), o = t.querySelector(".cmp-peep-address").textContent, a = n.getElementsByTagName("header")[0];
                f.setup(o, a), g.setStatusColor(n), document.body.appendChild(n), f.activate("alternate", "ease");
                var r = function(e) {
                    switch (g.setStatusColor(), document.body.removeChild(n), e.explicitOriginalTarget.className) {
                      case "cmp-contact-menu-edit":
                        this.editBubble(t);
                        break;

                      case "cmp-contact-menu-delete":
                        this.deleteBubble(t);
                        break;

                      case "cmp-contact-menu-cancel":                    }
                    return !1;
                }.bind(this);
                return n.addEventListener("submit", r), void 0;
            }
            var c = e.currentTarget.getElementsByClassName("cmp-addr-text")[0];
            i(e, c);
        },
        _warnAttachmentSizeExceeded: function(e) {
            var t = l.cloneNode(!0), n = t.getElementsByTagName("h1")[0], i = t.getElementsByTagName("p")[0];
            e > 1 ? (m.setAttributes(n, "composer-attachments-large"), m.setAttributes(i, "compose-attchments-size-exceeded")) : (m.setAttributes(n, "composer-attachment-large"), 
            m.setAttributes(i, "compose-attchment-size-exceeded")), v.show(t, {
                id: "msg-attach-ok",
                handler: function() {}.bind(this)
            });
        },
        _onAttachmentDone: function() {
            this._totalAttachmentsDone += 1, this._totalAttachmentsDone < this._totalAttachmentsFinishing || setTimeout(function() {
                var e = this._wantAttachment;
                this._totalAttachmentsFinishing = 0, this._totalAttachmentsDone = 0, this._wantAttachment = !1, 
                u.isShowing() && u.hide(), e && this.onAttachmentAdd();
            }.bind(this), 600);
        },
        addAttachmentsSubjectToSizeLimits: function(e) {
            var t = 0;
            if (this.composer.attachments) for (var n = 0; n < this.composer.attachments.length; n++) t += this.composer.attachments[n].blob.size;
            for (var i = !1; e.length; ) {
                var o = e.shift();
                if (t += o.blob.size, t >= x) {
                    this._warnAttachmentSizeExceeded(1 + e.length);
                    break;
                }
                this._totalAttachmentsFinishing += 1, this.composer.addAttachment(o, this._onAttachmentDone), 
                i = !0;
            }
            i && this.renderAttachments();
        },
        renderAttachments: function() {
            if (this.composer.attachments && this.composer.attachments.length) {
                this.attachmentsContainer.innerHTML = "";
                for (var e = o, t = e.getElementsByClassName("cmp-attachment-filename")[0], n = e.getElementsByClassName("cmp-attachment-filesize")[0], i = 0; i < this.composer.attachments.length; i++) {
                    var s = this.composer.attachments[i];
                    t.textContent = s.name, y.fileSize(n, s.blob.size);
                    var a = e.cloneNode(!0);
                    this.attachmentsContainer.appendChild(a), a.classList.add(_(s.blob.type)), a.getElementsByClassName("cmp-attachment-remove")[0].addEventListener("click", this.onClickRemoveAttachment.bind(this, a, s));
                }
                this.updateAttachmentsSize(), this.attachmentsContainer.classList.remove("collapsed");
            } else this.attachmentsContainer.classList.add("collapsed");
        },
        updateAttachmentsSize: function() {
            if (m.setAttributes(this.attachmentLabel, "compose-attachments", {
                n: this.composer.attachments.length
            }), 0 === this.composer.attachments.length) this.attachmentsSize.textContent = "", 
            this.attachmentsContainer.classList.add("collapsed"); else {
                for (var e = 0, t = 0; t < this.composer.attachments.length; t++) e += this.composer.attachments[t].blob.size;
                y.fileSize(this.attachmentsSize, e);
            }
            this.composer.attachments.length > 1 ? this.attachmentTotal.classList.remove("collapsed") : this.attachmentTotal.classList.add("collapsed");
        },
        onClickRemoveAttachment: function(e, t) {
            e.parentNode.removeChild(e), this.composer.removeAttachment(t), this.updateAttachmentsSize();
        },
        onBack: function() {
            var e = function() {
                this.activity && (this.activity.postError("cancelled"), this.activity = null), this._closeCard();
            }.bind(this);
            if (!this._saveNeeded()) return console.log("compose: back: no save needed, exiting without prompt"), 
            e(), void 0;
            console.log("compose: back: save needed, prompting");
            var t = a.cloneNode(!0);
            this._savePromptMenu = t, g.setStatusColor(t), document.body.appendChild(t);
            var n = function(n) {
                switch (g.setStatusColor(), document.body.removeChild(t), this._savePromptMenu = null, 
                n.explicitOriginalTarget.id) {
                  case "cmp-draft-save":
                    console.log("compose: explicit draft save on exit"), this._saveDraft("explicit"), 
                    e();
                    break;

                  case "cmp-draft-discard":
                    console.log("compose: explicit draft discard on exit"), this.composer.abortCompositionDeleteDraft(), 
                    e();
                    break;

                  case "cmp-draft-cancel":
                    console.log("compose: canceled compose exit");
                }
                return !1;
            }.bind(this);
            t.addEventListener("submit", n);
        },
        onCurrentCardDocumentVisibilityChange: function() {
            document.hidden && this._saveNeeded() && (console.log("compose: autosaving; we became hidden and save needed."), 
            this._saveDraft("automatic"));
        },
        validateAddresses: function() {
            var e = this.extractAddresses();
            return 0 === e.all.length ? this.sendButton.setAttribute("aria-disabled", "true") : this.sendButton.setAttribute("aria-disabled", "false"), 
            0 === e.invalid.length ? (this.errorMessage.classList.add("collapsed"), !0) : !1;
        },
        onSend: function() {
            this.validateAddresses() ? this.reallySend() : v.show(c.cloneNode(!0), {
                id: "cmp-confirm-invalid-addresses",
                handler: function() {}
            });
        },
        reallySend: function() {
            this._saveStateToComposer();
            var e = this.activity;
            this.sending = !0, console.log("compose: initiating send"), d.emit("uiDataOperationStart", this._dataIdSendEmail), 
            this.composer.finishCompositionSendMessage(function() {
                d.emit("uiDataOperationStop", this._dataIdSendEmail), this.composer && (e && (e.postResult("complete"), 
                e = null), this._closeCard());
            }.bind(this));
        },
        onContactAdd: function(e) {
            e.stopPropagation();
            var t = e.target, n = this;
            t.classList.remove("show");
            try {
                var i = new MozActivity({
                    name: "pick",
                    data: {
                        type: "webcontacts/email"
                    }
                });
                i.onsuccess = function() {
                    if (this.result.email) {
                        var e = t.parentElement.querySelector(".cmp-addr-text"), i = this.result.name;
                        Array.isArray(i) && (i = i[0]), n.insertBubble(e, i, this.result.email);
                    }
                };
            } catch (o) {
                console.log("WebActivities unavailable? : " + o);
            }
        },
        onAttachmentAdd: function(t) {
            if (t && t.stopPropagation(), this._totalAttachmentsFinishing > 0) return this._wantAttachment = !0, 
            u.toast({
                text: m.get("compose-attachment-still-working")
            }), void 0;
            try {
                console.log("compose: attach: triggering web activity");
                var n = new MozActivity({
                    name: "pick",
                    data: {
                        type: [ "image/*", "video/*", "audio/*", "application/*" ],
                        nocrop: !0
                    }
                });
                n.onsuccess = function() {
                    e([ "attachment_name" ], function(e) {
                        var t = n.result.blob, i = n.result.blob.name || n.result.name, o = this.composer.attachments.length + 1;
                        i = e.ensureName(t, i, o), console.log("compose: attach activity success:", i), 
                        i = i.substring(i.lastIndexOf("/") + 1), this.addAttachmentsSubjectToSizeLimits([ {
                            name: i,
                            blob: n.result.blob
                        } ]);
                    }.bind(this));
                }.bind(this);
            } catch (i) {
                console.log("WebActivities unavailable? : " + i);
            }
        },
        die: function() {
            this._savePromptMenu && (document.body.removeChild(this._savePromptMenu), this._savePromptMenu = null), 
            !this._selfClosed && this._saveNeeded() && (console.log("compose: autosaving draft because not self-closed"), 
            this._saveDraft("automatic")), this.composer && (this.composer.die(), this.composer = null);
        }
    } ];
});