define([ "require", "evt", "./base", "template!./setup_done.html" ], function(e) {
    var t = e("evt");
    return [ e("./base")(e("template!./setup_done.html")), {
        onAddAnother: function() {
            t.emit("addAccount");
        },
        onShowMail: function() {
            t.emit("showLatestAccount");
        },
        die: function() {}
    } ];
});