define([ "require", "query_string", "services", "cards" ], function(e) {
    function t(e) {
        var t = e.data;
        if ("oauth2Complete" === e.type) {
            if (!t.code) return i("reject", new Error("no code returned")), void 0;
            console.log("oauth redirect returned with code"), p = !0, n(t.code).then(function(e) {
                var t = 1e3 * parseInt(e.expires_in, 10), n = Date.now() + Math.max(0, t - h), s = {
                    status: "success",
                    tokens: {
                        accessToken: e.access_token,
                        refreshToken: e.refresh_token,
                        expireTimeMS: n
                    },
                    secrets: o
                };
                i("resolve", s);
            }, function(e) {
                i("reject", e);
            });
        } else i("resolve", {
            status: "cancel"
        });
    }
    function n(e) {
        return console.log("redeeming oauth code"), new Promise(function(t, n) {
            var i = new XMLHttpRequest({
                mozSystem: !0
            });
            i.open("POST", a.tokenEndpoint, !0), i.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), 
            i.timeout = h, i.onload = function() {
                if (i.status < 200 || i.status >= 300) console.error("token redemption failed", i.status, i.responseText), 
                n("status" + i.status); else try {
                    var e = JSON.parse(i.responseText);
                    console.log("oauth code redeemed. access_token? " + !!e.access_token + ", refresh_token? " + !!e.refresh_token), 
                    t(e);
                } catch (o) {
                    console.error("badly formed JSON response for token redemption:", i.responseText), 
                    n(o);
                }
            }, i.onerror = function(e) {
                console.error("token redemption weird error:", e), n(e);
            }, i.ontimeout = function() {
                console.error("token redemption timeout"), n("timeout");
            };
            var s = {
                code: e,
                client_id: o.clientId,
                client_secret: o.clientSecret,
                redirect_uri: f,
                grant_type: "authorization_code"
            };
            i.send(c.fromObject(s));
        });
    }
    function i(e, t) {
        console.log("oauth2 fetch reset with action: " + e);
        var n = s[e];
        s = r = null, p = !1, n(t);
    }
    var o, s, r, a, c = e("query_string"), l = e("services"), d = e("cards"), u = l.oauth2, p = !1, h = 3e4, f = "http://localhost";
    return function(e, n) {
        if (s && i("reject", new Error("Multiple oauth calls, starting new one")), r = new Promise(function(e, t) {
            s = {
                resolve: e,
                reject: t
            };
        }), a = e, o = void 0, e.clientId && e.clientSecret ? o = {
            clientId: e.clientId,
            clientSecret: e.clientSecret
        } : e.secretGroup && (o = u[e.secretGroup]), !o) return i("reject", new Error("no secrets for group: " + e.secretGroup)), 
        r;
        var l = {
            client_id: o.clientId,
            redirect_uri: f,
            response_type: "code",
            scope: e.scope,
            max_auth_age: 0
        }, p = e.authEndpoint + "?" + c.fromObject(l);
        if (n) {
            var h = c.fromObject(n);
            h && (p += "&" + h);
        }
        return d.pushCard("setup_oauth2", "animate", {
            url: p,
            onBrowserComplete: t
        }), r;
    };
});