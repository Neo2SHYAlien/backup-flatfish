define("tmpl!cards/msg/contact_menu.html", [ "tmpl" ], function(e) {
    return e.toDom('<form class="msg-contact-menu" role="dialog" data-type="action">\n   <header></header>\n   <menu>\n    <button class="msg-contact-menu-new collapsed" data-l10n-id="message-contact-menu-new">\n      Send new maiL\n    </button>\n    <button class="msg-contact-menu-reply collapsed" data-l10n-id="message-contact-menu-reply">\n      ReplY\n    </button>\n    <button class="msg-contact-menu-view collapsed" data-l10n-id="message-contact-menu-view">\n      View contacT\n    </button>\n    <button class="msg-contact-menu-create-contact collapsed" data-l10n-id="message-contact-menu-create">\n      Save new contacT\n    </button>\n    <button class="msg-contact-menu-add-to-existing-contact collapsed" data-l10n-id="message-contact-menu-add-existing">\n      Add to existing contacT\n    </button>\n     <button class="msg-contact-menu-cancel" data-l10n-id="message-multiedit-cancel">\n      CanceL\n    </button>\n   </menu>\n </form>');
}), define("tmpl!cards/msg/reply_menu.html", [ "tmpl" ], function(e) {
    return e.toDom('<form class="msg-reply-menu" role="dialog" data-type="action">\n  <header></header>\n  <menu>\n    <button class="msg-reply-menu-reply" data-l10n-id="message-reply-menu-reply">\n      ReplY\n    </button>\n    <button class="msg-reply-menu-reply-all" data-l10n-id="message-reply-menu-reply-all">\n      ReplY AlL\n    </button>\n    <button class="msg-reply-menu-forward" data-l10n-id="message-reply-menu-forward">\n      ForwarD\n    </button>\n    <button class="msg-reply-menu-cancel" data-l10n-id="message-reply-menu-cancel">\n      CanceL\n    </button>\n  </menu>\n</form>\n');
}), define("tmpl!cards/msg/browse_confirm.html", [ "tmpl" ], function(e) {
    return e.toDom('<form role="dialog" class="msg-browse-confirm" data-type="confirm">\n  <section>\n    <h1 data-l10n-id="confirm-dialog-title">Confirmation</h1>\n    <p></p>\n  </section>\n  <menu>\n    <button id="msg-browse-cancel" data-l10n-id="message-multiedit-cancel">CanceL</button>\n    <button id="msg-browse-ok" class="recommend" data-l10n-id="dialog-button-ok">OK</button>\n  </menu>\n</form>');
}), define("tmpl!cards/msg/peep_bubble.html", [ "tmpl" ], function(e) {
    return e.toDom('<div class="msg-peep-bubble peep-bubble" dir="auto">\n  <span class="msg-peep-content"></span>\n</div>\n');
}), define("tmpl!cards/msg/attachment_item.html", [ "tmpl" ], function(e) {
    return e.toDom('<li class="msg-attachment-item">\n  <span class="msg-attachment-icon"></span>\n  <span class="msg-attachment-fileinfo">\n    <span dir="auto" class="msg-attachment-filename"></span>\n    <span class="msg-attachment-filesize"></span>\n    <span data-l10n-id="message-attachment-too-large"\n          class="msg-attachment-too-large"></span>\n  </span>\n  <button class="msg-attachment-download">\n    <span class="icon icon-download"></span></button>\n  <span class="msg-attachment-downloading">\n    <progress class="small"></progress>\n  </span>\n  <button class="msg-attachment-view">\n    <span data-l10n-id="message-attachment-view" class="icon icon-view"></span>\n  </button>\n</li>\n');
}), define("tmpl!cards/msg/attachment_disabled_confirm.html", [ "tmpl" ], function(e) {
    return e.toDom('<form role="dialog" class="msg-attachment-disabled-confirm" data-type="confirm">\n  <section>\n    <p><span data-l10n-id="message-send-attachment-disabled-confirm"></span></p>\n  </section>\n  <menu>\n    <button id="msg-attachment-disabled-cancel" data-l10n-id="message-multiedit-cancel">CanceL</button>\n    <button id="msg-attachment-disabled-ok" data-l10n-id="dialog-button-ok">OK</button>\n  </menu>\n</form>');
}), define("marquee", [], function() {
    var e = {
        timingFunction: [ "linear", "ease" ],
        setup: function(e, t) {
            this._headerNode = t, this._headerWrapper = document.getElementById("marquee-h-wrapper"), 
            this._headerWrapper || (this._headerWrapper = document.createElement("div"), this._headerWrapper.id = "marquee-h-wrapper", 
            this._headerNode.appendChild(this._headerWrapper));
            var n = document.getElementById("marquee-h-text");
            n || (n = document.createElement("div"), n.id = "marquee-h-text", this._headerWrapper.appendChild(n)), 
            n.textContent = e;
        },
        activate: function(t, n) {
            if (this._headerNode && this._headerWrapper) {
                var i, o, s = t || "scroll", a = n || null, r = e.timingFunction.indexOf(a) >= 0 ? a : "linear", c = "marquee", l = document.getElementById("marquee-h-text");
                if (this._headerWrapper.clientWidth < this._headerWrapper.scrollWidth) switch (this._marqueeCssClassList = [], 
                s) {
                  case "scroll":
                    i = c + "-rtl", o = this._headerWrapper.scrollWidth, l.style.width = o + "px", l.classList.add(i + "-start-" + r), 
                    this._marqueeCssClassList.push(i + "-start-" + r);
                    var d = this;
                    l.addEventListener("animationend", function() {
                        l.classList.remove(i + "-start-" + r), this._marqueeCssClassList.pop();
                        var e = d._headerWrapper.clientWidth + "px";
                        l.style.transform = "translateX(" + e + ")", l.classList.add(i), this._marqueeCssClassList.push(i);
                    });
                    break;

                  case "alternate":
                    i = c + "-alt-", o = this._headerWrapper.scrollWidth - this._headerWrapper.clientWidth, 
                    l.style.width = o + "px", l.classList.add(i + r);
                } else {
                    if (!this._marqueeCssClassList) return;
                    for (var u in this._marqueeCssClassList) l.classList.remove(u);
                    l.style.transform = "";
                }
            }
        }
    };
    return e;
}), define("mime_to_class", [], function() {
    return function(e) {
        return e = e || "", "mime-" + (e.split("/")[0] || "");
    };
}), define("file_display", [ "require", "l10n!" ], function(e) {
    var t = e("l10n!");
    return {
        fileSize: function(e, n) {
            var i = Math.ceil(n / 1024);
            t.setAttributes(e, "attachment-size-kib", {
                kilobytes: i
            });
        }
    };
}), define("template!cards/message_reader.html", [ "template" ], function(e) {
    return {
        createdCallback: e.templateCreatedCallback,
        template: e.objToFn({
            id: "cards/message_reader.html",
            deps: [],
            text: '<section class="msg-reader-header" role="region" data-statuscolor="default">\n  <header>\n    <a data-event="click:onBack" href="#" class="msg-back-btn">\n      <span class="icon icon-back"></span>\n    </a>\n    <menu type="toolbar">\n      <button data-prop="previousBtn" class="msg-up-btn">\n        <span data-prop="previousIcon" class="icon icon-up"></span>\n      </button>\n      <button data-prop="nextBtn" class="msg-down-btn">\n        <span data-prop="nextIcon" class="icon icon-down"></span>\n      </button>\n    </menu>\n    <h1 dir="auto" class="msg-reader-header-label"></h1>\n  </header>\n</section>\n<div data-prop="scrollContainer"\n     class="scrollregion-below-header scrollregion-horizontal-too">\n  <div data-prop="envelopeBar" class="msg-envelope-bar">\n    <div class="msg-envelope-line msg-envelope-from-line">\n      <span class="msg-envelope-key"\n             data-l10n-id="envelope-from">FroM</span>\n    </div>\n    <!-- the details starts out collapsed, but can be toggled -->\n    <div class="msg-envelope-details">\n      <div class="msg-envelope-line msg-envelope-to-line">\n        <span class="msg-envelope-key"\n               data-l10n-id="envelope-to">tO</span>\n      </div>\n      <div class="msg-envelope-line msg-envelope-cc-line">\n        <span class="msg-envelope-key"\n               data-l10n-id="envelope-cc">cC</span>\n      </div>\n      <div class="msg-envelope-line msg-envelope-bcc-line">\n        <span class="msg-envelope-key"\n               data-l10n-id="envelope-bcc">BcC</span>\n      </div>\n    </div>\n    <div class="msg-envelope-subject-container">\n      <h3 class="msg-envelope-subject"></h3>\n      <span class="msg-envelope-date"></span>\n    </div>\n  </div>\n  <ul data-prop="attachmentsContainer"\n      class="msg-attachments-container collapsed">\n  </ul>\n  <!-- Tells us about remote/not downloaded images, asks to show -->\n  <div data-prop="loadBar" class="msg-reader-load-infobar collapsed">\n    <p data-prop="loadBarText" class="msg-reader-load-infobar-text"></p>\n    <button class="msg-reader-load-infobar-button"></button>\n  </div>\n  <div data-prop="rootBodyNode"\n       class="msg-body-container"><progress></progress></div>\n</div>\n\n<ul class="bb-tablist msg-reader-action-toolbar">\n  <li role="presentation">\n    <button data-prop="deleteBtn" class="icon msg-delete-btn"></button>\n  </li>\n  <li role="presentation">\n    <button data-prop="starBtn" class="icon msg-star-btn"></button>\n  </li>\n  <li role="presentation">\n    <button data-prop="readBtn" class="icon msg-mark-read-btn"></button>\n  </li>\n  <li role="presentation">\n    <button data-prop="moveBtn" class="icon msg-move-btn"></button>\n  </li>\n  <li role="presentation">\n    <button data-prop="replyBtn" class="icon msg-reply-btn"></button>\n  </li>\n</ul>\n'
        })
    };
}), define("cards/message_reader", [ "require", "tmpl!./msg/delete_confirm.html", "tmpl!./msg/contact_menu.html", "tmpl!./msg/reply_menu.html", "tmpl!./msg/browse_confirm.html", "tmpl!./msg/peep_bubble.html", "tmpl!./msg/attachment_item.html", "tmpl!./msg/attachment_disabled_confirm.html", "cards", "confirm_dialog", "date", "toaster", "model", "header_cursor", "evt", "iframe_shims", "marquee", "l10n!", "query_uri", "mime_to_class", "file_display", "message_display", "./base", "template!./message_reader.html" ], function(e) {
    function t(e) {
        return new MozActivity(e);
    }
    var n, i = e("tmpl!./msg/delete_confirm.html"), o = e("tmpl!./msg/contact_menu.html"), s = e("tmpl!./msg/reply_menu.html"), a = e("tmpl!./msg/browse_confirm.html"), r = e("tmpl!./msg/peep_bubble.html"), c = e("tmpl!./msg/attachment_item.html"), l = e("tmpl!./msg/attachment_disabled_confirm.html"), d = e("cards"), u = e("confirm_dialog"), p = e("date"), h = e("toaster"), f = e("model"), m = e("header_cursor").cursor, g = e("evt"), v = e("iframe_shims"), _ = e("marquee"), y = e("l10n!"), b = e("query_uri"), x = e("mime_to_class"), S = e("file_display"), w = e("message_display"), T = [ null, "msg-body-content", "msg-body-signature", "msg-body-leadin", null, "msg-body-disclaimer", "msg-body-list", "msg-body-product", "msg-body-ads" ], A = [ "msg-body-q1", "msg-body-q2", "msg-body-q3", "msg-body-q4", "msg-body-q5", "msg-body-q6", "msg-body-q7", "msg-body-q8", "msg-body-q9" ], k = "msg-body-qmax";
    return [ e("./base")(e("template!./message_reader.html")), {
        createdCallback: function() {
            this.htmlBodyNodes = [], this._on("msg-up-btn", "click", "onPrevious"), this._on("msg-down-btn", "click", "onNext"), 
            this._on("msg-reply-btn", "click", "onReplyMenu"), this._on("msg-delete-btn", "click", "onDelete"), 
            this._on("msg-star-btn", "click", "onToggleStar"), this._on("msg-move-btn", "click", "onMove"), 
            this._on("msg-mark-read-btn", "click", "onMarkRead"), this._on("msg-envelope-bar", "click", "onEnvelopeClick"), 
            this._on("msg-reader-load-infobar", "click", "onLoadBarClick"), this._emittedContentEvents = !1, 
            this.disableReply(), this._builtBodyDom = !1, this.handleBodyChange = this.handleBodyChange.bind(this), 
            this.onMessageSuidNotFound = this.onMessageSuidNotFound.bind(this), this.onCurrentMessage = this.onCurrentMessage.bind(this), 
            m.on("messageSuidNotFound", this.onMessageSuidNotFound), m.latest("currentMessage", this.onCurrentMessage), 
            m.setCurrentMessage(this.header);
        },
        onArgs: function(e) {
            this.messageSuid = e.messageSuid;
        },
        _contextMenuType: {
            VIEW_CONTACT: 1,
            CREATE_CONTACT: 2,
            ADD_TO_CONTACT: 4,
            REPLY: 8,
            NEW_MESSAGE: 16
        },
        skipEmitContentEvents: !0,
        _on: function(e, t, n, i) {
            this.getElementsByClassName(e)[0].addEventListener(t, function(e) {
                return this.header || i ? this[n](e) : void 0;
            }.bind(this), !1);
        },
        _setHeader: function(e) {
            this.header = e.makeCopy(), this.hackMutationHeader = e, this.header.isRead ? this.readBtn.classList.remove("unread") : this.header.setRead(!0), 
            this.starBtn.classList.toggle("msg-star-btn-on", this.hackMutationHeader.isStarred), 
            this.emit("header");
        },
        postInsert: function() {
            this._inDom = !0, this._afterInDomMessage && (this.onCurrentMessage(this._afterInDomMessage), 
            this._afterInDomMessage = null);
        },
        told: function(e) {
            e.messageSuid && (this.messageSuid = e.messageSuid);
        },
        handleBodyChange: function(e) {
            this.buildBodyDom(e.changeDetails);
        },
        onBack: function() {
            d.removeCardAndSuccessors(this, "animate");
        },
        onPrevious: function() {
            m.advance("previous");
        },
        onNext: function() {
            m.advance("next");
        },
        onMessageSuidNotFound: function(e) {
            this.messageSuid === e && this.onBack();
        },
        onCurrentMessage: function(e) {
            if (!this._inDom) return this._afterInDomMessage = e, void 0;
            this.messageSuid = null, this._setHeader(e.header), this.clearDom(), this.latestOnce("header", function() {
                this.buildHeaderDom(this), this.header.getBody({
                    downloadBodyReps: !0
                }, function(e) {
                    this.header.id === e.id && (this.body = e, e.onchange = this.handleBodyChange, e.bodyRepsDownloaded && this.buildBodyDom());
                }.bind(this));
            }.bind(this));
            var t = e.siblings.hasPrevious;
            this.previousBtn.disabled = !t, this.previousIcon.classList[t ? "remove" : "add"]("icon-disabled");
            var n = e.siblings.hasNext;
            this.nextBtn.disabled = !n, this.nextIcon.classList[n ? "remove" : "add"]("icon-disabled");
        },
        reply: function() {
            d.eatEventsUntilNextCard();
            var e = this.header.replyToMessage(null, function() {
                d.pushCard("compose", "animate", {
                    composer: e
                });
            });
        },
        replyAll: function() {
            d.eatEventsUntilNextCard();
            var e = this.header.replyToMessage("all", function() {
                d.pushCard("compose", "animate", {
                    composer: e
                });
            });
        },
        forward: function() {
            var e = this.header.hasAttachments || this.body.embeddedImageCount > 0, t = function() {
                d.eatEventsUntilNextCard();
                var e = this.header.forwardMessage("inline", function() {
                    d.pushCard("compose", "animate", {
                        composer: e
                    });
                });
            }.bind(this);
            if (e) {
                var n = l.cloneNode(!0);
                u.show(n, {
                    id: "msg-attachment-disabled-ok",
                    handler: function() {
                        t();
                    }
                }, {
                    id: "msg-attachment-disabled-cancel",
                    handler: null
                });
            } else t();
        },
        canReplyAll: function() {
            var e = f.account.identities.map(function(e) {
                return e.address;
            }), t = (this.header.to || []).concat(this.header.cc || []);
            this.header.replyTo && this.header.replyTo.author && t.push(this.header.replyTo.author);
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                if (i.address && -1 == e.indexOf(i.address)) return !0;
            }
            return !1;
        },
        onReplyMenu: function() {
            var e = s.cloneNode(!0);
            d.setStatusColor(e), document.body.appendChild(e);
            var t = function(t) {
                switch (d.setStatusColor(), document.body.removeChild(e), t.explicitOriginalTarget.className) {
                  case "msg-reply-menu-reply":
                    this.reply();
                    break;

                  case "msg-reply-menu-reply-all":
                    this.replyAll();
                    break;

                  case "msg-reply-menu-forward":
                    this.forward();
                    break;

                  case "msg-reply-menu-cancel":                }
                return !1;
            }.bind(this);
            e.addEventListener("submit", t), this.canReplyAll() || e.querySelector(".msg-reply-menu-reply-all").classList.add("collapsed");
        },
        onDelete: function() {
            var e = i.cloneNode(!0), t = e.getElementsByTagName("p")[0];
            y.setAttributes(t, "message-edit-delete-confirm"), u.show(e, {
                id: "msg-delete-ok",
                handler: function() {
                    var e = this.header.deleteMessage();
                    d.removeCardAndSuccessors(this, "animate"), h.toastOperation(e);
                }.bind(this)
            }, {
                id: "msg-delete-cancel",
                handler: null
            });
        },
        onToggleStar: function() {
            var e = this.querySelector(".msg-star-btn");
            e.classList.toggle("msg-star-btn-on", !this.hackMutationHeader.isStarred), this.hackMutationHeader.isStarred = !this.hackMutationHeader.isStarred, 
            this.header.setStarred(this.hackMutationHeader.isStarred);
        },
        onMove: function() {
            d.folderSelector(function(e) {
                var t = this.header.moveMessage(e);
                d.removeCardAndSuccessors(this, "animate"), h.toastOperation(t);
            }.bind(this), function(e) {
                return e.isValidMoveTarget;
            });
        },
        setRead: function(e) {
            this.hackMutationHeader.isRead = e, this.header.setRead(e), this.readBtn.classList.toggle("unread", !e);
        },
        onMarkRead: function() {
            this.setRead(!this.hackMutationHeader.isRead);
        },
        onEnvelopeClick: function(e) {
            var t = e.target;
            t.classList.contains("msg-peep-bubble") && this.onPeepClick(t);
        },
        onPeepClick: function(e) {
            var n = o.cloneNode(!0), i = e.peep, s = n.getElementsByTagName("header")[0];
            _.setup(i.address, s), document.body.appendChild(n), _.activate("alternate", "ease");
            var a = function(e) {
                switch (document.body.removeChild(n), e.explicitOriginalTarget.className) {
                  case "msg-contact-menu-new":
                    d.pushCard("compose", "animate", {
                        composerData: {
                            message: this.header,
                            onComposer: function(e) {
                                e.to = [ {
                                    address: i.address,
                                    name: i.name
                                } ];
                            }
                        }
                    });
                    break;

                  case "msg-contact-menu-view":
                    t({
                        name: "open",
                        data: {
                            type: "webcontacts/contact",
                            params: {
                                id: i.contactId
                            }
                        }
                    });
                    break;

                  case "msg-contact-menu-create-contact":
                    var o = {
                        email: i.address
                    };
                    i.name && (o.givenName = i.name), t({
                        name: "new",
                        data: {
                            type: "webcontacts/contact",
                            params: o
                        }
                    });
                    break;

                  case "msg-contact-menu-add-to-existing-contact":
                    t({
                        name: "update",
                        data: {
                            type: "webcontacts/contact",
                            params: {
                                email: i.address
                            }
                        }
                    });
                    break;

                  case "msg-contact-menu-reply":
                    var s = this.header.replyToMessage(null, function() {
                        d.pushCard("compose", "animate", {
                            composer: s
                        });
                    });
                }
                return !1;
            }.bind(this);
            n.addEventListener("submit", a);
            var r = this._contextMenuType.NEW_MESSAGE, c = i.type;
            "from" === c && (r |= this._contextMenuType.REPLY), i.isContact ? r |= this._contextMenuType.VIEW_CONTACT : (r |= this._contextMenuType.CREATE_CONTACT, 
            r |= this._contextMenuType.ADD_TO_CONTACT), r & this._contextMenuType.VIEW_CONTACT && n.querySelector(".msg-contact-menu-view").classList.remove("collapsed"), 
            r & this._contextMenuType.CREATE_CONTACT && n.querySelector(".msg-contact-menu-create-contact").classList.remove("collapsed"), 
            r & this._contextMenuType.ADD_TO_CONTACT && n.querySelector(".msg-contact-menu-add-to-existing-contact").classList.remove("collapsed"), 
            r & this._contextMenuType.REPLY && n.querySelector(".msg-contact-menu-reply").classList.remove("collapsed"), 
            r & this._contextMenuType.NEW_MESSAGE && n.querySelector(".msg-contact-menu-new").classList.remove("collapsed");
        },
        onLoadBarClick: function() {
            var e = this, t = this.loadBar;
            if (this.body.embeddedImagesDownloaded) {
                for (var n = 0; n < this.htmlBodyNodes.length; n++) this.body.showExternalImages(this.htmlBodyNodes[n], this.iframeResizeHandler);
                t.classList.add("collapsed");
            } else this.body.downloadEmbeddedImages(function() {
                if (e.body) for (var t = 0; t < e.htmlBodyNodes.length; t++) e.body.showEmbeddedImages(e.htmlBodyNodes[t], e.iframeResizeHandler);
            }), t.classList.add("collapsed");
        },
        getAttachmentBlob: function(e, t) {
            try {
                var n = e._file[0], i = e._file[1], o = navigator.getDeviceStorage(n), s = o.get(i);
                s.onerror = function() {
                    console.warn("Could not open attachment file: ", i, s.error.name);
                }, s.onsuccess = function() {
                    var e = s.result;
                    t(e);
                };
            } catch (a) {
                console.warn("Exception getting attachment from device storage:", e._file, "\n", a, "\n", a.stack);
            }
        },
        onDownloadAttachmentClick: function(e, t) {
            e.setAttribute("state", "downloading"), t.download(function() {
                t._file && e.setAttribute("state", "downloaded");
            });
        },
        onViewAttachmentClick: function(e, t) {
            console.log("trying to open", t._file, "type:", t.mimetype), t._file && t.isDownloaded && this.getAttachmentBlob(t, function(e) {
                try {
                    if (!e) throw new Error("Blob does not exist");
                    var i = t.filename.split(".").pop(), o = e.type || t.mimetype, s = n.isSupportedType(o) ? o : n.guessTypeFromExtension(i), a = new MozActivity({
                        name: "open",
                        data: {
                            type: s,
                            filename: t.filename,
                            blob: e
                        }
                    });
                    a.onerror = function() {
                        console.warn('Problem with "open" activity', a.error.name);
                    }, a.onsuccess = function() {
                        console.log('"open" activity allegedly succeeded');
                    };
                } catch (r) {
                    console.warn('Problem creating "open" activity:', r, "\n", r.stack);
                }
            });
        },
        onHyperlinkClick: function(e, n, i) {
            var o = a.cloneNode(!0), s = o.getElementsByTagName("p")[0];
            y.setAttributes(s, "browse-to-url-prompt", {
                url: i
            }), u.show(o, {
                id: "msg-browse-ok",
                handler: function() {
                    if (/^mailto:/i.test(i)) {
                        var e = b(i);
                        d.pushCard("compose", "animate", {
                            composerData: {
                                onComposer: function(t) {
                                    Object.keys(e).forEach(function(n) {
                                        t[n] = e[n];
                                    });
                                }
                            }
                        });
                    } else t({
                        name: "view",
                        data: {
                            type: "url",
                            url: i
                        }
                    });
                }.bind(this)
            }, {
                id: "msg-browse-cancel",
                handler: null
            });
        },
        _populatePlaintextBodyNode: function(e, t) {
            for (var n = 0; n < t.length; n += 2) {
                var i, o = document.createElement("div"), s = 15 & t[n];
                if (4 === s) {
                    var a = (255 & t[n] >> 8) + 1;
                    i = a > 8 ? k : A[a];
                } else i = T[s];
                i && o.setAttribute("class", i);
                for (var r = f.api.utils.linkifyPlain(t[n + 1], document), c = 0; c < r.length; c++) o.appendChild(r[c]);
                e.appendChild(o);
            }
        },
        buildHeaderDom: function(e) {
            function t(t) {
                var n = t.element.querySelector(".msg-peep-content");
                "from" === t.type ? (e.querySelector(".msg-reader-header-label").textContent = t.name || t.address, 
                n.textContent = t.address, n.classList.add("msg-peep-address")) : (n.textContent = t.name || t.address, 
                !t.name && t.address ? n.classList.add("msg-peep-address") : n.classList.remove("msg-peep-address"));
            }
            function n(n, i) {
                var o = "msg-envelope-" + n + "-line", s = e.getElementsByClassName(o)[0];
                if (!i || !i.length) return s.classList.add("collapsed"), void 0;
                s.classList.remove("collapsed");
                for (var a = r, c = 0; c < i.length; c++) {
                    var l = i[c];
                    l.type = n, l.element = a.cloneNode(!0), l.element.peep = l, l.onchange = t, t(l), 
                    s.appendChild(l.element);
                }
            }
            var i = this.header;
            n("from", [ i.author ]), n("to", i.to), n("cc", i.cc), n("bcc", i.bcc);
            var o = e.querySelector(".msg-envelope-date");
            o.dataset.time = i.date.valueOf(), o.textContent = p.prettyDate(i.date), w.subject(e.querySelector(".msg-envelope-subject"), i);
        },
        clearDom: function() {
            Array.slice(this.querySelectorAll(".msg-peep-bubble")).forEach(function(e) {
                e.parentNode.removeChild(e);
            });
            var e = this.querySelector(".msg-attachments-container");
            e.innerHTML = "", this.rootBodyNode.innerHTML = "<progress></progress>", this.loadBar.classList.add("collapsed");
        },
        buildBodyDom: function(t) {
            var i = this.body;
            if (i && this.header.id === i.id) {
                var o = this, s = this.rootBodyNode, a = i.bodyReps, r = !1, l = i.embeddedImageCount && i.embeddedImagesDownloaded;
                if (this._builtBodyDom || (v.bindSanitizedClickHandler(s, this.onHyperlinkClick.bind(this), s, null), 
                this._builtBodyDom = !0), a.length && a[0].isDownloaded) {
                    var d = s.querySelector("progress");
                    d && d.parentNode.removeChild(d);
                }
                for (var u = 0; u < a.length; u++) {
                    var p = a[u], h = s.childNodes[u];
                    if (h || (h = s.appendChild(document.createElement("div"))), !t || !t.bodyReps || -1 !== t.bodyReps.indexOf(u)) if (h.innerHTML = "", 
                    "plain" === p.type) this._populatePlaintextBodyNode(h, p.content); else if ("html" === p.type) {
                        var m = v.createAndInsertIframeForContent(p.content, this.scrollContainer, h, null, "interactive", this.onHyperlinkClick.bind(this)), g = m.iframe, _ = g.contentDocument.body;
                        this.iframeResizeHandler = m.resizeHandler, f.api.utils.linkifyHTML(g.contentDocument), 
                        this.htmlBodyNodes.push(_), i.checkForExternalImages(_) && (r = !0), l && i.showEmbeddedImages(_, this.iframeResizeHandler);
                    }
                }
                var b = this.loadBar;
                i.embeddedImageCount && !i.embeddedImagesDownloaded ? (b.classList.remove("collapsed"), 
                y.setAttributes(this.loadBarText, "message-download-images-tap", {
                    n: i.embeddedImageCount
                })) : r ? (b.classList.remove("collapsed"), y.setAttributes(this.loadBarText, "message-show-external-images")) : b.classList.add("collapsed");
                var w = o.querySelector(".msg-attachments-container");
                i.attachments && i.attachments.length ? (w.classList.remove("collapsed"), e([ "shared/js/mime_mapper" ], function(e) {
                    n || (n = e);
                    for (var o = c, s = o.querySelector(".msg-attachment-filename"), a = o.querySelector(".msg-attachment-filesize"), r = 0; r < i.attachments.length; r++) {
                        var l = w.childNodes[r];
                        if (l || (l = w.appendChild(document.createElement("li"))), !t || !t.attachments || -1 !== t.attachments.indexOf(r)) {
                            var d, u = i.attachments[r], p = u.filename.split(".").pop(), h = 20971520, f = !0, m = x(u.mimetype || n.guessTypeFromExtension(p));
                            u.isDownloaded ? d = "downloaded" : u.isDownloadable ? u.sizeEstimateInBytes > h ? (d = "toolarge", 
                            f = !1) : d = n.isSupportedType(u.mimetype) || n.isSupportedExtension(p) ? "downloadable" : "nodownload" : (d = "nodownload", 
                            f = !1), o.setAttribute("state", d), s.textContent = u.filename, S.fileSize(a, u.sizeEstimateInBytes);
                            var g = o.cloneNode(!0);
                            g.classList.add(m), w.replaceChild(g, l);
                            var v = g.querySelector(".msg-attachment-download");
                            v.disabled = !f, f && v.addEventListener("click", this.onDownloadAttachmentClick.bind(this, g, u)), 
                            g.querySelector(".msg-attachment-view").addEventListener("click", this.onViewAttachmentClick.bind(this, g, u)), 
                            this.enableReply();
                        }
                    }
                }.bind(this))) : (w.classList.add("collapsed"), this.enableReply());
            }
        },
        disableReply: function() {
            var e = this.querySelector(".msg-reply-btn");
            e.setAttribute("aria-disabled", !0);
        },
        enableReply: function() {
            var e = this.querySelector(".msg-reply-btn");
            e.removeAttribute("aria-disabled"), this._emittedContentEvents || (g.emit("metrics:contentDone"), 
            this._emittedContentEvents = !0);
        },
        die: function() {
            m.removeListener("messageSuidNotFound", this.onMessageSuidNotFound), m.removeListener("currentMessage", this.onCurrentMessage), 
            this.header && (this.header.__die(), this.header = null), this.body && (this.body.die(), 
            this.body = null);
        }
    } ];
});