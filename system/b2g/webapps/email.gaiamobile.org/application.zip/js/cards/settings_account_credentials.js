define([ "require", "l10n!", "cards", "./oauth2/fetch", "./base", "template!./settings_account_credentials.html" ], function(e) {
    var t = e("l10n!"), n = e("cards"), i = e("./oauth2/fetch");
    return [ e("./base")(e("template!./settings_account_credentials.html")), {
        onArgs: function(e) {
            this.account = e.account, this.headerLabel.textContent = this.account.name, "password" !== this.account.authMechanism && (this.querySelector(".tng-account-server-password").classList.add("collapsed"), 
            this.saveButton.classList.add("collapsed")), "oauth2" === this.account.authMechanism && this.reauthButton.classList.remove("collapsed"), 
            this.usernameNodeInput.value = this.account.username;
        },
        onBack: function() {
            n.removeCardAndSuccessors(this, "animate", 1);
        },
        onClickSave: function() {
            var e = this.passwordNodeInput.value;
            e ? (this.account.modifyAccount({
                password: e
            }), this.account.clearProblems()) : alert(t.get("settings-password-empty")), this.onBack();
        },
        onClickReauth: function() {
            var e = this.account._wireRep.credentials.oauth2;
            i(e).then(function(e) {
                "success" === e.status && (this.account.modifyAccount({
                    oauthTokens: e.tokens
                }), this.account.clearProblems(), this.onBack());
            }.bind(this));
        },
        die: function() {}
    } ];
});