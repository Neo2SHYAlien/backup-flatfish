define([ "require", "evt", "model", "cards", "html_cache", "form_navigation", "./base", "template!./setup_account_info.html", "./setup_account_error_mixin" ], function(e) {
    var t = e("evt"), n = e("model"), i = e("cards"), o = e("html_cache"), s = e("form_navigation");
    return [ e("./base")(e("template!./setup_account_info.html")), e("./setup_account_error_mixin"), {
        createdCallback: function() {
            this.formNavigation = new s({
                formElem: this.formNode,
                onLast: this.onNext.bind(this)
            }), this.needsFocus = !0;
        },
        onArgs: function(e) {
            e.allowBack && this.backButton.classList.remove("collapsed");
        },
        onCardVisible: function() {
            this.needsFocus && (this.nameNode.focus(), this.needsFocus = !1);
        },
        onBack: function() {
            n.foldersSlice ? i.removeCardAndSuccessors(this, "animate", 1) : t.emit("resetApp");
        },
        onNext: function(e) {
            e.preventDefault(), o.save(""), i.pushCard("setup_progress", "animate", {
                displayName: this.nameNode.value,
                emailAddress: this.emailNode.value,
                callingCard: this
            }, "right");
        },
        onInfoInput: function() {
            this.nextButton.disabled = this.manualConfig.disabled = !this.formNode.checkValidity();
        },
        onClickManualConfig: function(e) {
            e.preventDefault(), i.pushCard("setup_manual_config", "animate", {
                displayName: this.nameNode.value,
                emailAddress: this.emailNode.value
            }, "right");
        },
        die: function() {
            this.formNavigation = null;
        }
    } ];
});