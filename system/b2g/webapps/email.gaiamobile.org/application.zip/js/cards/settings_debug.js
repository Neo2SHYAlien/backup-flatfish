var _secretDebug;

define([ "require", "api", "cards", "./base", "template!./settings_debug.html" ], function(e) {
    var t = e("api"), n = e("cards");
    return _secretDebug || (_secretDebug = {}), [ e("./base")(e("template!./settings_debug.html")), {
        createdCallback: function() {
            this.loggingSelect.value = t.config.debugLogging || "";
        },
        onClose: function() {
            n.removeCardAndSuccessors(this, "animate", 1);
        },
        resetApp: function() {
            window.location.reload();
        },
        dumpLog: function(e) {
            t.debugSupport("dumpLog", e);
        },
        onChangeLogging: function() {
            var e = this.loggingSelect.value || !1;
            t.debugSupport("setLogging", e);
        },
        fastSync: function() {
            _secretDebug.fastSync = [ 2e4, 6e4 ];
        },
        die: function() {}
    } ];
});