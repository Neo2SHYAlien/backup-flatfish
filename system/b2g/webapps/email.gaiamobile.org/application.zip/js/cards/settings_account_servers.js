define([ "require", "l10n!", "cards", "./base", "template!./settings_account_servers.html" ], function(e) {
    var t = e("l10n!"), n = e("cards");
    return [ e("./base")(e("template!./settings_account_servers.html")), {
        onArgs: function(e) {
            this.account = e.account, this.server = e.account.servers[e.index], this.headerLabel.textContent = this.account.name, 
            t.setAttributes(this.serverLabel, "settings-" + this.server.type + "-label"), this.hostnameNodeInput.value = this.server.connInfo.hostname || this.server.connInfo.server, 
            this.portNodeInput.value = this.server.connInfo.port || "";
        },
        onBack: function() {
            n.removeCardAndSuccessors(this, "animate", 1);
        },
        die: function() {}
    } ];
});