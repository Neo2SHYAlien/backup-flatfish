define([ "require", "cards", "l10n!", "./base", "template!./setup_account_prefs.html", "./account_prefs_mixins" ], function(e) {
    var t = e("cards"), n = e("l10n!");
    return [ e("./base")(e("template!./setup_account_prefs.html")), e("./account_prefs_mixins"), {
        onArgs: function(e) {
            this.account = e.account, this.identity = this.account.identities[0], this.identity.modifyIdentity({
                signatureEnabled: !0,
                signature: n.get("settings-default-signature-2")
            }), this._bindPrefs("tng-account-check-interval", "tng-notify-mail", "tng-sound-onsend", "tng-signature-input", "signature-button");
        },
        onNext: function() {
            t.pushCard("setup_done", "animate");
        },
        onCardVisible: function() {
            this.updateSignatureButton();
        },
        die: function() {}
    } ];
});