var requirejs, require, define;

(function(global, undef) {
    function hasProp(e, t) {
        return hasOwn.call(e, t);
    }
    function getOwn(e, t) {
        return e && hasProp(e, t) && e[t];
    }
    function eachProp(e, t) {
        var n;
        for (n in e) if (hasProp(e, n) && t(e[n], n)) break;
    }
    function mixin(e, t, n, i) {
        return t && eachProp(t, function(t, s) {
            (n || !hasProp(e, s)) && (!i || "object" != typeof t || !t || Array.isArray(t) || "function" == typeof t || t instanceof RegExp ? e[s] = t : (e[s] || (e[s] = {}), 
            mixin(e[s], t, n, i)));
        }), e;
    }
    function getGlobal(e) {
        if (!e) return e;
        var t = global;
        return e.split(".").forEach(function(e) {
            t = t[e];
        }), t;
    }
    function newContext(e) {
        function t(e) {
            var t, n, i = e.length;
            for (t = 0; i > t; t++) if (n = e[t], "." === n) e.splice(t, 1), t -= 1; else if (".." === n) {
                if (1 === t && (".." === e[2] || ".." === e[0])) break;
                t > 0 && (e.splice(t - 1, 2), t -= 2);
            }
        }
        function n(e, n, i) {
            var s, o, a, r, c, l, d, u, h, p, f, m = n && n.split("/"), g = m, v = D.map, _ = v && v["*"];
            if (e && "." === e.charAt(0) && (n ? (g = m.slice(0, m.length - 1), e = e.split("/"), 
            d = e.length - 1, D.nodeIdCompat && jsSuffixRegExp.test(e[d]) && (e[d] = e[d].replace(jsSuffixRegExp, "")), 
            e = g.concat(e), t(e), e = e.join("/")) : 0 === e.indexOf("./") && (e = e.substring(2))), 
            i && v && (m || _)) {
                a = e.split("/");
                e: for (r = a.length; r > 0; r -= 1) {
                    if (l = a.slice(0, r).join("/"), m) for (c = m.length; c > 0; c -= 1) if (o = getOwn(v, m.slice(0, c).join("/")), 
                    o && (o = getOwn(o, l))) {
                        u = o, h = r;
                        break e;
                    }
                    !p && _ && getOwn(_, l) && (p = getOwn(_, l), f = r);
                }
                !u && p && (u = p, h = f), u && (a.splice(0, h, u), e = a.join("/"));
            }
            return s = getOwn(D.pkgs, e), s ? s : e;
        }
        function i(e) {
            function t() {
                var t;
                return e.init && (t = e.init.apply(global, arguments)), t || e.exports && getGlobal(e.exports);
            }
            return t;
        }
        function s(e) {
            var t, n, i, s;
            for (t = 0; t < queue.length; t += 1) {
                if ("string" != typeof queue[t][0]) {
                    if (!e) break;
                    queue[t].unshift(e), e = undef;
                }
                i = queue.shift(), n = i[0], t -= 1, hasProp(O, n) || hasProp(M, n) || (hasProp(B, n) ? S.apply(undef, i) : M[n] = i);
            }
            e && (s = getOwn(D.shim, e) || {}, S(e, s.deps || [], s.exportsFn));
        }
        function o(e, t) {
            var i = function(n, o, a, r) {
                var c, l;
                if (t && s(), "string" == typeof n) {
                    if (C[n]) return C[n](e);
                    if (c = w(n, e, !0).id, !hasProp(O, c)) throw new Error("Not loaded: " + c);
                    return O[c];
                }
                return n && !Array.isArray(n) && (l = n, n = undef, Array.isArray(o) && (n = o, 
                o = a, a = r), t) ? i.config(l)(n, o, a) : (o = o || function() {}, I(function() {
                    s(), S(undef, n || [], o, a, e);
                }), i);
            };
            return i.isBrowser = "undefined" != typeof document && "undefined" != typeof navigator, 
            i.nameToUrl = function(e, t, n) {
                var s, o, a, r, c, l, d, u = getOwn(D.pkgs, e);
                if (u && (e = u), d = getOwn(z, e)) return i.nameToUrl(d, t, n);
                if (urlRegExp.test(e)) c = e + (t || ""); else {
                    for (s = D.paths, o = e.split("/"), a = o.length; a > 0; a -= 1) if (r = o.slice(0, a).join("/"), 
                    l = getOwn(s, r)) {
                        Array.isArray(l) && (l = l[0]), o.splice(0, a, l);
                        break;
                    }
                    c = o.join("/"), c += t || (/^data\:|\?/.test(c) || n ? "" : ".js"), c = ("/" === c.charAt(0) || c.match(/^[\w\+\.\-]+:/) ? "" : D.baseUrl) + c;
                }
                return D.urlArgs ? c + ((-1 === c.indexOf("?") ? "?" : "&") + D.urlArgs) : c;
            }, i.toUrl = function(t) {
                var s, o = t.lastIndexOf("."), a = t.split("/")[0], r = "." === a || ".." === a;
                return -1 !== o && (!r || o > 1) && (s = t.substring(o, t.length), t = t.substring(0, o)), 
                i.nameToUrl(n(t, e), s, !0);
            }, i.defined = function(t) {
                return hasProp(O, w(t, e, !0).id);
            }, i.specified = function(t) {
                return t = w(t, e, !0).id, hasProp(O, t) || hasProp(B, t);
            }, i;
        }
        function a(e, t, n) {
            e && (O[e] = n, requirejs.onResourceLoad && requirejs.onResourceLoad(k, t.map, t.deps)), 
            t.finished = !0, t.resolve(n);
        }
        function r(e, t) {
            e.finished = !0, e.rejected = !0, e.reject(t);
        }
        function c(e) {
            return function(t) {
                return n(t, e, !0);
            };
        }
        function l(e) {
            var t = e.map.id, n = e.factory.apply(O[t], e.values);
            t ? n === undef && (e.cjsModule ? n = e.cjsModule.exports : e.usingExports && (n = O[t])) : N.splice(N.indexOf(e), 1), 
            a(t, e, n);
        }
        function d(e, t) {
            this.rejected || this.depDefined[t] || (this.depDefined[t] = !0, this.depCount += 1, 
            this.values[t] = e, this.depending || this.depCount !== this.depMax || l(this));
        }
        function u(e) {
            var t = {};
            return t.promise = new Promise(function(e, n) {
                t.resolve = e, t.reject = n;
            }), t.map = e ? w(e, null, !0) : {}, t.depCount = 0, t.depMax = 0, t.values = [], 
            t.depDefined = [], t.depFinished = d, t.map.pr && (t.deps = [ w(t.map.pr) ]), t;
        }
        function h(e) {
            var t;
            return e ? (t = hasProp(B, e) && B[e], t || (t = B[e] = u(e))) : (t = u(), N.push(t)), 
            t;
        }
        function p(e, t) {
            return function(n) {
                e.rejected || (n.dynaId || (n.dynaId = "id" + (H += 1), n.requireModules = [ t ]), 
                r(e, n));
            };
        }
        function f(e, t, n, i) {
            n.depMax += 1, T(e, t).then(function(e) {
                n.depFinished(e, i);
            }, p(n, e.id)).catch(p(n, n.map.id));
        }
        function m(e) {
            function t(t) {
                n || a(e, h(e), t);
            }
            var n;
            return t.error = function(t) {
                h(e).reject(t);
            }, t.fromText = function(t, i) {
                var o = h(e), a = w(w(e).n), c = a.id;
                n = !0, o.factory = function(e, t) {
                    return t;
                }, i && (t = i), hasProp(D.config, e) && (D.config[c] = D.config[e]);
                try {
                    x.exec(t);
                } catch (l) {
                    r(o, new Error("fromText eval for " + c + " failed: " + l));
                }
                s(c), o.deps = [ a ], f(a, null, o, o.deps.length);
            }, t;
        }
        function g(e, t, n) {
            e.load(t.n, o(n), m(t.id), {});
        }
        function v(e) {
            var t, n = e ? e.indexOf("!") : -1;
            return n > -1 && (t = e.substring(0, n), e = e.substring(n + 1, e.length)), [ t, e ];
        }
        function _(e, t, n) {
            var i = e.map.id;
            t[i] = !0, !e.finished && e.deps && e.deps.forEach(function(i) {
                var s = i.id, o = !hasProp(C, s) && h(s);
                !o || o.finished || n[s] || (hasProp(t, s) ? e.deps.forEach(function(t, n) {
                    t.id === s && e.depFinished(O[s], n);
                }) : _(o, t, n));
            }), n[i] = !0;
        }
        function y(e) {
            var t, n = [], i = 1e3 * D.waitSeconds, s = i && q + i < new Date().getTime();
            0 === P && (e ? e.finished || _(e, {}, {}) : N.length && N.forEach(function(e) {
                _(e, {}, {});
            })), s ? (eachProp(B, function(e) {
                e.finished || n.push(e.map.id);
            }), t = new Error("Timeout for modules: " + n), t.requireModules = n, x.onError(t)) : (P || N.length) && (E || (E = !0, 
            setTimeout(function() {
                E = !1, y();
            }, 70)));
        }
        function b(e) {
            setTimeout(function() {
                e.dynaId && U[e.dynaId] || (U[e.dynaId] = !0, x.onError(e));
            });
        }
        var x, S, w, T, C, E, A, k, I, O = {}, M = {}, D = {
            waitSeconds: 7,
            baseUrl: "./",
            paths: {},
            bundles: {},
            pkgs: {},
            shim: {},
            config: {}
        }, L = {}, N = [], B = {}, R = {}, F = {}, P = 0, q = new Date().getTime(), H = 0, U = {}, j = {}, z = {};
        return function() {
            function e() {
                t = null;
                var e = n;
                for (n = []; e.length; ) e.shift()();
            }
            var t, n = [];
            I = function(i) {
                n.push(i), t || (t = new Promise(function(e) {
                    e();
                }).then(e).catch(b));
            };
        }(), A = "function" == typeof importScripts ? function(e) {
            var t = e.url;
            j[t] || (j[t] = !0, h(e.id), importScripts(t), s(e.id));
        } : function(e) {
            var t, n = e.id, i = e.url;
            j[i] || (j[i] = !0, t = document.createElement("script"), t.setAttribute("data-requiremodule", n), 
            t.type = D.scriptType || "text/javascript", t.charset = "utf-8", t.async = !0, P += 1, 
            t.addEventListener("load", function() {
                P -= 1, s(n);
            }, !1), t.addEventListener("error", function() {
                P -= 1;
                var e, i = getOwn(D.paths, n), s = getOwn(B, n);
                i && Array.isArray(i) && i.length > 1 ? (t.parentNode.removeChild(t), i.shift(), 
                s.map = w(n), A(s.map)) : (e = new Error("Load failed: " + n + ": " + t.src), e.requireModules = [ n ], 
                h(n).reject(e));
            }, !1), t.src = i, document.head.appendChild(t));
        }, T = function(e, t) {
            var n, i, s = e.id, o = D.shim[s];
            if (hasProp(M, s)) n = M[s], delete M[s], S.apply(undef, n); else if (!hasProp(B, s)) if (e.pr) {
                if (!(i = getOwn(z, s))) return T(w(e.pr)).then(function(e) {
                    var n = w(s, t, !0), i = n.id, o = getOwn(D.shim, i);
                    return hasProp(F, i) || (F[i] = !0, o && o.deps ? x(o.deps, function() {
                        g(e, n, t);
                    }) : g(e, n, t)), h(i).promise;
                });
                e.url = x.nameToUrl(i), A(e);
            } else o && o.deps ? x(o.deps, function() {
                A(e);
            }) : A(e);
            return h(s).promise;
        }, w = function(e, t, i) {
            if ("string" != typeof e) return e;
            var s, o, a, r, l, d = e + " & " + (t || "") + " & " + !!i;
            return a = v(e), r = a[0], e = a[1], !r && hasProp(L, d) ? L[d] : (r && (r = n(r, t, i), 
            s = hasProp(O, r) && O[r]), r ? e = s && s.normalize ? s.normalize(e, c(t)) : n(e, t, i) : (e = n(e, t, i), 
            a = v(e), r = a[0], e = a[1], o = x.nameToUrl(e)), l = {
                id: r ? r + "!" + e : e,
                n: e,
                pr: r,
                url: o
            }, r || (L[d] = l), l);
        }, C = {
            require: function(e) {
                return o(e);
            },
            exports: function(e) {
                var t = O[e];
                return "undefined" != typeof t ? t : O[e] = {};
            },
            module: function(e) {
                return {
                    id: e,
                    uri: "",
                    exports: C.exports(e),
                    config: function() {
                        return getOwn(D.config, e) || {};
                    }
                };
            }
        }, S = function(e, t, n, i, s) {
            if (!e || !hasProp(R, e)) {
                R[e] = !0;
                var o = h(e);
                t && !Array.isArray(t) && (n = t, t = []), o.promise.catch(i || b), s = s || e, 
                "function" == typeof n ? (!t.length && n.length && (n.toString().replace(commentRegExp, "").replace(cjsRequireRegExp, function(e, n) {
                    t.push(n);
                }), t = (1 === n.length ? [ "require" ] : [ "require", "exports", "module" ]).concat(t)), 
                o.factory = n, o.deps = t, o.depending = !0, t.forEach(function(n, i) {
                    var a;
                    t[i] = a = w(n, s, !0), n = a.id, "require" === n ? o.values[i] = C.require(e) : "exports" === n ? (o.values[i] = C.exports(e), 
                    o.usingExports = !0) : "module" === n ? o.values[i] = o.cjsModule = C.module(e) : void 0 === n ? o.values[i] = void 0 : f(a, s, o, i);
                }), o.depending = !1, o.depCount === o.depMax && l(o)) : e && a(e, o, n), q = new Date().getTime(), 
                e || y(o);
            }
        }, x = o(null, !0), x.config = function(t) {
            if (t.context && t.context !== e) return newContext(t.context).config(t);
            L = {}, t.baseUrl && "/" !== t.baseUrl.charAt(t.baseUrl.length - 1) && (t.baseUrl += "/");
            var n = D.shim, s = {
                paths: !0,
                bundles: !0,
                config: !0,
                map: !0
            };
            return eachProp(t, function(e, t) {
                s[t] ? (D[t] || (D[t] = {}), mixin(D[t], e, !0, !0)) : D[t] = e;
            }), t.bundles && eachProp(t.bundles, function(e, t) {
                e.forEach(function(e) {
                    e !== t && (z[e] = t);
                });
            }), t.shim && (eachProp(t.shim, function(e, t) {
                Array.isArray(e) && (e = {
                    deps: e
                }), !e.exports && !e.init || e.exportsFn || (e.exportsFn = i(e)), n[t] = e;
            }), D.shim = n), t.packages && t.packages.forEach(function(e) {
                var t, n;
                e = "string" == typeof e ? {
                    name: e
                } : e, n = e.name, t = e.location, t && (D.paths[n] = e.location), D.pkgs[n] = e.name + "/" + (e.main || "main").replace(currDirRegExp, "").replace(jsSuffixRegExp, "");
            }), (t.deps || t.callback) && x(t.deps, t.callback), x;
        }, x.onError = function(e) {
            throw e;
        }, k = {
            id: e,
            defined: O,
            waiting: M,
            config: D,
            deferreds: B
        }, contexts[e] = k, x;
    }
    var topReq, dataMain, src, subPath, bootstrapConfig = requirejs || require, hasOwn = Object.prototype.hasOwnProperty, contexts = {}, queue = [], currDirRegExp = /^\.\//, urlRegExp = /^\/|\:|\?|\.js$/, commentRegExp = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/gm, cjsRequireRegExp = /[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g, jsSuffixRegExp = /\.js$/;
    "function" != typeof requirejs && (requirejs = topReq = newContext("_"), "function" != typeof require && (require = topReq), 
    topReq.exec = function(text) {
        return eval(text);
    }, topReq.contexts = contexts, define = function() {
        queue.push([].slice.call(arguments, 0));
    }, define.amd = {
        jQuery: !0
    }, bootstrapConfig && topReq.config(bootstrapConfig), topReq.isBrowser && !contexts._.config.skipDataMain && (dataMain = document.querySelectorAll("script[data-main]")[0], 
    dataMain = dataMain && dataMain.getAttribute("data-main"), dataMain && (dataMain = dataMain.replace(jsSuffixRegExp, ""), 
    bootstrapConfig && bootstrapConfig.baseUrl || (src = dataMain.split("/"), dataMain = src.pop(), 
    subPath = src.length ? src.join("/") + "/" : "./", topReq.config({
        baseUrl: subPath
    })), topReq([ dataMain ]))));
})(this), define("alameda", function() {}), define("evt", [], function() {
    function e() {
        this._events = {}, this._pendingEvents = {};
    }
    var t, n = Array.prototype.slice, i = [ "_events", "_pendingEvents", "on", "once", "latest", "latestOnce", "removeListener", "emitWhenListener", "emit" ];
    return e.prototype = {
        on: function(e, t) {
            var n = this._events[e], i = this._pendingEvents[e];
            return n || (n = this._events[e] = []), n.push(t), i && (i.forEach(function(e) {
                t.apply(null, e);
            }), delete this._pendingEvents[e]), this;
        },
        once: function(e, t) {
            function n() {
                s || (s = !0, t.apply(null, arguments), setTimeout(function() {
                    i.removeListener(e, n);
                }));
            }
            var i = this, s = !1;
            return this.on(e, n);
        },
        latest: function(e, t) {
            this[e] && !this._pendingEvents[e] && t(this[e]), this.on(e, t);
        },
        latestOnce: function(e, t) {
            this[e] && !this._pendingEvents[e] ? t(this[e]) : this.once(e, t);
        },
        removeListener: function(e, t) {
            var n, i = this._events[e];
            i && (n = i.indexOf(t), -1 !== n && i.splice(n, 1), 0 === i.length && delete this._events[e]);
        },
        emitWhenListener: function(e) {
            var t = this._events[e];
            t ? this.emit.apply(this, arguments) : (this._pendingEvents[e] || (this._pendingEvents[e] = []), 
            this._pendingEvents[e].push(n.call(arguments, 1)));
        },
        emit: function(e) {
            var t = n.call(arguments, 1);
            Promise.resolve().then(function() {
                var n = this._events[e];
                n && n.forEach(function(e) {
                    try {
                        e.apply(null, t);
                    } catch (n) {
                        setTimeout(function() {
                            throw n;
                        });
                    }
                });
            }.bind(this));
        }
    }, t = new e(), t.Emitter = e, t.mix = function(t) {
        var n = new e();
        return i.forEach(function(e) {
            if (t.hasOwnProperty(e)) throw new Error('Object already has a property "' + e + '"');
            t[e] = n[e];
        }), t;
    }, t;
}), define("app_self", [ "require", "exports", "module", "evt" ], function(e, t, n) {
    function i() {
        a.getSelf().onsuccess = function(e) {
            c = !0;
            var t = e.target.result;
            o.self = t, o.emit("self", o.self);
        };
    }
    var s = e("evt"), o = s.mix({}), a = navigator.mozApps, r = o.latest, c = !1;
    return a || (o.self = {}, c = !0), o.latest = function(e) {
        if (c || i(), "self" !== e) throw new Error(n.id + ' only supports "self" property');
        return r.apply(this, arguments);
    }, o;
}), define("query_uri", [], function() {
    function e(e) {
        try {
            return decodeURIComponent(e);
        } catch (t) {
            return console.error('Skipping "' + e + '", decodeURIComponent error: ' + t), "";
        }
    }
    function t(t) {
        function n(e) {
            if (!e) return [];
            e = e.split(/[,;]/);
            var t = e.filter(function(e) {
                return "" !== e.trim();
            });
            return t;
        }
        var i = /^mailto:(.*)/i, s = {};
        if (t && t.match(i)) {
            t = t.match(i)[1];
            var o = t.split("?"), a = /(?:^|&)subject=([^\&]*)/i, r = /(?:^|&)body=([^\&]*)/i, c = /(?:^|&)cc=([^\&]*)/i, l = /(?:^|&)bcc=([^\&]*)/i;
            if (s.to = o[0] ? n(e(o[0])) : [], 2 == o.length) {
                var d = o[1];
                d.match(a) && (s.subject = e(d.match(a)[1])), d.match(r) && (s.body = e(d.match(r)[1])), 
                d.match(c) && (s.cc = n(e(d.match(c)[1]))), o[1].match(l) && (s.bcc = n(e(d.match(l)[1])));
            }
        }
        return s;
    }
    return t;
}), define("app_messages", [ "require", "app_self", "evt", "query_uri" ], function(e) {
    var t = e("app_self"), n = e("evt"), i = e("query_uri"), s = {}, o = window.htmlCacheRestorePendingMessage && window.htmlCacheRestorePendingMessage.length ? window.htmlCacheRestorePendingMessage : [];
    o.forEach(function(e) {
        s[e] = !0;
    });
    var a = n.mix({
        hasPending: function(e) {
            return s.hasOwnProperty(e) || navigator.mozHasPendingMessage && navigator.mozHasPendingMessage(e);
        },
        onActivityRequest: function(t) {
            var n = t.source, s = n.data, o = n.name, a = s.type, r = s.url || s.URI;
            console.log("Received activity: " + o), e([ "attachment_name" ], function(e) {
                var n;
                "url" === a && "share" === o ? n = {
                    body: r
                } : (n = i(r), n.attachmentBlobs = s.blobs || [], n.attachmentNames = s.filenames || [], 
                e.ensureNameList(n.attachmentBlobs, n.attachmentNames)), this.emitWhenListener("activity", o, n, t);
            }.bind(this));
        },
        onNotification: function(e) {
            if (!e.clicked) return this.emitWhenListener("notificationClosed"), void 0;
            "undefined" != typeof Notification && Notification.get && Notification.get().then(function(t) {
                t && t.some(function(t) {
                    return t.tag === e.tag && t.close ? (t.close(), !0) : void 0;
                });
            });
            var n = e.data || {};
            document.hidden && t.latest("self", function(e) {
                e.launch();
            }), this.emitWhenListener("notification", n);
        }
    });
    return "mozSetMessageHandler" in navigator ? (navigator.mozSetMessageHandler("activity", a.onActivityRequest.bind(a)), 
    navigator.mozSetMessageHandler("notification", a.onNotification.bind(a)), n.on("notification", a.onNotification.bind(a))) : console.warn("Activity support disabled!"), 
    a;
}), define("html_cache", [ "require", "exports", "module" ], function(e, t) {
    t.cloneAsInertNodeAvoidingCustomElementHorrors = function(e) {
        var t = document.createElement("template"), n = t.content.ownerDocument;
        return n.importNode(e, !0);
    }, t.save = function(e) {
        var t = document.querySelector("html").getAttribute("dir");
        e = encodeURIComponent(HTML_COOKIE_CACHE_VERSION + (t ? "," + t : "") + ":" + e);
        var n = Date.now() + 63072e7;
        n = new Date(n).toUTCString();
        for (var i = 0, s = 0, o = e.length, a = 0; o > a; a = s, i += 1) s = 2030 + a, 
        s > o && (s = o), document.cookie = "htmlc" + i + "=" + e.substring(a, s) + "; expires=" + n;
        var r = 40;
        for (i > 39 && (i = 0, console.log("htmlCache.save TOO BIG. Removing all of it.")), 
        a = i; r > a; a++) document.cookie = "htmlc" + a + "=; expires=" + n;
        console.log("htmlCache.save: " + e.length + " in " + i + " segments, lang dir: " + t);
    }, t.saveFromNode = function(e) {
        var n = e.classList;
        n.remove("before"), n.remove("after"), n.add("center");
        var i = e.outerHTML;
        t.save(i);
    };
    var n = 0, i = "";
    t.delayedSaveFromNode = function(e) {
        i = e, n || (n = setTimeout(function() {
            n = 0, t.saveFromNode(i), i = null;
        }, 500));
    };
}), define("l10n", {
    load: function(e, t, n, i) {
        return i.isBuild ? n() : (t([ "l10nbase", "l10ndate" ], function() {
            navigator.mozL10n.once(function() {
                var e = navigator.mozL10n.language.direction, t = document.querySelector("html");
                t.getAttribute("dir") !== e && (console.log("email l10n updating html dir to " + e), 
                t.setAttribute("dir", e)), n(navigator.mozL10n);
            });
        }), void 0);
    }
}), define("tmpl", [ "l10n!" ], function(e) {
    var t = {
        pluginBuilder: "./tmpl_builder",
        toDom: function(t) {
            var n = document.createElement("div");
            n.innerHTML = t;
            var i = n.children[0];
            return e.translateFragment(i), i;
        },
        load: function(e, n, i) {
            n([ "text!" + e ], function(e) {
                var n = t.toDom(e);
                i(n);
            });
        }
    };
    return t;
}), define("tmpl!cards/toaster.html", [ "tmpl" ], function(e) {
    return e.toDom('<section role="status" class="toaster collapsed">\n  <p class="toaster-text"></p>\n  <div class="toaster-action-target"><button class="toaster-action"></button></div>\n</section>\n');
}), define("toaster", [ "require", "l10n!", "tmpl!./cards/toaster.html" ], function(e) {
    var t = e("l10n!"), n = e("tmpl!./cards/toaster.html"), i = {
        defaultTimeout: 5e3,
        _previousActionClass: void 0,
        init: function(e) {
            this.el = n, e.appendChild(this.el), this.text = this.el.querySelector(".toaster-text"), 
            this.actionButton = this.el.querySelector(".toaster-action"), this.el.addEventListener("click", this.hide.bind(this)), 
            this.el.addEventListener("transitionend", this.hide.bind(this)), this.el.querySelector(".toaster-action-target").addEventListener("click", this.onAction.bind(this)), 
            this.currentToast = null;
        },
        toastOperation: function(e) {
            if (e && e.affectedCount) {
                var n = e.operation, i = e.undo && "move" !== n && "delete" !== n;
                this.toast({
                    text: t.get("toaster-message-" + n, {
                        n: e.affectedCount
                    }),
                    actionLabel: t.get("toaster-undo"),
                    actionClass: "undo",
                    action: i && e.undo.bind(e)
                });
            }
        },
        onAction: function() {
            var e = this.currentToast && this.currentToast.action;
            this.hide(), e && e();
        },
        toast: function(e) {
            e = e || {}, console.log("Showing toast:", JSON.stringify(e)), this.hide(), this.currentToast = e, 
            this.text.textContent = e.text, this.actionButton.textContent = e.actionLabel, this._previousActionClass && (this.actionButton.classList.remove(this._previousActionClass), 
            this._previousActionClass = void 0), e.actionClass && (this._previousActionClass = e.actionClass, 
            this.actionButton.classList.add(this._previousActionClass)), this.el.classList.toggle("actionable", !e.action), 
            this.actionButton.disabled = !e.action, this.el.classList.remove("collapsed"), this._fadeTimeout = setTimeout(function() {
                this.el.classList.add("fadeout");
            }.bind(this), e.timeout || this.defaultTimeout);
        },
        isShowing: function() {
            return !this.el.classList.contains("collapsed");
        },
        hide: function() {
            this.currentToast = null, this.el.classList.add("collapsed"), this.el.classList.remove("fadeout"), 
            window.clearTimeout(this._fadeTimeout), this._fadeTimeout = null;
        }
    };
    return i;
}), define("input_areas", [ "require", "exports", "module" ], function() {
    var e = Array.prototype.slice;
    return function(t) {
        var n = 'form p input + button[type="reset"],form p textarea + button[type="reset"]', i = e.call(t.querySelectorAll(n));
        i.forEach(function(e) {
            e.addEventListener("mousedown", function(e) {
                e.preventDefault();
            }), e.addEventListener("click", function(e) {
                e.target.previousElementSibling.value = "", e.preventDefault();
            });
        });
    };
}), define("cards", [ "require", "l10n!", "evt", "toaster", "input_areas" ], function(e) {
    function t(e, t) {
        e && e.classList.add(t);
    }
    function n(e, t) {
        e && e.classList.remove(t);
    }
    function i(e) {
        return e.replace(/^cards-/, "").replace(/-/g, "_");
    }
    var s = e("l10n!"), o = e("evt"), a = e("toaster"), r = e("input_areas"), c = {
        _cardDefs: {},
        _cardStack: [],
        activeCardIndex: -1,
        _pendingPush: null,
        _zIndex: 0,
        _rootNode: null,
        _containerNode: null,
        _cardsNode: null,
        _animatingDeadDomNodes: [],
        _transitionCount: 0,
        _startupEventsEmitted: !1,
        _popupActive: null,
        _eatingEventsUntilNextCard: !1,
        _init: function() {
            this._rootNode = document.body, this._containerNode = document.getElementById("cardContainer"), 
            this._cardsNode = document.getElementById("cards"), this._statusColorMeta = document.querySelector('meta[name="theme-color"]'), 
            a.init(this._containerNode), this._containerNode.addEventListener("click", this._onMaybeIntercept.bind(this), !0), 
            this._cardsNode.addEventListener("transitionend", this._onTransitionEnd.bind(this), !1), 
            document.addEventListener("visibilitychange", function() {
                var e = this._cardStack[this.activeCardIndex];
                e && e.onCurrentCardDocumentVisibilityChange && e.onCurrentCardDocumentVisibilityChange(document.hidden);
            }.bind(this));
        },
        _onMaybeIntercept: function(e) {
            if (this._eatingEventsUntilNextCard) return e.stopPropagation(), e.preventDefault(), 
            void 0;
            if (this._popupActive) return e.stopPropagation(), e.preventDefault(), this._popupActive.close(), 
            void 0;
            var t = e.target;
            for (t = e.target; t && !t.classList.contains("card"); t = t.parentElement) ;
        },
        pushCard: function(t, n, i, s) {
            var o = this._cardDefs[t];
            if (i = i || {}, !o) {
                var a = Array.slice(arguments);
                return this._pendingPush = [ t ], "none" !== n && this.eatEventsUntilNextCard(), 
                e([ "element!cards/" + t ], function(e) {
                    this._cardDefs[t] = e, this.pushCard.apply(this, a);
                }.bind(this)), void 0;
            }
            this._pendingPush = null, console.log("pushCard for type: " + t);
            var c = i.cachedNode || new o();
            c.extraClasses && c.classList.add.apply(c.classList, c.extraClasses), i && c.onArgs && c.onArgs(i), 
            c.classList.add("card"), c.setAttribute("data-type", t);
            var l, d;
            s ? "left" === s ? (l = this.activeCardIndex++, d = this._cardsNode.children[l], 
            c.classList.add("before")) : "right" === s && (l = this.activeCardIndex + 1, d = l >= this._cardStack.length ? null : this._cardsNode.children[l], 
            c.classList.add("after")) : (l = this._cardStack.length, d = null, c.classList.add(0 === l ? "before" : "after")), 
            this._cardStack.splice(l, 0, c), i.cachedNode || this._cardsNode.insertBefore(c, d), 
            r(c), c.callHeaderFontSize || window.dispatchEvent(new CustomEvent("lazyload", {
                detail: c
            })), "postInsert" in c && c.postInsert(), "none" !== n && (i.cachedNode || c.clientWidth, 
            this._showCard(l, n, "forward")), i.onPushed && i.onPushed(c);
        },
        pushOrTellCard: function(e, t, n) {
            var i = e;
            return this.hasCard(i) ? (this.tellCard(i, n), !1) : (this.pushCard.apply(this, Array.slice(arguments)), 
            !0);
        },
        setStatusColor: function(e) {
            var t;
            e || (e = this._cardStack[this.activeCardIndex]);
            var n = e.dataset.statuscolor ? e : e.querySelector("[data-statuscolor]");
            n ? (t = n.dataset.statuscolor, "default" === t ? t = null : "background" === t && (t = getComputedStyle(n).backgroundColor)) : t = getComputedStyle(e).backgroundColor, 
            t && 0 !== t.indexOf("rgb") && 0 !== t.indexOf("#") && (t = null), t = t || this._statusColorMeta.dataset.statuscolor;
            var i = this._statusColorMeta.getAttribute("content");
            t !== i && this._statusColorMeta.setAttribute("content", t);
        },
        _findCardUsingType: function(e) {
            for (var t = 0; t < this._cardStack.length; t++) {
                var n = this._cardStack[t];
                if (i(this.cardName(n)) === e) return t;
            }
        },
        _findCard: function(e, t) {
            var n;
            if (n = "string" == typeof e ? this._findCardUsingType(e, t) : "number" == typeof e ? e : this._cardStack.indexOf(e), 
            n > -1) return n;
            if (t) return void 0;
            throw new Error("Unable to find card with query:", e);
        },
        cardName: function(e) {
            return e.nodeName.toLowerCase();
        },
        hasCard: function(e) {
            return this._pendingPush && this._pendingPush === e ? !0 : this._findCard(e, !0) > -1;
        },
        isVisible: function(e) {
            return !(!e || !e.classList.contains("center"));
        },
        findCardObject: function(e) {
            return this._cardStack[this._findCard(e)];
        },
        getCurrentCardType: function() {
            var e = null, t = this._cardStack[this.activeCardIndex];
            return this._pendingPush ? e = this._pendingPush : t && (e = i(this.cardName(t))), 
            e;
        },
        folderSelector: function(t, n) {
            var i = this;
            e([ "model", "value_selector" ], function(e, o) {
                if (!i.folderPrompt) {
                    var a = s.get("messages-folder-select");
                    i.folderPrompt = new o(a);
                }
                e.latestOnce("foldersSlice", function(e) {
                    var s = e.items;
                    s.forEach(function(e) {
                        var s = !n || n(e);
                        (e.neededForHierarchy || s) && i.folderPrompt.addToList(e.name, e.depth, s, function(e) {
                            return function() {
                                i.folderPrompt.hide(), t(e);
                            };
                        }(e));
                    }), i.folderPrompt.show();
                });
            });
        },
        moveToCard: function(e, t) {
            this._showCard(this._findCard(e), t || "animate");
        },
        tellCard: function(e, t) {
            var n = this._findCard(e), i = this._cardStack[n];
            "told" in i ? i.told(t) : console.warn("Tried to tell a card that's not listening!", e, t);
        },
        removeCardAndSuccessors: function(e, t, n, i, s) {
            if (this._cardStack.length) {
                if (e && 1 === this._cardStack.length && !s) return c.pushDefaultCard(function() {
                    this.removeCardAndSuccessors(e, t, n, i);
                }.bind(this));
                var o, a, r;
                if (void 0 === e) throw new Error("undefined is not a valid card spec!");
                if (null === e) o = 0, this._zIndex = 0; else {
                    for (a = this._cardStack.length - 1; a >= 0; a--) if (r = this._cardStack[a], r === e) {
                        o = a;
                        break;
                    }
                    if (void 0 === o) throw new Error("No card represented by that DOM node");
                }
                if (n || (n = this._cardStack.length - o), "none" === t) e && e.classList.contains("anim-overlay") && (this._zIndex -= 10); else {
                    var l = -1;
                    i ? l = this._findCard(i) : this._cardStack.length && (l = Math.min(o - 1, this._cardStack.length - 1)), 
                    l > -1 && this._showCard(l, t, "back");
                }
                o <= this.activeCardIndex && (this.activeCardIndex -= n, this.activeCardIndex < -1 && (this.activeCardIndex = -1));
                var d = this._cardStack.splice(o, n);
                for (a = 0; a < d.length; a++) {
                    r = d[a];
                    try {
                        r.die();
                    } catch (u) {
                        console.warn("Problem cleaning up card:", u, "\n", u.stack);
                    }
                    switch (t) {
                      case "animate":
                      case "immediate":
                        this._animatingDeadDomNodes.push(r);
                        break;

                      case "none":
                        r.parentNode.removeChild(r);
                    }
                }
                this._setScreenReaderVisibility();
            }
        },
        removeAllCards: function() {
            return this.removeCardAndSuccessors(null, "none");
        },
        _showCard: function(e, i, s) {
            if (e !== this.activeCardIndex) {
                var o = document.activeElement;
                o && o.blur && o.blur(), e > this._cardStack.length - 1 && (e = this._cardStack.length - 1), 
                this.activeCardIndex > this._cardStack.length - 1 && (this.activeCardIndex = -1), 
                -1 === this.activeCardIndex && (this.activeCardIndex = 0 === e ? e : e - 1);
                var r = null !== e ? this._cardStack[e] : null, c = this._cardStack[this.activeCardIndex], l = this._cardStack[e], d = "forward" === s;
                1 === this._cardStack.length && (this._zIndex = 0), d && l.classList.contains("anim-overlay") && (c = null, 
                this._zIndex += 10), c && c.classList.contains("anim-overlay") && (d ? "immediate" !== i && (c.classList.contains("anim-vertical") ? (n(c, "anim-vertical"), 
                t(c, "disabled-anim-vertical")) : c.classList.contains("anim-fade") && (n(c, "anim-fade"), 
                t(c, "disabled-anim-fade"))) : (this.setStatusColor(l), l = null, this._zIndex -= 10)), 
                l && d && this._zIndex && (l.style.zIndex = this._zIndex);
                var u = this._cardsNode;
                l && this.setStatusColor(l), "immediate" === i ? (t(c, "no-anim"), t(l, "no-anim"), 
                u.clientWidth, this._eatingEventsUntilNextCard = !1) : "none" === i || (this._transitionCount = c && l ? 2 : 1, 
                this._eatingEventsUntilNextCard = !0), this.activeCardIndex === e ? (n(c, "before"), 
                n(c, "after"), t(c, "center")) : this.activeCardIndex > e ? (n(c, "center"), t(c, "after"), 
                n(l, "before"), t(l, "center")) : (n(c, "center"), t(c, "before"), n(l, "after"), 
                t(l, "center")), "immediate" === i && (u.clientWidth, n(c, "no-anim"), n(l, "no-anim"), 
                this._onCardVisible(r)), a.hide(), this.activeCardIndex = e, this._setScreenReaderVisibility();
            }
        },
        _setScreenReaderVisibility: function() {
            this._cardStack.forEach(function(e, t) {
                e.setAttribute("aria-hidden", t !== this.activeCardIndex);
            }, this);
        },
        _onTransitionEnd: function(i) {
            if (i.target.classList.contains("card")) {
                var s = this._cardStack[this.activeCardIndex];
                if (s && (this._transitionCount > 0 && (this._transitionCount -= 1), 0 === this._transitionCount)) {
                    this._eatingEventsUntilNextCard && (this._eatingEventsUntilNextCard = !1), this._animatingDeadDomNodes.length && setTimeout(function() {
                        this._animatingDeadDomNodes.forEach(function(e) {
                            e.parentNode && e.parentNode.removeChild(e);
                        }), this._animatingDeadDomNodes = [];
                    }.bind(this), 100);
                    var o = s;
                    if (o.classList.contains("disabled-anim-vertical") ? (n(o, "disabled-anim-vertical"), 
                    t(o, "anim-vertical")) : o.classList.contains("disabled-anim-fade") && (n(o, "disabled-anim-fade"), 
                    t(o, "anim-fade")), this._afterTransitionAction) {
                        var a = this._afterTransitionAction;
                        this._afterTransitionAction = null, a();
                    }
                    this._onCardVisible(s);
                    var r = s.nextCards;
                    r && (console.log("Preloading cards: " + r), e(r.map(function(e) {
                        return "cards/" + e;
                    })));
                }
            }
        },
        _onCardVisible: function(e) {
            e.onCardVisible && e.onCardVisible(), this._emitStartupEvents(e.skipEmitContentEvents);
        },
        _emitStartupEvents: function(e) {
            this._startupEventsEmitted || (startupCacheEventsSent ? (window.performance.mark("contentInteractive"), 
            window.dispatchEvent(new CustomEvent("moz-content-interactive"))) : (window.performance.mark("navigationLoaded"), 
            window.dispatchEvent(new CustomEvent("moz-chrome-dom-loaded"))), window.performance.mark("navigationInteractive"), 
            window.dispatchEvent(new CustomEvent("moz-chrome-interactive")), e || o.emit("metrics:contentDone"), 
            this._startupEventsEmitted = !0);
        },
        eatEventsUntilNextCard: function() {
            this._eatingEventsUntilNextCard = !0;
        },
        stopEatingEvents: function() {
            this._eatingEventsUntilNextCard = !1;
        },
        assertNoCards: function() {
            if (this._cardStack.length) throw new Error("There are " + this._cardStack.length + " cards but" + " there should be ZERO");
        }
    };
    return c;
}), define("element", [], function() {
    function e(e) {
        for (var t = e.split("-"), n = 1; n < t.length; n++) t[n] = t[n].charAt(0).toUpperCase() + t[n].substring(1);
        return t.join("");
    }
    function t(t, n, i) {
        var s = Object.getPrototypeOf(t), o = e(n), a = Object.getOwnPropertyDescriptor(s, o);
        a && a.set && (t[o] = i);
    }
    function n(e) {
        return function() {
            var t, n, i = o.call(arguments), s = this._element.props[e];
            for (t = 0; t < s.length; t++) n = s[t].apply(this, i);
            return n;
        };
    }
    function i(e, t, i, s) {
        if (e.hasOwnProperty(t)) {
            var o = e._element.props[t];
            o || (o = e._element.props[t] = [ e[t] ], e[t] = n(t)), s = s || "push", o[s](i);
        } else e[t] = i;
    }
    function s(e, t) {
        return Array.isArray(t) ? (t.forEach(function(t) {
            s(e, t);
        }), void 0) : (Object.keys(t).forEach(function(n) {
            var s, o = Object.getOwnPropertyDescriptor(t, n);
            s = n.indexOf(a), s > 0 && s === n.length - r ? i(e, n, o.value) : Object.defineProperty(e, n, o);
        }), void 0);
    }
    var o = Array.prototype.slice, a = "Callback", r = a.length, c = /[^a-z]/g, l = {
        load: function(e, n, o, a) {
            n([ e ], function(n) {
                if (a.isBuild || !n || "function" == typeof n) return o();
                var r = Object.create(HTMLElement.prototype);
                Object.defineProperty(r, "_element", {
                    enumerable: !1,
                    configurable: !1,
                    writable: !1,
                    value: {}
                }), r._element.props = {}, s(r, n), i(r, "createdCallback", function() {
                    var e, n, i = this.attributes;
                    for (e = 0; e < i.length; e++) n = i.item(e), t(this, n.nodeName, n.value);
                }, "unshift"), i(r, "attributeChangedCallback", function(e, n, i) {
                    t(this, e, i);
                }, "unshift"), e = e.toLowerCase().replace(c, "-"), o(document.registerElement(e, {
                    prototype: r
                }));
            });
        }
    };
    return l;
}), define("cards/mixins/data-prop", [], function() {
    return {
        templateInsertedCallback: function() {
            for (var e = this.querySelectorAll("[data-prop]"), t = e.length, n = 0; t > n; n++) this[e[n].dataset.prop] = e[n];
        }
    };
}), define("cards/mixins/data-event", [], function() {
    var e = Array.prototype.slice;
    return {
        templateInsertedCallback: function() {
            e.call(this.querySelectorAll("[data-event]")).forEach(function(e) {
                e.dataset.event.split(",").forEach(function(t) {
                    var n, i, s = t.split(":");
                    if (s[1] || (s[1] = s[0]), n = s[0].trim(), i = s[1].trim(), "function" != typeof this[i]) throw new Error('"' + i + '" is not a function, ' + "cannot bind with data-event");
                    e.addEventListener(n, function(e) {
                        return e.stopPropagation(), this[i](e);
                    }.bind(this), !1);
                }.bind(this));
            }.bind(this));
        }
    };
}), define("cards/base", [ "require", "l10n!", "evt", "./mixins/data-prop", "./mixins/data-event" ], function(e) {
    var t = e("l10n!"), n = e("evt").Emitter;
    return function() {
        function e() {
            clearTimeout(s), i(), s = setInterval(i, 6e4);
        }
        var n = new t.DateTimeFormat(), i = function() {
            for (var e = document.querySelectorAll("[data-time]"), t = e.length; t--; ) e[t].textContent = n.fromNow(e[t].dataset.time, "compactFormat" in e[t].dataset);
        }, s = setInterval(i, 6e4);
        t.ready(e), document.addEventListener("visibilitychange", function() {
            document && !document.hidden && e();
        });
    }(), function(t) {
        return [ t ? t : {}, e("./mixins/data-prop"), e("./mixins/data-event"), n.prototype, {
            createdCallback: function() {
                n.call(this);
            },
            batchAddClass: function(e, t) {
                for (var n = this.getElementsByClassName(e), i = 0; i < n.length; i++) n[i].classList.add(t);
            },
            bindContainerHandler: function(e, t, n) {
                e.addEventListener(t, function(t) {
                    var i = t.target;
                    if (i !== e) {
                        for (;i && i.parentNode !== e; ) i = i.parentNode;
                        n(i, t);
                    }
                }, !1);
            }
        } ];
    };
}), define("template", [ "require", "exports", "module", "element" ], function(e, t, n) {
    function i() {
        l = !0;
        var e = document.querySelector("template#body");
        e && (e.parentNode.removeChild(e), document.body.innerHTML = e.innerHTML), d.forEach(function(e) {
            e();
        }), d = [];
    }
    function s(e, t) {
        if (0 === e.indexOf(".") && t) {
            var n = t.split("/");
            n.pop(), t = n.join("/"), e = (t ? t + "/" : "") + e;
        }
        return e;
    }
    function o() {
        ("cached" === this.dataset.cached || this.template) && ("cached" !== this.dataset.cached && this.template && (this.innerHTML = "", 
        this.appendChild(this.template())), this.templateInsertedCallback && this.templateInsertedCallback());
    }
    var a, r, c, l = !1, d = [], u = /<(\w+-\w+)(\s|>)/g, h = /<!--*.?-->/g, p = /\s(hrefid|srcid)="([^"]+)"/g, f = "build:", m = n.config(), g = "element!", v = {};
    if (e("element"), m.hasOwnProperty(g) && (g = m.depPrefix), "undefined" != typeof document && (c = document.createElement("div")), 
    r = "undefined" != typeof XMLHttpRequest ? function(e, t, n) {
        var i = new XMLHttpRequest();
        i.open("GET", e, !0), i.onreadystatechange = function() {
            var s, o;
            4 === i.readyState && (s = i.status, s > 399 && 600 > s ? (o = new Error(e + " HTTP status: " + s), 
            o.xhr = i, n(o)) : t(i.responseText));
        }, i.responseType = "text", i.send(null);
    } : function(e, t) {
        t(requirejs._readFile(e));
    }, a = {
        fetchText: r,
        ready: function(e) {
            l ? setTimeout(e) : d.push(e);
        },
        makeFullId: s,
        makeTemplateFn: function(e) {
            return function() {
                var t, n = document.createDocumentFragment();
                for (c.innerHTML = e; t = c.firstChild; ) n.appendChild(t);
                return n;
            };
        },
        idsToUrls: function(t, n) {
            return t = t.replace(p, function(t, i, o) {
                o = s(o, n);
                var a = "hrefid" === i ? "href" : "src";
                return " " + a + '="' + e.toUrl(o) + '"';
            });
        },
        depsFromText: function(e) {
            var t, n, i = [];
            for (n = e.replace(h, ""), u.lastIndex = 0; t = u.exec(n); ) i.push(g + t[1]);
            return i;
        },
        textToTemplate: function(e, t, n) {
            var i, s = a.depsFromText(e);
            return i = {
                id: t,
                deps: s,
                text: e
            }, n || (i.text = a.idsToUrls(e, t), i.fn = a.makeTemplateFn(i.text)), i;
        },
        objToFn: function(e) {
            var t = a.idsToUrls(e.text, e.id);
            return a.makeTemplateFn(t);
        },
        templateCreatedCallback: o,
        load: function(t, n, i, s) {
            var c = s.isBuild;
            if (0 === t.indexOf(f) && c) {
                t = t.substring(f.length);
                var l = t.split(","), d = 0, u = function() {
                    d += 1, d === l.length && i();
                };
                u.__requireJsBuild = !0, t.split(",").forEach(function(t) {
                    var i = n.toUrl(t);
                    e(a.depsFromText(requirejs._readFile(i)), u);
                });
            } else r(n.toUrl(t), function(e) {
                var s = a.textToTemplate(e, t, c);
                n(s.deps, function() {
                    c && (v[t] = s), i({
                        createdCallback: o,
                        template: s.fn
                    });
                });
            }, i.error);
        },
        write: function(e, t, i) {
            if (v.hasOwnProperty(t)) {
                var s = v[t], o = JSON.stringify(s.deps);
                o = o.replace(/^\s*\[/, "").replace(/\]\s*$/, "").trim(), o && (o = ", " + o), i.asModule(e + "!" + t, "define(['" + n.id + "'" + o + "], function(template) { return {\n" + "createdCallback: template.templateCreatedCallback,\n" + "template: template.objToFn(" + JSON.stringify(v[t]) + ")}; });\n");
            }
        }
    }, "undefined" != typeof document) {
        var _, y = !1;
        _ = function() {
            if (!y) {
                y = !0;
                var t = a.textToTemplate(document.body.innerHTML);
                e(t.deps, i);
            }
        }, "interactive" === document.readyState || "complete" === document.readyState ? _() : window.addEventListener("DOMContentLoaded", _);
    }
    return a;
}), define("template!cards/confirm_dialog.html", [ "template" ], function(e) {
    return {
        createdCallback: e.templateCreatedCallback,
        template: e.objToFn({
            id: "cards/confirm_dialog.html",
            deps: [],
            text: '<div class="card-confirm-dialog card">\n  <form data-statuscolor="background"\n        role="dialog" data-type="confirm" class="collapsed confirm-dialog-form">\n    <section>\n      <h1 data-l10n-id="confirm-dialog-title">ConfirmatioN</h1>\n      <p class="confirm-dialog-message"></p>\n    </section>\n    <menu>\n      <button class="confirm-dialog-cancel" data-l10n-id="message-multiedit-cancel">CanceL</button>\n      <button class="confirm-dialog-ok recommend" data-l10n-id="dialog-button-ok">OK</button>\n    </menu>\n  </form>\n</div>\n'
        })
    };
}), define("cards/confirm_dialog", [ "require", "cards", "./base", "template!./confirm_dialog.html" ], function(e) {
    var t = e("cards");
    return [ e("./base")(e("template!./confirm_dialog.html")), {
        onArgs: function(e) {
            var t = e.dialogBodyNode, n = e.confirm, i = e.cancel, s = e.callback;
            t ? this.appendChild(t) : (t = this.querySelector(".confirm-dialog-form"), t.querySelector(".confirm-dialog-message").textContent = e.message, 
            t.classList.remove("collapsed"), n = {
                handler: function() {
                    s(!0);
                }
            }, i = {
                handler: function() {
                    s(!1);
                }
            }), t.addEventListener("submit", function(e) {
                e.preventDefault(), e.stopPropagation(), this.hide();
                var t = e.explicitOriginalTarget, s = t.id, o = t.classList.contains("confirm-dialog-ok"), a = t.classList.contains("confirm-dialog-cancel");
                (o || s === n.id) && n.handler ? n.handler() : (a || s === i.id) && i.handler && i.handler();
            }.bind(this));
        },
        hide: function() {
            t.removeCardAndSuccessors(this, "immediate", 1, null, !0);
        },
        die: function() {}
    } ];
}), define("confirm_dialog", [ "require", "exports", "module", "cards", "element!cards/confirm_dialog" ], function(e) {
    var t = e("cards"), n = e("element!cards/confirm_dialog");
    return n.show = function(e, n, i) {
        var s;
        "string" != typeof e && (s = e, e = null), t.pushCard("confirm_dialog", "immediate", {
            dialogBodyNode: s,
            message: e,
            confirm: n,
            callback: n,
            cancel: i
        }, "right");
    }, n;
}), define("model", [ "require", "evt" ], function(e) {
    function t(e) {
        throw console.error("FATAL:", e), new Error(e);
    }
    var n = e("evt"), i = {
        firstRun: null,
        acctsSlice: null,
        account: null,
        foldersSlice: null,
        folder: null,
        _callEmit: function(e) {
            this.emit(e, this[e]);
        },
        inited: !1,
        hasAccount: function() {
            return i.getAccountCount() > 0;
        },
        getAccount: function(e) {
            if (!i.acctsSlice || !i.acctsSlice.items) throw new Error("No acctsSlice available");
            var t;
            return i.acctsSlice.items.some(function(n) {
                return n.id === e ? !!(t = n) : void 0;
            }), t;
        },
        getAccountCount: function() {
            var e = 0;
            return i.acctsSlice && i.acctsSlice.items && i.acctsSlice.items.length && (e = i.acctsSlice.items.length), 
            e;
        },
        init: function(t, s) {
            e([ "api" ], function(e) {
                var o = function() {
                    this.die();
                    var o = e.viewAccounts(!1);
                    o.oncomplete = function() {
                        if (i.acctsSlice = o, o.items.length) {
                            var e = t ? o.items.slice(-1)[0] : o.defaultAccount;
                            this.changeAccount(e, s);
                        }
                        this.inited = !0, this._callEmit("acctsSlice"), n.emit("metrics:apiDone");
                    }.bind(this);
                }.bind(this);
                this.api ? o() : (this.once("api", o), this.api = e, this._callEmit("api", this.api));
            }.bind(this));
        },
        changeAccount: function(e, t) {
            if (this.account && this.account.id === e.id) return t && t(), void 0;
            this._dieFolders(), this.account = e, this._callEmit("account");
            var n = this.api.viewFolders("account", e);
            n.oncomplete = function() {
                this.foldersSlice = n, this.foldersSlice.onchange = this.notifyFoldersSliceOnChange.bind(this), 
                this.selectInbox(t), this._callEmit("foldersSlice");
            }.bind(this);
        },
        changeAccountFromId: function(e, t) {
            if (!this.acctsSlice || !this.acctsSlice.items.length) throw new Error("No accounts available");
            this.acctsSlice.items.some(function(n) {
                return n.id === e ? (this.changeAccount(n, t), !0) : void 0;
            }.bind(this));
        },
        changeFolder: function(e) {
            !e || this.folder && e.id === this.folder.id || (this.folder = e, this._callEmit("folder"));
        },
        selectInbox: function(e) {
            this.selectFirstFolderWithType("inbox", e);
        },
        selectFirstFolderWithType: function(e, n) {
            if (!this.foldersSlice) throw new Error("No foldersSlice available");
            var i = this.foldersSlice.getFirstFolderWithType(e);
            i || t("We have an account without a folderType " + e + "!", this.foldersSlice.items), 
            this.folder && this.folder.id === i.id ? n && n() : (n && this.once("folder", n), 
            this.changeFolder(i));
        },
        notifyInboxMessages: function(e) {
            e.id === this.account.id && i.emit("newInboxMessages", e.count);
        },
        notifyFoldersSliceOnChange: function(e) {
            i.emit("foldersSliceOnChange", e);
        },
        notifyBackgroundSendStatus: function(e) {
            i.emit("backgroundSendStatus", e);
        },
        _dieFolders: function() {
            this.foldersSlice && this.foldersSlice.die(), this.foldersSlice = null, this.folder = null;
        },
        die: function() {
            this.acctsSlice && this.acctsSlice.die(), this.acctsSlice = null, this.account = null, 
            this._dieFolders();
        }
    };
    return n.mix(i);
}), define("array", [ "require" ], function() {
    var e = {
        indexOfGeneric: function(e, t, n) {
            var i = -1;
            return e.some(function(e, s) {
                return t.call(n, e) ? (i = s, !0) : void 0;
            }), i;
        }
    };
    return e;
}), define("header_cursor", [ "require", "array", "evt", "model" ], function(e) {
    function t(e, t) {
        return function() {
            var t = Array.slice(arguments);
            this.emit.apply(this, [ "messages_" + e ].concat(t));
        }.bind(t);
    }
    function n() {
        o.Emitter.call(this), this.searchMode = "nonsearch";
    }
    function i(e, t) {
        this.header = e, this.siblings = t;
    }
    var s = e("array"), o = e("evt"), a = e("model");
    n.prototype = o.mix({
        currentMessage: null,
        messagesSlice: null,
        expectingMessageSuid: null,
        sliceEvents: [ "splice", "change", "status", "remove", "complete" ],
        _inited: !1,
        init: function() {
            this._inited = !0, this.on("messages_splice", this.onMessagesSplice.bind(this)), 
            this.on("messages_remove", this.onMessagesSpliceRemove.bind(this)), this.on("messages_complete", function() {
                this.messagesSlice && (this.messagesSlice.oncomplete = t("complete", this));
            }.bind(this)), this.onLatestFolder = this.onLatestFolder.bind(this), a.latest("folder", this.onLatestFolder);
        },
        advance: function(e) {
            var t = this.indexOfMessageById(this.currentMessage.header.id);
            switch (e) {
              case "previous":
                t -= 1;
                break;

              case "next":
                t += 1;
            }
            var n = this.messagesSlice.items;
            0 > t || t >= n.length || this.setCurrentMessageByIndex(t);
        },
        setCurrentMessageBySuid: function(e) {
            this.expectingMessageSuid = e, this.checkExpectingMessageSuid();
        },
        checkExpectingMessageSuid: function(e) {
            var t = this.expectingMessageSuid;
            if (t && a.folder && "inbox" === a.folder.type) {
                var n = this.indexOfMessageById(t);
                return n > -1 ? (this.expectingMessageSuid = null, this.setCurrentMessageByIndex(n)) : (e && (console.error("header_cursor could not find messageSuid " + t + ", emitting messageSuidNotFound"), 
                this.emit("messageSuidNotFound", t)), void 0);
            }
        },
        setCurrentMessage: function(e) {
            e && this.setCurrentMessageByIndex(this.indexOfMessageById(e.id));
        },
        setCurrentMessageByIndex: function(e) {
            var t = this.messagesSlice.items;
            if (!(-1 === e || e > t.length - 1)) {
                var n = t[e];
                "header" in n && (n = n.header);
                var s = new i(n, {
                    hasPrevious: 0 !== e,
                    hasNext: e !== t.length - 1
                });
                this.emit("currentMessage", s, e), this.currentMessage = s;
            }
        },
        indexOfMessageById: function(e) {
            var t = this.messagesSlice && this.messagesSlice.items || [];
            return s.indexOfGeneric(t, function(t) {
                var n = "header" in t ? t.header.id : t.id;
                return n === e;
            });
        },
        onLatestFolder: function() {
            a.foldersSlice && this.freshMessagesSlice();
        },
        startSearch: function(e, t) {
            this.searchMode = "search", this.bindToSlice(a.api.searchFolderMessages(a.folder, e, t));
        },
        endSearch: function() {
            this.die(), this.searchMode = "nonsearch", this.freshMessagesSlice();
        },
        freshMessagesSlice: function() {
            this.bindToSlice(a.api.viewFolderMessages(a.folder));
        },
        bindToSlice: function(e) {
            this.die(), this.messagesSlice = e, this.sliceEvents.forEach(function(n) {
                e["on" + n] = t(n, this);
            }.bind(this));
        },
        onMessagesSplice: function() {
            this.messagesSlice && this.messagesSlice.atTop && this.expectingMessageSuid && this.messagesSlice.items && this.messagesSlice.items.length && this.checkExpectingMessageSuid(!0);
        },
        onMessagesSpliceRemove: function(e, t) {
            if (this.currentMessage !== e) return this.setCurrentMessage(this.currentMessage);
            var n = this.messagesSlice.items;
            if (0 === n.length) return this.currentMessage = null;
            var i = Math.min(t, n.length - 1), s = this.messagesSlice.items[i];
            this.setCurrentMessage(s);
        },
        die: function() {
            this.messagesSlice && (this.messagesSlice.die(), this.messagesSlice = null), this.currentMessage = null;
        }
    });
    var r = n.prototype.on;
    return n.prototype.on = function() {
        return this._inited || (this.init(), n.prototype.on = r), r.apply(this, arguments);
    }, i.prototype = {
        header: null,
        siblings: null
    }, {
        CurrentMessage: i,
        cursor: new n()
    };
}), function(e) {
    const t = [ 16, 17, 18, 19, 20, 21, 22, 23 ];
    var n = {
        _cachedContexts: {},
        _getCachedContext: function(e, t, n) {
            n = n || "italic";
            var i = this._cachedContexts, s = i[e] && i[e][t] ? i[e][t][n] : null;
            if (!s) {
                var o = document.createElement("canvas");
                o.setAttribute("moz-opaque", "true"), o.setAttribute("width", "1"), o.setAttribute("height", "1"), 
                s = o.getContext("2d", {
                    willReadFrequently: !0
                }), s.font = n + " " + e + "px " + t, i[e] || (i[e] = {}), i[e][t] || (i[e][t] = {}), 
                i[e][t][n] = s;
            }
            return s;
        },
        resetCache: function() {
            this._cachedContexts = {};
        },
        _textChangeObserver: null,
        _handleTextChanges: function(e) {
            for (var t = 0; t < e.length; t++) this._reformatHeaderText(e[t].target);
        },
        _getTextChangeObserver: function() {
            return this._textChangeObserver || (this._textChangeObserver = new MutationObserver(this._handleTextChanges.bind(this))), 
            this._textChangeObserver;
        },
        _observeHeaderChanges: function(e) {
            var t = this._getTextChangeObserver();
            t.observe(e, {
                childList: !0
            });
        },
        _reformatHeaderText: function(e) {
            if ("" !== e.textContent.trim()) {
                this.resetCentering(e);
                var t = this.getStyleProperties(e);
                t.textWidth = this.autoResizeElement(e, t), this.centerTextToScreen(e, t);
            }
        },
        _registerHeadersInSubtree: function(e) {
            if (e) for (var t = e.querySelectorAll("header > h1"), n = 0; n < t.length; n++) window.requestAnimationFrame(function(e) {
                this._reformatHeaderText(e), this._observeHeaderChanges(e);
            }.bind(this, t[n]));
        },
        getFontWidth: function(e, t, n, i) {
            var s = this._getCachedContext(t, n, i);
            return s.measureText(e).width;
        },
        getMaxFontSizeInfo: function(e, t, n, i) {
            var s, o, a = t.length - 1;
            do s = t[a], o = this.getFontWidth(e, s, n), a--; while (o > i && a >= 0);
            return {
                fontSize: s,
                overflow: o > i,
                textWidth: o
            };
        },
        getOverflowCount: function(e, t, n, i) {
            var s, o, a = -1;
            do a++, s = e.substr(0, e.length - a), o = this.getFontWidth(s, t, n); while (s.length > 0 && o > i);
            return a;
        },
        getAllowedSizes: function(e) {
            return "H1" === e.tagName && "HEADER" === e.parentNode.tagName ? t : [];
        },
        getContentWidth: function(e) {
            var t = parseInt(e.width, 10);
            return "border-box" === e.boxSizing && (t -= parseInt(e.paddingRight, 10) + parseInt(e.paddingLeft, 10)), 
            t;
        },
        getStyleProperties: function(e) {
            var t = window.getComputedStyle(e), n = this.getContentWidth(t);
            return isNaN(n) && (n = 0), {
                fontFamily: t.fontFamily,
                contentWidth: n,
                paddingRight: parseInt(t.paddingRight, 10),
                paddingLeft: parseInt(t.paddingLeft, 10),
                offsetLeft: e.offsetLeft
            };
        },
        autoResizeElement: function(e, t) {
            var n = this.getAllowedSizes(e);
            if (0 === n.length) return 0;
            var i = t.contentWidth || this.getContentWidth(e), s = t.fontFamily || getComputedStyle(e).fontFamily, o = this.getMaxFontSizeInfo(e.textContent.trim(), n, s, i);
            return e.style.fontSize = o.fontSize + "px", o.textWidth;
        },
        resetCentering: function(e) {
            e.style.marginLeft = e.style.marginRight = "0";
        },
        centerTextToScreen: function(e, t) {
            var n = t.textWidth + t.paddingRight + t.paddingLeft, i = t.offsetLeft, s = this.getWindowWidth() - i - t.contentWidth - t.paddingRight - t.paddingLeft;
            if (i !== s) {
                var o = Math.max(i, s);
                n + 2 * o < this.getWindowWidth() - 1 && (e.style.marginLeft = e.style.marginRight = o + "px");
            }
        },
        _initHeaderFormatting: function() {
            navigator.mozL10n ? navigator.mozL10n.once(function() {
                this._registerHeadersInSubtree(document.body);
            }.bind(this)) : this._registerHeadersInSubtree(document.body);
        },
        init: function() {
            window.addEventListener("lazyload", function(e) {
                this._registerHeadersInSubtree(e.detail);
            }.bind(this)), "loading" === document.readyState ? window.addEventListener("DOMContentLoaded", function() {
                this._initHeaderFormatting();
            }.bind(this)) : this._initHeaderFormatting();
        },
        getWindowWidth: function() {
            return window.innerWidth;
        }
    };
    n.init(), e.FontSizeUtils = n;
}(this), define("shared/js/font_size_utils", function() {}), define("metrics", [ "require", "evt" ], function(e) {
    function t() {
        i && s && (window.performance.mark("fullyLoaded"), window.dispatchEvent(new CustomEvent("moz-app-loaded")));
    }
    var n = e("evt"), i = !1, s = !1;
    n.once("metrics:apiDone", function() {
        i = !0, t();
    }), n.once("metrics:contentDone", function() {
        s = !0, startupCacheEventsSent || (window.performance.mark("visuallyLoaded"), window.dispatchEvent(new CustomEvent("moz-app-visually-complete")), 
        window.performance.mark("contentInteractive"), window.dispatchEvent(new CustomEvent("moz-content-interactive"))), 
        t();
    });
}), function(e) {
    function t(e) {
        return "string" == typeof e ? navigator.mozL10n.get(e) : e.raw ? e.raw : navigator.mozL10n.get(e.id, e.args);
    }
    e.NotificationHelper = {
        getIconURI: function(e, t) {
            var n = e.manifest.icons;
            if (t && (n = e.manifest.entry_points[t].icons), !n) return null;
            var i = Object.keys(n).map(function(e) {
                return parseInt(e, 10);
            });
            i.sort(function(e, t) {
                return t - e;
            });
            var s = document.documentElement.clientWidth < 480, o = i[s ? i.length - 1 : 0];
            return e.installOrigin + n[o];
        },
        send: function(n, i) {
            return new Promise(function(s) {
                navigator.mozL10n.once(function() {
                    var o = t(n);
                    i.bodyL10n && (i.body = t(i.bodyL10n)), i.dir = navigator.mozL10n.language.direction, 
                    i.lang = navigator.mozL10n.language.code;
                    var a = new e.Notification(o, i);
                    i.closeOnClick !== !1 && a.addEventListener("click", function r() {
                        a.removeEventListener("click", r), a.close();
                    }), s(a);
                });
            });
        }
    };
}(this), define("shared/js/notification_helper", function(e) {
    return function() {
        var t;
        return t || e.NotificationHelper;
    };
}(this)), define("sync", [ "require", "app_self", "evt", "model", "l10n!", "shared/js/notification_helper" ], function(e) {
    var t = e("app_self"), n = e("evt"), i = e("model"), s = e("l10n!"), o = e("shared/js/notification_helper"), a = "1";
    i.latestOnce("api", function(e) {
        function r(e) {
            return "id" + e.join(" ");
        }
        function c(e) {
            return "function" == typeof Notification && Notification.get ? Notification.get().then(function(t) {
                var n = {};
                return t.forEach(function(t) {
                    var i = t.data;
                    i.v && i.v === a ? i.ntype === e && (i.notification = t, n[i.accountId] = i) : t.close();
                }), n;
            }, function(e) {
                return console.error("email notification.get call failed: " + e), {};
            }) : Promise.resolve({});
        }
        function l(e) {
            t.latest("self", function(t) {
                i.latestOnce("account", function(n) {
                    c("sync").then(function(i) {
                        e(t, n, i);
                    });
                });
            });
        }
        function d(e, t) {
            var n = [], i = 3;
            return e.sort(function(e, t) {
                return t.date - e.date;
            }), e.some(function(e) {
                return n.length > i ? !0 : (-1 === n.indexOf(e.from) && n.push(e.from), void 0);
            }), t.some(function(e) {
                return n.length > i ? !0 : (-1 === n.indexOf(e) && n.push(e), void 0);
            }), n;
        }
        var u = !document.hidden, h = {};
        u && e.setInteractive(), document.addEventListener("visibilitychange", function() {
            document.hidden || (u = !0, e.setInteractive());
        }, !1);
        var p;
        "function" != typeof Notification ? (console.log("email: notifications not available"), 
        p = function() {}) : p = function(e, t, i, s, o, a) {
            if (console.log("Notification sent for " + e), "granted" !== Notification.permission) return console.log("email: notification skipped, permission: " + Notification.permission), 
            void 0;
            o = o || {};
            var r = {
                body: i,
                icon: s,
                tag: e,
                data: o,
                mozbehavior: {
                    noscreen: !0
                }
            };
            a && Object.keys(a).forEach(function(e) {
                r.mozbehavior[e] = a[e];
            });
            var c = new Notification(t, r);
            c.onclick = function() {
                n.emit("notification", {
                    clicked: !0,
                    imageURL: s,
                    data: o,
                    tag: e
                });
            };
        }, e.oncronsyncstart = function(e) {
            console.log("email oncronsyncstart: " + e);
            var t = r(e);
            h[t] = !0;
        }, e.oncronsyncstop = function(e) {
            function t() {
                n.emit("cronSyncStop", e.accountIds);
                var t = r(e.accountIds);
                h[t] = !1;
                var i = Object.keys(h).some(function(e) {
                    return !!h[e];
                });
                if (!u && !i) {
                    var s = "mail sync complete, closing mail app";
                    "function" == typeof plog ? plog(s) : console.log(s), window.close();
                }
            }
            return console.log("email oncronsyncstop: " + e.accountIds), e.updates ? (l(function(n, r, c) {
                var l = o.getIconURI(n);
                e.updates.forEach(function(e) {
                    if (r.id === e.id && !document.hidden) return i.notifyInboxMessages(e), void 0;
                    if (i.getAccount(e.id).notifyOnNew && "function" == typeof Notification) {
                        var t, n, o, u, h = e.count, f = [], m = c[e.id];
                        if (m && (m.count && (h += parseInt(m.count, 10)), m.fromNames && (f = m.fromNames)), 
                        h > 1) {
                            var g = d(e.latestMessageInfos, f);
                            t = {
                                v: a,
                                ntype: "sync",
                                type: "message_list",
                                accountId: e.id,
                                count: h,
                                fromNames: g
                            }, m && m.count && (u = {
                                soundFile: "does-not-exist-to-simulate-silent",
                                vibrationPattern: [ 1 ]
                            }), n = 1 === i.getAccountCount() ? s.get("new-emails-notify-one-account", {
                                n: h
                            }) : s.get("new-emails-notify-multiple-accounts", {
                                n: h,
                                accountName: e.address
                            }), o = g.join(s.get("senders-separation-sign"));
                        } else {
                            var v = e.latestMessageInfos[0];
                            t = {
                                v: a,
                                ntype: "sync",
                                type: "message_reader",
                                accountId: v.accountId,
                                messageSuid: v.messageSuid,
                                count: 1,
                                fromNames: [ v.from ]
                            }, 1 === i.getAccountCount() ? (n = v.subject, o = v.from) : (n = s.get("new-emails-notify-multiple-accounts", {
                                n: h,
                                accountName: e.address
                            }), o = s.get("new-emails-notify-multiple-accounts-body", {
                                from: v.from,
                                subject: v.subject
                            }));
                        }
                        p(e.id, n, o, l, t, u);
                    }
                }), t();
            }), void 0) : (t(), void 0);
        };
        var f = "backgroundSendFailed", m = null;
        e.onbackgroundsendstatus = function(e) {
            console.log("outbox: Message", e.suid, "status =", JSON.stringify({
                state: e.state,
                err: e.err,
                sendFailures: e.sendFailures,
                emitNotifications: e.emitNotifications
            }));
            var n;
            switch (e.state) {
              case "pending":
                n = "background-send-pending";
                break;

              case "sending":
                n = "background-send-sending";
                break;

              case "success":
                n = "background-send-success";
                break;

              case "error":
                n = e.badAddresses && e.badAddresses.length || "bad-recipient" === e.err ? "background-send-error-recipients" : "background-send-error";
                break;

              case "syncDone":
                break;

              default:
                return console.error('No state description for background send state "' + e.state + '"'), 
                void 0;
            }
            n && (e.localizedDescription = s.get(n)), "success" === e.state && i.latestOnce("acctsSlice", function() {
                var t = i.getAccount(e.accountId);
                return t ? (t.playSoundOnSend && (m || (m = new Audio("/sounds/firefox_sent.opus"), 
                m.mozAudioChannelType = "notification"), m.play()), void 0) : (console.error("Invalid account ID", e.accountId, "for a background send notification."), 
                void 0);
            }.bind(this)), document.hidden ? "error" === e.state && e.emitNotifications && t.latest("self", function(t) {
                var n = o.getIconURI(t), i = {
                    v: a,
                    ntype: "outbox",
                    type: "message_reader",
                    folderType: "outbox",
                    accountId: e.accountId,
                    messageSuid: e.suid
                };
                p(f, s.get("background-send-error-title"), e.localizedDescription, n, i);
            }) : i.notifyBackgroundSendStatus(e);
        }, n.on("inboxShown", function(e) {
            c("sync").then(function(t) {
                t.hasOwnProperty(e) && t[e].notification.close();
            });
        });
    });
}), define("wake_locks", [ "require", "evt" ], function(e) {
    function t() {
        l = {}, d = 0, document.hidden ? (console.log("email: cronsync wake locks expired, force closing app"), 
        window.close()) : (console.log("email: cronsync wake locks expired, but app visible, not force closing"), 
        Object.keys(c).forEach(function(e) {
            i(e);
        }));
    }
    function n() {
        var e = Object.keys(l);
        return e.length ? (console.log("email: cronsync wake lock force shutdown waiting on email data operations: " + e.join(", ")), 
        d = setTimeout(t, h), void 0) : t();
    }
    function i(e) {
        console.log('email: clearing wake locks for "' + e + '"');
        var t = a[e];
        t && clearTimeout(t), a[e] = 0;
        var n = c[e];
        c[e] = null, n && n.forEach(function(e) {
            e.unlock();
        });
    }
    function s(e) {
        return "id" + e.join(" ");
    }
    function o(e) {
        i(s(e));
    }
    var a = {}, r = e("evt"), c = {}, l = {}, d = 0, u = 45e3, h = 5e3;
    r.on("uiDataOperationStart", function(e) {
        l[e] = !0;
    }), r.on("uiDataOperationStop", function(e) {
        delete l[e], d && !Object.keys(l).length && (clearTimeout(d), t());
    }), r.on("cronSyncWakeLocks", function(e, t) {
        a[e] && i(e), c[e] = t, a[e] = setTimeout(n, u);
    }), r.on("cronSyncStop", o);
}), function() {
    function e() {
        for (var e = arguments[0] + ":", t = 1; t < arguments.length; t++) e += " " + arguments[t];
        e += "[0m\n", dump(e);
    }
    "mozTCPSocket" in window.navigator && (window.console = {
        log: e.bind(null, "[32mLOG"),
        error: e.bind(null, "[31mERR"),
        info: e.bind(null, "[36mINF"),
        warn: e.bind(null, "[33mWAR")
    }), window.onerror = function(e, t, n) {
        return console.error("onerror reporting:", e, "@", t, ":", n), !1;
    };
}(), define("console_hook", function() {}), define("tmpl!cards/msg/header_item.html", [ "tmpl" ], function(e) {
    return e.toDom('<a class="msg-header-item">\n  <label class="pack-checkbox negative">\n    <input type="checkbox"><span></span>\n  </label>\n  <div class="msg-header-syncing-section"></div>\n  <div class="msg-header-unread-section"></div>\n  <div class="msg-header-details-section">\n    <span class="msg-header-author-and-date">\n      <span dir="auto" class="msg-header-author"></span>\n      <span class="msg-header-date"></span>\n    </span><span dir="auto" class="msg-header-subject"></span>\n    <span dir="auto" class="msg-header-snippet"></span>\n  </div><div class="msg-header-icons-section">\n    <span class="msg-header-star"></span>\n    <span class="msg-header-attachments"></span>\n  </div><div class="msg-header-avatar-section">\n  </div></a>\n');
}), define("tmpl!cards/msg/delete_confirm.html", [ "tmpl" ], function(e) {
    return e.toDom('<form role="dialog" class="msg-delete-confirm" data-type="confirm">\n  <section>\n    <h1 data-l10n-id="confirm-dialog-title">ConfirmatioN</h1>\n    <p></p>\n  </section>\n  <menu>\n    <button id="msg-delete-cancel" data-l10n-id="message-multiedit-cancel">CanceL</button>\n    <button id="msg-delete-ok" class="danger" data-l10n-id="message-edit-menu-delete">OK</button>\n  </menu>\n</form>');
}), define("tmpl!cards/msg/large_message_confirm.html", [ "tmpl" ], function(e) {
    return e.toDom('<form role="dialog" class="msg-large-message-confirm" data-type="confirm">\n  <section>\n    <h1 data-l10n-id="confirm-dialog-title">ConfirmatioN</h1>\n    <p><span data-l10n-id="message-large-message-confirm"></span></p>\n  </section>\n  <menu>\n    <button id="msg-large-message-cancel" data-l10n-id="message-large-message-cancel">CanceL</button>\n    <button id="msg-large-message-ok" data-l10n-id="message-large-message-ok">OK</button>\n  </menu>\n</form>\n');
}), define("date", [ "require", "l10n!" ], function(e) {
    var t = e("l10n!"), n = {
        prettyDate: function(e, n) {
            var i = new t.DateTimeFormat();
            return i.fromNow(e, n);
        },
        setPrettyNodeDate: function(e, t) {
            t ? (e.dataset.time = t.valueOf(), e.dataset.compactFormat = !0, e.textContent = n.prettyDate(t, !0)) : (e.textContent = "", 
            e.removeAttribute("data-time"));
        }
    };
    return n;
}), define("vscroll", [ "require", "exports", "module", "evt" ], function(e) {
    function t(e, t) {
        o ? e.style.transform = "translateY(" + t + "px)" : e.style.top = t + "px";
    }
    function n(e, t, n, s) {
        i.Emitter.call(this), this.container = e, this.scrollingContainer = t, this.template = n, 
        this.defaultData = s, this._inited = !1, this._capturedScreenMetrics = !1, this.firstRenderedIndex = 0, 
        this._limited = !1, this.nodes = [], this.nodesDataIndices = {}, this.nodesIndex = -1, 
        this.scrollTop = 0, this.visibleOffset = 0, this.oldListSize = 0, this._lastEventTime = 0, 
        this.onEvent = this.onEvent.bind(this), this.onChange = this.onChange.bind(this), 
        this._scrollTimeoutPoll = this._scrollTimeoutPoll.bind(this);
    }
    var i = e("evt"), s = Array.prototype.slice, o = !1;
    n.nodeClassName = "vscroll-node", n.trimMessagesForCache = function(e, t) {
        var i = s.call(e.querySelectorAll("." + n.nodeClassName));
        i.forEach(function(n) {
            var i = parseInt(n.dataset.index, 10);
            delete n.dataset.index, i > t - 1 && e.removeChild(n);
        });
    }, n.prototype = {
        eventRateLimitMillis: 0,
        itemsPerScreen: void 0,
        prerenderScreens: 3,
        prefetchScreens: 2,
        retainExtraRenderedScreens: 3,
        recalculatePaddingScreens: 1.5,
        lastScrollTopSetTime: 0,
        prerenderItemCount: void 0,
        prefetchItemCount: void 0,
        recalculatePaddingItemCount: void 0,
        itemDefaultDataClass: "default-data",
        prepareData: function() {},
        bindData: function() {},
        setData: function(e) {
            this.list = e, this._inited ? (this.waitingForRecalculate || this._recalculate(0), 
            this.emit("dataChanged")) : (this._init(), this.renderCurrentPosition());
        },
        updateDataBind: function(e, t, n) {
            if (this._inited) {
                if (this.oldListSize !== this.list.size() || n) return this.waitingForRecalculate || (this.waitingForRecalculate = !0, 
                this.once("scrollStopped", function() {
                    this._recalculate(e);
                }.bind(this))), void 0;
                for (var i = 0; i < t.length; i++) {
                    var s = e + i, o = this._getNodeFromDataIndex(s);
                    o && this.bindData(t[i], o);
                }
            }
        },
        onEvent: function() {
            return this._lastEventTime = Date.now(), this.eventRateLimitMillis ? (this._limited || (this._limited = !0, 
            setTimeout(this.onChange, this.eventRateLimitMillis)), void 0) : (this.onChange(), 
            void 0);
        },
        onChange: function() {
            if (this._limited = !1, this._inited) {
                this.lastScrollTopSetTime && this.lastScrollTopSetTime + 1e3 < Date.now() && (this.lastScrollTopSetTime = 0);
                var e, t, n = this.scrollingContainer.scrollTop, i = n >= this.scrollTop;
                this.scrollTop = n;
                var s = this.getVisibleIndexRange();
                i ? (e = s[0], t = s[1] + this.prerenderItemCount, this.prepareData(t + this.prefetchItemCount)) : (e = s[0] - this.prerenderItemCount, 
                t = s[1]), this._render(e, t), this._startScrollStopPolling();
            }
        },
        nowVisible: function() {
            !this._inited && this.list && (this._init(), this.onChange());
        },
        renderCurrentPosition: function() {
            if (this._inited) {
                var e = this.scrollingContainer.scrollTop;
                this.scrollTop = e;
                var t = this.getVisibleIndexRange(), n = t[0] - this.recalculatePaddingItemCount, i = t[1] + this.recalculatePaddingItemCount;
                this._render(n, i), this.prepareData(i);
            }
        },
        indexAtScrollPosition: function(e) {
            var t = e - this.visibleOffset;
            return 0 > t && (t = 0), this.itemHeight ? Math.floor(t / this.itemHeight) : 0;
        },
        getVisibleIndexRange: function() {
            if (void 0 === this.itemHeight) return void 0;
            var e = this.scrollTop;
            return [ this.indexAtScrollPosition(e), this.indexAtScrollPosition(e + this.innerHeight) ];
        },
        jumpToIndex: function(e) {
            this._setContainerScrollTop(e * this.itemHeight + this.visibleOffset);
        },
        clearDisplay: function() {
            this.container.innerHTML = "", this.container.style.height = "0px", this.oldListSize = 0;
        },
        destroy: function() {
            this.scrollingContainer.removeEventListener("scroll", this.onEvent), this._scrollTimeoutPoll && (clearTimeout(this._scrollTimeoutPoll), 
            this._scrollTimeoutPoll = 0);
        },
        _setContainerScrollTop: function(e) {
            this.scrollingContainer.scrollTop = e, this.lastScrollTopSetTime = Date.now();
        },
        _render: function(e, n) {
            var i, s = this.list.size();
            for (0 > e && (e = 0), n >= s && (n = s - 1), this.firstRenderedIndex = e, this._inited || this._init(), 
            i = e; n >= i; i++) if (!this._getNodeFromDataIndex(i)) {
                var o = this._nextAvailableNode(e, n), a = this.list(i);
                a || (a = this.defaultData), o.parentNode && o.parentNode.removeChild(o), t(o, i * this.itemHeight), 
                this._setNodeDataIndex(this.nodesIndex, i), this.bindData(a, o), this.container.appendChild(o);
            }
        },
        _setNodeDataIndex: function(e, t) {
            var n = this.nodes[e].vScrollDataIndex;
            n > -1 && (this.nodesDataIndices[n] = -1);
            var i = this.nodes[e];
            i.vScrollDataIndex = t, i.dataset.index = t, this.nodesDataIndices[t] = e;
        },
        _getNodeFromDataIndex: function(e) {
            var t = this.nodesDataIndices[e];
            return void 0 === t && (t = -1), -1 === t ? null : this.nodes[t];
        },
        captureScreenMetrics: function() {
            this._capturedScreenMetrics || (this.innerHeight = this.scrollingContainer.getBoundingClientRect().height, 
            this.innerHeight > 0 && (this._capturedScreenMetrics = !0));
        },
        _init: function() {
            if (!this._inited) {
                this.container.innerHTML = "";
                var e = this.template.cloneNode(!0);
                if (this.container.appendChild(e), this.itemHeight = e.clientHeight, this.container.removeChild(e), 
                this.captureScreenMetrics(), this.itemHeight && this.innerHeight) {
                    this.scrollingContainer.addEventListener("scroll", this.onEvent), this.itemsPerScreen = Math.ceil(this.innerHeight / this.itemHeight), 
                    this.prerenderItemCount = Math.ceil(this.itemsPerScreen * this.prerenderScreens), 
                    this.prefetchItemCount = Math.ceil(this.itemsPerScreen * this.prefetchScreens), 
                    this.recalculatePaddingItemCount = Math.ceil(this.itemsPerScreen * this.recalculatePaddingScreens), 
                    this.nodeCount = this.itemsPerScreen + this.prerenderItemCount + Math.ceil(this.retainExtraRenderedScreens * this.itemsPerScreen);
                    for (var i = 0; i < this.nodeCount; i++) e = this.template.cloneNode(!0), e.classList.add(n.nodeClassName), 
                    t(e, -1 * this.itemHeight), this.nodes.push(e), this._setNodeDataIndex(i, -1);
                    this._calculateTotalHeight(), this._inited = !0, this.emit("inited");
                }
            }
        },
        _nextAvailableNode: function(e, t) {
            var n, i, s, o = 0;
            for (n = this.nodesIndex + 1; o < this.nodes.length; o++, n++) if (n > this.nodes.length - 1 && (n = 0), 
            i = this.nodes[n], s = i.vScrollDataIndex, e > s || s > t) {
                this.nodesIndex = n;
                break;
            }
            return i;
        },
        _recalculate: function(e) {
            if (this._inited) {
                var n, i = this.indexAtScrollPosition(this.scrollTop), s = this.scrollTop % this.itemHeight, o = this.list.size() - this.oldListSize;
                e && i > e && o > 0 && 0 !== this.oldListSize && 0 !== i && (i += o), console.log("VSCROLL scrollTop: " + this.scrollTop + ", RECALCULATE: " + i + ", " + s), 
                this._calculateTotalHeight();
                for (var a = 0; a < this.nodeCount; a++) n = this.nodes[a], t(n, -1 * this.itemHeight), 
                this._setNodeDataIndex(a, -1);
                this.waitingForRecalculate = !1, this._setContainerScrollTop(this.itemHeight * i + s), 
                this.renderCurrentPosition(), this.emit("recalculated", 0 === i);
            }
        },
        _calculateTotalHeight: function() {
            var e = this.list.size();
            (this.oldListSize !== e || 0 === parseInt(this.container.style.height, 10)) && (this.totalHeight = this.itemHeight * e, 
            this.container.style.height = this.totalHeight + "px", this.oldListSize = e);
        },
        _scrollTimeoutPoll: function() {
            this._scrollStopTimeout = 0, Date.now() > this._lastEventTime + 300 ? this.emit("scrollStopped") : this._scrollStopTimeout = setTimeout(this._scrollTimeoutPoll, 300);
        },
        _startScrollStopPolling: function() {
            this._scrollStopTimeout || (this._scrollStopTimeout = setTimeout(this._scrollTimeoutPoll, 300));
        }
    }, i.mix(n.prototype);
    var a = n.prototype.on;
    return n.prototype.on = function(e) {
        return "scrollStopped" === e && this._startScrollStopPolling(), a.apply(this, s.call(arguments));
    }, n;
}), define("message_list_topbar", [ "require", "exports", "module", "l10n!" ], function(e) {
    function t(e) {
        this.domNode = e, this.createdCallback();
    }
    var n = e("l10n!"), i = {
        domNode: null,
        _scrollContainer: null,
        _vScroll: null,
        _delayedState: null,
        _newEmailCount: 0,
        _scrollTop: 0,
        _thresholdMultiplier: 2,
        visibleOffset: 0,
        createdCallback: function() {
            this.domNode.addEventListener("click", this._onClick.bind(this)), this.domNode.addEventListener("transitionend", this._onTransitionEnd.bind(this));
        },
        resetNodeForCache: function(e) {
            e.classList.remove("closing"), e.textContent = "", e.dataset.state = "", this.domNode.style.left = "";
        },
        bindToElements: function(e, t) {
            this._scrollContainer = e, this._scrollContainer.addEventListener("scroll", this._onScroll.bind(this)), 
            this._scrollTop = this._scrollContainer.scrollTop, this._vScroll = t;
        },
        showNewEmailCount: function(e) {
            this._scrollTop <= this.visibleOffset || (this._newEmailCount = e, this._showState("message"));
        },
        _getState: function() {
            return this.domNode.dataset.state;
        },
        _showState: function(e) {
            var t = this._getState();
            t !== e && (t && e ? t === e || "message" === t && "top" === e || (this._delayedState = e, 
            this._animating || this._animateState("")) : this._animateState(e));
        },
        _animateState: function(e) {
            this._animating = !0, !e && this._getState() ? this.domNode.classList.add("closing") : (this.domNode.classList.add("no-anim"), 
            this.domNode.classList.toggle("horiz-message", "message" === e), this.domNode.classList.toggle("horiz-top", "top" === e), 
            this.domNode.clientWidth, "message" === e ? n.setAttributes(this.domNode, "new-messages", {
                n: this._newEmailCount
            }) : "top" === e && n.setAttributes(this.domNode, "message-list-top-action"), this.domNode.classList.remove("no-anim"), 
            this.domNode.clientWidth, this.domNode.dataset.state = e);
        },
        _onTransitionEnd: function() {
            this._animating = !1, this.domNode.classList.contains("closing") && (this.domNode.classList.remove("closing"), 
            this.domNode.dataset.state = "", this.domNode.style.left = ""), this._delayedState && (this._animateState(this._delayedState), 
            this._delayedState = null);
        },
        _onScroll: function() {
            if (!this._topThreshold) {
                var e = this._scrollContainer.getBoundingClientRect();
                this._topThreshold = e.height * this._thresholdMultiplier, this.domNode.style.top = e.top + "px";
            }
            if (!(this._vScroll.lastScrollTopSetTime && this._vScroll.lastScrollTopSetTime + 500 > Date.now())) {
                var t = this._scrollContainer.scrollTop, n = t > this._scrollTop, i = this._getState();
                t !== this._scrollTop && (t <= this.visibleOffset ? this._showState("") : n ? this._showState("") : "top" !== i && t > this._topThreshold && this._showState("top")), 
                this._scrollTop = t;
            }
        },
        _onClick: function() {
            this._vScroll && (this._vScroll.jumpToIndex(0), this._showState(""));
        }
    };
    return t.prototype = i, t;
}), function(e) {
    var t = {
        setAriaSelected: function(e, t) {
            Array.prototype.forEach.call(t, function(t) {
                t.setAttribute("aria-selected", t === e ? "true" : "false");
            });
        }
    };
    e.AccessibilityHelper = t;
}(window), define("shared/js/accessibility_helper", function(e) {
    return function() {
        var t;
        return t || e.AccessibilityHelper;
    };
}(this)), define("message_display", [ "require", "l10n!" ], function(e) {
    var t = e("l10n!");
    return {
        subject: function(e, n) {
            var i = n.subject && n.subject.trim();
            i ? (e.textContent = i, e.classList.remove("msg-no-subject"), e.removeAttribute("data-l10n-id")) : (t.setAttributes(e, "message-no-subject"), 
            e.classList.add("msg-no-subject"));
        }
    };
}), define("template!cards/message_list.html", [ "template" ], function(e) {
    return {
        createdCallback: e.templateCreatedCallback,
        template: e.objToFn({
            id: "cards/message_list.html",
            deps: [],
            text: '<!-- Non-search header -->\n<section data-prop="normalHeader"\n         class="msg-list-header msg-nonsearch-only"\n         data-statuscolor="default"\n         role="region">\n  <header>\n    <a href="#" class="msg-folder-list-btn" data-event="click:onShowFolders">\n      <span class="icon icon-menu">menu</span>\n    </a>\n    <menu data-prop="headerMenuNode" type="toolbar" class="anim-opacity">\n      <a href="#" class="msg-compose-btn" data-event="click:onCompose">\n        <span class="icon icon-compose">compose</span>\n      </a>\n    </menu>\n    <h1 data-prop="folderLabel"\n        class="msg-list-header-folder-label header-label">\n      <span data-prop="folderNameNode"\n            dir="auto"\n            class="msg-list-header-folder-name"></span>\n      <span data-prop="folderUnread"\n            class="msg-list-header-folder-unread collapsed"></span>\n      </h1>\n  </header>\n</section>\n<!-- Multi-edit state header -->\n<section data-prop="editHeader"\n         class="msg-listedit-header collapsed" role="region">\n  <header>\n    <a href="#" data-event="click:setEditModeDone"\n       class="msg-listedit-cancel-btn">\n      <span class="icon icon-close"></span>\n    </a>\n    <h1 data-prop="headerNode" class="msg-listedit-header-label">\n    </h1>\n  </header>\n</section>\n<!-- Search header -->\n<section role="region" data-prop="searchHeader"\n         class="msg-search-header msg-search-only">\n  <form role="search" data-event="submit:onSearchSubmit">\n    <button data-event="click:onCancelSearch"\n            class="msg-search-cancel" type="submit"\n            data-l10n-id="message-search-cancel">Cancel</button>\n    <p>\n      <input data-prop="searchInput" data-event="input:onSearchTextChange"\n             type="text" required="required" class="msg-search-text"\n             autocorrect="off"\n             inputmode="verbatim"\n             x-inputmode="verbatim"\n             dir="auto"\n             data-l10n-id="message-search-input" />\n      <button type="reset" data-l10n-id="form-clear-input"></button>\n    </p>\n  </form>\n  <!-- Search filter switcher -->\n  <header class="msg-search-controls-bar">\n    <ul role="tablist" class="bb-tablist filter" data-type="filter">\n      <li role="presentation" class="msg-search-from msg-search-filter"\n          data-filter="author">\n        <a data-l10n-id="message-search-from" role="tab"\n          aria-selected="false">FroM</a></li>\n      <li role="presentation" class="msg-search-to msg-search-filter"\n          data-filter="recipients">\n        <a data-l10n-id="message-search-to" role="tab"\n          aria-selected="false">tO</a></li>\n      <li role="presentation" class="msg-search-subject msg-search-filter"\n           data-filter="subject">\n        <a data-l10n-id="message-search-subject" role="tab"\n          aria-selected="false">SubjecT</a>\n      </li>\n      <li role="presentation" class="msg-search-body msg-search-filter"\n           data-filter="body">\n        <a data-l10n-id="message-search-body" role="tab"\n          aria-selected="false">BodY</a></li>\n      <li role="presentation" class="msg-search-body msg-search-filter"\n          data-filter="all">\n        <a data-l10n-id="message-search-all" role="tab"\n          aria-selected="true">AlL</a></li>\n    </ul>\n  </header>\n</section>\n<!-- Scroll region -->\n<div data-prop="scrollContainer" class="msg-list-scrollouter">\n  <!-- exists so we can force a minimum height -->\n  <div class="msg-list-scrollinner">\n    <!-- The search textbox hides under the lip of the messages.\n         As soon as any typing happens in it, we push the search\n         controls card. -->\n    <form role="search" data-prop="searchBar"\n          class="msg-search-tease-bar msg-nonsearch-only">\n      <p>\n        <input data-event="focus:onSearchButton"\n               class="msg-search-text-tease" type="text"\n               dir="auto"\n               data-l10n-id="message-search-input" />\n      </p>\n    </form>\n    <div data-prop="messagesContainer" class="msg-messages-container">\n    </div>\n    <!-- maintain vertical space for the syncing/sync more div\'s\n         regardless of their displayed status so we don\'t scroll them\n         out of the way -->\n    <div class="msg-messages-sync-container">\n      <p data-prop="syncingNode" class="msg-messages-syncing collapsed">\n        <span data-l10n-id="messages-syncing">Message loadinG</span>\n      </p>\n      <p data-prop="syncMoreNode"\n         data-event="click:onGetMoreMessages"\n         class="msg-messages-sync-more collapsed">\n        <span data-l10n-id="messages-load-more">LoaD MorE</span>\n      </p>\n    </div>\n  </div>\n</div>\n<!-- New email notification bar -->\n<div class="message-list-topbar"></div>\n<!-- Conveys background send, plus undo-able recent actions -->\n<div class="msg-activity-infobar hidden">\n</div>\n<!-- Toolbar for non-multi-edit state -->\n<ul data-prop="normalToolbar" class="bb-tablist msg-list-action-toolbar">\n  <li role="presentation" class="msg-nonsearch-only">\n    <button data-prop="refreshBtn" data-event="click:onRefresh"\n            class="icon msg-refresh-btn" data-state="synchronized"></button>\n  </li>\n  <li role="presentation" class="msg-nonsearch-only msg-last-sync">\n    <span data-prop="lastSyncedLabel"\n          class="msg-last-synced-label"\n          data-l10n-id="folder-last-synced-label"></span>\n    <span data-prop="lastSyncedAtNode"\n          class="msg-last-synced-value"></span>\n  </li>\n  <li role="presentation">\n    <button data-prop="editBtn" data-event="click:setEditModeStart"\n            class="icon msg-edit-btn"></button>\n  </li>\n</ul>\n\n<!-- Toolbar for multi-edit state -->\n<ul data-prop="editToolbar"\n    class="bb-tablist msg-listedit-action-toolbar collapsed">\n  <li role="presentation">\n    <button data-prop="deleteBtn" data-event="click:onDeleteMessages"\n            class="icon msg-delete-btn"></button>\n  </li>\n  <li role="presentation">\n    <button data-prop="starBtn" data-event="click:onStarMessages"\n            class="icon msg-star-btn"></button>\n  </li>\n  <li role="presentation">\n    <button data-prop="readBtn" data-event="click:onMarkMessagesRead"\n            class="icon msg-mark-read-btn"></button>\n  </li>\n  <li role="presentation">\n    <button data-prop="moveBtn" data-event="click:onMoveMessages"\n            class="icon msg-move-btn"></button>\n  </li>\n</ul>\n\n<div data-prop="messageEmptyContainer"\n     class="msg-list-empty-container collapsed">\n  <p data-prop="messageEmptyText"\n     class="msg-list-empty-message-text"\n     data-l10n-id="messages-folder-empty">No messagE</p>\n</div>\n'
        })
    };
}), define("cards/message_list", [ "require", "tmpl!./msg/header_item.html", "tmpl!./msg/delete_confirm.html", "tmpl!./msg/large_message_confirm.html", "cards", "confirm_dialog", "date", "evt", "toaster", "model", "header_cursor", "html_cache", "l10n!", "vscroll", "message_list_topbar", "shared/js/accessibility_helper", "message_display", "./base", "template!./message_list.html" ], function(e) {
    function t(e, t) {
        for (var n = e.text, i = 0, s = 0; s <= e.matchRuns.length; s++) {
            var o;
            if (o = s === e.matchRuns.length ? {
                start: n.length,
                length: 0
            } : e.matchRuns[s], o.start > i) {
                var a = document.createTextNode(n.substring(i, o.start));
                t.appendChild(a);
            }
            if (o.length) {
                var r = document.createElement("span");
                r.classList.add(_), r.textContent = n.substr(o.start, o.length), t.appendChild(r), 
                i = o.start + o.length;
            }
        }
    }
    var n = e("tmpl!./msg/header_item.html"), i = e("tmpl!./msg/delete_confirm.html"), s = e("tmpl!./msg/large_message_confirm.html"), o = e("cards"), a = e("confirm_dialog"), r = e("date"), c = e("evt"), l = e("toaster"), d = e("model"), u = e("header_cursor").cursor, h = e("html_cache"), p = e("l10n!"), f = e("vscroll"), m = e("message_list_topbar"), g = e("shared/js/accessibility_helper"), v = e("message_display"), _ = "highlight", y = {
        isPlaceholderData: !0,
        id: "INVALID",
        author: {
            name: "▃▃▃▃▃▃▃▃",
            address: "",
            contactId: null
        },
        to: [ {
            name: " ",
            address: " ",
            contactId: null
        } ],
        cc: null,
        bcc: null,
        date: "0",
        hasAttachments: !1,
        snippet: "▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃",
        isRead: !0,
        isStarred: !1,
        sendStatus: {},
        subject: "▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃"
    }, b = {
        header: y,
        matches: []
    }, x = 10, S = 6e3, w = 4096;
    return [ e("./base")(e("template!./message_list.html")), {
        createdCallback: function() {
            var e = this.mode;
            "nonsearch" === e ? this.batchAddClass("msg-search-only", "collapsed") : (this.batchAddClass("msg-nonsearch-only", "collapsed"), 
            this.dataset.statuscolor = "background"), this.bindContainerHandler(this.messagesContainer, "click", this.onClickMessage.bind(this)), 
            this._needsSizeLastSync = !0, this.updateLastSynced(), "search" === e && (this.bindContainerHandler(this.querySelector(".filter"), "click", this.onSearchFilterClick.bind(this)), 
            this.searchFilterTabs = this.querySelectorAll('.filter [role="tab"]')), this.editMode = !1, 
            this.selectedMessages = null, this.curFolder = null, this.isIncomingFolder = !0, 
            this._emittedContentEvents = !1, this.usingCachedNode = "cached" === this.dataset.cached;
            var t = function(e) {
                return u.messagesSlice.items[e];
            }.bind(this);
            if (t.size = function() {
                var e = u.messagesSlice;
                return Math.max(e.headerCount || 0, e.items.length);
            }, this.listFunc = t, this.waitingOnChunk = !0, this.desiredHighAbsoluteIndex = 0, 
            this._needVScrollData = !1, this.vScroll = new f(this.messagesContainer, this.scrollContainer, n, "nonsearch" === this.mode ? y : b), 
            this.vScroll.bindData = "nonsearch" === this.mode ? function(e, t) {
                e.element = t, t.message = e, this.updateMessageDom(!0, e);
            }.bind(this) : function(e, t) {
                e.element = t, t.message = e.header, this.updateMatchedMessageDom(!0, e);
            }.bind(this), this.vScroll.prepareData = function(e) {
                var t = u.messagesSlice && u.messagesSlice.items, n = u.messagesSlice.headerCount;
                t && n && (e > n - 1 && (e = n - 1), e < t.length || this.loadNextChunk(e));
            }.bind(this), this._hideSearchBoxByScrolling = this._hideSearchBoxByScrolling.bind(this), 
            this._onVScrollStopped = this._onVScrollStopped.bind(this), this.vScroll.on("inited", this._hideSearchBoxByScrolling), 
            this.vScroll.on("dataChanged", this._hideSearchBoxByScrolling), this.vScroll.on("scrollStopped", this._onVScrollStopped), 
            this.vScroll.on("recalculated", function(e) {
                e && this._hideSearchBoxByScrolling();
            }.bind(this)), this._topBar = new m(this.querySelector(".message-list-topbar")), 
            this._topBar.bindToElements(this.scrollContainer, this.vScroll), this._folderChanged = this._folderChanged.bind(this), 
            this.onNewMail = this.onNewMail.bind(this), this.onFoldersSliceChange = this.onFoldersSliceChange.bind(this), 
            this.messages_splice = this.messages_splice.bind(this), this.messages_change = this.messages_change.bind(this), 
            this.messages_status = this.messages_status.bind(this), this.messages_complete = this.messages_complete.bind(this), 
            this.onFolderPickerClosing = this.onFolderPickerClosing.bind(this), c.on("folderPickerClosing", this.onFolderPickerClosing), 
            d.latest("folder", this._folderChanged), d.on("newInboxMessages", this.onNewMail), 
            d.on("backgroundSendStatus", this.onBackgroundSendStatus.bind(this)), d.on("foldersSliceOnChange", this.onFoldersSliceChange), 
            this.sliceEvents.forEach(function(e) {
                var t = "messages_" + e;
                u.on(t, this[t]);
            }.bind(this)), this.onCurrentMessage = this.onCurrentMessage.bind(this), u.on("currentMessage", this.onCurrentMessage), 
            this.curFolder && "nonsearch" === this.mode) {
                var i = u.messagesSlice && u.messagesSlice.items;
                i && i.length && (this.messages_splice(0, 0, i), this.messages_complete(0));
            }
        },
        mode: "nonsearch",
        _topBar: null,
        _distanceBetweenMessages: 0,
        sliceEvents: [ "splice", "change", "status", "complete" ],
        toolbarEditButtonNames: [ "starBtn", "readBtn", "deleteBtn", "moveBtn" ],
        skipEmitContentEvents: !0,
        postInsert: function() {
            this._hideSearchBoxByScrolling(), this.vScroll.visibleOffset = this.searchBar.getBoundingClientRect().height, 
            this._topBar.visibleOffset = this.vScroll.visibleOffset, this.vScroll.captureScreenMetrics(), 
            "search" === this.mode && this.searchInput.focus();
        },
        onSearchButton: function() {
            this.curFolder && o.pushCard("message_list_search", "animate", {
                folder: this.curFolder
            });
        },
        setEditMode: function(e) {
            if (this.curFolder) if ("outbox" === this.curFolder.type) {
                if (e && this.outboxSyncInProgress) return;
                d.api.setOutboxSyncEnabled(d.account, !e, function() {
                    this._setEditMode(e);
                }.bind(this));
            } else this._setEditMode(e);
        },
        _setEditMode: function(e) {
            var t;
            if (this.editMode = e, e) {
                this.normalHeader.classList.add("collapsed"), this.searchHeader.classList.add("collapsed"), 
                this.normalToolbar.classList.add("collapsed"), this.editHeader.classList.remove("collapsed"), 
                this.editToolbar.classList.remove("collapsed"), this.messagesContainer.classList.add("show-edit"), 
                this.selectedMessages = [];
                var n = this.messagesContainer.querySelectorAll("input[type=checkbox]");
                for (t = 0; t < n.length; t++) n[t].checked = !1;
                this.selectedMessagesUpdated();
            } else {
                "nonsearch" === this.mode ? this.normalHeader.classList.remove("collapsed") : this.searchHeader.classList.remove("collapsed"), 
                this.normalToolbar.classList.remove("collapsed"), this.editHeader.classList.add("collapsed"), 
                this.editToolbar.classList.add("collapsed"), this.messagesContainer.classList.remove("show-edit");
                var i = this.getElementsByClassName("msg-header-item-selected");
                for (t = i.length - 1; t >= 0; t--) i[t].classList.remove("msg-header-item-selected");
                this.selectedMessages = null;
            }
        },
        setEditModeStart: function() {
            this.setEditMode(!0);
        },
        setEditModeDone: function() {
            this.setEditMode(!1);
        },
        selectedMessagesUpdated: function() {
            p.setAttributes(this.headerNode, "message-multiedit-header", {
                n: this.selectedMessages.length
            });
            for (var e = !!this.selectedMessages.length, t = 0, n = 0, i = 0; i < this.selectedMessages.length; i++) {
                var s = this.selectedMessages[i];
                s.isStarred && t++, s.isRead && n++;
            }
            this.setAsStarred = !(t && t === this.selectedMessages.length), this.setAsRead = e && 0 === n, 
            this.readBtn.classList.toggle("unread", n > 0), this.toolbarEditButtonNames.forEach(function(t) {
                this[t].disabled = !e;
            }.bind(this));
        },
        _hideSearchBoxByScrolling: function() {
            var e = this.searchBar, t = this.scrollContainer;
            e.classList.contains("collapsed") && (e.classList.remove("collapsed"), t.scrollTop += e.offsetHeight), 
            0 === t.scrollTop && (t.scrollTop = e.offsetHeight);
        },
        onShowFolders: function() {
            o.pushCard("folder_picker", "immediate", {
                onPushed: function() {
                    this.headerMenuNode.classList.add("transparent");
                }.bind(this)
            });
        },
        onCompose: function() {
            o.pushCard("compose", "animate");
        },
        sizeLastSync: function() {
            if (this._needsSizeLastSync && this.lastSyncedLabel.scrollWidth) {
                var e = this.lastSyncedLabel, t = e.scrollWidth > e.parentNode.clientWidth / 2;
                e.parentNode.classList[t ? "add" : "remove"]("long"), this._needsSizeLastSync = !1;
            }
        },
        updateLastSynced: function(e) {
            var t = e ? "remove" : "add";
            this.lastSyncedLabel.classList[t]("collapsed"), r.setPrettyNodeDate(this.lastSyncedAtNode, e), 
            this.sizeLastSync();
        },
        updateUnread: function(e) {
            var t = "";
            e > 0 && (t = e > 999 ? p.get("messages-folder-unread-max") : e), this.folderUnread.textContent = t, 
            this.folderUnread.classList.toggle("collapsed", !t), this.callHeaderFontSize();
        },
        onFoldersSliceChange: function(e) {
            e === this.curFolder && (this.updateUnread(e.unread), this.updateLastSynced(e.lastSyncedAt));
        },
        callHeaderFontSize: function() {
            requestAnimationFrame(function() {
                FontSizeUtils._reformatHeaderText(this.folderLabel);
            }.bind(this));
        },
        showFolder: function(e, t) {
            if (e === this.curFolder && !t) return !1;
            switch (this.usingCachedNode || this.vScroll.clearDisplay(), this._needVScrollData = !0, 
            this.curFolder = e, e.type) {
              case "drafts":
              case "localdrafts":
              case "outbox":
              case "sent":
                this.isIncomingFolder = !1;
                break;

              default:
                this.isIncomingFolder = !0;
            }
            return this.folderNameNode.textContent = e.name, this.updateUnread(e.unread), this.hideEmptyLayout(), 
            this.refreshBtn.classList.toggle("collapsed", "localdrafts" === e.type), this.moveBtn.classList.toggle("collapsed", "localdrafts" === e.type || "outbox" === e.type), 
            this.starBtn.classList.toggle("collapsed", "outbox" === e.type), this.readBtn.classList.toggle("collapsed", "outbox" === e.type), 
            this.updateLastSynced(e.lastSyncedAt), t && (this._snippetRequestPending = !1, u.freshMessagesSlice()), 
            this.onFolderShown(), !0;
        },
        showSearch: function(e, t) {
            return console.log("sf: showSearch. phrase:", e, e.length), this.curFolder = d.folder, 
            this.vScroll.clearDisplay(), this.curPhrase = e, this.curFilter = t, e.length < 1 ? (this.showEmptyLayout(), 
            !1) : (this._snippetRequestPending = !1, this.waitingOnChunk = !0, u.startSearch(e, {
                author: "all" === t || "author" === t,
                recipients: "all" === t || "recipients" === t,
                subject: "all" === t || "subject" === t,
                body: "all" === t || "body" === t
            }), !0);
        },
        onSearchFilterClick: function(e) {
            g.setAriaSelected(e.firstElementChild, this.searchFilterTabs), this.showSearch(this.searchInput.value, e.dataset.filter);
        },
        onSearchTextChange: function() {
            console.log("sf: typed, now:", this.searchInput.value), this.showSearch(this.searchInput.value, this.curFilter);
        },
        onSearchSubmit: function(e) {
            e.preventDefault(), this.searchInput.blur();
        },
        onCancelSearch: function(e) {
            if (e.explicitOriginalTarget === e.target) {
                try {
                    u.endSearch();
                } catch (t) {
                    console.error("problem killing slice:", t, "\n", t.stack);
                }
                o.removeCardAndSuccessors(this, "animate");
            }
        },
        onGetMoreMessages: function() {
            u.messagesSlice && u.messagesSlice.requestGrowth(1, !0);
        },
        messages_status: function(e) {
            u.searchMode === this.mode && "outbox" !== this.curFolder.type && ("synchronizing" === e || "syncblocked" === e ? (this.syncingNode.classList.remove("collapsed"), 
            this.syncMoreNode.classList.add("collapsed"), this.hideEmptyLayout(), this.refreshBtn.dataset.state = "synchronizing") : ("syncfailed" === e || "synced" === e) && ("syncfailed" === e && l.toast({
                text: p.get("toaster-retryable-syncfailed")
            }), this.refreshBtn.dataset.state = "synchronized", this.syncingNode.classList.add("collapsed"), 
            this._manuallyTriggeredSync = !1));
        },
        isEmpty: function() {
            return 0 === u.messagesSlice.items.length;
        },
        showEmptyLayout: function() {
            this._clearCachedMessages(), p.setAttributes(this.messageEmptyText, "search" === this.mode ? "messages-search-empty" : "messages-folder-empty"), 
            this.messageEmptyContainer.classList.remove("collapsed"), this.editBtn.disabled = !0, 
            "outbox" === this.curFolder.type && (this.refreshBtn.disabled = !0), this._hideSearchBoxByScrolling();
        },
        hideEmptyLayout: function() {
            this.messageEmptyContainer.classList.add("collapsed"), this.editBtn.disabled = !1, 
            this.refreshBtn.disabled = !1;
        },
        messages_complete: function(e) {
            u.searchMode === this.mode && (console.log("message_list complete:", u.messagesSlice.items.length, "items of", u.messagesSlice.headerCount, "alleged known headers. canGrow:", u.messagesSlice.userCanGrowDownwards), 
            u.messagesSlice.userCanGrowDownwards && u.messagesSlice.headerCount ? this.syncMoreNode.classList.remove("collapsed") : this.syncMoreNode.classList.add("collapsed"), 
            0 === u.messagesSlice.items.length && this.showEmptyLayout(), "search" !== this.mode || this.vScroll.list || this.vScroll.setData(this.listFunc), 
            this.onNewMail(e), this.waitingOnChunk = !1, this.desiredHighAbsoluteIndex && (this.loadNextChunk(this.desiredHighAbsoluteIndex), 
            this.desiredHighAbsoluteIndex = 0), this.vScroll.updateDataBind(0, [], 0), this._emittedContentEvents || (c.emit("metrics:contentDone"), 
            this._emittedContentEvents = !0));
        },
        onNewMail: function(e) {
            var t = d.foldersSlice.getFirstFolderWithType("inbox");
            if (t.id === this.curFolder.id && e && e > 0) {
                if (!o.isVisible(this)) return this._whenVisible = this.onNewMail.bind(this, e), 
                void 0;
                this._manuallyTriggeredSync ? this.vScroll.jumpToIndex(0) : this._topBar.showNewEmailCount(e);
            }
        },
        onBackgroundSendStatus: function(e) {
            "outbox" === this.curFolder.type && ("sending" === e.state ? this.toggleOutboxSyncingDisplay(!0) : "syncDone" === e.state && this.toggleOutboxSyncingDisplay(!1)), 
            e.emitNotifications && l.toast({
                text: e.localizedDescription
            });
        },
        _onVScrollStopped: function() {
            u.messagesSlice && !u.messagesSlice.pendingRequestCount && o.isVisible(this) && !this._hasSnippetRequest() && this._requestSnippets();
        },
        _hasSnippetRequest: function() {
            var e = S, t = Date.now(), n = this._lastSnippetRequest + e > t;
            return this._snippetRequestPending && n ? !0 : !1;
        },
        _pendingSnippetRequest: function() {
            this._snippetRequestPending = !0, this._lastSnippetRequest = Date.now();
        },
        _clearSnippetRequest: function() {
            this._snippetRequestPending = !1;
        },
        _requestSnippets: function() {
            var e = u.messagesSlice.items, t = e.length;
            if (t) {
                var n = this._clearSnippetRequest.bind(this), i = {
                    maximumBytesToFetch: w
                };
                if (x > t) return this._pendingSnippetRequest(), u.messagesSlice.maybeRequestBodies(0, x - 1, i, n), 
                void 0;
                var s = this.vScroll.getVisibleIndexRange();
                s && (this._pendingSnippetRequest(), u.messagesSlice.maybeRequestBodies(s[0], s[1], i, n));
            }
        },
        _cacheListLimit: 7,
        _cacheDomTimeoutId: 0,
        _isCacheableCardState: function() {
            return this.cacheableFolderId === this.curFolder.id && "nonsearch" === this.mode && !this.editMode;
        },
        _cacheDom: function() {
            if (this._cacheDomTimeoutId = 0, this._isCacheableCardState()) {
                var e = h.cloneAsInertNodeAvoidingCustomElementHorrors(this);
                e.dataset.cached = "cached", e.querySelector('menu[type="toolbar"]').classList.remove("transparent");
                var t = e.querySelector(".msg-search-tease-bar");
                t && t.classList.add("collapsed"), t = e.querySelector(".message-list-topbar"), 
                t && this._topBar.resetNodeForCache(t);
                var n = e.querySelector(".msg-last-synced-label");
                n && n.classList.add("collapsed"), n = e.querySelector(".msg-last-synced-value"), 
                n && (n.innerHTML = ""), f.trimMessagesForCache(e.querySelector(".msg-messages-container"), this._cacheListLimit), 
                h.saveFromNode(e);
            }
        },
        _considerCacheDom: function(e) {
            !this._cacheDomTimeoutId && this._isCacheableCardState() && 0 === this.vScroll.firstRenderedIndex && (e || 0 === e) && e < this._cacheListLimit && (this._cacheDomTimeoutId = setTimeout(this._cacheDom.bind(this), 600));
        },
        _clearCachedMessages: function() {
            this.usingCachedNode && (this.messagesContainer.innerHTML = "", this.usingCachedNode = !1);
        },
        loadNextChunk: function(e) {
            if (!this.vScroll.waitingForRecalculate) {
                if (this.waitingOnChunk) return this.desiredHighAbsoluteIndex = e, void 0;
                e >= u.messagesSlice.headerCount && (e = u.messagesSlice.headerCount - 1);
                var t = u.messagesSlice.items, n = t.length - 1, i = e - n;
                i > 0 && (console.log("message_list loadNextChunk growing", i, 1 === i ? "(will get boosted to 15!) to" : "to", e + 1, "items out of", u.messagesSlice.headerCount, "alleged known"), 
                u.messagesSlice.requestGrowth(i, !1), this.waitingOnChunk = !0);
            }
        },
        messages_splice: function(e, t, n) {
            u.searchMode !== this.mode || 0 === e && 0 === t && !n.length || (this._clearCachedMessages(), 
            this._needVScrollData && (this.vScroll.setData(this.listFunc), this._needVScrollData = !1), 
            this.vScroll.updateDataBind(e, n, t), n.length > 0 && this.hideEmptyLayout(), u.messagesSlice.headerCount || this.vScroll.once("scrollStopped", function() {
                u.messagesSlice.headerCount || this.showEmptyLayout();
            }.bind(this)), (n.length || t) && this._considerCacheDom(e));
        },
        messages_change: function(e, t) {
            u.searchMode === this.mode && ("nonsearch" === this.mode ? this.onMessagesChange(e, t) : this.updateMatchedMessageDom(!1, e));
        },
        onMessagesChange: function(e, t) {
            this.updateMessageDom(!1, e), this._considerCacheDom(t);
        },
        _updatePeepDom: function(e) {
            e.element.textContent = e.name || e.address;
        },
        updateMessageDom: function(e, t) {
            var n = t.element;
            if (n) {
                var i = t.isPlaceholderData ? "add" : "remove";
                n.classList[i](this.vScroll.itemDefaultDataClass), n.dataset.id = t.id;
                var s = n.querySelector(".msg-header-date"), o = n.querySelector(".msg-header-subject"), a = n.querySelector(".msg-header-snippet");
                if (e) {
                    var c;
                    c = this.isIncomingFolder ? t.author : t.to && t.to.length ? t.to[0] : t.cc && t.cc.length ? t.cc[0] : t.bcc && t.bcc.length ? t.bcc[0] : t.author, 
                    c.element = n.querySelector(".msg-header-author"), c.onchange = this._updatePeepDom, 
                    c.onchange(c);
                    var l = t.date.valueOf();
                    s.dataset.time = l, s.textContent = l ? r.prettyDate(t.date) : "", v.subject(n.querySelector(".msg-header-subject"), t);
                    var d = n.querySelector(".msg-header-attachments");
                    d.classList.toggle("msg-header-attachments-yes", t.hasAttachments), a.classList.toggle("icon-short", t.hasAttachments);
                }
                a.textContent = t.snippet, n.classList.toggle("unread", !t.isRead);
                var u = n.querySelector(".msg-header-star");
                u.classList.toggle("msg-header-star-starred", t.isStarred), o.classList.toggle("icon-short", t.isStarred);
                var h = n.querySelector(".msg-header-syncing-section"), p = t.sendStatus && t.sendStatus.state;
                if (h.classList.toggle("msg-header-syncing-section-syncing", "sending" === p), h.classList.toggle("msg-header-syncing-section-error", "error" === p), 
                this.editMode) {
                    var f = n.querySelector("input[type=checkbox]");
                    f.checked = -1 !== this.selectedMessages.indexOf(t);
                }
            }
        },
        updateMatchedMessageDom: function(e, n) {
            var i = n.element, s = n.matches, o = n.header;
            if (i) {
                var a = o.isPlaceholderData ? "add" : "remove";
                i.classList[a](this.vScroll.itemDefaultDataClass), i.dataset.id = n.id;
                var c = i.querySelector(".msg-header-date"), l = i.querySelector(".msg-header-subject");
                if (e) {
                    var d = i.querySelector(".msg-header-author");
                    s.author ? (d.textContent = "", t(s.author, d)) : (o.author.element = d, o.author.onchange = this._updatePeepDom, 
                    o.author.onchange(o.author)), c.dataset.time = o.date.valueOf(), c.textContent = r.prettyDate(o.date), 
                    s.subject ? (l.textContent = "", t(s.subject[0], l)) : v.subject(l, o);
                    var u = i.querySelector(".msg-header-snippet");
                    s.body ? (u.textContent = "", t(s.body[0], u)) : u.textContent = o.snippet;
                    var h = i.querySelector(".msg-header-attachments");
                    h.classList.toggle("msg-header-attachments-yes", o.hasAttachments), u.classList.toggle("icon-short", o.hasAttachments);
                }
                var p = i.querySelector(".msg-header-unread-section");
                p.classList.toggle("msg-header-unread-section-unread", !o.isRead), c.classList.toggle("msg-header-date-unread", !o.isRead);
                var f = i.querySelector(".msg-header-star");
                if (f.classList.toggle("msg-header-star-starred", o.isStarred), l.classList.toggle("icon-short", o.isStarred), 
                this.editMode) {
                    var m = i.querySelector("input[type=checkbox]");
                    m.checked = -1 !== this.selectedMessages.indexOf(o);
                }
            }
        },
        onFolderPickerClosing: function() {
            this.headerMenuNode.classList.remove("transparent");
        },
        onFolderShown: function() {
            if ("search" !== this.mode) {
                var e = d.account, t = d.foldersSlice;
                if (!document.hidden && e && t && this.curFolder) {
                    var n = t.getFirstFolderWithType("inbox");
                    n === this.curFolder && c.emit("inboxShown", e.id);
                }
            }
        },
        onCurrentCardDocumentVisibilityChange: function() {
            this.onFolderShown();
        },
        onCardVisible: function() {
            if (this._whenVisible) {
                var e = this._whenVisible;
                this._whenVisible = null, e();
            }
            this.vScroll.nowVisible(), this.sizeLastSync();
        },
        onClickMessage: function(e) {
            function t() {
                o.pushCard("message_reader", "animate", {
                    header: n,
                    messageSuid: e.dataset.id
                });
            }
            if (!this.curFolder || "outbox" !== this.curFolder.type || !this.outboxSyncInProgress) {
                var n = e.message;
                if (!n || !n.isPlaceholderData) {
                    if (this.editMode) {
                        var i = this.selectedMessages.indexOf(n), s = e.querySelector("input[type=checkbox]");
                        return -1 !== i ? (this.selectedMessages.splice(i, 1), s.checked = !1) : (this.selectedMessages.push(n), 
                        s.checked = !0), this.selectedMessagesUpdated(), void 0;
                    }
                    if (this.curFolder && "localdrafts" === this.curFolder.type) var a = n.editAsDraft(function() {
                        o.pushCard("compose", "animate", {
                            composer: a
                        });
                    }); else {
                        if (this.curFolder && "outbox" === this.curFolder.type) {
                            if ("sending" === n.sendStatus.state) return;
                            var r = d.foldersSlice.getFirstFolderWithType("localdrafts");
                            return console.log("outbox: Moving message to localdrafts."), d.api.moveMessages([ n ], r, function(e) {
                                n.id = e[n.id], console.log("outbox: Editing message in localdrafts.");
                                var t = n.editAsDraft(function() {
                                    o.pushCard("compose", "animate", {
                                        composer: t
                                    });
                                });
                            }), void 0;
                        }
                        if (n) u.setCurrentMessage(n); else {
                            if (!e.dataset.id) return;
                            u.setCurrentMessageBySuid(e.dataset.id);
                        }
                        var c = 1048576;
                        n && n.bytesToDownloadForBodyDisplay > c ? this.showLargeMessageWarning(n.bytesToDownloadForBodyDisplay, function(e) {
                            e && t();
                        }) : t();
                    }
                }
            }
        },
        onCurrentMessage: function(e, t) {
            if (e && u.searchMode === this.mode) {
                var n = this.vScroll.getVisibleIndexRange();
                n && (t < n[0] || t > n[1]) && this.vScroll.jumpToIndex(t);
            }
        },
        onHoldMessage: function() {
            this.curFolder && this.setEditMode(!0);
        },
        toggleOutboxSyncingDisplay: function(e) {
            if (e !== this._outboxSyncing) {
                this._outboxSyncing = e;
                var t, n = this.messagesContainer.getElementsByClassName("msg-header-syncing-section");
                if (e) {
                    for (t = 0; t < n.length; t++) n[t].classList.add("msg-header-syncing-section-syncing"), 
                    n[t].classList.remove("msg-header-syncing-section-error");
                    this.editBtn.disabled = !0, this.refreshBtn.dataset.state = "synchronizing";
                } else for (this.editBtn.disabled = this.isEmpty(), this.refreshBtn.dataset.state = "synchronized", 
                t = 0; t < n.length; t++) n[t].classList.remove("msg-header-syncing-section-syncing");
            }
        },
        onRefresh: function() {
            if (u.messagesSlice) {
                if ("outbox" === this.curFolder.type) this.toggleOutboxSyncingDisplay(!0); else switch (u.messagesSlice.status) {
                  case "new":
                  case "synchronizing":
                    break;

                  case "synced":
                    this._manuallyTriggeredSync = !0, u.messagesSlice.refresh();
                    break;

                  case "syncfailed":
                    u.messagesSlice.items.length ? u.messagesSlice.refresh() : this.showFolder(this.curFolder, !0);
                }
                d.api.sendOutboxMessages(d.account);
            }
        },
        onStarMessages: function() {
            var e = d.api.markMessagesStarred(this.selectedMessages, this.setAsStarred);
            this.setEditMode(!1), l.toastOperation(e);
        },
        onMarkMessagesRead: function() {
            var e = d.api.markMessagesRead(this.selectedMessages, this.setAsRead);
            this.setEditMode(!1), l.toastOperation(e);
        },
        onDeleteMessages: function() {
            if (0 === this.selectedMessages.length) return this.setEditMode(!1);
            var e = i.cloneNode(!0), t = e.getElementsByTagName("p")[0];
            p.setAttributes(t, "message-multiedit-delete-confirm", {
                n: this.selectedMessages.length
            }), a.show(e, {
                id: "msg-delete-ok",
                handler: function() {
                    var e = d.api.deleteMessages(this.selectedMessages);
                    l.toastOperation(e), this.setEditMode(!1);
                }.bind(this)
            }, {
                id: "msg-delete-cancel",
                handler: null
            });
        },
        showLargeMessageWarning: function(e, t) {
            var n = s.cloneNode(!0);
            a.show(n, {
                id: "msg-large-message-ok",
                handler: function() {
                    t(!0);
                }
            }, {
                id: "msg-large-message-cancel",
                handler: function() {
                    t(!1);
                }
            });
        },
        onMoveMessages: function() {
            o.folderSelector(function(e) {
                var t = d.api.moveMessages(this.selectedMessages, e);
                l.toastOperation(t), this.setEditMode(!1);
            }.bind(this), function(e) {
                return e.isValidMoveTarget;
            });
        },
        _folderChanged: function(e) {
            if (d.foldersSlice) {
                var t = d.foldersSlice.getFirstFolderWithType("inbox");
                this.cacheableFolderId = d.account === d.acctsSlice.defaultAccount ? t.id : null, 
                this.folder = e, "nonsearch" == this.mode ? this.showFolder(e) && this._hideSearchBoxByScrolling() : this.showSearch("", "all");
            }
        },
        die: function() {
            this.sliceEvents.forEach(function(e) {
                var t = "messages_" + e;
                u.removeListener(t, this[t]);
            }.bind(this)), c.removeListener("folderPickerClosing", this.onFolderPickerClosing), 
            d.removeListener("folder", this._folderChanged), d.removeListener("newInboxMessages", this.onNewMail), 
            d.removeListener("foldersSliceOnChange", this.onFoldersSliceChange), u.removeListener("currentMessage", this.onCurrentMessage), 
            this.vScroll.destroy();
        }
    } ];
}), "undefined" == typeof TestUrlResolver && requirejs.config({
    waitSeconds: 0,
    baseUrl: "js",
    paths: {
        l10nbase: "../shared/js/l10n",
        l10ndate: "../shared/js/l10n_date",
        style: "../style",
        shared: "../shared"
    },
    map: {
        "*": {
            api: "ext/main-frame-setup"
        }
    },
    shim: {
        l10ndate: [ "l10nbase" ],
        "shared/js/mime_mapper": {
            exports: "MimeMapper"
        },
        "shared/js/notification_helper": {
            exports: "NotificationHelper"
        },
        "shared/js/accessibility_helper": {
            exports: "AccessibilityHelper"
        }
    },
    definePrim: "prim"
}), navigator.mozAudioChannelManager && (navigator.mozAudioChannelManager.volumeControlChannel = "notification"), 
define("mail_app", [ "require", "exports", "module", "app_messages", "html_cache", "l10n!", "cards", "confirm_dialog", "evt", "model", "header_cursor", "shared/js/font_size_utils", "metrics", "sync", "wake_locks" ], function(e) {
    function t(e) {
        return "setup_account_info" === e ? [ "setup_account_info", "immediate", {
            onPushed: function(e) {
                var t = u.cloneAsInertNodeAvoidingCustomElementHorrors(e);
                t.dataset.cached = "cached", u.delayedSaveFromNode(t);
            }
        } ] : "message_list" === e ? [ "message_list", "immediate", {} ] : void 0;
    }
    function n(e, n) {
        var i = t(e);
        if (!i) throw new Error("Invalid start card: " + e);
        return i[2].cachedNode = T, n && Object.keys(n).forEach(function(e) {
            i[2][e] = n[e];
        }), p.pushCard.apply(p, i);
    }
    function i(e, i) {
        T = null;
        var s = t(e), o = s[0];
        p.hasCard(o) || (p.removeAllCards(), n(e, i));
    }
    function s() {
        var e = p.getCurrentCardType();
        return e && "message_list" === e;
    }
    function o(e) {
        w && document.hidden ? x = e : e();
    }
    function a(e) {
        o(function() {
            i("message_list", e);
        });
    }
    function r() {
        S = !1, y = !1, b = null, p.removeAllCards(), g.init();
    }
    function c() {
        if (b) {
            var e = b;
            return b = null, e(), !0;
        }
        return !1;
    }
    function l(e) {
        return function() {
            var t = Date.now();
            return E + 1e3 > t ? (console.log("email entry gate blocked fast repeated action"), 
            void 0) : (E = t, e.apply(null, _.call(arguments)));
        };
    }
    var d = e("app_messages"), u = e("html_cache"), h = e("l10n!"), p = e("cards"), f = e("confirm_dialog"), m = e("evt"), g = e("model"), v = e("header_cursor").cursor, _ = Array.prototype.slice, y = !1, b = null;
    e("shared/js/font_size_utils"), e("metrics"), e("sync"), e("wake_locks"), g.latestOnce("api", function(e) {
        e.onbadlogin = function(e, t, n) {
            switch (t) {
              case "bad-user-or-pass":
                p.pushCard("setup_fix_password", "animate", {
                    account: e,
                    whichSide: n,
                    restoreCard: p.activeCardIndex
                }, "right");
                break;

              case "imap-disabled":
              case "pop3-disabled":
                p.pushCard("setup_fix_gmail", "animate", {
                    account: e,
                    restoreCard: p.activeCardIndex
                }, "right");
                break;

              case "needs-app-pass":
                p.pushCard("setup_fix_gmail_twofactor", "animate", {
                    account: e,
                    restoreCard: p.activeCardIndex
                }, "right");
                break;

              case "needs-oauth-reauth":
                p.pushCard("setup_fix_oauth2", "animate", {
                    account: e,
                    restoreCard: p.activeCardIndex
                }, "right");
            }
        }, e.useLocalizedStrings({
            wrote: h.get("reply-quoting-wrote"),
            originalMessage: h.get("forward-original-message"),
            forwardHeaderLabels: {
                subject: h.get("forward-header-subject"),
                date: h.get("forward-header-date"),
                from: h.get("forward-header-from"),
                replyTo: h.get("forward-header-reply-to"),
                to: h.get("forward-header-to"),
                cc: h.get("forward-header-cc")
            },
            folderNames: {
                inbox: h.get("folder-inbox"),
                outbox: h.get("folder-outbox"),
                sent: h.get("folder-sent"),
                drafts: h.get("folder-drafts"),
                trash: h.get("folder-trash"),
                queue: h.get("folder-queue"),
                junk: h.get("folder-junk"),
                archives: h.get("folder-archives"),
                localdrafts: h.get("folder-localdrafts")
            }
        });
    }), p.pushDefaultCard = function(e) {
        g.latestOnce("foldersSlice", function() {
            p.pushCard("message_list", "none", {
                onPushed: e
            }, "left");
        });
    }, p._init();
    var x, S = !1, w = !1, T = p._cardsNode.children[0], C = T && T.getAttribute("data-type");
    (d.hasPending("activity") || d.hasPending("notification")) && (T = null, S = !0, 
    console.log("email waitForAppMessage")), d.hasPending("alarm") && (T = null, w = !0, 
    console.log("email startedInBackground")), T && (h.translateFragment(T), C ? n(C) : T = null), 
    document.addEventListener("visibilitychange", function() {
        w && x && !document.hidden && (x(), x = null);
    }, !1), m.on("addAccount", function() {
        p.removeAllCards(), n("setup_account_info", {
            allowBack: !0
        });
    }), m.on("accountDeleted", r), m.on("resetApp", r), m.on("showLatestAccount", function() {
        p.removeAllCards(), g.latestOnce("acctsSlice", function(e) {
            var t = e.items[e.items.length - 1];
            g.changeAccount(t, function() {
                n("message_list", {
                    onPushed: c
                });
            });
        });
    }), g.on("acctsSlice", function() {
        g.hasAccount() ? g.latestOnce("foldersSlice", function() {
            S || c() || a();
        }) : y || i("setup_account_info");
    });
    var E = 0;
    d.on("activity", l(function(e, t, n) {
        function o() {
            p.pushCard("compose", "immediate", {
                activity: n,
                composerData: {
                    onComposer: function(e, n) {
                        var i = t.attachmentBlobs;
                        if (t.to && (e.to = t.to), t.subject && (e.subject = t.subject), t.body && (e.body = {
                            text: t.body
                        }), t.cc && (e.cc = t.cc), t.bcc && (e.bcc = t.bcc), i) {
                            for (var s = [], o = 0; o < i.length; o++) s.push({
                                name: t.attachmentNames[o],
                                blob: i[o]
                            });
                            n.addAttachmentsSubjectToSizeLimits(s);
                        }
                    }
                }
            });
        }
        function a() {
            f.show(h.get("setup-empty-account-prompt"), function(e) {
                e || n.postError("cancelled"), y = !1, S = !1, b = o, i("setup_account_info");
            });
        }
        s() || p.removeAllCards(), g.inited ? g.hasAccount() ? o() : (y = !0, console.log("email waitingForCreateAccountPrompt"), 
        a()) : (o(), y = !0, console.log("email waitingForCreateAccountPrompt"), g.latestOnce("acctsSlice", function() {
            g.hasAccount() || a();
        }));
    })), d.on("notification", l(function(e) {
        e = e || {};
        var t = e.type || "message_list", n = e.folderType || "inbox";
        g.latestOnce("foldersSlice", function() {
            function i() {
                function n() {
                    S = !1;
                }
                s() || p.removeAllCards(), "message_list" === t ? a({
                    onPushed: n
                }) : "message_reader" === t && (v.setCurrentMessageBySuid(e.messageSuid), p.pushCard(t, "immediate", {
                    messageSuid: e.messageSuid,
                    onPushed: n
                }));
            }
            var o = g.acctsSlice, r = e.accountId;
            if (!r || g.account.id === r) return g.selectFirstFolderWithType(n, i);
            var c;
            o.items.some(function(e) {
                return e.id === r ? (c = e, !0) : void 0;
            }), c && g.changeAccount(c, function() {
                g.selectFirstFolderWithType(n, i);
            });
        });
    })), d.on("notificationClosed", l(function() {
        S && !p.getCurrentCardType() && r();
    })), g.init();
}), requirejs([ "console_hook", "cards/message_list", "mail_app" ]), function(e, t) {
    function n(e, t, n) {
        this.name = "L10nError", this.message = e, this.id = t, this.loc = n;
    }
    function i() {}
    function s(e) {
        function t(e, t) {
            return -1 !== t.indexOf(e);
        }
        function n(e, t, n) {
            return typeof e == typeof t && e >= t && n >= e;
        }
        var i = {
            af: 3,
            ak: 4,
            am: 4,
            ar: 1,
            asa: 3,
            az: 0,
            be: 11,
            bem: 3,
            bez: 3,
            bg: 3,
            bh: 4,
            bm: 0,
            bn: 3,
            bo: 0,
            br: 20,
            brx: 3,
            bs: 11,
            ca: 3,
            cgg: 3,
            chr: 3,
            cs: 12,
            cy: 17,
            da: 3,
            de: 3,
            dv: 3,
            dz: 0,
            ee: 3,
            el: 3,
            en: 3,
            eo: 3,
            es: 3,
            et: 3,
            eu: 3,
            fa: 0,
            ff: 5,
            fi: 3,
            fil: 4,
            fo: 3,
            fr: 5,
            fur: 3,
            fy: 3,
            ga: 8,
            gd: 24,
            gl: 3,
            gsw: 3,
            gu: 3,
            guw: 4,
            gv: 23,
            ha: 3,
            haw: 3,
            he: 2,
            hi: 4,
            hr: 11,
            hu: 0,
            id: 0,
            ig: 0,
            ii: 0,
            is: 3,
            it: 3,
            iu: 7,
            ja: 0,
            jmc: 3,
            jv: 0,
            ka: 0,
            kab: 5,
            kaj: 3,
            kcg: 3,
            kde: 0,
            kea: 0,
            kk: 3,
            kl: 3,
            km: 0,
            kn: 0,
            ko: 0,
            ksb: 3,
            ksh: 21,
            ku: 3,
            kw: 7,
            lag: 18,
            lb: 3,
            lg: 3,
            ln: 4,
            lo: 0,
            lt: 10,
            lv: 6,
            mas: 3,
            mg: 4,
            mk: 16,
            ml: 3,
            mn: 3,
            mo: 9,
            mr: 3,
            ms: 0,
            mt: 15,
            my: 0,
            nah: 3,
            naq: 7,
            nb: 3,
            nd: 3,
            ne: 3,
            nl: 3,
            nn: 3,
            no: 3,
            nr: 3,
            nso: 4,
            ny: 3,
            nyn: 3,
            om: 3,
            or: 3,
            pa: 3,
            pap: 3,
            pl: 13,
            ps: 3,
            pt: 3,
            rm: 3,
            ro: 9,
            rof: 3,
            ru: 11,
            rwk: 3,
            sah: 0,
            saq: 3,
            se: 7,
            seh: 3,
            ses: 0,
            sg: 0,
            sh: 11,
            shi: 19,
            sk: 12,
            sl: 14,
            sma: 7,
            smi: 7,
            smj: 7,
            smn: 7,
            sms: 7,
            sn: 3,
            so: 3,
            sq: 3,
            sr: 11,
            ss: 3,
            ssy: 3,
            st: 3,
            sv: 3,
            sw: 3,
            syr: 3,
            ta: 3,
            te: 3,
            teo: 3,
            th: 0,
            ti: 4,
            tig: 3,
            tk: 3,
            tl: 4,
            tn: 3,
            to: 0,
            tr: 0,
            ts: 3,
            tzm: 22,
            uk: 11,
            ur: 3,
            ve: 3,
            vi: 0,
            vun: 3,
            wa: 4,
            wae: 3,
            wo: 0,
            xh: 3,
            xog: 3,
            yo: 0,
            zh: 0,
            zu: 3
        }, s = {
            "0": function() {
                return "other";
            },
            "1": function(e) {
                return n(e % 100, 3, 10) ? "few" : 0 === e ? "zero" : n(e % 100, 11, 99) ? "many" : 2 === e ? "two" : 1 === e ? "one" : "other";
            },
            "2": function(e) {
                return 0 !== e && 0 === e % 10 ? "many" : 2 === e ? "two" : 1 === e ? "one" : "other";
            },
            "3": function(e) {
                return 1 === e ? "one" : "other";
            },
            "4": function(e) {
                return n(e, 0, 1) ? "one" : "other";
            },
            "5": function(e) {
                return n(e, 0, 2) && 2 !== e ? "one" : "other";
            },
            "6": function(e) {
                return 0 === e ? "zero" : 1 === e % 10 && 11 !== e % 100 ? "one" : "other";
            },
            "7": function(e) {
                return 2 === e ? "two" : 1 === e ? "one" : "other";
            },
            "8": function(e) {
                return n(e, 3, 6) ? "few" : n(e, 7, 10) ? "many" : 2 === e ? "two" : 1 === e ? "one" : "other";
            },
            "9": function(e) {
                return 0 === e || 1 !== e && n(e % 100, 1, 19) ? "few" : 1 === e ? "one" : "other";
            },
            "10": function(e) {
                return n(e % 10, 2, 9) && !n(e % 100, 11, 19) ? "few" : 1 !== e % 10 || n(e % 100, 11, 19) ? "other" : "one";
            },
            "11": function(e) {
                return n(e % 10, 2, 4) && !n(e % 100, 12, 14) ? "few" : 0 === e % 10 || n(e % 10, 5, 9) || n(e % 100, 11, 14) ? "many" : 1 === e % 10 && 11 !== e % 100 ? "one" : "other";
            },
            "12": function(e) {
                return n(e, 2, 4) ? "few" : 1 === e ? "one" : "other";
            },
            "13": function(e) {
                return n(e % 10, 2, 4) && !n(e % 100, 12, 14) ? "few" : 1 !== e && n(e % 10, 0, 1) || n(e % 10, 5, 9) || n(e % 100, 12, 14) ? "many" : 1 === e ? "one" : "other";
            },
            "14": function(e) {
                return n(e % 100, 3, 4) ? "few" : 2 === e % 100 ? "two" : 1 === e % 100 ? "one" : "other";
            },
            "15": function(e) {
                return 0 === e || n(e % 100, 2, 10) ? "few" : n(e % 100, 11, 19) ? "many" : 1 === e ? "one" : "other";
            },
            "16": function(e) {
                return 1 === e % 10 && 11 !== e ? "one" : "other";
            },
            "17": function(e) {
                return 3 === e ? "few" : 0 === e ? "zero" : 6 === e ? "many" : 2 === e ? "two" : 1 === e ? "one" : "other";
            },
            "18": function(e) {
                return 0 === e ? "zero" : n(e, 0, 2) && 0 !== e && 2 !== e ? "one" : "other";
            },
            "19": function(e) {
                return n(e, 2, 10) ? "few" : n(e, 0, 1) ? "one" : "other";
            },
            "20": function(e) {
                return !n(e % 10, 3, 4) && 9 !== e % 10 || n(e % 100, 10, 19) || n(e % 100, 70, 79) || n(e % 100, 90, 99) ? 0 === e % 1e6 && 0 !== e ? "many" : 2 !== e % 10 || t(e % 100, [ 12, 72, 92 ]) ? 1 !== e % 10 || t(e % 100, [ 11, 71, 91 ]) ? "other" : "one" : "two" : "few";
            },
            "21": function(e) {
                return 0 === e ? "zero" : 1 === e ? "one" : "other";
            },
            "22": function(e) {
                return n(e, 0, 1) || n(e, 11, 99) ? "one" : "other";
            },
            "23": function(e) {
                return n(e % 10, 1, 2) || 0 === e % 20 ? "one" : "other";
            },
            "24": function(e) {
                return n(e, 3, 10) || n(e, 13, 19) ? "few" : t(e, [ 2, 12 ]) ? "two" : t(e, [ 1, 11 ]) ? "one" : "other";
            }
        }, o = i[e.replace(/-.*$/, "")];
        return o in s ? s[o] : function() {
            return "other";
        };
    }
    function o(e, n) {
        var i = Object.keys(e);
        if ("string" == typeof e.$v && 2 === i.length) return e.$v;
        for (var s, o, r = 0; o = i[r]; r++) "$" !== o[0] && (s || (s = Object.create(null)), 
        s[o] = a(e[o], n, e.$i + "." + o));
        return {
            id: e.$i,
            value: e.$v === t ? null : e.$v,
            index: e.$x || null,
            attrs: s || null,
            env: n,
            dirty: !1
        };
    }
    function a(e, t, n) {
        if ("string" == typeof e) return e;
        var i;
        return Array.isArray(e) && (i = e), {
            id: n,
            value: i || e.$v || null,
            index: e.$x || null,
            env: t,
            dirty: !1
        };
    }
    function r(e, t) {
        if ("string" == typeof t) return t;
        if (t.dirty) throw new n("Cyclic reference detected: " + t.id);
        t.dirty = !0;
        var i;
        try {
            i = h(e, t.env, t.value, t.index);
        } finally {
            t.dirty = !1;
        }
        return i;
    }
    function c(e, t, i) {
        if (et.indexOf(i) > -1) return t["__" + i];
        if (e && e.hasOwnProperty(i)) {
            if ("string" == typeof e[i] || "number" == typeof e[i] && !isNaN(e[i])) return e[i];
            throw new n("Arg must be a string or a number: " + i);
        }
        if (i in t && "__proto__" !== i) return r(e, t[i]);
        throw new n("Unknown reference: " + i);
    }
    function l(e, t, i) {
        var s;
        try {
            s = c(e, t, i);
        } catch (o) {
            return "{{ " + i + " }}";
        }
        if ("number" == typeof s) return s;
        if ("string" == typeof s) {
            if (s.length >= tt) throw new n("Too many characters in placeable (" + s.length + ", max allowed is " + tt + ")");
            return s;
        }
        return "{{ " + i + " }}";
    }
    function d(e, t, n) {
        return n.reduce(function(n, i) {
            return "string" == typeof i ? n + i : "idOrVar" === i.t ? n + l(e, t, i.v) : void 0;
        }, "");
    }
    function u(e, n, i, s) {
        var o = s[0].v, a = c(e, n, o);
        if ("function" != typeof a) return a;
        var r = s[1] ? c(e, n, s[1]) : t;
        if (a === n.__plural) {
            if (0 === r && "zero" in i) return "zero";
            if (1 === r && "one" in i) return "one";
            if (2 === r && "two" in i) return "two";
        }
        return a(r);
    }
    function h(e, t, i, s) {
        if ("string" == typeof i || "boolean" == typeof i || "number" == typeof i || !i) return i;
        if (Array.isArray(i)) return d(e, t, i);
        if (s) {
            var o = u(e, t, i, s);
            if (i.hasOwnProperty(o)) return h(e, t, i[o]);
        }
        if ("other" in i) return h(e, t, i.other);
        throw new n("Unresolvable value");
    }
    function p(e, t) {
        if ("string" == typeof e) return t(e);
        if ("idOrVar" === e.t) return e;
        for (var n, i = Array.isArray(e) ? [] : {}, s = Object.keys(e), o = 0; n = s[o]; o++) i[n] = "$i" === n || "$x" === n ? e[n] : p(e[n], t);
        return i;
    }
    function f(e) {
        return e.replace(ot, function(e) {
            return e + e.toLowerCase();
        });
    }
    function m(e, t) {
        return t.replace(st, function(t) {
            return e.charAt(t.charCodeAt(0) - 65);
        });
    }
    function g(e) {
        return e.replace(ct, function(e) {
            return "‮" + e + "‬";
        });
    }
    function v(e, t) {
        if (!t) return t;
        var n = t.split(lt), i = n.map(function(t) {
            return lt.test(t) ? t : e(t);
        });
        return i.join("");
    }
    function _(e, t, n, i) {
        this.id = e, this.translate = v.bind(null, function(e) {
            return m(n, i(e));
        }), this.name = this.translate(t);
    }
    function y(e, t) {
        this.id = e, this.ctx = t, this.isReady = !1, this.isPseudo = dt.hasOwnProperty(e), 
        this.entries = Object.create(null), this.entries.__plural = s(this.isPseudo ? this.ctx.defaultLocale : e);
    }
    function b(e, t) {
        return it.createEntry(p(e, dt[this.id].translate), t);
    }
    function x(e) {
        this.id = e, this.isReady = !1, this.isLoading = !1, this.defaultLocale = "en-US", 
        this.availableLocales = [], this.supportedLocales = [], this.resLinks = [], this.locales = {}, 
        this._emitter = new i(), this._ready = new Promise(this.once.bind(this));
    }
    function S(e, t) {
        return this._emitter.emit("notfounderror", t), e;
    }
    function w(e) {
        for (var i, s, o = 0; i = this.supportedLocales[o]; ) {
            s = this.getLocale(i), s.isReady || s.build(null);
            var a = s.entries[e];
            if (a !== t) return a;
            o++, S.call(this, e, new n('"' + e + '"' + " not found in " + i + " in " + this.id, e, i));
        }
        throw new n('"' + e + '"' + " missing from all supported locales in " + this.id, e);
    }
    function T(e, t) {
        if ("string" == typeof t) return t;
        try {
            return it.format(e, t);
        } catch (n) {
            return this._emitter.emit("resolveerror", n), t.id;
        }
    }
    function C(e, t) {
        if (!t.attrs) return {
            value: T.call(this, e, t),
            attrs: null
        };
        var n = {
            value: T.call(this, e, t),
            attrs: Object.create(null)
        };
        for (var i in t.attrs) n.attrs[i] = T.call(this, e, t.attrs[i]);
        return n;
    }
    function E(e, t, n) {
        return this._ready.then(w.bind(this, t)).then(e.bind(this, n), S.bind(this, t));
    }
    function A(e, t, i) {
        if (!this.isReady) throw new n("Context not ready");
        var s;
        try {
            s = w.call(this, t);
        } catch (o) {
            if (o.loc) throw o;
            return S.call(this, t, o), "";
        }
        return e.call(this, i, s);
    }
    function k(e, t, n) {
        return -1 === e.indexOf(t[0]) || t[0] === n ? [ n ] : [ t[0], n ];
    }
    function I(e) {
        var t = this.getLocale(e[0]);
        t.isReady ? O.call(this, e) : t.build(O.bind(this, e));
    }
    function O(e) {
        this.supportedLocales = e, this.isReady = !0, this._emitter.emit("ready");
    }
    function M(e) {
        return pt.indexOf(e) >= 0 ? "rtl" : "ltr";
    }
    function D(e, t) {
        return e = _t[e], _t[document.readyState] >= e ? (t(), void 0) : (document.addEventListener("readystatechange", function n() {
            _t[document.readyState] >= e && (document.removeEventListener("readystatechange", n), 
            t());
        }), void 0);
    }
    function L() {
        ft = new MutationObserver(U.bind(navigator.mozL10n)), ft.observe(document, vt);
    }
    function N(t) {
        t ? B.call(navigator.mozL10n) : (L(), e.setTimeout(B.bind(navigator.mozL10n)));
    }
    function B() {
        for (var e, t = document.head.querySelectorAll('link[rel="localization"],meta[name="availableLanguages"],meta[name="defaultLanguage"],script[type="application/l10n"]'), n = 0; e = t[n]; n++) {
            var i = e.getAttribute("rel") || e.nodeName.toLowerCase();
            switch (i) {
              case "localization":
                this.ctx.resLinks.push(e.getAttribute("href"));
                break;

              case "meta":
                F.call(this, e);
                break;

              case "script":
                P.call(this, e);
            }
        }
        return this.ctx.availableLocales.length || this.ctx.registerLocales(this.ctx.defaultLocale), 
        q.call(this);
    }
    function R(e) {
        return e.split(",").map(function(e) {
            return e = e.trim().split(":"), e[0];
        });
    }
    function F(e) {
        if (!this.ctx.availableLocales.length) {
            switch (e.getAttribute("name")) {
              case "availableLanguages":
                gt.availableLanguages = R(e.getAttribute("content"));
                break;

              case "defaultLanguage":
                gt.defaultLanguage = e.getAttribute("content");
            }
            2 === Object.keys(gt).length && (this.ctx.registerLocales(gt.defaultLanguage, gt.availableLanguages), 
            gt = {});
        }
    }
    function P(e) {
        var t = e.getAttribute("lang"), n = this.ctx.getLocale(t);
        n.addAST(JSON.parse(e.textContent));
    }
    function q() {
        this.ctx.requestLocales.apply(this.ctx, navigator.languages || [ navigator.language ]), 
        e.addEventListener("languagechange", function() {
            this.ctx.requestLocales.apply(this.ctx, navigator.languages || [ navigator.language ]);
        }.bind(this));
    }
    function H(e) {
        for (var t, n = new Set(), i = 0; i < e.length; i++) {
            if (t = e[i], "childList" === t.type) for (var s, o = 0; o < t.addedNodes.length; o++) s = t.addedNodes[o], 
            s.nodeType === Node.ELEMENT_NODE && n.add(s);
            "attributes" === t.type && n.add(t.target);
        }
        n.forEach(function(e) {
            e.childElementCount ? W.call(this, e) : e.hasAttribute("data-l10n-id") && K.call(this, e);
        }, this);
    }
    function U(e, t) {
        t.disconnect(), H.call(this, e), t.observe(document, vt);
    }
    function j() {
        if (ht || G.call(this), ht = !1, mt) {
            for (var e, t = 0; e = mt[t]; t++) K.call(this, e);
            mt = null;
        }
        ft || L(), z.call(this);
    }
    function z() {
        var t = new CustomEvent("localized", {
            bubbles: !1,
            cancelable: !1,
            detail: {
                language: this.ctx.supportedLocales[0]
            }
        });
        e.dispatchEvent(t);
    }
    function G() {
        document.documentElement.lang = this.language.code, document.documentElement.dir = this.language.direction, 
        W.call(this, document.documentElement);
    }
    function W(e) {
        e.hasAttribute("data-l10n-id") && K.call(this, e);
        for (var t = X(e), n = 0; n < t.length; n++) K.call(this, t[n]);
    }
    function Y(e, t, n) {
        e.setAttribute("data-l10n-id", t), n && e.setAttribute("data-l10n-args", JSON.stringify(n));
    }
    function V(e) {
        return {
            id: e.getAttribute("data-l10n-id"),
            args: JSON.parse(e.getAttribute("data-l10n-args"))
        };
    }
    function X(e) {
        return e ? e.querySelectorAll("*[data-l10n-id]") : [];
    }
    function K(e) {
        if (!this.ctx.isReady) return mt || (mt = []), mt.push(e), void 0;
        var t = V(e);
        if (!t.id) return !1;
        var n = this.ctx.getEntity(t.id, t.args);
        if (!n) return !1;
        "string" == typeof n.value && $.call(this, t.id, e, n.value);
        for (var i in n.attrs) {
            var s = n.attrs[i];
            bt.hasOwnProperty(i) ? e.setAttribute(bt[i], s) : "innerHTML" === i ? e.innerHTML = s : e.setAttribute(i, s);
        }
        return !0;
    }
    function $(e, t, i) {
        if (t.firstElementChild) throw new n('setTextContent is deprecated (https://bugzil.la/1053629). Setting text content of elements with child elements is no longer supported by l10n.js. Offending data-l10n-id: "' + e + '" on element ' + t.outerHTML + " in " + this.ctx.id);
        t.textContent = i;
    }
    n.prototype = Object.create(Error.prototype), n.prototype.constructor = n;
    var J = {
        load: function(e, t, i) {
            var s = new XMLHttpRequest();
            s.overrideMimeType && s.overrideMimeType("text/plain"), s.open("GET", e, !i), s.addEventListener("load", function(i) {
                200 === i.target.status || 0 === i.target.status ? t(null, i.target.responseText) : t(new n("Not found: " + e));
            }), s.addEventListener("error", t), s.addEventListener("timeout", t);
            try {
                s.send(null);
            } catch (o) {
                t(new n("Not found: " + e));
            }
        },
        loadJSON: function(e, t) {
            var i = new XMLHttpRequest();
            i.overrideMimeType && i.overrideMimeType("application/json"), i.open("GET", e), 
            i.responseType = "json", i.addEventListener("load", function(i) {
                200 === i.target.status || 0 === i.target.status ? t(null, i.target.response) : t(new n("Not found: " + e));
            }), i.addEventListener("error", t), i.addEventListener("timeout", t);
            try {
                i.send(null);
            } catch (s) {
                t(new n("Not found: " + e));
            }
        }
    };
    i.prototype.emit = function() {
        if (this._listeners) {
            var e = Array.prototype.slice.call(arguments), t = e.shift();
            if (this._listeners[t]) for (var n = this._listeners[t].slice(), i = 0; i < n.length; i++) n[i].apply(this, e);
        }
    }, i.prototype.addEventListener = function(e, t) {
        this._listeners || (this._listeners = {}), e in this._listeners || (this._listeners[e] = []), 
        this._listeners[e].push(t);
    }, i.prototype.removeEventListener = function(e, t) {
        if (this._listeners) {
            var n = this._listeners[e], i = n.indexOf(t);
            -1 !== i && n.splice(i, 1);
        }
    };
    var Q = 100, Z = {
        patterns: null,
        entryIds: null,
        init: function() {
            this.patterns = {
                comment: /^\s*#|^\s*$/,
                entity: /^([^=\s]+)\s*=\s*(.+)$/,
                multiline: /[^\\]\\$/,
                index: /\{\[\s*(\w+)(?:\(([^\)]*)\))?\s*\]\}/i,
                unicode: /\\u([0-9a-fA-F]{1,4})/g,
                entries: /[^\r\n]+/g,
                controlChars: /\\([\\\n\r\t\b\f\{\}\"\'])/g,
                placeables: /\{\{\s*([^\s]*?)\s*\}\}/
            };
        },
        parse: function(e, t) {
            this.patterns || this.init();
            var n = [];
            this.entryIds = Object.create(null);
            var i = t.match(this.patterns.entries);
            if (!i) return n;
            for (var s = 0; s < i.length; s++) {
                var o = i[s];
                if (!this.patterns.comment.test(o)) {
                    for (;this.patterns.multiline.test(o) && s < i.length; ) o = o.slice(0, -1) + i[++s].trim();
                    var a = o.match(this.patterns.entity);
                    if (a) try {
                        this.parseEntity(a[1], a[2], n);
                    } catch (r) {
                        if (!e) throw r;
                        e._emitter.emit("parseerror", r);
                    }
                }
            }
            return n;
        },
        parseEntity: function(e, t, i) {
            var s, o, a = e.indexOf("[");
            -1 !== a ? (s = e.substr(0, a), o = e.substring(a + 1, e.length - 1)) : (s = e, 
            o = null);
            var r = s.split(".");
            if (r.length > 2) throw new n('Error in ID: "' + s + '".' + " Nested attributes are not supported.");
            var c;
            if (r.length > 1) {
                if (s = r[0], c = r[1], "$" === c[0]) throw new n('Attribute can\'t start with "$"', e);
            } else c = null;
            this.setEntityValue(s, c, o, this.unescapeString(t), i);
        },
        setEntityValue: function(e, n, i, s, o) {
            var a, r;
            return -1 !== s.indexOf("{{") && (s = this.parseString(s)), n ? (a = this.entryIds[e], 
            a === t ? (r = {
                $i: e
            }, i ? (r[n] = {}, r[n][i] = s) : r[n] = s, o.push(r), this.entryIds[e] = o.length - 1, 
            void 0) : i ? ("string" == typeof o[a][n] && (o[a][n] = {
                $x: this.parseIndex(o[a][n]),
                $v: {}
            }), o[a][n].$v[i] = s, void 0) : (o[a][n] = s, void 0)) : i ? (a = this.entryIds[e], 
            a === t ? (r = {}, r[i] = s, o.push({
                $i: e,
                $v: r
            }), this.entryIds[e] = o.length - 1, void 0) : ("string" == typeof o[a].$v && (o[a].$x = this.parseIndex(o[a].$v), 
            o[a].$v = {}), o[a].$v[i] = s, void 0)) : (o.push({
                $i: e,
                $v: s
            }), this.entryIds[e] = o.length - 1, void 0);
        },
        parseString: function(e) {
            var t = e.split(this.patterns.placeables), i = [], s = t.length, o = (s - 1) / 2;
            if (o >= Q) throw new n("Too many placeables (" + o + ", max allowed is " + Q + ")");
            for (var a = 0; a < t.length; a++) 0 !== t[a].length && (1 === a % 2 ? i.push({
                t: "idOrVar",
                v: t[a]
            }) : i.push(t[a]));
            return i;
        },
        unescapeString: function(e) {
            return -1 !== e.lastIndexOf("\\") && (e = e.replace(this.patterns.controlChars, "$1")), 
            e.replace(this.patterns.unicode, function(e, t) {
                return unescape("%u" + "0000".slice(t.length) + t);
            });
        },
        parseIndex: function(e) {
            var t = e.match(this.patterns.index);
            if (!t) throw new n("Malformed index");
            return t[2] ? [ {
                t: "idOrVar",
                v: t[1]
            }, t[2] ] : [ {
                t: "idOrVar",
                v: t[1]
            } ];
        }
    }, et = [ "plural" ], tt = 2500, nt = /\{\{\s*(.+?)\s*\}\}/g, it = {
        createEntry: o,
        format: r,
        rePlaceables: nt
    }, st = /[a-zA-Z]/g, ot = /[aeiouAEIOU]/g, at = "ȦƁƇḒḖƑƓĦĪĴĶĿḾȠǾƤɊŘŞŦŬṼẆẊẎẐ[\\]^_`ȧƀƈḓḗƒɠħīĵķŀḿƞǿƥɋřşŧŭṽẇẋẏẑ", rt = "∀ԐↃpƎɟפHIſӼ˥WNOԀÒᴚS⊥∩ɅＭXʎZ[\\]ᵥ_,ɐqɔpǝɟƃɥıɾʞʅɯuodbɹsʇnʌʍxʎz", ct = /[^\W0-9_]+/g, lt = /(%[EO]?\w|\{\s*.+?\s*\})/, dt = {
        "qps-ploc": new _("qps-ploc", "Accented English", at, f),
        "qps-plocm": new _("qps-plocm", "Mirrored English", rt, g)
    };
    y.prototype.build = function(e) {
        function t(t) {
            t && o._emitter.emit("fetcherror", t), --r <= 0 && (a.isReady = !0, e && e());
        }
        function n(e, n) {
            !e && n && a.addAST(n), t(e);
        }
        function i(e, n) {
            if (!e && n) {
                var i = Z.parse(o, n);
                a.addAST(i);
            }
            t(e);
        }
        var s = !e, o = this.ctx, a = this, r = o.resLinks.length;
        if (0 === r) return t(), void 0;
        for (var c = this.isPseudo ? o.defaultLocale : this.id, l = 0; l < o.resLinks.length; l++) {
            var d = decodeURI(o.resLinks[l]), u = d.replace("{locale}", c), h = u.substr(u.lastIndexOf(".") + 1);
            switch (h) {
              case "json":
                J.loadJSON(u, n, s);
                break;

              case "properties":
                J.load(u, i, s);
            }
        }
    }, y.prototype.addAST = function(e) {
        for (var t, n = this.isPseudo ? b.bind(this) : it.createEntry, i = 0; t = e[i]; i++) this.entries[t.$i] = n(t, this.entries);
    }, x.prototype.formatValue = function(e, t) {
        return E.call(this, T, e, t);
    }, x.prototype.formatEntity = function(e, t) {
        return E.call(this, C, e, t);
    }, x.prototype.get = function(e, t) {
        return A.call(this, T, e, t);
    }, x.prototype.getEntity = function(e, t) {
        return A.call(this, C, e, t);
    }, x.prototype.getLocale = function(e) {
        var t = this.locales;
        return t[e] ? t[e] : t[e] = new y(e, this);
    }, x.prototype.registerLocales = function(e, t) {
        if (this.availableLocales = [ this.defaultLocale = e ], t) for (var n, i = 0; n = t[i]; i++) -1 === this.availableLocales.indexOf(n) && this.availableLocales.push(n);
    }, x.prototype.requestLocales = function() {
        if (this.isLoading && !this.isReady) throw new n("Context not ready");
        this.isLoading = !0;
        var e = Array.prototype.slice.call(arguments);
        if (0 === e.length) throw new n("No locales requested");
        var t = e.filter(function(e) {
            return e in dt;
        }), i = k(this.availableLocales.concat(t), e, this.defaultLocale);
        I.call(this, i);
    }, x.prototype.addEventListener = function(e, t) {
        this._emitter.addEventListener(e, t);
    }, x.prototype.removeEventListener = function(e, t) {
        this._emitter.removeEventListener(e, t);
    }, x.prototype.ready = function(e) {
        this.isReady && setTimeout(e), this.addEventListener("ready", e);
    }, x.prototype.once = function(e) {
        if (this.isReady) return setTimeout(e), void 0;
        var t = function() {
            this.removeEventListener("ready", t), e();
        }.bind(this);
        this.addEventListener("ready", t);
    };
    var ut = !1, ht = !1, pt = [ "ar", "he", "fa", "ps", "qps-plocm", "ur" ], ft = null, mt = null, gt = {}, vt = {
        attributes: !0,
        characterData: !1,
        childList: !0,
        subtree: !0,
        attributeFilter: [ "data-l10n-id", "data-l10n-args" ]
    };
    navigator.mozL10n = {
        ctx: new x(e.document ? document.URL : null),
        get: function(e, t) {
            return navigator.mozL10n.ctx.get(e, t);
        },
        formatValue: function(e, t) {
            return navigator.mozL10n.ctx.formatValue(e, t);
        },
        formatEntity: function(e, t) {
            return navigator.mozL10n.ctx.formatEntity(e, t);
        },
        translateFragment: function(e) {
            return W.call(navigator.mozL10n, e);
        },
        setAttributes: Y,
        getAttributes: V,
        ready: function(e) {
            return navigator.mozL10n.ctx.ready(e);
        },
        once: function(e) {
            return navigator.mozL10n.ctx.once(e);
        },
        get readyState() {
            return navigator.mozL10n.ctx.isReady ? "complete" : "loading";
        },
        language: {
            set code(e) {
                navigator.mozL10n.ctx.requestLocales(e);
            },
            get code() {
                return navigator.mozL10n.ctx.supportedLocales[0];
            },
            get direction() {
                return M(navigator.mozL10n.ctx.supportedLocales[0]);
            }
        },
        qps: dt,
        _getInternalAPI: function() {
            return {
                Error: n,
                Context: x,
                Locale: y,
                Resolver: it,
                getPluralRule: s,
                rePlaceables: nt,
                translateDocument: G,
                onMetaInjected: F,
                PropertiesParser: Z,
                walkContent: p
            };
        }
    }, navigator.mozL10n.ctx.ready(j.bind(navigator.mozL10n)), navigator.mozL10n.ctx.addEventListener("notfounderror", function(e) {
        (ut || "en-US" === e.loc) && console.warn(e.toString());
    }), ut && (navigator.mozL10n.ctx.addEventListener("manifesterror", console.error.bind(console)), 
    navigator.mozL10n.ctx.addEventListener("fetcherror", console.error.bind(console)), 
    navigator.mozL10n.ctx.addEventListener("parseerror", console.error.bind(console)), 
    navigator.mozL10n.ctx.addEventListener("resolveerror", console.error.bind(console)));
    var _t = {
        loading: 0,
        interactive: 1,
        complete: 2
    };
    if (e.document) {
        ht = !dt.hasOwnProperty(navigator.language) && document.documentElement.lang === navigator.language;
        var yt = document.documentElement.dataset.noCompleteBug ? !0 : !ht;
        D("interactive", N.bind(navigator.mozL10n, yt));
    }
    var bt = {
        ariaLabel: "aria-label",
        ariaValueText: "aria-valuetext",
        ariaMozHint: "aria-moz-hint"
    };
}(this), define("l10nbase", function() {}), navigator.mozL10n.DateTimeFormat = function() {
    function e(t, n) {
        for (var s = n.match(/(%E.|%O.|%.)/g), o = 0; s && o < s.length; o++) {
            var a = "";
            switch (s[o]) {
              case "%a":
                a = i("weekday-" + t.getDay() + "-short");
                break;

              case "%A":
                a = i("weekday-" + t.getDay() + "-long");
                break;

              case "%b":
              case "%h":
                a = i("month-" + t.getMonth() + "-short");
                break;

              case "%B":
                a = i("month-" + t.getMonth() + "-long");
                break;

              case "%Eb":
                a = i("month-" + t.getMonth() + "-genitive");
                break;

              case "%I":
                a = t.getHours() % 12 || 12;
                break;

              case "%e":
                a = t.getDate();
                break;

              case "%p":
                a = t.getHours() < 12 ? i("time_am") : i("time_pm");
                break;

              case "%c":
              case "%x":
              case "%X":
                var r = i("dateTimeFormat_" + s[o]);
                r && !/(%c|%x|%X)/.test(r) && (a = e(t, r));
            }
            n = n.replace(s[o], a || t.toLocaleFormat(s[o]));
        }
        return n;
    }
    function t(e) {
        e = Math.abs(e);
        var t = {}, n = [ "years", 31536e3, "months", 2592e3, "weeks", 604800, "days", 86400, "hours", 3600, "minutes", 60 ];
        if (60 > e) return {
            minutes: Math.round(e / 60)
        };
        for (var i = 0, s = n.length; s > i; i += 2) {
            var o = n[i + 1];
            e >= o && (t[n[i]] = Math.floor(e / o), e -= t[n[i]] * o);
        }
        return t;
    }
    function n(n, s, o) {
        switch (o = o || 864e3, n.constructor) {
          case String:
            n = parseInt(n);
            break;

          case Date:
            n = n.getTime();
        }
        var a = (Date.now() - n) / 1e3;
        if (isNaN(a)) return i("incorrectDate");
        if (Math.abs(a) > 60 && (a = a > 0 ? Math.ceil(a) : Math.floor(a)), a > o) return e(new Date(n), "%x");
        var r = s ? "-short" : "-long", c = t(a), l = a >= 0 ? "-ago" : "-until";
        for (var d in c) return i(d + l + r, {
            value: c[d]
        });
    }
    var i = navigator.mozL10n.get;
    return {
        localeDateString: function(t) {
            return e(t, "%x");
        },
        localeTimeString: function(t) {
            return e(t, "%X");
        },
        localeString: function(t) {
            return e(t, "%c");
        },
        localeFormat: e,
        fromNow: n,
        relativeParts: t
    };
}, define("l10ndate", function() {}), define("text", {
    load: function(e, t, n) {
        var i = t.toUrl(e), s = new XMLHttpRequest();
        s.open("GET", i, !0), s.onreadystatechange = function() {
            var e, t;
            4 === s.readyState && (e = s.status, e > 399 && 600 > e ? (t = new Error(i + " HTTP status: " + e), 
            t.xhr = s, n.error(t)) : n(s.responseText));
        }, s.responseType = "text", s.send(null);
    }
}), define("folder_depth_classes", [], function() {
    return [ "fld-folder-depth0", "fld-folder-depth1", "fld-folder-depth2", "fld-folder-depth3", "fld-folder-depth4", "fld-folder-depth5", "fld-folder-depthmax" ];
}), define("tmpl!cards/value_selector.html", [ "tmpl" ], function(e) {
    return e.toDom('<form class="email-value-selector collapsed" role="dialog" data-type="value-selector">\n  <section class="scrollable">\n    <h1></h1>\n    <ol role="listbox">\n    </ol>\n  </section>\n  <menu>\n    <button class="full"\n            data-l10n-id="message-multiedit-cancel"></button>\n  </menu>\n</form>');
}), define("tmpl!cards/vsl/item.html", [ "tmpl" ], function(e) {
    return e.toDom('<li role="option"><label role="presentation"> <span></span></label></li>');
}), define("value_selector", [ "require", "cards", "folder_depth_classes", "tmpl!cards/value_selector.html", "tmpl!cards/vsl/item.html" ], function(e) {
    function t() {}
    function n(e, n) {
        var r, c, l, d, u, h, p, f;
        return r = function() {
            f = {
                title: "No Title",
                list: [ {
                    label: "Dummy element",
                    callback: function() {
                        alert("Define an action here!");
                    }
                } ]
            }, document.body.appendChild(o);
            var t = o.querySelector("button");
            t.addEventListener("click", function(e) {
                e.stopPropagation(), e.preventDefault(), l();
            }), h(), "string" == typeof e && u(e), Array.isArray(n) && (f.list = n);
        }, c = function() {
            d(), i.setStatusColor(o), o.classList.remove("collapsed");
        }, l = function() {
            i.setStatusColor(), o.classList.add("collapsed"), h();
        }, d = function() {
            var e = o.querySelector("h1"), n = o.querySelector("ol");
            e.textContent = f.title, n.innerHTML = "", f.list.forEach(function(e) {
                var i = a.cloneNode(!0);
                i.querySelector("span").textContent = e.label;
                var o = e.depth;
                o = Math.min(s.length - 1, o), i.classList.add(s[o]);
                var r = e.selectable ? e.callback : t;
                i.addEventListener("click", r, !1), n.appendChild(i);
            });
        }, u = function(e) {
            f.title = e;
        }, h = function() {
            f.list = [];
        }, p = function(e, t, n, i) {
            f.list.push({
                label: e,
                depth: t,
                selectable: n,
                callback: i
            });
        }, r(), {
            init: r,
            show: c,
            hide: l,
            setTitle: u,
            addToList: p,
            List: n
        };
    }
    var i = e("cards"), s = e("folder_depth_classes"), o = e("tmpl!cards/value_selector.html"), a = e("tmpl!cards/vsl/item.html");
    return n;
});

var GestureDetector = function() {
    function e(t, n) {
        this.element = t, this.options = n || {}, this.options.panThreshold = this.options.panThreshold || e.PAN_THRESHOLD, 
        this.state = m, this.timers = {};
    }
    function t(e) {
        var t = e.timeStamp;
        return t > 2 * Date.now() ? Math.floor(t / 1e3) : t;
    }
    function n(e, n) {
        return Object.freeze({
            screenX: n.screenX,
            screenY: n.screenY,
            clientX: n.clientX,
            clientY: n.clientY,
            timeStamp: t(e)
        });
    }
    function i(e, n, i) {
        return Object.freeze({
            screenX: d((n.screenX + i.screenX) / 2),
            screenY: d((n.screenY + i.screenY) / 2),
            clientX: d((n.clientX + i.clientX) / 2),
            clientY: d((n.clientY + i.clientY) / 2),
            timeStamp: t(e)
        });
    }
    function s(t, n) {
        var i = e.THRESHOLD_SMOOTHING;
        return Object.freeze({
            screenX: d(t.screenX + i * (n.screenX - t.screenX)),
            screenY: d(t.screenY + i * (n.screenY - t.screenY)),
            clientX: d(t.clientX + i * (n.clientX - t.clientX)),
            clientY: d(t.clientY + i * (n.clientY - t.clientY)),
            timeStamp: d(t.timeStamp + i * (n.timeStamp - t.timeStamp))
        });
    }
    function o(e, t) {
        var n = t.screenX - e.screenX, i = t.screenY - e.screenY;
        return u(n * n + i * i);
    }
    function a(e, t) {
        return 180 * h(t.screenY - e.screenY, t.screenX - e.screenX) / p;
    }
    function r(e, t) {
        var n = t - e;
        return n > 180 ? n -= 360 : -180 >= n && (n += 360), n;
    }
    function c(t, n) {
        var i = l(n.screenX - t.screenX), s = l(n.screenY - t.screenY), o = n.timeStamp - t.timeStamp;
        return i < e.DOUBLE_TAP_DISTANCE && s < e.DOUBLE_TAP_DISTANCE && o < e.DOUBLE_TAP_TIME;
    }
    e.prototype.startDetecting = function() {
        var e = this;
        f.forEach(function(t) {
            e.element.addEventListener(t, e);
        });
    }, e.prototype.stopDetecting = function() {
        var e = this;
        f.forEach(function(t) {
            e.element.removeEventListener(t, e);
        });
    }, e.prototype.handleEvent = function(e) {
        var t = this.state[e.type];
        if (t) if (e.changedTouches) {
            "touchend" === e.type && e.changedTouches.length > 1 && console.warn("gesture_detector.js: spurious extra changed touch on touchend. See https://bugzilla.mozilla.org/show_bug.cgi?id=785554");
            for (var n = 0; n < e.changedTouches.length; n++) t(this, e, e.changedTouches[n]), 
            t = this.state[e.type];
        } else t(this, e);
    }, e.prototype.startTimer = function(e, t) {
        this.clearTimer(e);
        var n = this;
        this.timers[e] = setTimeout(function() {
            n.timers[e] = null;
            var t = n.state[e];
            t && t(n, e);
        }, t);
    }, e.prototype.clearTimer = function(e) {
        this.timers[e] && (clearTimeout(this.timers[e]), this.timers[e] = null);
    }, e.prototype.switchTo = function(e, t, n) {
        this.state = e, e.init && e.init(this, t, n);
    }, e.prototype.emitEvent = function(e, t) {
        if (!this.target) return console.error("Attempt to emit event with no target"), 
        void 0;
        var n = this.element.ownerDocument.createEvent("CustomEvent");
        n.initCustomEvent(e, !0, !0, t), this.target.dispatchEvent(n);
    }, e.HOLD_INTERVAL = 1e3, e.PAN_THRESHOLD = 20, e.DOUBLE_TAP_DISTANCE = 50, e.DOUBLE_TAP_TIME = 500, 
    e.VELOCITY_SMOOTHING = .5, e.SCALE_THRESHOLD = 20, e.ROTATE_THRESHOLD = 22.5, e.THRESHOLD_SMOOTHING = .9;
    var l = Math.abs, d = Math.floor, u = Math.sqrt, h = Math.atan2, p = Math.PI, f = [ "touchstart", "touchmove", "touchend" ], m = {
        name: "initialState",
        init: function(e) {
            e.target = null, e.start = e.last = null, e.touch1 = e.touch2 = null, e.vx = e.vy = null, 
            e.startDistance = e.lastDistance = null, e.startDirection = e.lastDirection = null, 
            e.lastMidpoint = null, e.scaled = e.rotated = null;
        },
        touchstart: function(e, t, n) {
            e.switchTo(g, t, n);
        }
    }, g = {
        name: "touchStartedState",
        init: function(t, i, s) {
            t.target = i.target, t.touch1 = s.identifier, t.start = t.last = n(i, s), t.options.holdEvents && t.startTimer("holdtimeout", e.HOLD_INTERVAL);
        },
        touchstart: function(e, t, n) {
            e.clearTimer("holdtimeout"), e.switchTo(y, t, n);
        },
        touchmove: function(e, t, n) {
            n.identifier === e.touch1 && (l(n.screenX - e.start.screenX) > e.options.panThreshold || l(n.screenY - e.start.screenY) > e.options.panThreshold) && (e.clearTimer("holdtimeout"), 
            e.switchTo(v, t, n));
        },
        touchend: function(e, t, i) {
            i.identifier === e.touch1 && (e.lastTap && c(e.lastTap, e.start) ? (e.emitEvent("tap", e.start), 
            e.emitEvent("dbltap", e.start), e.lastTap = null) : (e.emitEvent("tap", e.start), 
            e.lastTap = n(t, i)), e.clearTimer("holdtimeout"), e.switchTo(m));
        },
        holdtimeout: function(e) {
            e.switchTo(_);
        }
    }, v = {
        name: "panStartedState",
        init: function(e, t, i) {
            e.start = e.last = s(e.start, n(t, i)), "touchmove" === t.type && v.touchmove(e, t, i);
        },
        touchmove: function(t, i, s) {
            if (s.identifier === t.touch1) {
                var o = n(i, s);
                t.emitEvent("pan", {
                    absolute: {
                        dx: o.screenX - t.start.screenX,
                        dy: o.screenY - t.start.screenY
                    },
                    relative: {
                        dx: o.screenX - t.last.screenX,
                        dy: o.screenY - t.last.screenY
                    },
                    position: o
                });
                var a = o.timeStamp - t.last.timeStamp, r = (o.screenX - t.last.screenX) / a, c = (o.screenY - t.last.screenY) / a;
                null == t.vx ? (t.vx = r, t.vy = c) : (t.vx = t.vx * e.VELOCITY_SMOOTHING + r * (1 - e.VELOCITY_SMOOTHING), 
                t.vy = t.vy * e.VELOCITY_SMOOTHING + c * (1 - e.VELOCITY_SMOOTHING)), t.last = o;
            }
        },
        touchend: function(e, t, i) {
            if (i.identifier === e.touch1) {
                var s = n(t, i), o = s.screenX - e.start.screenX, a = s.screenY - e.start.screenY, r = 180 * h(a, o) / p;
                0 > r && (r += 360);
                var c;
                r >= 315 || 45 > r ? c = "right" : r >= 45 && 135 > r ? c = "down" : r >= 135 && 225 > r ? c = "left" : r >= 225 && 315 > r && (c = "up"), 
                e.emitEvent("swipe", {
                    start: e.start,
                    end: s,
                    dx: o,
                    dy: a,
                    dt: t.timeStamp - e.start.timeStamp,
                    vx: e.vx,
                    vy: e.vy,
                    direction: c,
                    angle: r
                }), e.switchTo(m);
            }
        }
    }, _ = {
        name: "holdState",
        init: function(e) {
            e.emitEvent("holdstart", e.start);
        },
        touchmove: function(e, t, i) {
            var s = n(t, i);
            e.emitEvent("holdmove", {
                absolute: {
                    dx: s.screenX - e.start.screenX,
                    dy: s.screenY - e.start.screenY
                },
                relative: {
                    dx: s.screenX - e.last.screenX,
                    dy: s.screenY - e.last.screenY
                },
                position: s
            }), e.last = s;
        },
        touchend: function(e, t, i) {
            var s = n(t, i);
            e.emitEvent("holdend", {
                start: e.start,
                end: s,
                dx: s.screenX - e.start.screenX,
                dy: s.screenY - e.start.screenY
            }), e.switchTo(m);
        }
    }, y = {
        name: "transformState",
        init: function(e, t, n) {
            e.touch2 = n.identifier;
            var i = t.touches.identifiedTouch(e.touch1), s = t.touches.identifiedTouch(e.touch2);
            e.startDistance = e.lastDistance = o(i, s), e.startDirection = e.lastDirection = a(i, s), 
            e.scaled = e.rotated = !1;
        },
        touchmove: function(t, n, s) {
            if (s.identifier === t.touch1 || s.identifier === t.touch2) {
                var c = n.touches.identifiedTouch(t.touch1), u = n.touches.identifiedTouch(t.touch2), h = i(n, c, u), p = o(c, u), f = a(c, u), m = r(t.startDirection, f);
                t.scaled || (l(p - t.startDistance) > e.SCALE_THRESHOLD ? (t.scaled = !0, t.startDistance = t.lastDistance = d(t.startDistance + e.THRESHOLD_SMOOTHING * (p - t.startDistance))) : p = t.startDistance), 
                t.rotated || (l(m) > e.ROTATE_THRESHOLD ? t.rotated = !0 : f = t.startDirection), 
                (t.scaled || t.rotated) && (t.emitEvent("transform", {
                    absolute: {
                        scale: p / t.startDistance,
                        rotate: r(t.startDirection, f)
                    },
                    relative: {
                        scale: p / t.lastDistance,
                        rotate: r(t.lastDirection, f)
                    },
                    midpoint: h
                }), t.lastDistance = p, t.lastDirection = f, t.lastMidpoint = h);
            }
        },
        touchend: function(e, t, n) {
            if (n.identifier === e.touch2) e.touch2 = null; else {
                if (n.identifier !== e.touch1) return;
                e.touch1 = e.touch2, e.touch2 = null;
            }
            (e.scaled || e.rotated) && e.emitEvent("transformend", {
                absolute: {
                    scale: e.lastDistance / e.startDistance,
                    rotate: r(e.startDirection, e.lastDirection)
                },
                relative: {
                    scale: 1,
                    rotate: 0
                },
                midpoint: e.lastMidpoint
            }), e.switchTo(b);
        }
    }, b = {
        name: "afterTransformState",
        touchstart: function(e, t, n) {
            e.switchTo(y, t, n);
        },
        touchend: function(e, t, n) {
            n.identifier === e.touch1 && e.switchTo(m);
        }
    };
    return e;
}();

define("shared/js/gesture_detector", function() {}), define("iframe_shims", [ "shared/js/gesture_detector" ], function() {
    function e(e, o, a, r, c, l) {
        var d = 0, u = a.offsetWidth - d, h = document.createElement("div");
        h.setAttribute("style", "padding: 0; border-width: 0; margin: 0; overflow: hidden;"), 
        h.style.width = u + "px";
        var p = document.createElement("iframe");
        p.setAttribute("sandbox", "allow-same-origin"), p.setAttribute("style", "padding: 0; border-width: 0; margin: 0; overflow: hidden; transform-origin: top " + ("rtl" === document.documentElement.dir ? "right" : "left") + "; " + "pointer-events: none;"), 
        s.tapTransform && (p.style.transform = "scale(1)"), p.style.width = u + "px", h.appendChild(p), 
        a.insertBefore(h, r), p.contentDocument.open(), p.contentDocument.write("<!doctype html><html><head>"), 
        p.contentDocument.write(i), p.contentDocument.write("</head><body>"), p.contentDocument.write(e), 
        p.contentDocument.write("</body>"), p.contentDocument.close();
        var f = p.contentDocument.body, m = f.scrollWidth, g = f.scrollHeight, v = Math.min(1, u / m), _ = s.initialScale || v, y = _, b = y, x = 0;
        h.style.width = Math.ceil(m * y) + "px", h.style.height = Math.ceil(g * y) + "px", 
        p.style.width = m + "px";
        var S = function(e) {
            if ("initial" === e || "poll" === e) {
                m = f.scrollWidth, g = f.scrollHeight;
                var t = v;
                v = Math.min(1, u / m), y === t && (y = v), p.style.width = m + "px", console.log("iframe_shims: recalculating height / width because", e, "sw", m, "sh", g, "bs", v);
            }
            console.log("iframe_shims: scale:", y), p.style.transform = "scale(" + y + ")", 
            p.style.height = g * Math.max(1, y) + d + "px", h.style.width = Math.ceil(m * y) + "px", 
            h.style.height = Math.ceil(g * y) + d + "px";
        };
        S("initial");
        var w, T, C = !1, E = function(e, t, n) {
            if (e !== y && (_ = e, w = t, T = n, !C)) {
                C = !0;
                var i = o.scrollTop - R, a = o.scrollLeft, r = t + a, c = n + i, l = e / y, d = Math.ceil(c * l), u = Math.ceil(r * l);
                y = e, S("zoom"), o.scrollTop = d + R - n, o.scrollLeft = u - t, window.setTimeout(A, s.zoomDelayMS);
            }
        }, A = function() {
            C = !1, y !== _ && window.requestAnimationFrame(function() {
                console.log("delayed zoomFrame timeout, probably causing a mem-spike"), E(_, w, T);
            });
        }, k = null, I = 0, O = function() {
            var e = s, t = f.scrollWidth, n = f.scrollHeight, i = !1;
            (t > m || n > g) && (S("poll"), i = !0), k = ++I < e.resizeLimit ? window.setTimeout(O, i ? e.didResizePollIntervalMS : e.noResizePollIntervalMS) : null;
        };
        k = window.setTimeout(O, s.initialResizePollIntervalMS);
        var M = {
            iframe: p,
            resizeHandler: function() {
                I = 0, k && window.clearTimeout(k), k = window.setTimeout(O, s.pictureDelayPollIntervalMS);
            }
        };
        if ("interactive" !== c) return M;
        var D = h, L = new n(D);
        L.startDetecting(), l && (h.removeEventListener("click", l), t(h, l, null, p));
        var N = document.getElementsByClassName("msg-reader-header")[0], B = document.getElementsByClassName("msg-envelope-bar")[0], R = N.clientHeight + B.clientHeight;
        D.addEventListener("dbltap", function(e) {
            var t = y;
            if (b === _) {
                switch (x = (x + 1) % 3) {
                  case 0:
                    t = v;
                    break;

                  case 1:
                    t = 1;
                    break;

                  case 2:
                    t = 2;
                }
                console.log("already in double-tap, deciding on new scale", t);
            } else _ > 1 ? (t = b, x = 0) : (t = 2, x = 2), console.log("user was not in double-tap switching to double-tap with", t);
            b = t;
            try {
                E(t, e.detail.clientX, e.detail.clientY);
            } catch (n) {
                console.error("zoom bug!", n, "\n", n.stack);
            }
        });
        var F = !1;
        return D.addEventListener("transformend", function() {
            F = !1;
        }), D.addEventListener("transform", function(e) {
            if (!F) {
                var t = e.detail.absolute.scale, n = _;
                if (t > 1.15) if (F = !0, 1 > _) n = 1; else if (1.5 > _) n = 1.5; else {
                    if (!(2 > _)) return;
                    n = 2;
                } else {
                    if (!(.9 > t)) return;
                    if (F = !0, _ > 1.5) n = 1.5; else if (_ > 1) n = 1; else {
                        if (!(_ > v)) return;
                        n = v;
                    }
                }
                E(n, e.detail.midpoint.clientX, e.detail.midpoint.clientY);
            }
        }), M;
    }
    function t(e, t, n, i) {
        var s, o, a, r, c, l, d, u, h, p, f, m, g, v, _, y, b;
        i ? (a = document.getElementsByClassName("scrollregion-horizontal-too")[0], r = document.getElementsByClassName("msg-reader-header")[0], 
        c = document.getElementsByClassName("msg-envelope-bar")[0], l = document.getElementsByClassName("msg-attachments-container")[0], 
        y = document.getElementsByClassName("msg-reader-load-infobar")[0], d = document.getElementsByClassName("msg-body-container")[0], 
        _ = window.getComputedStyle(d), f = parseInt(_.marginTop), m = parseInt(_.marginLeft), 
        u = r.clientHeight, h = c.clientHeight, s = "tap", v = i.contentDocument) : s = "click", 
        e.addEventListener(s, function(e) {
            if (i) {
                b = y.clientHeight, p = l.clientHeight, _ = window.getComputedStyle(l), g = p ? parseInt(_.marginTop) : 0;
                var s, r, c = i.style.transform || "scale(1)", d = c.match(/(\d|\.)+/g)[0];
                s = e.detail.clientX + a.scrollLeft - m, r = e.detail.clientY + a.scrollTop - u - h - b - p - g - f, 
                o = v.elementFromPoint(s / d, r / d);
            } else o = e.originalTarget;
            for (;o !== n; ) {
                if ("A" === o.nodeName && o.hasAttribute("ext-href")) return t(e, o, o.getAttribute("ext-href"), o.textContent), 
                e.preventDefault(), e.stopPropagation(), void 0;
                o = o.parentNode;
            }
        });
    }
    var n = window.GestureDetector, i = '<style type="text/css">\nblockquote {margin: 0; -moz-border-start: 0.2rem solid gray;padding: 0; -moz-padding-start: 0.5rem; }\nhtml, body { max-width: 120rem; word-wrap: break-word; overflow: hidden; padding: 0; margin: 0; }\npre { white-space: pre-wrap; word-wrap: break-word; }\n.moz-external-link { color: #00aac5; cursor: pointer; }\n</style>', s = {
        zoomDelayMS: 200,
        initialScale: null,
        resizeLimit: 4,
        initialResizePollIntervalMS: 200,
        noResizePollIntervalMS: 250,
        didResizePollIntervalMS: 300,
        pictureDelayPollIntervalMS: 200
    };
    return {
        createAndInsertIframeForContent: e,
        bindSanitizedClickHandler: t,
        iframeShimsOpts: s
    };
}), define("cards/editor_mixins", [ "require" ], function() {
    return {
        _bindEditor: function(e) {
            this._editorNode = e;
        },
        populateEditor: function(e) {
            for (var t = e.split("\n"), n = document.createDocumentFragment(), i = 0, s = t.length; s > i; i++) i && n.appendChild(document.createElement("br")), 
            n.appendChild(document.createTextNode(t[i]));
            this._editorNode.appendChild(n);
        },
        fromEditor: function() {
            for (var e = "", t = this._editorNode.childNodes.length, n = 0; t > n; n++) {
                var i = this._editorNode.childNodes[n];
                e += "BR" === i.nodeName && "_moz" !== i.getAttribute("type") ? "\n" : i.textContent;
            }
            return e;
        }
    };
}), define("tmpl!cards/fld/folder_item.html", [ "tmpl" ], function(e) {
    return e.toDom('<a class="fld-folder-item">\n  <span class="selected-indicator"></span>\n  <span dir="auto" class="fld-folder-name"></span>\n  <span class="fld-folder-unread"></span>\n</a>');
}), define("tmpl!cards/fld/account_item.html", [ "tmpl" ], function(e) {
    return e.toDom('<a class="fld-account-item">\n  <span class="selected-indicator"></span>\n  <span dir="auto" class="fld-account-name"></span>\n</a>');
}), define("css", {
    load: function(e, t, n, i) {
        if (i.isBuild) return n();
        var s = document.createElement("link");
        s.type = "text/css", s.rel = "stylesheet", s.href = t.toUrl(e + ".css"), s.addEventListener("load", n, !1), 
        document.head.appendChild(s);
    }
}), define("template!cards/folder_picker.html", [ "template" ], function(e) {
    return {
        createdCallback: e.templateCreatedCallback,
        template: e.objToFn({
            id: "cards/folder_picker.html",
            deps: [],
            text: '<!-- Our card does not have a header of its own; it reuses the message_list\'s\n     header.  We want to steal clicks on its menu button too, hence this node\n     and fld-header-back which is a transparent button that overlays the menu\n     button. -->\n<div class="fld-header-placeholder" data-statuscolor="default">\n  <button data-l10n-id="drawer-back"\n          data-event="click:_closeCard"\n          class="fld-header-back">BacK</button>\n</div>\n<!-- Backing semi-opaque layer for everything below the header so that\n     anything that the folder drawer does not cover looks inactive-ish.\n     Clicking on this makes the drawer go away. -->\n<div data-event="click:_closeCard" class="fld-shield"></div>\n<!-- This exists to clip fld-content so that when it animates in/out using\n     translateY it doesn\'t paint over-top of the header. -->\n<div class="fld-content-container">\n  <!-- This is the actual drawer thing that slides up/down using translateY.\n       -->\n  <div class="fld-content">\n    <!-- Scrollable container holds everything but the non-scrolling settings\n         button. -->\n    <div class="fld-acct-scrollouter">\n      <!-- Combo-box style widget that shows the current account name when\n           collapsed and the fld-acct-header-account-header label when\n           expanded.  The actual items live in fld-accountlist-container\n           for animation reasons; see below. -->\n      <a data-prop="accountHeader"\n         data-event="click:toggleAccounts"\n         class="fld-acct-header closed" role="region">\n        <!--\n          The &nbsp; is on purpose, so that initial height measurement of the\n          element be correct even before this element has real content.\n        -->\n        <span class="fld-acct-header-account-label">&nbsp;</span>\n        <span class="fld-acct-header-account-header"\n              data-l10n-id="drawer-accounts-header">AccountS</span>\n        <span class="fld-account-switch-arrow"></span>\n      </a>\n      <!-- Exists to clip fld-acct-container which uses translateY to hide the\n           list of accounts in negative-space until the account list is\n           opened.  This has an explicit height style set based on whether the\n           list of accounts is displayed or not because fld-acct-scrollinner\n           will always have the same height for layout purposes because the\n           translateY hiding does not affect layout. -->\n      <div data-prop="fldAcctScrollInner" class="fld-acct-scrollinner">\n        <!-- The list of all accounts and the folders for the current account.\n             As noted above, translateY is used to hide the list of accounts\n             when we don\'t want to be displaying it. -->\n        <div data-prop="fldAcctContainer" class="fld-acct-container">\n          <!-- The list of accounts -->\n          <div data-prop="accountListContainer"\n               class="fld-accountlist-container">\n          </div>\n          <!-- The list of folders for the current account. -->\n          <div data-prop="foldersContainer"\n               class="fld-folders-container">\n          </div>\n        </div>\n      </div>\n    </div>\n    <!-- settings button; always present; does not scroll -->\n    <a data-event="click:onShowSettings" class="fld-nav-toolbar bottom-toolbar">\n      <span class="fld-settings-link" data-l10n-id="drawer-settings-link">SettingS</span>\n    </a>\n  </div>\n</div>\n'
        })
    };
}), define("cards/folder_picker", [ "require", "tmpl!./fld/folder_item.html", "tmpl!./fld/account_item.html", "folder_depth_classes", "cards", "model", "evt", "css!style/folder_cards", "./base", "template!./folder_picker.html" ], function(e) {
    var t = e("tmpl!./fld/folder_item.html"), n = e("tmpl!./fld/account_item.html"), i = e("folder_depth_classes"), s = e("cards"), o = e("model"), a = e("evt");
    return e("css!style/folder_cards"), [ e("./base")(e("template!./folder_picker.html")), {
        createdCallback: function() {
            this.bindContainerHandler(this.foldersContainer, "click", this.onClickFolder.bind(this)), 
            this.updateAccount = this.updateAccount.bind(this), o.latest("account", this.updateAccount), 
            this.bindContainerHandler(this.accountListContainer, "click", this.onClickAccount.bind(this)), 
            this.addEventListener("transitionend", this.onTransitionEnd.bind(this));
            var e = o.getAccountCount();
            e > 1 && (this.classList.remove("one-account"), this.currentAccountContainerHeight = this.accountHeader.getBoundingClientRect().height * e, 
            this.hideAccounts()), this.acctsSlice = o.api.viewAccounts(!1), this.acctsSlice.onsplice = this.onAccountsSplice.bind(this), 
            this.acctsSlice.onchange = this.onAccountsChange.bind(this);
        },
        extraClasses: [ "anim-vertical", "anim-overlay", "one-account" ],
        onShowSettings: function() {
            s.pushCard("settings_main", "animate");
        },
        updateAccount: function(e) {
            var t = this.curAccount;
            this.mostRecentSyncTimestamp = 0, t !== e && (this.foldersContainer.innerHTML = "", 
            o.latestOnce("folder", function(t) {
                this.curAccount = e, this.querySelector(".fld-acct-header-account-label").textContent = e.name, 
                this.curFolder || (this.curFolder = t), this.foldersSlice && (this.foldersSlice.onsplice = null, 
                this.foldersSlice.onchange = null), this.foldersSlice = o.foldersSlice, this.onFoldersSplice(0, 0, this.foldersSlice.items, !0, !1), 
                this.foldersSlice.onsplice = this.onFoldersSplice.bind(this);
            }.bind(this)));
        },
        onClickAccount: function(e) {
            var t = this.curAccount.id, n = e.account.id;
            this.curAccount = e.account, t !== n && (this._waitingAccountId = n, this._closeCard());
        },
        toggleAccounts: function() {
            var e = this.fldAcctContainer.classList.contains("animated");
            e || (this.fldAcctContainer.classList.add("animated"), this.fldAcctContainer.clientWidth), 
            this.accountHeader.classList.contains("closed") ? this.showAccounts() : this.hideAccounts();
        },
        showAccounts: function() {
            var e = this.currentAccountContainerHeight;
            this.fldAcctScrollInner.style.height = e + this.foldersContainer.getBoundingClientRect().height + "px", 
            this.fldAcctContainer.style.transform = "translateY(0)", this.accountHeader.classList.remove("closed");
        },
        hideAccounts: function() {
            var e = this.foldersContainer.getBoundingClientRect().height;
            e && (this.fldAcctScrollInner.style.height = e + "px"), this.fldAcctContainer.style.transform = "translateY(-" + this.currentAccountContainerHeight + "px)", 
            this.accountHeader.classList.add("closed");
        },
        onAccountsSplice: function(e, t, i) {
            var s = this.accountListContainer, o = this.acctsSlice.items.length + i.length - t;
            this.classList.toggle("one-account", 1 >= o);
            var a;
            if (t) for (var r = e + t - 1; r >= e; r--) a = this.acctsSlice.items[r], a.element && s.removeChild(a.element);
            var c = e >= s.childElementCount ? null : s.children[e];
            i.forEach(function(e) {
                var t = e.element = n.cloneNode(!0);
                t.account = e, this.updateAccountDom(e, !0), s.insertBefore(t, c);
            }.bind(this)), this.currentAccountContainerHeight = this.accountHeader.getBoundingClientRect().height * s.children.length, 
            this.hideAccounts();
        },
        onAccountsChange: function(e) {
            this.updateAccountDom(e, !1);
        },
        updateAccountDom: function(e, t) {
            var n = e.element;
            t && (n.querySelector(".fld-account-name").textContent = e.name, this.curAccount && this.curAccount.id === e.id && n.classList.add("fld-account-selected"));
        },
        onFoldersSplice: function(e, n, i) {
            var s, o = this.foldersContainer;
            if (n) for (var a = e + n - 1; a >= e; a--) s = this.foldersSlice.items[a], o.removeChild(s.element);
            var r = e >= o.childElementCount ? null : o.children[e], c = this;
            i.forEach(function(e) {
                var n = e.element = t.cloneNode(!0);
                n.folder = e, c.updateFolderDom(e, !0), o.insertBefore(n, r);
            });
        },
        updateFolderDom: function(e, t) {
            var n = e.element;
            if (t) {
                e.selectable || n.classList.add("fld-folder-unselectable");
                var s = Math.min(i.length - 1, e.depth);
                n.classList.add(i[s]), s > 0 && n.classList.add("fld-folder-depthnonzero"), n.querySelector(".fld-folder-name").textContent = e.name, 
                n.dataset.type = e.type;
            }
            e === this.curFolder ? n.classList.add("fld-folder-selected") : n.classList.remove("fld-folder-selected");
        },
        onClickFolder: function(e) {
            var t = e.folder;
            if (t.selectable) {
                var n = this.curFolder;
                this.curFolder = t, this.updateFolderDom(n), this.updateFolderDom(t), this._showFolder(t), 
                this._closeCard();
            }
        },
        onTransitionEnd: function(e) {
            !this.classList.contains("opened") && e.target.classList.contains("fld-content") && (s.removeCardAndSuccessors(this, "none"), 
            this._waitingAccountId && (o.changeAccountFromId(this._waitingAccountId, function() {
                o.selectInbox();
            }), this._waitingAccountId = null));
        },
        _closeCard: function() {
            a.emit("folderPickerClosing"), this.classList.remove("opened");
        },
        _showFolder: function(e) {
            o.changeFolder(e);
        },
        onCardVisible: function() {
            this.classList.add("opened");
        },
        die: function() {
            this.acctsSlice.die(), o.removeListener("account", this.updateAccount);
        }
    } ];
});