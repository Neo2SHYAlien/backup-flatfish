define([ "require" ], function() {
    function e(e) {
        function t(e, t) {
            for (var n in t) e[n] = t[n];
            return e;
        }
        if (!e.formElem) throw new Error("The form element should be defined.");
        var n = this;
        this.options = t({
            formElem: null,
            checkFormValidity: function() {
                return n.options.formElem.checkValidity();
            },
            onLast: function() {}
        }, e), this.options.formElem.addEventListener("keypress", this.onKeyPress.bind(this)), 
        this.options.formElem.addEventListener("click", this.onClick.bind(this));
    }
    return e.prototype = {
        onKeyPress: function(e) {
            if (13 === e.keyCode) {
                var t = this.focusNextInput(e);
                !t && this.options.checkFormValidity() && this.options.onLast(e);
            }
        },
        onClick: function(e) {
            if ("reset" === e.target.type) for (var t = this.options.checkFormValidity(), n = this.options.formElem.getElementsByTagName("button"), i = 0; i < n.length; i++) {
                var s = n[i];
                "reset" !== s.type && (s.disabled = !t);
            }
        },
        focusNextInput: function(e) {
            for (var t = e.target, n = this.options.formElem.getElementsByTagName("input"), i = !1, s = 0; s < n.length; s++) {
                var o = n[s];
                if (t !== o) {
                    if (i && "hidden" !== o.type && "button" !== o.type && (o.focus(), document.activeElement === o)) return o;
                } else i = !0;
            }
            return t.blur(), null;
        }
    }, e;
});