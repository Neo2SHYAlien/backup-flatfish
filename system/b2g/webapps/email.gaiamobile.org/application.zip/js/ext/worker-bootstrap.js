function consoleHelper() {
    for (var e = arguments[0] + ":", t = 1; t < arguments.length; t++) e += " " + arguments[t];
    e += "[0m\n", dump(e);
}

var requirejs, require, define;

(function(global, undef) {
    function hasProp(e, t) {
        return hasOwn.call(e, t);
    }
    function getOwn(e, t) {
        return e && hasProp(e, t) && e[t];
    }
    function eachProp(e, t) {
        var n;
        for (n in e) if (hasProp(e, n) && t(e[n], n)) break;
    }
    function mixin(e, t, n, i) {
        return t && eachProp(t, function(t, o) {
            (n || !hasProp(e, o)) && (!i || "object" != typeof t || !t || Array.isArray(t) || "function" == typeof t || t instanceof RegExp ? e[o] = t : (e[o] || (e[o] = {}), 
            mixin(e[o], t, n, i)));
        }), e;
    }
    function getGlobal(e) {
        if (!e) return e;
        var t = global;
        return e.split(".").forEach(function(e) {
            t = t[e];
        }), t;
    }
    function newContext(e) {
        function t(e) {
            var t, n, i = e.length;
            for (t = 0; i > t; t++) if (n = e[t], "." === n) e.splice(t, 1), t -= 1; else if (".." === n) {
                if (1 === t && (".." === e[2] || ".." === e[0])) break;
                t > 0 && (e.splice(t - 1, 2), t -= 2);
            }
        }
        function n(e, n, i) {
            var o, s, r, a, c, l, d, u, p, h, f, m = n && n.split("/"), g = m, v = M.map, _ = v && v["*"];
            if (e && "." === e.charAt(0) && (n ? (g = m.slice(0, m.length - 1), e = e.split("/"), 
            d = e.length - 1, M.nodeIdCompat && jsSuffixRegExp.test(e[d]) && (e[d] = e[d].replace(jsSuffixRegExp, "")), 
            e = g.concat(e), t(e), e = e.join("/")) : 0 === e.indexOf("./") && (e = e.substring(2))), 
            i && v && (m || _)) {
                r = e.split("/");
                e: for (a = r.length; a > 0; a -= 1) {
                    if (l = r.slice(0, a).join("/"), m) for (c = m.length; c > 0; c -= 1) if (s = getOwn(v, m.slice(0, c).join("/")), 
                    s && (s = getOwn(s, l))) {
                        u = s, p = a;
                        break e;
                    }
                    !h && _ && getOwn(_, l) && (h = getOwn(_, l), f = a);
                }
                !u && h && (u = h, p = f), u && (r.splice(0, p, u), e = r.join("/"));
            }
            return o = getOwn(M.pkgs, e), o ? o : e;
        }
        function i(e) {
            function t() {
                var t;
                return e.init && (t = e.init.apply(global, arguments)), t || e.exports && getGlobal(e.exports);
            }
            return t;
        }
        function o(e) {
            var t, n, i, o;
            for (t = 0; t < queue.length; t += 1) {
                if ("string" != typeof queue[t][0]) {
                    if (!e) break;
                    queue[t].unshift(e), e = undef;
                }
                i = queue.shift(), n = i[0], t -= 1, hasProp(C, n) || hasProp(O, n) || (hasProp(L, n) ? S.apply(undef, i) : O[n] = i);
            }
            e && (o = getOwn(M.shim, e) || {}, S(e, o.deps || [], o.exportsFn));
        }
        function s(e, t) {
            var i = function(n, s, r, a) {
                var c, l;
                if (t && o(), "string" == typeof n) {
                    if (A[n]) return A[n](e);
                    if (c = w(n, e, !0).id, !hasProp(C, c)) throw new Error("Not loaded: " + c);
                    return C[c];
                }
                return n && !Array.isArray(n) && (l = n, n = undef, Array.isArray(s) && (n = s, 
                s = r, r = a), t) ? i.config(l)(n, s, r) : (s = s || function() {}, prim.nextTick(function() {
                    o(), S(undef, n || [], s, r, e);
                }), i);
            };
            return i.isBrowser = "undefined" != typeof document && "undefined" != typeof navigator, 
            i.nameToUrl = function(e, t, n) {
                var o, s, r, a, c, l, d, u = getOwn(M.pkgs, e);
                if (u && (e = u), d = getOwn(j, e)) return i.nameToUrl(d, t, n);
                if (urlRegExp.test(e)) c = e + (t || ""); else {
                    for (o = M.paths, s = e.split("/"), r = s.length; r > 0; r -= 1) if (a = s.slice(0, r).join("/"), 
                    l = getOwn(o, a)) {
                        Array.isArray(l) && (l = l[0]), s.splice(0, r, l);
                        break;
                    }
                    c = s.join("/"), c += t || (/^data\:|\?/.test(c) || n ? "" : ".js"), c = ("/" === c.charAt(0) || c.match(/^[\w\+\.\-]+:/) ? "" : M.baseUrl) + c;
                }
                return M.urlArgs ? c + ((-1 === c.indexOf("?") ? "?" : "&") + M.urlArgs) : c;
            }, i.toUrl = function(t) {
                var o, s = t.lastIndexOf("."), r = t.split("/")[0], a = "." === r || ".." === r;
                return -1 !== s && (!a || s > 1) && (o = t.substring(s, t.length), t = t.substring(0, s)), 
                i.nameToUrl(n(t, e), o, !0);
            }, i.defined = function(t) {
                return hasProp(C, w(t, e, !0).id);
            }, i.specified = function(t) {
                return t = w(t, e, !0).id, hasProp(C, t) || hasProp(L, t);
            }, i;
        }
        function r(e, t, n) {
            e && (C[e] = n, requirejs.onResourceLoad && requirejs.onResourceLoad(I, t.map, t.deps)), 
            t.finished = !0, t.resolve(n);
        }
        function a(e, t) {
            e.finished = !0, e.rejected = !0, e.reject(t);
        }
        function c(e) {
            return function(t) {
                return n(t, e, !0);
            };
        }
        function l(e) {
            var t = e.map.id, n = e.factory.apply(C[t], e.values);
            t ? n === undef && (e.cjsModule ? n = e.cjsModule.exports : e.usingExports && (n = C[t])) : N.splice(N.indexOf(e), 1), 
            r(t, e, n);
        }
        function d(e, t) {
            this.rejected || this.depDefined[t] || (this.depDefined[t] = !0, this.depCount += 1, 
            this.values[t] = e, this.depending || this.depCount !== this.depMax || l(this));
        }
        function u(e) {
            var t = {};
            return t.promise = prim(function(e, n) {
                t.resolve = e, t.reject = n;
            }), t.map = e ? w(e, null, !0) : {}, t.depCount = 0, t.depMax = 0, t.values = [], 
            t.depDefined = [], t.depFinished = d, t.map.pr && (t.deps = [ w(t.map.pr) ]), t;
        }
        function p(e) {
            var t;
            return e ? (t = hasProp(L, e) && L[e], t || (t = L[e] = u(e))) : (t = u(), N.push(t)), 
            t;
        }
        function h(e, t) {
            return function(n) {
                e.rejected || (n.dynaId || (n.dynaId = "id" + (U += 1), n.requireModules = [ t ]), 
                a(e, n));
            };
        }
        function f(e, t, n, i) {
            n.depMax += 1, T(e, t).then(function(e) {
                n.depFinished(e, i);
            }, h(n, e.id)).catch(h(n, n.map.id));
        }
        function m(e) {
            function t(t) {
                n || r(e, p(e), t);
            }
            var n;
            return t.error = function(t) {
                p(e).reject(t);
            }, t.fromText = function(t, i) {
                var s = p(e), r = w(w(e).n), c = r.id;
                n = !0, s.factory = function(e, t) {
                    return t;
                }, i && (t = i), hasProp(M.config, e) && (M.config[c] = M.config[e]);
                try {
                    x.exec(t);
                } catch (l) {
                    a(s, new Error("fromText eval for " + c + " failed: " + l));
                }
                o(c), s.deps = [ r ], f(r, null, s, s.deps.length);
            }, t;
        }
        function g(e, t, n) {
            e.load(t.n, s(n), m(t.id), {});
        }
        function v(e) {
            var t, n = e ? e.indexOf("!") : -1;
            return n > -1 && (t = e.substring(0, n), e = e.substring(n + 1, e.length)), [ t, e ];
        }
        function _(e, t, n) {
            var i = e.map.id;
            t[i] = !0, !e.finished && e.deps && e.deps.forEach(function(i) {
                var o = i.id, s = !hasProp(A, o) && p(o);
                !s || s.finished || n[o] || (hasProp(t, o) ? e.deps.forEach(function(t, n) {
                    t.id === o && e.depFinished(C[o], n);
                }) : _(s, t, n));
            }), n[i] = !0;
        }
        function y(e) {
            var t, n = [], i = 1e3 * M.waitSeconds, o = i && P + i < new Date().getTime();
            0 === F && (e ? e.finished || _(e, {}, {}) : N.length && N.forEach(function(e) {
                _(e, {}, {});
            })), o ? (eachProp(L, function(e) {
                e.finished || n.push(e.map.id);
            }), t = new Error("Timeout for modules: " + n), t.requireModules = n, x.onError(t)) : (F || N.length) && (E || (E = !0, 
            prim.nextTick(function() {
                E = !1, y();
            })));
        }
        function b(e) {
            prim.nextTick(function() {
                e.dynaId && H[e.dynaId] || (H[e.dynaId] = !0, x.onError(e));
            });
        }
        var x, S, w, T, A, E, k, I, C = {}, O = {}, M = {
            waitSeconds: 7,
            baseUrl: "./",
            paths: {},
            bundles: {},
            pkgs: {},
            shim: {},
            config: {}
        }, D = {}, N = [], L = {}, R = {}, B = {}, F = 0, P = new Date().getTime(), U = 0, H = {}, q = {}, j = {};
        return k = "function" == typeof importScripts ? function(e) {
            var t = e.url;
            q[t] || (q[t] = !0, p(e.id), importScripts(t), o(e.id));
        } : function(e) {
            var t, n = e.id, i = e.url;
            q[i] || (q[i] = !0, t = document.createElement("script"), t.setAttribute("data-requiremodule", n), 
            t.type = M.scriptType || "text/javascript", t.charset = "utf-8", t.async = !0, F += 1, 
            t.addEventListener("load", function() {
                F -= 1, o(n);
            }, !1), t.addEventListener("error", function() {
                F -= 1;
                var e, i = getOwn(M.paths, n), o = getOwn(L, n);
                i && Array.isArray(i) && i.length > 1 ? (t.parentNode.removeChild(t), i.shift(), 
                o.map = w(n), k(o.map)) : (e = new Error("Load failed: " + n + ": " + t.src), e.requireModules = [ n ], 
                p(n).reject(e));
            }, !1), t.src = i, document.head.appendChild(t));
        }, T = function(e, t) {
            var n, i, o = e.id, s = M.shim[o];
            if (hasProp(O, o)) n = O[o], delete O[o], S.apply(undef, n); else if (!hasProp(L, o)) if (e.pr) {
                if (!(i = getOwn(j, o))) return T(w(e.pr)).then(function(e) {
                    var n = w(o, t, !0), i = n.id, s = getOwn(M.shim, i);
                    return hasProp(B, i) || (B[i] = !0, s && s.deps ? x(s.deps, function() {
                        g(e, n, t);
                    }) : g(e, n, t)), p(i).promise;
                });
                e.url = x.nameToUrl(i), k(e);
            } else s && s.deps ? x(s.deps, function() {
                k(e);
            }) : k(e);
            return p(o).promise;
        }, w = function(e, t, i) {
            if ("string" != typeof e) return e;
            var o, s, r, a, l, d = e + " & " + (t || "") + " & " + !!i;
            return r = v(e), a = r[0], e = r[1], !a && hasProp(D, d) ? D[d] : (a && (a = n(a, t, i), 
            o = hasProp(C, a) && C[a]), a ? e = o && o.normalize ? o.normalize(e, c(t)) : n(e, t, i) : (e = n(e, t, i), 
            r = v(e), a = r[0], e = r[1], s = x.nameToUrl(e)), l = {
                id: a ? a + "!" + e : e,
                n: e,
                pr: a,
                url: s
            }, a || (D[d] = l), l);
        }, A = {
            require: function(e) {
                return s(e);
            },
            exports: function(e) {
                var t = C[e];
                return "undefined" != typeof t ? t : C[e] = {};
            },
            module: function(e) {
                return {
                    id: e,
                    uri: "",
                    exports: A.exports(e),
                    config: function() {
                        return getOwn(M.config, e) || {};
                    }
                };
            }
        }, S = function(e, t, n, i, o) {
            if (!e || !hasProp(R, e)) {
                R[e] = !0;
                var s = p(e);
                t && !Array.isArray(t) && (n = t, t = []), s.promise.catch(i || b), o = o || e, 
                "function" == typeof n ? (!t.length && n.length && (n.toString().replace(commentRegExp, "").replace(cjsRequireRegExp, function(e, n) {
                    t.push(n);
                }), t = (1 === n.length ? [ "require" ] : [ "require", "exports", "module" ]).concat(t)), 
                s.factory = n, s.deps = t, s.depending = !0, t.forEach(function(n, i) {
                    var r;
                    t[i] = r = w(n, o, !0), n = r.id, "require" === n ? s.values[i] = A.require(e) : "exports" === n ? (s.values[i] = A.exports(e), 
                    s.usingExports = !0) : "module" === n ? s.values[i] = s.cjsModule = A.module(e) : void 0 === n ? s.values[i] = void 0 : f(r, o, s, i);
                }), s.depending = !1, s.depCount === s.depMax && l(s)) : e && r(e, s, n), P = new Date().getTime(), 
                e || y(s);
            }
        }, x = s(null, !0), x.config = function(t) {
            if (t.context && t.context !== e) return newContext(t.context).config(t);
            D = {}, t.baseUrl && "/" !== t.baseUrl.charAt(t.baseUrl.length - 1) && (t.baseUrl += "/");
            var n, o = M.shim, s = {
                paths: !0,
                bundles: !0,
                config: !0,
                map: !0
            };
            return eachProp(t, function(e, t) {
                s[t] ? (M[t] || (M[t] = {}), mixin(M[t], e, !0, !0)) : M[t] = e;
            }), t.bundles && eachProp(t.bundles, function(e, t) {
                e.forEach(function(e) {
                    e !== t && (j[e] = t);
                });
            }), t.shim && (eachProp(t.shim, function(e, t) {
                Array.isArray(e) && (e = {
                    deps: e
                }), !e.exports && !e.init || e.exportsFn || (e.exportsFn = i(e)), o[t] = e;
            }), M.shim = o), t.packages && t.packages.forEach(function(e) {
                var t, n;
                e = "string" == typeof e ? {
                    name: e
                } : e, n = e.name, t = e.location, t && (M.paths[n] = e.location), M.pkgs[n] = e.name + "/" + (e.main || "main").replace(currDirRegExp, "").replace(jsSuffixRegExp, "");
            }), n = M.definePrim, n && (O[n] = [ n, [], function() {
                return prim;
            } ]), (t.deps || t.callback) && x(t.deps, t.callback), x;
        }, x.onError = function(e) {
            throw e;
        }, I = {
            id: e,
            defined: C,
            waiting: O,
            config: M,
            deferreds: L
        }, contexts[e] = I, x;
    }
    var prim, topReq, dataMain, src, subPath, bootstrapConfig = requirejs || require, hasOwn = Object.prototype.hasOwnProperty, contexts = {}, queue = [], currDirRegExp = /^\.\//, urlRegExp = /^\/|\:|\?|\.js$/, commentRegExp = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/gm, cjsRequireRegExp = /[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g, jsSuffixRegExp = /\.js$/;
    "function" != typeof requirejs && (function() {
        function e() {
            a = 0;
            var e = l;
            for (l = []; e.length; ) e.shift()();
        }
        function t(t) {
            l.push(t), a || (a = setTimeout(e, 0));
        }
        function n(e) {
            e();
        }
        function i(e) {
            var t = typeof e;
            return "object" === t || "function" === t;
        }
        function o(e, t) {
            prim.nextTick(function() {
                e.forEach(function(e) {
                    e(t);
                });
            });
        }
        function s(e, t, n) {
            e.hasOwnProperty("v") ? prim.nextTick(function() {
                n(e.v);
            }) : t.push(n);
        }
        function r(e, t, n) {
            e.hasOwnProperty("e") ? prim.nextTick(function() {
                n(e.e);
            }) : t.push(n);
        }
        var a, c, l = [];
        c = "function" == typeof setImmediate ? setImmediate.bind() : "undefined" != typeof process && process.nextTick ? process.nextTick : "undefined" != typeof setTimeout ? t : n, 
        prim = function d(e) {
            function t() {
                function e(e, l, d) {
                    if (!a) {
                        if (a = !0, n === e) return a = !1, s.reject(new TypeError("value is same promise")), 
                        void 0;
                        try {
                            var u = e && e.then;
                            i(e) && "function" == typeof u ? (r = t(), u.call(e, r.resolve, r.reject)) : (c[l] = e, 
                            o(d, e));
                        } catch (p) {
                            a = !1, s.reject(p);
                        }
                    }
                }
                var s, r, a = !1;
                return s = {
                    resolve: function(t) {
                        e(t, "v", l);
                    },
                    reject: function(t) {
                        e(t, "e", u);
                    }
                };
            }
            var n, a, c = {}, l = [], u = [];
            a = t(), n = {
                then: function(e, t) {
                    var n = d(function(n, i) {
                        function o(e, t, o) {
                            try {
                                e && "function" == typeof e ? (o = e(o), n(o)) : t(o);
                            } catch (s) {
                                i(s);
                            }
                        }
                        s(c, l, o.bind(void 0, e, n)), r(c, u, o.bind(void 0, t, i));
                    });
                    return n;
                },
                "catch": function(e) {
                    return n.then(null, e);
                }
            };
            try {
                e(a.resolve, a.reject);
            } catch (p) {
                a.reject(p);
            }
            return n;
        }, prim.resolve = function(e) {
            return prim(function(t) {
                t(e);
            });
        }, prim.reject = function(e) {
            return prim(function(t, n) {
                n(e);
            });
        }, prim.cast = function(e) {
            return i(e) && "then" in e ? e : prim(function(t, n) {
                e instanceof Error ? n(e) : t(e);
            });
        }, prim.all = function(e) {
            return prim(function(t, n) {
                function i(e, n) {
                    r[e] = n, o += 1, o === s && t(r);
                }
                var o = 0, s = e.length, r = [];
                e.forEach(function(e, t) {
                    prim.cast(e).then(function(e) {
                        i(t, e);
                    }, function(e) {
                        n(e);
                    });
                });
            });
        }, prim.nextTick = c;
    }(), requirejs = topReq = newContext("_"), "function" != typeof require && (require = topReq), 
    topReq.exec = function(text) {
        return eval(text);
    }, topReq.contexts = contexts, define = function() {
        queue.push([].slice.call(arguments, 0));
    }, define.amd = {
        jQuery: !0
    }, bootstrapConfig && topReq.config(bootstrapConfig), topReq.isBrowser && !contexts._.config.skipDataMain && (dataMain = document.querySelectorAll("script[data-main]")[0], 
    dataMain = dataMain && dataMain.getAttribute("data-main"), dataMain && (dataMain = dataMain.replace(jsSuffixRegExp, ""), 
    bootstrapConfig && bootstrapConfig.baseUrl || (src = dataMain.split("/"), dataMain = src.pop(), 
    subPath = src.length ? src.join("/") + "/" : "./", topReq.config({
        baseUrl: subPath
    })), topReq([ dataMain ]))));
})(this), define("alameda", function() {});

var window = self;

window.console = {
    log: consoleHelper.bind(null, "[32mWLOG"),
    error: consoleHelper.bind(null, "[31mWERR"),
    info: consoleHelper.bind(null, "[36mWINF"),
    warn: consoleHelper.bind(null, "[33mWWAR")
}, require([ "worker-setup" ]), define("worker-bootstrap", function() {}), function(e) {
    requirejs.config({
        baseUrl: ".",
        packages: [ {
            name: "wo-imap-handler",
            location: "ext/imap-handler/src",
            main: "imap-handler"
        } ],
        map: {
            browserbox: {
                axe: "axeshim-browserbox"
            },
            "browserbox-imap": {
                axe: "axeshim-browserbox"
            },
            "ext/smtpclient": {
                axe: "axeshim-smtpclient"
            }
        },
        paths: {
            bleach: "ext/bleach.js/lib/bleach",
            "imap-formal-syntax": "ext/imap-handler/src/imap-formal-syntax",
            "smtpclient-response-parser": "ext/smtpclient/src/smtpclient-response-parser",
            tests: "../test/unit",
            wbxml: "ext/activesync-lib/wbxml/wbxml",
            "activesync/codepages": "ext/activesync-lib/codepages",
            "activesync/protocol": "ext/activesync-lib/protocol",
            "activesync-lib": "ext/activesync-lib",
            addressparser: "ext/addressparser",
            alameda: "ext/alameda",
            axe: "ext/axe",
            "axe-logger": "ext/axe-logger",
            "axeshim-browserbox": "ext/axeshim-browserbox",
            "axeshim-smtpclient": "ext/axeshim-smtpclient",
            "bleach.js": "ext/bleach.js",
            browserbox: "ext/browserbox",
            "browserbox-imap": "ext/browserbox-imap",
            evt: "ext/evt",
            "imap-handler": "ext/imap-handler",
            mailbuild: "ext/mailbuild",
            md5: "ext/md5",
            mimefuncs: "ext/mimefuncs",
            mimeparser: "ext/mimeparser",
            "mimeparser-tzabbr": "ext/mimeparser-tzabbr",
            mimetypes: "ext/mimetypes",
            mix: "ext/mix",
            punycode: "ext/punycode",
            rdcommon: "ext/rdcommon",
            "safe-base64": "ext/safe-base64",
            smtpclient: "ext/smtpclient",
            stringencoding: "ext/stringencoding",
            "tcp-socket": "ext/tcp-socket",
            utf7: "ext/utf7",
            wmsy: "ext/wmsy",
            "wo-utf7": "ext/wo-utf7"
        },
        waitSeconds: 0
    }), "string" == typeof gelamWorkerBaseUrl && requirejs.config({
        baseUrl: gelamWorkerBaseUrl
    }), e.setZeroTimeout = function(e) {
        setTimeout(function() {
            e();
        }, 0);
    };
}(this), define("worker-config", function() {}), define("worker-router", [], function() {
    function e(e) {
        var t = e.data, n = r[t.type];
        n && n(t);
    }
    function t(e) {
        delete r[e];
    }
    function n(e, t) {
        return r[e] = t, function(t, n) {
            window.postMessage({
                type: e,
                uid: null,
                cmd: t,
                args: n
            });
        };
    }
    function i(e) {
        if (a.hasOwnProperty(e)) return a[e];
        r[e] = function(e) {
            var n = t[e.uid];
            n && (delete t[e.uid], n.apply(n, e.args));
        };
        var t = {}, n = 0, i = function(i, o, s) {
            s && (t[n] = s), window.postMessage({
                type: e,
                uid: n++,
                cmd: i,
                args: o
            });
        };
        return a[e] = i, i;
    }
    function o(e) {
        var t = 0, n = {};
        return r[e] = function(e) {
            var t = n[e.uid];
            t && t(e);
        }, {
            register: function(i) {
                var o = t++;
                return n[o] = i, {
                    sendMessage: function(t, n, i) {
                        window.postMessage({
                            type: e,
                            uid: o,
                            cmd: t,
                            args: n
                        }, i);
                    },
                    unregister: function() {
                        delete n[o];
                    }
                };
            }
        };
    }
    function s() {
        window.removeEventListener("message", e), r = {}, a = {};
    }
    var r = {};
    window.addEventListener("message", e);
    var a = {};
    return {
        registerSimple: n,
        registerCallbackType: i,
        registerInstanceType: o,
        unregister: t,
        shutdown: s
    };
}), define("rdcommon/deferred", [], function() {
    var e = 1, t = {}, n = null, i = function(i) {
        var o = this;
        this.id = e++, this.name = i, this.stack = new Error().stack, this.promise = new Promise(function(e, i) {
            o.resolve = function(n) {
                delete t[o.id], o.resolved = !0, o.value = n, e(n);
            }, o.reject = function(e) {
                o.promise.catch(function(e) {
                    n && n(e);
                }), delete t[o.id], o.rejected = !0, o.value = e, i(e);
            };
        }), t[this.id] = this, this.value = null, this.resolved = !1, this.rejected = !1;
    };
    return i.prototype.toString = function() {
        return "<Deferred " + (this.name || "") + ">";
    }, i.setUnhandledRejectionHandler = function(e) {
        n = e;
    }, i.getAllActiveDeferreds = function() {
        var e = [];
        for (var n in t) e.push(t[n]);
        return e;
    }, i.clearActiveDeferreds = function() {
        t = {};
    }, i;
}), define("rdcommon/microtime", [ "require" ], function() {
    return window && window.performance && window.performance.now ? {
        now: function() {
            return 1e3 * window.performance.now();
        }
    } : {
        now: function() {
            return 1e3 * Date.now();
        }
    };
}), define("rdcommon/extransform", [ "require", "exports" ], function(e, t) {
    function n(e) {
        if (!e) return e;
        if (e.length > 96) {
            var t = e.lastIndexOf("/");
            if (-1 !== t) return e.substring(t + 1);
        }
        return i && e.substring(0, i.length) === i ? e.substring(i.length) : e;
    }
    var i;
    Error.prepareStackTrace = function(e, t) {
        for (var i = [], o = 0; o < t.length; o++) {
            var s = t[o];
            i.push({
                filename: n(s.getFileName()),
                lineNo: s.getLineNumber(),
                funcName: s.getFunctionName()
            });
        }
        return i;
    }, Error.captureStackTrace || (Error.captureStackTrace = function(e) {
        try {
            throw new Error();
        } catch (t) {
            for (var i, s = t.stack.split("\n"), r = e.stack = [], a = 0; a < s.length; a++) (i = o.exec(s[a])) && r.push({
                filename: n(i[2]),
                lineNo: i[3],
                funcName: i[1]
            });
        }
    }), t.gimmeStack = function() {
        var e = {};
        return Error.captureStackTrace(e), e.stack.slice(2);
    };
    var o = /^(.*)@(.+):(\d+)$/;
    t.transformException = function(e) {
        if (!(e instanceof Error || e && "object" == typeof e && "stack" in e)) return {
            n: "Object",
            m: "" + e,
            f: []
        };
        var t = e.stack;
        if (Array.isArray(t)) return {
            n: e.name,
            m: e.message,
            f: t
        };
        var i = {
            n: e.name,
            m: e.message,
            f: []
        };
        if (t) for (var s, r = t.split("\n"), a = i.f, c = 0; c < r.length; c++) (s = o.exec(r[c])) && a.push({
            filename: n(s[2]),
            lineNo: s[3],
            funcName: s[1]
        }); else e.filename && i.f.push({
            filename: e.filename,
            lineNo: e.lineNumber,
            funcName: ""
        });
        return i;
    };
}), define("rdcommon/log", [ "./deferred", "./microtime", "./extransform", "exports" ], function(e, t, n, i) {
    function o() {}
    function s(e, t, n) {
        if (null == e || "object" != typeof e) return e;
        n || (n = 0);
        var i = n + 1, o = 64;
        if (t && "tostring" === t) {
            if (Array.isArray(e)) return e.join("");
            if ("string" != typeof e) return e.toString();
        }
        var r = {};
        for (var a in e) {
            var c = e[a];
            switch (typeof c) {
              case "string":
                r[a] = o && c.length > o ? "OMITTED STRING, originally " + c.length + " bytes long" : c;
                break;

              case "object":
                r[a] = null == c || Array.isArray(c) || "toJSON" in c || n >= 2 ? c : s(c, null, i);
                break;

              default:
                r[a] = c;
            }
        }
        return r;
    }
    function r(e, t, n) {
        var i, o = 0, s = 0, r = n - 1;
        "toJSON" in e && (e = e.toJSON()), "toJSON" in t && (t = t.toJSON());
        for (i in e) {
            if (o++, !(i in t)) return !1;
            if (n) {
                if (!a(e[i], t[i], r)) return !1;
            } else if (e[i] !== t[i]) return !1;
        }
        for (i in t) s++;
        return o !== s ? !1 : !0;
    }
    function a(e, t, n) {
        var i = typeof e, o = typeof t;
        if ("object" !== i || o !== i || null == e || null == t) return e === t;
        if (e === t) return !0;
        if (Array.isArray(e)) {
            if (!Array.isArray(t)) return !1;
            if (e.length !== t.length) return !1;
            for (var s = 0; s < e.length; s++) if (!a(e[s], t[s], n - 1)) return !1;
            return !0;
        }
        return r(e, t, n);
    }
    function c(e) {
        return function() {
            this._ignore || (this._ignore = {}), this._ignore[e] = !0;
        };
    }
    function l(e, t) {
        this.moduleFab = e, this.name = t, this._latchedVars = [];
        var n = this.dummyProto = Object.create(v);
        n.__defName = t, n.__latchedVars = this._latchedVars, n.__FAB = this.moduleFab;
        var i = this.logProto = Object.create(_);
        i.__defName = t, i.__latchedVars = this._latchedVars, i.__FAB = this.moduleFab;
        var o = this.testLogProto = Object.create(y);
        o.__defName = t, o.__latchedVars = this._latchedVars, o.__FAB = this.moduleFab;
        var s = this.testActorProto = Object.create(S);
        s.__defName = t, this._definedAs = {};
    }
    function d(e, t, n) {
        var i = (t._testActors, t._rawDefs);
        for (var o in n) {
            var s, r, a = n[o];
            i[o] = a;
            for (s in a) if (-1 === T.indexOf(s)) throw new Error("key '" + s + "' is not a legal log def key");
            var c = new l(t, o);
            if ("semanticIdent" in a && c.useSemanticIdent(a.semanticIdent), "stateVars" in a) for (s in a.stateVars) c.addStateVar(s);
            if ("latchState" in a) for (s in a.latchState) c.addLatchedState(s);
            if ("events" in a) {
                var d = null;
                "TEST_ONLY_events" in a && (d = a.TEST_ONLY_events);
                for (s in a.events) r = null, d && d.hasOwnProperty(s) && (r = d[s]), c.addEvent(s, a.events[s], r);
            }
            if ("asyncJobs" in a) {
                var u = null;
                "TEST_ONLY_asyncJobs" in a && (u = a.TEST_ONLY_asyncJobs);
                for (s in a.asyncJobs) r = null, u && u.hasOwnProperty(s) && (r = u[s]), c.addAsyncJob(s, a.asyncJobs[s], r);
            }
            if ("calls" in a) {
                var p = null;
                "TEST_ONLY_calls" in a && (p = a.TEST_ONLY_calls);
                for (s in a.calls) r = null, p && p.hasOwnProperty(s) && (r = p[s]), c.addCall(s, a.calls[s], r);
            }
            if ("errors" in a) for (s in a.errors) c.addError(s, a.errors[s]);
            c.makeFabs();
        }
        return t;
    }
    var u = n.gimmeStack, p = function() {
        return u().slice(2);
    }, h = 0;
    i.getCurrentSeq = function() {
        return h;
    };
    var f = 1, m = -1, g = i.ThingProto = {
        get digitalName() {
            return this.__diginame;
        },
        set digitalName(e) {
            this.__diginame = e;
        },
        toString: function() {
            return "[Thing:" + this.__type + "]";
        },
        toJSON: function() {
            var e = {
                type: this.__type,
                name: this.__name,
                dname: this.__diginame,
                uniqueName: this._uniqueName
            };
            return this.__hardcodedFamily && (e.family = this.__hardcodedFamily), e;
        }
    };
    i.__makeThing = function(e, t, n, i) {
        var o;
        return void 0 === i && (i = g), o = Object.create(i), o.__type = e, o.__name = t, 
        o.__diginame = n, o.__hardcodedFamily = null, o._uniqueName = m--, o;
    };
    var v = {
        _kids: void 0,
        logLevel: "dummy",
        toString: function() {
            return "[DummyLog]";
        },
        toJSON: function() {
            throw new Error("I WAS NOT PLANNING ON BEING SERIALIZED");
        },
        __die: o,
        __updateIdent: o
    }, _ = {
        _named: null,
        logLevel: "safe",
        toJSON: function() {
            var e = {
                loggerIdent: this.__defName,
                semanticIdent: this._ident,
                uniqueName: this._uniqueName,
                born: this._born,
                died: this._died,
                events: this._eventMap,
                entries: this._entries,
                kids: this._kids
            };
            if (this.__latchedVars.length) {
                for (var t = this.__latchedVars, n = {}, i = 0; i < t.length; i++) n[t[i]] = this[":" + t[i]];
                e.latched = n;
            }
            return this._named && (e.named = this._named), e;
        },
        __die: function() {
            this._died = t.now(), this.__FAB._onDeath && this.__FAB._onDeath(this);
        },
        __updateIdent: function(e) {
            if (Array.isArray(e)) {
                for (var t = [], n = 0; n < e.length; n++) {
                    var i = e[n];
                    "object" != typeof i || null == i ? t.push(i) : t.push(i._uniqueName);
                }
                e = t;
            }
            this._ident = e;
        }
    }, y = Object.create(_);
    y.logLevel = "dangerous", y.__unexpectedEntry = function(e, t) {
        var n = [ "!unexpected", t ];
        this._entries[e] = n;
    }, y.__mismatchEntry = function(e, t, n) {
        var i = [ "!mismatch", t, n ];
        this._entries[e] = i;
    }, y.__failedExpectation = function(e) {
        var n = [ "!failedexp", e, t.now(), h++ ];
        this._entries.push(n);
    }, y.__die = function() {
        this._died = t.now();
        var e = this._actor;
        e && (e._expectDeath && (e._expectDeath = !1, e.__loggerFired()), e._lifecycleListener && e._lifecycleListener.call(null, "dead", this.__instance, this));
    };
    var b = "(died)", x = [ b ], S = {
        toString: function() {
            return "[Actor " + this.__defName + ": " + this.__name + "]";
        },
        toJSON: function() {
            return {
                actorIdent: this.__defName,
                semanticIdent: this.__name,
                uniqueName: this._uniqueName,
                parentUniqueName: this._parentUniqueName,
                loggerUniqueName: this._logger ? this._logger._uniqueName : null
            };
        },
        __attachToLogger: function(e) {
            e._actor = this, this._logger = e, this._lifecycleListener && this._lifecycleListener.call(null, "attach", e.__instance, e);
        },
        attachLifecycleListener: function(e) {
            this._lifecycleListener = e;
        },
        asyncEventsAreComingDoNotResolve: function() {
            if (!this._activeForTestStep) throw new Error("Attempt to set expectations on an actor (" + this.__defName + ": " + this.__name + ") that is not " + "participating in this test step!");
            if (this._resolved) throw new Error("Attempt to add expectations when already resolved!");
            if (this._expectDeath) throw new Error("death expectation incompatible with async events");
            this._expectDeath = !0;
        },
        asyncEventsAllDoneDoResolve: function() {
            this._expectDeath = !1, this.__loggerFired();
        },
        expectNothing: function() {
            if (this._expectations.length) throw new Error("Already expecting something this turn! " + JSON.stringify(this._expectations[0]));
            this._expectNothing = !0;
        },
        expectOnly__die: function() {
            if (!this._activeForTestStep) throw new Error("Attempt to set expectations on an actor (" + this.__defName + ": " + this.__name + ") that is not " + "participating in this test step!");
            if (this._resolved) throw new Error("Attempt to add expectations when already resolved!");
            if (this._expectDeath) throw new Error("Already expecting our death!  Are you using asyncEventsAreComingDoNotResolve?");
            this._expectDeath = !0;
        },
        expectUseSetMatching: function() {
            this._unorderedSetMode = !0;
        },
        __prepForTestStep: function(e) {
            this._logger || e.reportPendingActor(this), this._activeForTestStep && this.__resetExpectations(), 
            this._activeForTestStep = !0, this._logger && (this._iEntry = this._logger._entries.length);
        },
        __waitForExpectations: function() {
            return this._expectNothing && (this._expectations.length || this._iExpectation) ? !1 : this._expectationsMetSoFar ? this._iExpectation >= this._expectations.length && (this._expectDeath ? this._logger && this._logger._died : !0) ? (this._resolved = !0, 
            this._expectationsMetSoFar) : (this._deferred || (this._deferred = new e()), this._deferred.promise) : !1;
        },
        __stepCleanup: null,
        __resetExpectations: function() {
            this.__stepCleanup && this.__stepCleanup();
            var e = this._expectationsMetSoFar;
            return this._expectationsMetSoFar = !0, this._iExpectation = 0, this._ignore = null, 
            this._expectations.splice(0, this._expectations.length), this._expectNothing = !1, 
            this._expectDeath = !1, this._unorderedSetMode = !1, this._deferred = null, this._resolved = !1, 
            this._activeForTestStep = !1, e;
        },
        __failUnmetExpectations: function() {
            if (this._iExpectation < this._expectations.length && this._logger) for (var e = this._iExpectation; e < this._expectations.length; e++) this._logger.__failedExpectation(this._expectations[e]);
            this._expectDeath && !this._logger._died && this._logger.__failedExpectation(x);
        },
        __loggerFired: function() {
            var e, t, n = this._logger._entries;
            if (this._unorderedSetMode) {
                for (;this._iExpectation < this._expectations.length && this._iEntry < n.length; ) if (t = n[this._iEntry++], 
                !("!" === t[0][0] || this._ignore && this._ignore.hasOwnProperty(t[0]))) {
                    for (var i = !1, o = this._iExpectation; o < this._expectations.length; o++) if (e = this._expectations[o], 
                    e[0] === t[0] && this["_verify_" + e[0]](e, t)) {
                        o !== this._iExpectation && (this._expectations[o] = this._expectations[this._iExpectation], 
                        this._expectations[this._iExpectation] = e), this._iExpectation++, i = !0;
                        break;
                    }
                    i || (this._logger.__unexpectedEntry(this._iEntry - 1, t), this._expectationsMetSoFar = !1, 
                    this._deferred && this._deferred.reject([ this.__defName, e, t ]));
                }
                return this._iExpectation === this._expectations.length && n.length > this._iEntry ? (this._expectationsMetSoFar = !1, 
                this._logger.__unexpectedEntry(this._iEntry, n[this._iEntry]), this._iEntry++) : this._iExpectation >= this._expectations.length && this._deferred && (this._expectDeath ? this._logger && this._logger._died : !0) && (this._resolved = !0, 
                this._deferred.resolve()), void 0;
            }
            for (;this._iExpectation < this._expectations.length && this._iEntry < n.length; ) if (e = this._expectations[this._iExpectation], 
            t = n[this._iEntry++], !("!" === t[0][0] || this._ignore && this._ignore.hasOwnProperty(t[0]))) {
                if (e[0] !== t[0]) this._logger.__unexpectedEntry(this._iEntry - 1, t); else {
                    if (this["_verify_" + e[0]](e, t)) {
                        this._iExpectation++;
                        continue;
                    }
                    this._logger.__mismatchEntry(this._iEntry - 1, e, t), this._iExpectation++;
                }
                return this._expectationsMetSoFar && (this._expectationsMetSoFar = !1, this._deferred && this._deferred.reject([ this.__defName, e, t ])), 
                void 0;
            }
            this._activeForTestStep && (this._expectations.length && this._iExpectation === this._expectations.length && n.length > this._iEntry || !this._expectations.length && this._expectNothing) && (this._ignore && this._ignore.hasOwnProperty(n[this._iEntry][0]) || (this._expectationsMetSoFar = !1, 
            this._logger.__unexpectedEntry(this._iEntry, n[this._iEntry])), this._iEntry++), 
            this._iExpectation >= this._expectations.length && this._deferred && (this._expectDeath ? this._logger && this._logger._died : !0) && (this._resolved = !0, 
            this._deferred.resolve());
        }
    };
    i.TestActorProtoBase = S;
    var w = 6;
    i.smartCompareEquiv = a, l.prototype = {
        _define: function(e, t) {
            if (this._definedAs.hasOwnProperty(e)) throw new Error("Attempt to define '" + e + "' as a " + t + " when it is already defined as a " + this._definedAs[e] + "!");
            this._definedAs[e] = t;
        },
        _wrapLogProtoForTest: function(e) {
            var t = this.logProto[e];
            this.testLogProto[e] = function() {
                var e = t.apply(this, arguments), n = this._actor;
                return n && n.__loggerFired(), e;
            };
        },
        addStateVar: function(e) {
            this._define(e, "state"), this.dummyProto[e] = o;
            var n = ":" + e;
            this.logProto[e] = function(i) {
                var o = this[n];
                o !== i && (this[n] = i, this._entries.push([ e, i, t.now(), h++ ]));
            }, this._wrapLogProtoForTest(e), this.testActorProto["expect_" + e] = function(t) {
                if (!this._activeForTestStep) throw new Error("Attempt to set expectations on an actor (" + this.__defName + ": " + this.__name + ") that is not " + "participating in this test step!");
                if (this._resolved) throw new Error("Attempt to add expectations when already resolved!");
                return this._ignore && this._ignore[e] || this._expectations.push([ e, p(), t ]), 
                this;
            }, this.testActorProto["ignore_" + e] = c(e), this.testActorProto["_verify_" + e] = function(e, t) {
                return a(e[2], t[1], w);
            };
        },
        addLatchedState: function(e) {
            this._define(e, "latchedState"), this._latchedVars.push(e);
            var t = ":" + e;
            this.testLogProto[e] = this.logProto[e] = this.dummyProto[e] = function(e) {
                this[t] = e;
            };
        },
        addEvent: function(e, i, o) {
            this._define(e, "event");
            var r = 0, l = [];
            for (var d in i) r++, l.push(i[d]);
            if (this.dummyProto[e] = function() {
                this._eventMap[e] = (this._eventMap[e] || 0) + 1;
            }, this.logProto[e] = function() {
                this._eventMap[e] = (this._eventMap[e] || 0) + 1;
                for (var i = [ e ], o = 0; r > o; o++) if (l[o] === C) {
                    var s = arguments[o];
                    i.push(n.transformException(s));
                } else i.push(arguments[o]);
                i.push(t.now()), i.push(h++), this._entries.push(i);
            }, o) {
                var u = 0, f = [];
                for (d in o) u++, f.push(o[d]);
                this.testLogProto[e] = function() {
                    this._eventMap[e] = (this._eventMap[e] || 0) + 1;
                    var i, o = [ e ];
                    for (i = 0; r > i; i++) if (l[i] === C) {
                        var a = arguments[i];
                        o.push(n.transformException(a));
                    } else o.push(arguments[i]);
                    o.push(t.now()), o.push(h++);
                    for (var c = 0; u > c; c++, i++) o.push(s(arguments[i], f[c]));
                    this._entries.push(o);
                    var d = this._actor;
                    d && d.__loggerFired();
                };
            } else this._wrapLogProtoForTest(e);
            this.testActorProto["expect_" + e] = function() {
                if (!this._activeForTestStep) throw new Error("Attempt to set expectations on an actor (" + this.__defName + ": " + this.__name + ") that is not " + "participating in this test step!");
                if (this._resolved) throw new Error("Attempt to add expectations when already resolved!");
                for (var t = [ e, p() ], n = 0; n < arguments.length; n++) l[n] && l[n] !== C && t.push(arguments[n]);
                return this._ignore && this._ignore[e] || this._expectations.push(t), this;
            }, this.testActorProto["ignore_" + e] = c(e), this.testActorProto["_verify_" + e] = function(e, t) {
                for (var n = 2; n < e.length; n++) if (!a(e[n], t[n - 1], w)) return !1;
                return !0;
            };
        },
        addAsyncJob: function(e, i, r) {
            var l = e + "_begin", d = e + "_end";
            this.dummyProto[l] = o, this.dummyProto[d] = o;
            var u = 0, f = 0, m = [], g = [];
            for (var v in i) u++, m.push(i[v]);
            if (this.logProto[l] = function() {
                this._eventMap[l] = (this._eventMap[l] || 0) + 1;
                for (var e = [ l ], i = 0; u > i; i++) if (m[i] === C) {
                    var o = arguments[i];
                    e.push(n.transformException(o));
                } else e.push(arguments[i]);
                e.push(t.now()), e.push(h++), this._entries.push(e);
            }, this.logProto[d] = function() {
                this._eventMap[d] = (this._eventMap[d] || 0) + 1;
                for (var e = [ d ], i = 0; u > i; i++) if (m[i] === C) {
                    var o = arguments[i];
                    e.push(n.transformException(o));
                } else e.push(arguments[i]);
                e.push(t.now()), e.push(h++), this._entries.push(e);
            }, r) {
                for (v in r) f++, g.push(r[v]);
                this.testLogProto[l] = function() {
                    this._eventMap[l] = (this._eventMap[l] || 0) + 1;
                    for (var e = [ l ], i = 0; u > i; i++) if (m[i] === C) {
                        var o = arguments[i];
                        e.push(n.transformException(o));
                    } else e.push(arguments[i]);
                    e.push(t.now()), e.push(h++);
                    for (var r = 0; f > r; r++, i++) e.push(s(arguments[i], g[r]));
                    this._entries.push(e);
                    var a = this._actor;
                    a && a.__loggerFired();
                }, this.testLogProto[d] = function() {
                    this._eventMap[d] = (this._eventMap[d] || 0) + 1;
                    for (var e = [ d ], i = 0; u > i; i++) if (m[i] === C) {
                        var o = arguments[i];
                        e.push(n.transformException(o));
                    } else e.push(arguments[i]);
                    e.push(t.now()), e.push(h++);
                    for (var r = 0; f > r; r++, i++) e.push(s(arguments[i], g[r]));
                    this._entries.push(e);
                    var a = this._actor;
                    a && a.__loggerFired();
                };
            } else this._wrapLogProtoForTest(l), this._wrapLogProtoForTest(d);
            this.testActorProto["expect_" + l] = function() {
                if (!this._activeForTestStep) throw new Error("Attempt to set expectations on an actor (" + this.__defName + ": " + this.__name + ") that is not " + "participating in this test step!");
                if (this._resolved) throw new Error("Attempt to add expectations when already resolved!");
                for (var e = [ l, p() ], t = 0; t < arguments.length; t++) m[t] && m[t] !== C && e.push(arguments[t]);
                return this._ignore && this._ignore[l] || this._expectations.push(e), this;
            }, this.testActorProto["ignore_" + l] = c(l), this.testActorProto["expect_" + d] = function() {
                if (!this._activeForTestStep) throw new Error("Attempt to set expectations on an actor (" + this.__defName + ": " + this.__name + ") that is not " + "participating in this test step!");
                if (this._resolved) throw new Error("Attempt to add expectations when already resolved!");
                for (var e = [ d, p() ], t = 0; t < arguments.length; t++) m[t] && m[t] !== C && e.push(arguments[t]);
                return this._ignore && this._ignore[d] || this._expectations.push(e), this;
            }, this.testActorProto["ignore_" + d] = c(d), this.testActorProto["_verify_" + l] = this.testActorProto["_verify_" + d] = function(e, t) {
                for (var n = 2; n < e.length; n++) if (!a(e[n], t[n - 1], w)) return !1;
                return !0;
            };
        },
        addCall: function(e, i, o) {
            this._define(e, "call");
            var r = 0, l = 0, d = [], u = [];
            for (var f in i) r++, d.push(i[f]);
            if (this.dummyProto[e] = function() {
                var t;
                try {
                    t = arguments[r + 1].apply(arguments[r], Array.prototype.slice.call(arguments, r + 2));
                } catch (n) {
                    this._eventMap[e] = (this._eventMap[e] || 0) + 1, t = n;
                }
                return t;
            }, this.logProto[e] = function() {
                var i, o, s = [ e ];
                for (o = 0; r > o; o++) s.push(arguments[o]);
                s.push(t.now()), s.push(h++), this._entries.push(s);
                try {
                    i = arguments[r + 1].apply(arguments[r], Array.prototype.slice.call(arguments, o + 2)), 
                    s.push(t.now()), s.push(h++), s.push(null);
                } catch (a) {
                    s.push(t.now()), s.push(h++), s.push(n.transformException(a)), this._eventMap[e] = (this._eventMap[e] || 0) + 1, 
                    i = a;
                }
                return i;
            }, o) {
                for (f in o) l++, u.push(o[f]);
                this.testLogProto[e] = function() {
                    var i, o, a = [ e ];
                    for (o = 0; r > o; o++) a.push(arguments[o]);
                    a.push(t.now()), a.push(h++), this._entries.push(a);
                    try {
                        i = arguments[r + 1].apply(arguments[r], Array.prototype.slice.call(arguments, o + 2)), 
                        a.push(t.now()), a.push(h++), a.push(null), o += 2;
                        for (var c = 0; l > c; c++, o++) a.push(s(arguments[o], u[c]));
                    } catch (d) {
                        a.push(t.now()), a.push(h++), a.push(n.transformException(d)), o += 2;
                        for (var c = 0; l > c; c++, o++) a.push(s(arguments[o], u[c]));
                        this._eventMap[e] = (this._eventMap[e] || 0) + 1, i = d;
                    }
                    var p = this._actor;
                    return p && p.__loggerFired(), i;
                };
            } else this._wrapLogProtoForTest(e);
            this.testActorProto["expect_" + e] = function() {
                if (!this._activeForTestStep) throw new Error("Attempt to set expectations on an actor (" + this.__defName + ": " + this.__name + ") that is not " + "participating in this test step!");
                if (this._resolved) throw new Error("Attempt to add expectations when already resolved!");
                for (var t = [ e, p() ], n = 0; n < arguments.length; n++) d[n] && t.push(arguments[n]);
                return this._ignore && this._ignore[e] || this._expectations.push(t), this;
            }, this.testActorProto["ignore_" + e] = c(e), this.testActorProto["_verify_" + e] = function(e, t) {
                if (t.length > r + l + 6) return !1;
                for (var n = 2; n < e.length; n++) if (!a(e[n], t[n - 1], w)) return !1;
                return !0;
            };
        },
        addError: function(e, i) {
            this._define(e, "error");
            var o = 0, s = [];
            for (var r in i) o++, s.push(i[r]);
            this.dummyProto[e] = function() {
                this._eventMap[e] = (this._eventMap[e] || 0) + 1;
            }, this.logProto[e] = function() {
                this._eventMap[e] = (this._eventMap[e] || 0) + 1;
                for (var i = [ e ], r = 0; o > r; r++) if (s[r] === C) {
                    var a = arguments[r];
                    i.push(n.transformException(a));
                } else i.push(arguments[r]);
                i.push(t.now()), i.push(h++), this._entries.push(i);
            }, this._wrapLogProtoForTest(e), this.testActorProto["expect_" + e] = function() {
                if (!this._activeForTestStep) throw new Error("Attempt to set expectations on an actor (" + this.__defName + ": " + this.__name + ") that is not " + "participating in this test step!");
                if (this._resolved) throw new Error("Attempt to add expectations when already resolved!");
                for (var t = [ e ], n = 0; n < arguments.length; n++) s[n] && s[n] !== C && t.push(arguments[n]);
                return this._ignore && this._ignore[e] || this._expectations.push(t), this;
            }, this.testActorProto["ignore_" + e] = c(e), this.testActorProto["_verify_" + e] = function(e, t) {
                for (var n = 2; n < e.length; n++) if (!a(e[n], t[n - 1], w)) return !1;
                return !0;
            };
        },
        useSemanticIdent: function() {},
        makeFabs: function() {
            var e = this.moduleFab, n = function() {
                this._eventMap = {};
            };
            n.prototype = this.dummyProto;
            var i = function(e) {
                this.__updateIdent(e), this._uniqueName = f++, this._eventMap = {}, this._entries = [], 
                this._born = t.now(), this._died = null, this._kids = null;
            };
            i.prototype = this.logProto;
            var o = function(e) {
                i.call(this, e), this._actor = null;
            };
            o.prototype = this.testLogProto;
            var s = function(e, t) {
                this.__name = e, this._uniqueName = f++, this._parentUniqueName = t, this._logger = void 0, 
                this._ignore = null, this._expectations = [], this._expectationsMetSoFar = !0, this._expectNothing = !1, 
                this._expectDeath = !1, this._unorderedSetMode = !1, this._activeForTestStep = !1, 
                this._iEntry = this._iExpectation = 0, this._lifecycleListener = null;
            };
            s.prototype = this.testActorProto, this.moduleFab._actorCons[this.name] = s;
            var r = function a(t, s, r) {
                var c, l;
                if (l = e._underTest || a._underTest) {
                    if ("string" == typeof s) throw new Error("A string can't be a logger => not a valid parent");
                    c = new o(r), c.__instance = t, s = l.reportNewLogger(c, s);
                } else {
                    if (!e._generalLog && !o._generalLog) return new n();
                    c = new i(r);
                }
                return s && (void 0 === s._kids || (null === s._kids ? s._kids = [ c ] : s._kids.push(c))), 
                c;
            };
            this.moduleFab[this.name] = r;
        }
    };
    var T = [ "implClass", "type", "subtype", "topBilling", "semanticIdent", "dicing", "stateVars", "latchState", "events", "asyncJobs", "calls", "errors", "TEST_ONLY_calls", "TEST_ONLY_events", "TEST_ONLY_asyncJobs", "LAYER_MAPPING" ];
    i.__augmentFab = d;
    var A = [], E = !1, k = !1;
    i.register = function(e, t) {
        var n = {
            _generalLog: E,
            _underTest: k,
            _actorCons: {},
            _rawDefs: {},
            _onDeath: null
        };
        return A.push(n), d(e, n, t);
    }, i.provideSchemaForAllKnownFabs = function() {
        for (var e = {
            $v: 2
        }, t = 0; t < A.length; t++) {
            var n = A[t]._rawDefs;
            for (var i in n) e[i] = n[i];
        }
        return e;
    };
    var I = {
        reportNewLogger: function(e, t) {
            return t;
        }
    };
    i.enableGeneralLogging = function() {
        E = !0;
        for (var e = 0; e < A.length; e++) {
            var t = A[e];
            t._generalLog = !0;
        }
    }, i.DEBUG_markAllFabsUnderTest = function() {
        k = I;
        for (var e = 0; e < A.length; e++) {
            var t = A[e];
            t._underTest = I;
        }
    }, i.DEBUG_realtimeLogEverything = function(e) {
        var t = {
            reportNewLogger: function(t, n) {
                return t._actor = {
                    __loggerFired: function() {
                        var n = t._entries[t._entries.length - 1];
                        e(t.__defName + "(" + t._ident + ")" + JSON.stringify(n) + "\n");
                    }
                }, n;
            }
        };
        k = t;
        for (var n = 0; n < A.length; n++) {
            var i = A[n];
            i._underTest = t;
        }
    }, i.DEBUG_dumpEntriesOnDeath = function(e) {
        e._generalLog = !0, e._onDeath = function(e) {
            console.log("!! DIED:", e.__defName, e._ident), console.log(JSON.stringify(e._entries, null, 2));
        };
    }, i.DEBUG_dumpAllFabEntriesOnDeath = function() {
        for (var e = 0; e < A.length; e++) {
            var t = A[e];
            i.DEBUG_dumpEntriesOnDeath(t);
        }
    }, i.CONNECTION = "connection", i.SERVER = "server", i.CLIENT = "client", i.TASK = "task", 
    i.DAEMON = "daemon", i.DATABASE = "database", i.CRYPTO = "crypto", i.QUERY = "query", 
    i.ACCOUNT = "account", i.LOGGING = "log", i.TEST_DRIVER = "testdriver", i.TEST_GROUP = "testgroup", 
    i.TEST_CASE = "testcase", i.TEST_PERMUTATION = "testperm", i.TEST_STEP = "teststep", 
    i.TEST_LAZY = "testlazy", i.TEST_SYNTHETIC_ACTOR = "test:synthactor";
    var C = i.EXCEPTION = "exception";
    i.JSONABLE = "jsonable", i.TOSTRING = "tostring", i.RAWOBJ_DATABIAS = "jsonable", 
    i.STATEREP = "staterep", i.STATEANNO = "stateanno", i.STATEDELTA = "statedelta";
}), define("util", [ "exports" ], function(e) {
    e.cmpHeaderYoungToOld = function(e, t) {
        var n = t.date - e.date;
        return n ? n : t.id - e.id;
    }, e.bsearchForInsert = function(e, t, n) {
        if (!e.length) return 0;
        for (var i, o, s = 0, r = e.length - 1; r >= s; ) if (i = s + Math.floor((r - s) / 2), 
        o = n(t, e[i]), 0 > o) r = i - 1; else {
            if (!(o > 0)) break;
            s = i + 1;
        }
        return 0 > o ? i : o > 0 ? i + 1 : i;
    }, e.bsearchMaybeExists = function(e, t, n, i, o) {
        for (var s, r, a = void 0 === i ? 0 : i, c = void 0 === o ? e.length - 1 : o; c >= a; ) if (s = a + Math.floor((c - a) / 2), 
        r = n(t, e[s]), 0 > r) c = s - 1; else {
            if (!(r > 0)) return s;
            a = s + 1;
        }
        return null;
    }, e.partitionMessagesByFolderId = function(e) {
        for (var t = [], n = {}, i = 0; i < e.length; i++) {
            var o = e[i], s = o.suid, r = s.lastIndexOf("/"), a = s.substring(0, r);
            if (n.hasOwnProperty(a)) n[a].push(o); else {
                var c = [ o ];
                t.push({
                    folderId: a,
                    messages: c
                }), n[a] = c;
            }
        }
        return t;
    }, e.formatAddresses = function(e) {
        for (var t = [], n = 0; n < e.length; n++) {
            var i = e[n];
            "string" == typeof i ? t.push(i) : i.name ? t.push('"' + i.name.replace(/["']/g, "") + '" <' + i.address + ">") : t.push(i.address);
        }
        return t.join(", ");
    };
}), define("evt", [], function() {
    function e() {
        this._events = {}, this._pendingEvents = {};
    }
    var t, n = Array.prototype.slice, i = [ "_events", "_pendingEvents", "on", "once", "latest", "latestOnce", "removeListener", "emitWhenListener", "emit" ];
    return e.prototype = {
        on: function(e, t) {
            var n = this._events[e], i = this._pendingEvents[e];
            return n || (n = this._events[e] = []), n.push(t), i && (i.forEach(function(e) {
                t.apply(null, e);
            }), delete this._pendingEvents[e]), this;
        },
        once: function(e, t) {
            function n() {
                o || (o = !0, t.apply(null, arguments), setTimeout(function() {
                    i.removeListener(e, n);
                }));
            }
            var i = this, o = !1;
            return this.on(e, n);
        },
        latest: function(e, t) {
            this[e] && !this._pendingEvents[e] && t(this[e]), this.on(e, t);
        },
        latestOnce: function(e, t) {
            this[e] && !this._pendingEvents[e] ? t(this[e]) : this.once(e, t);
        },
        removeListener: function(e, t) {
            var n, i = this._events[e];
            i && (n = i.indexOf(t), -1 !== n && i.splice(n, 1), 0 === i.length && delete this._events[e]);
        },
        emitWhenListener: function(e) {
            var t = this._events[e];
            t ? this.emit.apply(this, arguments) : (this._pendingEvents[e] || (this._pendingEvents[e] = []), 
            this._pendingEvents[e].push(n.call(arguments, 1)));
        },
        emit: function(e) {
            var t = n.call(arguments, 1), i = this._events[e];
            i && i.forEach(function(e) {
                try {
                    e.apply(null, t);
                } catch (n) {
                    setTimeout(function() {
                        throw n;
                    });
                }
            });
        }
    }, t = new e(), t.Emitter = e, t.mix = function(t) {
        var n = new e();
        return i.forEach(function(e) {
            if (t.hasOwnProperty(e)) throw new Error('Object already has a property "' + e + '"');
            t[e] = n[e];
        }), t;
    }, t;
}), define("mailchew-strings", [ "exports", "evt" ], function(e, t) {
    e.events = new t.Emitter(), e.set = function(t) {
        e.strings = t, e.events.emit("strings", t);
    };
}), define("date", [ "module", "exports" ], function(e, t) {
    t.BEFORE = function(e, t) {
        return t > e;
    }, t.ON_OR_BEFORE = function(e, t) {
        return t >= e;
    }, t.SINCE = function(e, t) {
        return e >= t;
    }, t.STRICTLY_AFTER = function(e, t) {
        return e > t;
    }, t.IN_BS_DATE_RANGE = function(e, t, n) {
        return e >= t && n > e;
    };
    var n = 1;
    t.TIME_DIR_AT_OR_BEYOND = function(e, t, i) {
        return e === n ? i >= t : null === i ? t >= s() : t >= i;
    }, t.TIME_DIR_DELTA = function(e, t, i) {
        return e === n ? t - i : i - t;
    }, t.TIME_DIR_ADD = function(e, t, i) {
        return e === n ? t + i : t - i;
    }, t.HOUR_MILLIS = 36e5;
    var i = t.DAY_MILLIS = 864e5, o = null;
    t.TEST_LetsDoTheTimewarpAgain = function(e) {
        return null === e ? (o = null, void 0) : ("number" != typeof e && (e = e.valueOf()), 
        o = e, void 0);
    };
    var s = t.NOW = function() {
        return o || Date.now();
    }, r = "undefined" != typeof performance ? performance : Date;
    t.PERFNOW = function() {
        return o || r.now();
    };
    var a = t.makeDaysAgo = function(e, t) {
        var n = c((o || Date.now()) + t) - e * i;
        return n;
    };
    t.makeDaysBefore = function(e, t, n) {
        return null === e ? a(t - 1, n) : c(e) - t * i;
    };
    var c = t.quantizeDate = function(e) {
        return null === e ? null : ("number" == typeof e && (e = new Date(e)), e.setUTCHours(0, 0, 0, 0).valueOf());
    };
    t.quantizeDateUp = function(e) {
        "number" == typeof e && (e = new Date(e));
        var t = e.setUTCHours(0, 0, 0, 0).valueOf();
        return e.valueOf() === t ? t : t + i;
    };
}), define("slice_bridge_proxy", [ "exports" ], function(e) {
    function t(e, t, n) {
        this._bridge = e, this._ns = t, this._handle = n, this.__listener = null, this.status = "synced", 
        this.progress = 0, this.atTop = !1, this.atBottom = !1, this.headerCount = 0, this.userCanGrowUpwards = !1, 
        this.userCanGrowDownwards = !1, this.pendingUpdates = [], this.scheduledUpdate = !1;
    }
    e.SliceBridgeProxy = t, t.prototype = {
        sendSplice: function(e, t, n, i, o, s) {
            var r = {
                index: e,
                howMany: t,
                addItems: n,
                requested: i,
                moreExpected: o,
                newEmailCount: s,
                headerCount: this.headerCount,
                type: "slice"
            };
            this.addUpdate(r);
        },
        sendUpdate: function(e) {
            var t = {
                updates: e,
                type: "update"
            };
            this.addUpdate(t);
        },
        sendStatus: function(e, t, n, i, o) {
            this.status = e, null != i && (this.progress = i), this.sendSplice(0, 0, [], t, n, o);
        },
        sendSyncProgress: function(e) {
            this.progress = e, this.sendSplice(0, 0, [], !0, !0);
        },
        addUpdate: function(e) {
            this.pendingUpdates.push(e), this.pendingUpdates.length > 5 ? this.flushUpdates() : this.scheduledUpdate || (window.setZeroTimeout(this.flushUpdates.bind(this)), 
            this.scheduledUpdate = !0);
        },
        flushUpdates: function() {
            this._bridge.__sendMessage({
                type: "batchSlice",
                handle: this._handle,
                status: this.status,
                progress: this.progress,
                atTop: this.atTop,
                atBottom: this.atBottom,
                userCanGrowUpwards: this.userCanGrowUpwards,
                userCanGrowDownwards: this.userCanGrowDownwards,
                sliceUpdates: this.pendingUpdates
            }), this.pendingUpdates = [], this.scheduledUpdate = !1;
        },
        die: function() {
            this.__listener && this.__listener.die();
        }
    };
}), define("mailbridge", [ "rdcommon/log", "./util", "./mailchew-strings", "./date", "./slice_bridge_proxy", "require", "module", "exports" ], function(e, t, n, i, o, s, r, a) {
    function c(e) {
        return e.toBridgeWire();
    }
    function l(e, t) {
        if (!t) return e.id;
        var n = e.getFolderMetaForFolderId(t.parentId);
        return l(e, n) + "!" + g[t.type] + "!" + t.name.toLocaleLowerCase();
    }
    function d(e, t) {
        return t > e ? -1 : e > t ? 1 : 0;
    }
    function u(e, t) {
        if (!e) return !1;
        for (var n = t.address, i = 0; i < e.length; i++) if (e[i].address === n) return !0;
        return !1;
    }
    function p(e, t) {
        this.universe = e, this.universe.registerBridge(this), this._LOG = v.MailBridge(this, e._LOG, t), 
        this._slices = {}, this._slicesByType = {
            accounts: [],
            identities: [],
            folders: [],
            headers: [],
            matchedHeaders: []
        }, this._observedBodies = {}, this._pendingRequests = {}, this._lastUndoableOpPair = null;
    }
    var h = t.bsearchForInsert, f = t.bsearchMaybeExists, m = o.SliceBridgeProxy, g = {
        account: "a",
        inbox: "c",
        starred: "e",
        important: "f",
        drafts: "g",
        localdrafts: "h",
        outbox: "i",
        queue: "j",
        sent: "k",
        junk: "l",
        trash: "n",
        archive: "p",
        normal: "z",
        nomail: "z"
    };
    a.MailBridge = p, p.prototype = {
        __sendMessage: function() {
            throw new Error("This is supposed to get hidden by an instance var.");
        },
        __receiveMessage: function(e) {
            var t = "_cmd_" + e.type;
            return t in this ? (this._LOG.cmd(e.type, this, this[t], e), void 0) : (this._LOG.badMessageType(e.type), 
            void 0);
        },
        _cmd_ping: function(e) {
            this.__sendMessage({
                type: "pong",
                handle: e.handle
            });
        },
        _cmd_modifyConfig: function(e) {
            this.universe.modifyConfig(e.mods);
        },
        bodyHasObservers: function(e) {
            return !!this._observedBodies[e];
        },
        notifyConfig: function(e) {
            this.__sendMessage({
                type: "config",
                config: e
            });
        },
        _cmd_debugSupport: function(e) {
            switch (e.cmd) {
              case "setLogging":
                this.universe.modifyConfig({
                    debugLogging: e.arg
                });
                break;

              case "dumpLog":
                switch (e.arg) {
                  case "storage":
                    this.universe.dumpLogToDeviceStorage();
                }
            }
        },
        _cmd_setInteractive: function() {
            this.universe.setInteractive();
        },
        _cmd_localizedStrings: function(e) {
            n.set(e.strings);
        },
        _cmd_learnAboutAccount: function(e) {
            this.universe.learnAboutAccount(e.details).then(function(t) {
                this.__sendMessage({
                    type: "learnAboutAccountResults",
                    handle: e.handle,
                    data: t
                });
            }.bind(this), function() {
                this.__sendMessage({
                    type: "learnAboutAccountResults",
                    handle: e.handle,
                    data: {
                        result: "no-config-info",
                        configInfo: null
                    }
                });
            }.bind(this));
        },
        _cmd_tryToCreateAccount: function(e) {
            var t = this;
            this.universe.tryToCreateAccount(e.details, e.domainInfo, function(n, i, o) {
                t.__sendMessage({
                    type: "tryToCreateAccountResults",
                    handle: e.handle,
                    account: i ? i.toBridgeWire() : null,
                    error: n,
                    errorDetails: o
                });
            });
        },
        _cmd_clearAccountProblems: function(e) {
            var t = this.universe.getAccountForAccountId(e.accountId), n = this;
            t.checkAccount(function(i, o) {
                function s(e) {
                    return !e || "bad-user-or-pass" !== e && "bad-address" !== e && "needs-oauth-reauth" !== e && "imap-disabled" !== e;
                }
                s(i) && s(o) && n.universe.clearAccountProblems(t), n.__sendMessage({
                    type: "clearAccountProblems",
                    handle: e.handle
                });
            });
        },
        _cmd_modifyAccount: function(e) {
            var t = this.universe.getAccountForAccountId(e.accountId), n = t.accountDef;
            for (var o in e.mods) {
                var s = e.mods[o];
                switch (o) {
                  case "name":
                    n.name = s;
                    break;

                  case "username":
                    n.credentials.outgoingUsername === n.credentials.username && (n.credentials.outgoingUsername = s), 
                    n.credentials.username = s;
                    break;

                  case "incomingUsername":
                    n.credentials.username = s;
                    break;

                  case "outgoingUsername":
                    n.credentials.outgoingUsername = s;
                    break;

                  case "password":
                    n.credentials.outgoingPassword === n.credentials.password && (n.credentials.outgoingPassword = s), 
                    n.credentials.password = s;
                    break;

                  case "incomingPassword":
                    n.credentials.password = s;
                    break;

                  case "outgoingPassword":
                    n.credentials.outgoingPassword = s;
                    break;

                  case "oauthTokens":
                    var r = n.credentials.oauth2;
                    r.accessToken = s.accessToken, r.refreshToken = s.refreshToken, r.expireTimeMS = s.expireTimeMS;
                    break;

                  case "identities":
                    break;

                  case "servers":
                    break;

                  case "syncRange":
                    n.syncRange = s;
                    break;

                  case "syncInterval":
                    n.syncInterval = s;
                    break;

                  case "notifyOnNew":
                    n.notifyOnNew = s;
                    break;

                  case "playSoundOnSend":
                    n.playSoundOnSend = s;
                    break;

                  case "setAsDefault":
                    s && (n.defaultPriority = i.NOW());
                    break;

                  default:
                    throw new Error('Invalid key for modifyAccount: "' + o + '"');
                }
            }
            this.universe.saveAccountDef(n, null), this.__sendMessage({
                type: "modifyAccount",
                handle: e.handle
            });
        },
        _cmd_deleteAccount: function(e) {
            this.universe.deleteAccount(e.accountId);
        },
        _cmd_modifyIdentity: function(e) {
            var t = this.universe.getAccountForSenderIdentityId(e.identityId), n = t.accountDef, i = this.universe.getIdentityForSenderIdentityId(e.identityId);
            for (var o in e.mods) {
                var s = e.mods[o];
                switch (o) {
                  case "name":
                    i.name = s;
                    break;

                  case "address":
                    i.address = s;
                    break;

                  case "replyTo":
                    i.replyTo = s;
                    break;

                  case "signature":
                    i.signature = s;
                    break;

                  case "signatureEnabled":
                    i.signatureEnabled = s;
                    break;

                  default:
                    throw new Error('Invalid key for modifyIdentity: "' + o + '"');
                }
            }
            this.universe.saveAccountDef(n, null, function() {
                this.__sendMessage({
                    type: "modifyIdentity",
                    handle: e.handle
                });
            }.bind(this));
        },
        notifyBadLogin: function(e, t, n) {
            this.__sendMessage({
                type: "badLogin",
                account: e.toBridgeWire(),
                problem: t,
                whichSide: n
            });
        },
        _cmd_viewAccounts: function(e) {
            var t = this._slices[e.handle] = new m(this, "accounts", e.handle);
            t.markers = this.universe.accounts.map(function(e) {
                return e.id;
            }), this._slicesByType.accounts.push(t);
            var n = this.universe.accounts.map(c);
            t.sendSplice(0, 0, n, !0, !1);
        },
        notifyAccountAdded: function(e) {
            var t, n, i, o = e.toBridgeWire(), s = null, r = null;
            for (i = this._slicesByType.accounts, t = 0; t < i.length; t++) n = i[t], n.sendSplice(n.markers.length, 0, [ o ], !1, !1), 
            n.markers.push(e.id);
            o = e.toBridgeFolder(), i = this._slicesByType.folders;
            var a, c = l(e, o);
            for (t = 0; t < i.length; t++) if (n = i[t], "account" !== n.mode) {
                a = h(n.markers, c, d), s = [ o ], r = [ c ];
                for (var u = 0; u < e.folders.length; u++) {
                    var p = e.folders[u], f = l(e, p), m = h(r, f, d);
                    s.splice(m, 0, p), r.splice(m, 0, f);
                }
                n.sendSplice(a, 0, s, !1, !1), n.markers.splice.apply(n.markers, [ a, 0 ].concat(r));
            }
        },
        notifyAccountModified: function(e) {
            for (var t = this._slicesByType.accounts, n = e.toBridgeWire(), i = 0; i < t.length; i++) {
                var o = t[i], s = o.markers.indexOf(e.id);
                -1 !== s && o.sendUpdate([ s, n ]);
            }
        },
        notifyAccountRemoved: function(e) {
            var t, n, i;
            for (i = this._slicesByType.accounts, t = 0; t < i.length; t++) {
                n = i[t];
                var o = n.markers.indexOf(e);
                -1 !== o && (n.sendSplice(o, 1, [], !1, !1), n.markers.splice(o, 1));
            }
            i = this._slicesByType.folders;
            var s = e + "!!", r = e + "!|";
            for (t = 0; t < i.length; t++) {
                n = i[t];
                var a = h(n.markers, s, d), c = h(n.markers, r, d);
                c !== a && (n.sendSplice(a, c - a, [], !1, !1), n.markers.splice(a, c - a));
            }
        },
        _cmd_viewSenderIdentities: function(e) {
            var t = this._slices[e.handle] = new m(this, "identities", e.handle);
            this._slicesByType.identities.push(t);
            var n = this.universe.identities;
            t.sendSplice(0, 0, n, !0, !1);
        },
        _cmd_requestBodies: function(e) {
            var t = this;
            this.universe.downloadBodies(e.messages, e.options, function() {
                t.__sendMessage({
                    type: "requestBodiesComplete",
                    handle: e.handle,
                    requestId: e.requestId
                });
            });
        },
        notifyFolderAdded: function(e, t) {
            for (var n = l(e, t), i = this._slicesByType.folders, o = 0; o < i.length; o++) {
                var s = i[o], r = h(s.markers, n, d);
                s.sendSplice(r, 0, [ t ], !1, !1), s.markers.splice(r, 0, n);
            }
        },
        notifyFolderModified: function(e, t) {
            for (var n = l(e, t), i = this._slicesByType.folders, o = 0; o < i.length; o++) {
                var s = i[o], r = f(s.markers, n, d);
                null !== r && s.sendUpdate([ r, t ]);
            }
        },
        notifyFolderRemoved: function(e, t) {
            for (var n = l(e, t), i = this._slicesByType.folders, o = 0; o < i.length; o++) {
                var s = i[o], r = f(s.markers, n, d);
                null !== r && (s.sendSplice(r, 1, [], !1, !1), s.markers.splice(r, 1));
            }
        },
        notifyBodyModified: function(e, t, n) {
            var i = this._observedBodies[e], o = this.__sendMessage;
            if (i) for (var s in i) {
                var r = i[s] || o;
                r.call(this, {
                    type: "bodyModified",
                    handle: s,
                    bodyInfo: n,
                    detail: t
                });
            }
        },
        _cmd_viewFolders: function(e) {
            function t(e) {
                for (var t = 0; t < e.folders.length; t++) {
                    var n = e.folders[t], s = l(e, n), r = h(i, s, d);
                    o.splice(r, 0, n), i.splice(r, 0, s);
                }
            }
            var n = this._slices[e.handle] = new m(this, "folders", e.handle);
            this._slicesByType.folders.push(n), n.mode = e.mode, n.argument = e.argument;
            var i = n.markers = [], o = [];
            if ("account" === e.mode) t(this.universe.getAccountForAccountId(e.argument)); else {
                var s = this.universe.accounts.concat();
                s.sort(function(e, t) {
                    return e.id.localeCompare(t.id);
                });
                for (var r = 0; r < s.length; r++) {
                    var a = s[r], c = a.toBridgeFolder(), u = l(a, c), p = h(i, u, d);
                    o.splice(p, 0, c), i.splice(p, 0, u), t(a);
                }
            }
            n.sendSplice(0, 0, o, !0, !1);
        },
        _cmd_viewFolderMessages: function(e) {
            var t = this._slices[e.handle] = new m(this, "headers", e.handle);
            this._slicesByType.headers.push(t);
            var n = this.universe.getAccountForFolderId(e.folderId);
            n.sliceFolderMessages(e.folderId, t);
        },
        _cmd_searchFolderMessages: function(e) {
            var t = this._slices[e.handle] = new m(this, "matchedHeaders", e.handle);
            this._slicesByType.matchedHeaders.push(t);
            var n = this.universe.getAccountForFolderId(e.folderId);
            n.searchFolderMessages(e.folderId, t, e.phrase, e.whatToSearch);
        },
        _cmd_refreshHeaders: function(e) {
            var t = this._slices[e.handle];
            return t ? (t.__listener && t.__listener.refresh(), void 0) : (this._LOG.badSliceHandle(e.handle), 
            void 0);
        },
        _cmd_growSlice: function(e) {
            var t = this._slices[e.handle];
            return t ? (t.__listener && t.__listener.reqGrow(e.dirMagnitude, e.userRequestsGrowth), 
            void 0) : (this._LOG.badSliceHandle(e.handle), void 0);
        },
        _cmd_shrinkSlice: function(e) {
            var t = this._slices[e.handle];
            return t ? (t.__listener && t.__listener.reqNoteRanges(e.firstIndex, e.firstSuid, e.lastIndex, e.lastSuid), 
            void 0) : (this._LOG.badSliceHandle(e.handle), void 0);
        },
        _cmd_killSlice: function(e) {
            var t = this._slices[e.handle];
            if (!t) return this._LOG.badSliceHandle(e.handle), void 0;
            delete this._slices[e.handle];
            var n = this._slicesByType[t._ns], i = n.indexOf(t);
            n.splice(i, 1), t.die(), this.__sendMessage({
                type: "sliceDead",
                handle: e.handle
            });
        },
        _cmd_getBody: function(e) {
            var t = this, n = this.universe.getFolderStorageForMessageSuid(e.suid), i = [], o = function(e) {
                i.push(e);
            };
            this._observedBodies[e.suid] || (this._observedBodies[e.suid] = {}), this._observedBodies[e.suid][e.handle] = o;
            var s = function(o) {
                t.__sendMessage({
                    type: "gotBody",
                    handle: e.handle,
                    bodyInfo: o
                }), e.downloadBodyReps && !n.messageBodyRepsDownloaded(o) && t.universe.downloadMessageBodyReps(e.suid, e.date, function() {}), 
                i.forEach(t.__sendMessage, t), i = null, t._observedBodies[e.suid][e.handle] = null;
            };
            e.withBodyReps ? n.getMessageBodyWithReps(e.suid, e.date, s) : n.getMessageBody(e.suid, e.date, s);
        },
        _cmd_killBody: function(e) {
            var t = this._observedBodies[e.id];
            if (t) {
                delete t[e.handle];
                var n = !0;
                for (var i in t) {
                    n = !1;
                    break;
                }
                n && delete this._observedBodies[e.id];
            }
            this.__sendMessage({
                type: "bodyDead",
                handle: e.handle
            });
        },
        _cmd_downloadAttachments: function(e) {
            var t = this;
            this.universe.downloadMessageAttachments(e.suid, e.date, e.relPartIndices, e.attachmentIndices, function() {
                t.__sendMessage({
                    type: "downloadedAttachments",
                    handle: e.handle
                });
            });
        },
        _cmd_modifyMessageTags: function(e) {
            var t = this.universe.modifyMessageTags(e.opcode, e.messages, e.addTags, e.removeTags);
            this.__sendMessage({
                type: "mutationConfirmed",
                handle: e.handle,
                longtermIds: t
            });
        },
        _cmd_deleteMessages: function(e) {
            var t = this.universe.deleteMessages(e.messages);
            this.__sendMessage({
                type: "mutationConfirmed",
                handle: e.handle,
                longtermIds: t
            });
        },
        _cmd_moveMessages: function(e) {
            var t = this.universe.moveMessages(e.messages, e.targetFolder, function(n, i) {
                this.__sendMessage({
                    type: "mutationConfirmed",
                    handle: e.handle,
                    longtermIds: t,
                    result: i
                });
            }.bind(this));
        },
        _cmd_sendOutboxMessages: function(e) {
            var t = this.universe.getAccountForAccountId(e.accountId);
            this.universe.sendOutboxMessages(t, {
                reason: "api request"
            }, function() {
                this.__sendMessage({
                    type: "sendOutboxMessages",
                    handle: e.handle
                });
            }.bind(this));
        },
        _cmd_setOutboxSyncEnabled: function(e) {
            var t = this.universe.getAccountForAccountId(e.accountId);
            this.universe.setOutboxSyncEnabled(t, e.outboxSyncEnabled, function() {
                this.__sendMessage({
                    type: "setOutboxSyncEnabled",
                    handle: e.handle
                });
            }.bind(this));
        },
        _cmd_undo: function(e) {
            this.universe.undoMutation(e.longtermIds);
        },
        _cmd_beginCompose: function(e) {
            s([ "./drafts/composer", "mailchew" ], function(t, n) {
                var i, o, s = this._pendingRequests[e.handle] = {
                    type: "compose",
                    active: "begin",
                    account: null,
                    persistedNamer: null,
                    die: !1
                };
                i = "new" === e.mode && "folder" === e.submode ? this.universe.getAccountForFolderId(e.refSuid) : this.universe.getAccountForMessageSuid(e.refSuid), 
                s.account = i, o = i.identities[0];
                var r = n.generateBaseComposeBody(o);
                if ("reply" !== e.mode && "forward" !== e.mode) return this.__sendMessage({
                    type: "composeBegun",
                    handle: e.handle,
                    error: null,
                    identity: o,
                    subject: "",
                    body: {
                        text: r,
                        html: null
                    },
                    to: [],
                    cc: [],
                    bcc: [],
                    references: null,
                    attachments: []
                });
                var a = this.universe.getFolderStorageForMessageSuid(e.refSuid), c = this;
                a.getMessage(e.refSuid, e.refDate, {
                    withBodyReps: !0
                }, function(t) {
                    if (!t) return console.warn("Cannot compose message missing header/body: ", e.refSuid);
                    var i = t.header, r = t.body;
                    if ("reply" === e.mode) {
                        var a, l, d, p = {
                            name: e.refAuthor.name,
                            address: i.replyTo && i.replyTo.address || e.refAuthor.address
                        };
                        switch (e.submode) {
                          case "list":
                          case null:
                          case "sender":
                            a = [ p ], l = d = [];
                            break;

                          case "all":
                            a = u(i.to, p) || u(i.cc, p) ? i.to : i.to && i.to.length ? [ p ].concat(i.to) : [ p ];
                            var h = function(e) {
                                return e.address !== o.address;
                            };
                            a = a.filter(h), l = (i.cc || []).filter(h), d = i.bcc;
                        }
                        var f;
                        f = r.references ? r.references.concat([ e.refGuid ]).map(function(e) {
                            return "<" + e + ">";
                        }).join(" ") : e.refGuid ? "<" + e.refGuid + ">" : "", s.active = null, c.__sendMessage({
                            type: "composeBegun",
                            handle: e.handle,
                            error: null,
                            identity: o,
                            subject: n.generateReplySubject(e.refSubject),
                            body: n.generateReplyBody(r.bodyReps, p, e.refDate, o, e.refGuid),
                            to: a,
                            cc: l,
                            bcc: d,
                            referencesStr: f,
                            attachments: []
                        });
                    } else s.active = null, c.__sendMessage({
                        type: "composeBegun",
                        handle: e.handle,
                        error: null,
                        identity: o,
                        subject: n.generateForwardSubject(e.refSubject),
                        body: n.generateForwardMessage(e.refAuthor, e.refDate, e.refSubject, i, r, o),
                        to: [],
                        cc: [],
                        bcc: [],
                        references: null,
                        attachments: []
                    });
                });
            }.bind(this));
        },
        _cmd_attachBlobToDraft: function(e) {
            s([ "./drafts/composer" ], function() {
                var t = this._pendingRequests[e.draftHandle];
                t && this.universe.attachBlobToDraft(t.account, t.persistedNamer, e.attachmentDef, function(t) {
                    this.__sendMessage({
                        type: "attachedBlobToDraft",
                        handle: e.handle,
                        draftHandle: e.draftHandle,
                        err: t
                    });
                }.bind(this));
            }.bind(this));
        },
        _cmd_detachAttachmentFromDraft: function(e) {
            s([ "./drafts/composer" ], function() {
                var t = this._pendingRequests[e.draftHandle];
                t && this.universe.detachAttachmentFromDraft(t.account, t.persistedNamer, e.attachmentIndex, function(t) {
                    this.__sendMessage({
                        type: "detachedAttachmentFromDraft",
                        handle: e.handle,
                        draftHandle: e.draftHandle,
                        err: t
                    });
                }.bind(this));
            }.bind(this));
        },
        _cmd_resumeCompose: function(e) {
            var t = this._pendingRequests[e.handle] = {
                type: "compose",
                active: "resume",
                account: null,
                persistedNamer: e.messageNamer,
                die: !1
            }, n = t.account = this.universe.getAccountForMessageSuid(e.messageNamer.suid), i = this.universe.getFolderStorageForMessageSuid(e.messageNamer.suid), o = this;
            i.runMutexed("resumeCompose", function(s) {
                function r() {
                    o.__sendMessage({
                        type: "composeBegun",
                        handle: e.handle,
                        error: "no-message"
                    }), s();
                }
                i.getMessage(e.messageNamer.suid, e.messageNamer.date, function(i) {
                    try {
                        if (!i.header || !i.body) return r(), void 0;
                        var a = i.header, c = i.body, l = {
                            text: "",
                            html: null
                        };
                        c.bodyReps.length >= 1 && "plain" === c.bodyReps[0].type && 2 === c.bodyReps[0].content.length && 1 === c.bodyReps[0].content[0] && (l.text = c.bodyReps[0].content[1]), 
                        2 == c.bodyReps.length && "html" === c.bodyReps[1].type && (l.html = c.bodyReps[1].content);
                        var d = [];
                        c.attachments.forEach(function(e) {
                            d.push({
                                name: e.name,
                                blob: {
                                    size: e.sizeEstimate,
                                    type: e.type
                                }
                            });
                        }), t.active = null, o.__sendMessage({
                            type: "composeBegun",
                            handle: e.handle,
                            error: null,
                            identity: n.identities[0],
                            subject: a.subject,
                            body: l,
                            to: a.to,
                            cc: a.cc,
                            bcc: a.bcc,
                            referencesStr: c.references,
                            attachments: d,
                            sendStatus: a.sendStatus
                        }), s();
                    } catch (u) {
                        r();
                    }
                });
            });
        },
        _cmd_doneCompose: function(e) {
            s([ "./drafts/composer" ], function() {
                function t() {
                    i.__sendMessage({
                        type: "doneCompose",
                        handle: e.handle
                    });
                }
                var n = this._pendingRequests[e.handle], i = this;
                if (n) {
                    if ("die" === e.command) return n.active ? n.die = !0 : delete this._pendingRequests[e.handle], 
                    void 0;
                    var o;
                    if ("delete" === e.command) return n.persistedNamer ? (o = this.universe.getAccountForMessageSuid(n.persistedNamer.suid), 
                    this.universe.deleteDraft(o, n.persistedNamer, t)) : t(), delete this._pendingRequests[e.handle], 
                    void 0;
                    var s = e.state;
                    if (o = this.universe.getAccountForSenderIdentityId(s.senderId), this.universe.getIdentityForSenderIdentityId(s.senderId), 
                    "send" === e.command) {
                        n.persistedNamer = this.universe.saveDraft(o, n.persistedNamer, s, function() {
                            n.active = null, n.die && delete this._pendingRequests[e.handle];
                            var t = o.getFirstFolderWithType("outbox");
                            this.universe.moveMessages([ n.persistedNamer ], t.id), this.universe.sendOutboxMessages(o, {
                                reason: "moved to outbox",
                                emitNotifications: this.universe.online
                            });
                        }.bind(this));
                        var r = {
                            accountId: o.id,
                            suid: n.persistedNamer.suid,
                            state: this.universe.online ? "sending" : "pending",
                            emitNotifications: !0
                        };
                        this.__sendMessage({
                            type: "doneCompose",
                            handle: e.handle,
                            sendStatus: r
                        }), this.universe.__notifyBackgroundSendStatus(r);
                    } else "save" === e.command && (n.persistedNamer = this.universe.saveDraft(o, n.persistedNamer, s, function() {
                        n.active = null, n.die && delete i._pendingRequests[e.handle], i.__sendMessage({
                            type: "doneCompose",
                            handle: e.handle
                        });
                    }));
                }
            }.bind(this));
        },
        notifyCronSyncStart: function(e) {
            this.__sendMessage({
                type: "cronSyncStart",
                accountIds: e
            });
        },
        notifyCronSyncStop: function(e) {
            this.__sendMessage({
                type: "cronSyncStop",
                accountsResults: e
            });
        },
        notifyBackgroundSendStatus: function(e) {
            this.__sendMessage({
                type: "backgroundSendStatus",
                data: e
            });
        }
    };
    var v = a.LOGFAB = e.register(r, {
        MailBridge: {
            type: e.DAEMON,
            events: {
                send: {
                    type: !0
                }
            },
            TEST_ONLY_events: {
                send: {
                    msg: !1
                }
            },
            errors: {
                badMessageType: {
                    type: !0
                },
                badSliceHandle: {
                    handle: !0
                }
            },
            calls: {
                cmd: {
                    command: !0
                }
            },
            TEST_ONLY_calls: {}
        }
    });
}), define("rdcommon/logreaper", [ "./log", "./microtime", "exports" ], function(e, t, n) {
    function i(e) {
        this._rootLogger = e, this._lastTimestamp = null, this._lastSeq = null;
    }
    var o = [];
    n.LogReaper = i, i.prototype = {
        reapHierLogTimeSlice: function() {
            function n(e) {
                var t = !0, i = e.toJSON();
                i.events = null, i.kids = null, null !== e._died && (t = !1);
                var s = null;
                for (var r in e._eventMap) {
                    var a = e._eventMap[r];
                    a && (t = !1, null === s && (i.events = s = {}), s[r] = a, e._eventMap[r] = 0);
                }
                if (i.entries.length ? (t = !1, e._entries = []) : i.entries = o, e._kids && e._kids.length) for (var c = 0; c < e._kids.length; c++) {
                    var l = e._kids[c], d = n(l);
                    d && (i.kids || (i.kids = []), i.kids.push(d), t = !1), null !== l._died && e._kids.splice(c--, 1);
                }
                return t ? null : i;
            }
            var i, s, r = this._rootLogger;
            null === this._lastTimestamp ? (i = 0, s = r._born) : (i = this._lastSeq + 1, s = this._lastTimestamp);
            var a = (e.getCurrentSeq(), this._lastTimestamp = t.now());
            return {
                begin: s,
                end: a,
                logFrag: n(r)
            };
        }
    };
}), define("slog", [ "require", "exports", "module", "rdcommon/log", "evt" ], function(e, t) {
    e("rdcommon/log");
    var n = e("evt"), i = !1;
    t.setSensitiveDataLoggingEnabled = function(e) {
        i = e, t.log("meta:sensitive-logging", {
            enabled: e
        });
    };
    var o = new n.Emitter();
    t.resetEmitter = function() {
        o = new n.Emitter();
    };
    var s = t.LogChecker = function(e, t, n) {
        this.T = e, this.RT = t, this.eLazy = this.T.lazyLogger(n), this.eNotLogLazy = null, 
        this._subscribedTo = {}, this._interceptions = {};
    }, r = {};
    s.prototype.interceptOnce = function(e, t) {
        this.mustLog(e);
        var n = r[e] = r[e] || [];
        n.push(t);
    }, t.interceptable = function(e, n) {
        var i;
        return r[e] && (i = r[e].shift()), i ? (t.log(e), i(n)) : n();
    }, s.prototype.mustLog = function(e, t) {
        var n = this.eLazy, i = this._subscribedTo[e];
        void 0 === i && (i = this._subscribedTo[e] = [], o.on(e, function(t) {
            var s = i.shift();
            try {
                if (null === s) n.namedValue(e, t); else {
                    var r = !0;
                    s && (r = s(t)), n.namedValueD(e, r, t);
                }
            } catch (a) {
                console.error("Exception running LogChecker predicate:", a);
            }
            0 === i.length && o.removeListener(e);
        })), this.RT.reportActiveActorThisStep(n), "object" == typeof t ? (n.expect_namedValue(e, t), 
        i.push(null)) : (n.expect_namedValueD(e, !0), i.push(t));
    }, s.prototype.mustNotLog = function(e, t) {
        var n = this.eNotLogLazy;
        n || (n = this.eNotLogLazy = this.T.lazyLogger("slog")), this.RT.reportActiveActorThisStep(n), 
        n.expectNothing(), o.once(e, function(i) {
            try {
                var o = !0;
                t && (o = t(i)), n.namedValue(e, JSON.stringify(i));
            } catch (s) {
                console.error("Exception running LogChecker predicate:", s);
            }
        }.bind(this));
    }, [ "log", "info", "warn", "error" ].forEach(function(e) {
        t[e] = function(t, n) {
            var s = console[e].bind(console, "[slog]");
            o.emit(t, n), s.apply(console, Array.slice(arguments).map(function(e) {
                if ("object" != typeof e) return e;
                var t = {};
                for (var n in e) (i || "_" !== n[0]) && (t[n] = e[n]);
                try {
                    return JSON.stringify(t);
                } catch (o) {
                    return "[un-JSONifiable " + e + "]";
                }
            }));
        };
    }), t.debug = function(e, n) {
        i && t.log(e, n);
    };
}), define("a64", [ "exports" ], function(e) {
    function t(e, t) {
        var o = [];
        do o.push(n[63 & e]), e = Math.floor(e / 64); while (e > 0);
        o.reverse();
        var s = o.join("");
        return t && s.length < t ? i.substring(0, t - s.length) + s : s;
    }
    var n = [ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "{", "}" ], i = "0000000000000000";
    e.encodeInt = t;
    var o = Math.pow(10, 14) / Math.pow(2, 14), s = Math.pow(2, 14), r = Math.pow(2, 22), a = (Math.pow(2, 32), 
    Math.pow(2, 36));
    e.parseUI64 = function(e, n) {
        if (e.length < 16) return t(parseInt(e, 10));
        var c = parseInt(e.substring(e.length - 14), 10), l = parseInt(e.substring(0, e.length - 14), 10), d = l * o, u = d % a * s % a + c % a, p = u % a, h = Math.floor(u / a) % 2, f = Math.floor(d / r) + Math.floor(c / a) + h, m = t(f) + t(p, 6);
        return n && m.length < n ? i.substring(0, n - m.length) + m : m;
    }, e.cmpUI64 = function(e, t) {
        var n = e.length - t.length;
        return 0 !== n ? n : t > e ? -1 : e > t ? 1 : 0;
    }, e.decodeUI64 = function(e) {
        for (var t = 0; 48 === e.charCodeAt(t); t++) ;
        t && (e = e.substring(t));
        var a, c;
        if (e.length <= 8) {
            for (a = 0, c = 0; c < e.length; c++) a = 64 * a + n.indexOf(e[c]);
            return a.toString(10);
        }
        var l = e.substring(0, e.length - 6), d = 0, u = e.substring(e.length - 6), p = 0;
        for (c = 0; c < l.length; c++) d = 64 * d + n.indexOf(l[c]);
        for (c = 0; c < u.length; c++) p = 64 * p + n.indexOf(u[c]);
        var h = d * r + Math.floor(p / s), f = h / o, m = Math.floor(f), g = m.toString(), v = h - m * o, _ = v * s + p % s, y = _.toString();
        return y.length < 14 && (y = i.substring(0, 14 - y.length) + y), g + y;
    };
}), define("syncbase", [ "./date", "exports" ], function(e, t) {
    t.OPEN_REFRESH_THRESH_MS = 6e5, t.GROW_REFRESH_THRESH_MS = 36e5, t.EXPECTED_BLOCK_SIZE = 8, 
    t.MAX_BLOCK_SIZE = 1024 * t.EXPECTED_BLOCK_SIZE, t.BLOCK_SPLIT_SMALL_PART = 1024 * (t.EXPECTED_BLOCK_SIZE / 3), 
    t.BLOCK_SPLIT_EQUAL_PART = 1024 * (t.EXPECTED_BLOCK_SIZE / 2), t.BLOCK_SPLIT_LARGE_PART = 1024 * (t.EXPECTED_BLOCK_SIZE / 1.5), 
    t.BLOCK_PURGE_EVERY_N_NEW_BODY_BLOCKS = 32, t.BLOCK_PURGE_ONLY_AFTER_UNSYNCED_MS = 14 * e.DAY_MILLIS, 
    t.BLOCK_PURGE_HARD_MAX_BLOCK_LIMIT = 1024, t.POP3_SAVE_STATE_EVERY_N_MESSAGES = 50, 
    t.POP3_MAX_MESSAGES_PER_SYNC = 100, t.POP3_INFER_ATTACHMENTS_SIZE = 524288, t.POP3_SNIPPET_SIZE_GOAL = 4096, 
    t.SYNC_FOLDER_LIST_EVERY_MS = e.DAY_MILLIS, t.INITIAL_FILL_SIZE = 15, t.INITIAL_SYNC_DAYS = 3, 
    t.INITIAL_SYNC_GROWTH_DAYS = 3, t.TIME_SCALE_FACTOR_ON_NO_MESSAGES = 2, t.OLDEST_SYNC_DATE = Date.UTC(1990, 0, 1), 
    t.SYNC_WHOLE_FOLDER_AT_N_MESSAGES = 40, t.BISECT_DATE_AT_N_MESSAGES = 60, t.TOO_MANY_MESSAGES = 2e3, 
    t.DEFAULT_TZ_OFFSET = -252e5, t.HEADER_EST_SIZE_IN_BYTES = 430, t.MAX_OP_TRY_COUNT = 10, 
    t.OP_UNKNOWN_ERROR_TRY_COUNT_INCREMENT = 5, t.DEFERRED_OP_DELAY_MS = 3e4, t.CHECK_INTERVALS_ENUMS_TO_MS = {
        manual: 0,
        "3min": 18e4,
        "5min": 3e5,
        "10min": 6e5,
        "15min": 9e5,
        "30min": 18e5,
        "60min": 36e5
    }, t.DEFAULT_CHECK_INTERVAL_ENUM = "manual", t.CONNECT_TIMEOUT_MS = 3e4, t.STALE_CONNECTION_TIMEOUT_MS = 3e4, 
    t.KILL_CONNECTIONS_WHEN_JOBLESS = !0;
    var n = 864e5;
    t.SYNC_RANGE_ENUMS_TO_MS = {
        auto: 30 * n,
        "1d": 1 * n,
        "3d": 3 * n,
        "1w": 7 * n,
        "2w": 14 * n,
        "1m": 30 * n,
        all: 10950 * n
    }, t.CRONSYNC_MAX_MESSAGES_TO_REPORT_PER_ACCOUNT = 5, t.CRONSYNC_MAX_SNIPPETS_TO_FETCH_PER_ACCOUNT = 5, 
    t.MAX_SNIPPET_BYTES = 4096, t.TEST_adjustSyncValues = function(e) {
        var n = {
            fillSize: "INITIAL_FILL_SIZE",
            days: "INITIAL_SYNC_DAYS",
            growDays: "INITIAL_SYNC_GROWTH_DAYS",
            wholeFolderSync: "SYNC_WHOLE_FOLDER_AT_N_MESSAGES",
            bisectThresh: "BISECT_DATE_AT_N_MESSAGES",
            tooMany: "TOO_MANY_MESSAGES",
            scaleFactor: "TIME_SCALE_FACTOR_ON_NO_MESSAGES",
            openRefreshThresh: "OPEN_REFRESH_THRESH_MS",
            growRefreshThresh: "GROW_REFRESH_THRESH_MS"
        };
        for (var i in e) if (e.hasOwnProperty(i)) {
            var o = n[i] || i;
            t.hasOwnProperty(o) ? t[o] = e[i] : console.warn("Invalid key for TEST_adjustSyncValues: " + i);
        }
    };
}), define("maildb", [ "./worker-router", "exports" ], function(e, t) {
    function n(e) {
        function t() {
            console.log("main thread reports DB ready"), this._ready = !0, this._callbacksQueue.forEach(function(e) {
                e();
            }), this._callbacksQueue = null;
        }
        this._callbacksQueue = [], i("open", [ e ], t.bind(this));
    }
    var i = e.registerCallbackType("maildb");
    t.MailDB = n, n.prototype = {
        close: function() {
            i("close");
        },
        getConfig: function(e) {
            return this._ready ? (console.log("issuing getConfig call to main thread"), i("getConfig", null, e), 
            void 0) : (console.log("deferring getConfig call until ready"), this._callbacksQueue.push(this.getConfig.bind(this, e)), 
            void 0);
        },
        saveConfig: function(e) {
            i("saveConfig", [ e ]);
        },
        saveAccountDef: function(e, t, n, o) {
            i("saveAccountDef", [ e, t, n ], o);
        },
        loadHeaderBlock: function(e, t, n) {
            i("loadHeaderBlock", [ e, t ], n);
        },
        loadBodyBlock: function(e, t, n) {
            i("loadBodyBlock", [ e, t ], n);
        },
        saveAccountFolderStates: function(e, t, n, o, s) {
            var r = [ e, t, n, o ];
            return i("saveAccountFolderStates", r, s), null;
        },
        deleteAccount: function(e) {
            i("deleteAccount", [ e ]);
        }
    };
}), define("allback", [ "exports" ], function(e) {
    e.allbackMaker = function(e, t) {
        var n = Object.create(null), i = {}, o = e.concat();
        return e.forEach(function(e) {
            n[e] = void 0, i[e] = function(i) {
                var s = o.indexOf(e);
                if (-1 === s) throw console.error("Callback '" + e + "' fired multiple times!"), 
                new Error("Callback '" + e + "' fired multiple times!");
                o.splice(s, 1), n[e] = arguments.length > 1 ? arguments : i, 0 === o.length && t && t(n);
            };
        }), i;
    }, e.latch = function() {
        function e(e) {
            o++;
            var t = !1;
            return function() {
                if (t) {
                    var s = new Error("You have already resolved this deferred!");
                    throw console.error(s + "\n" + s.stack), s;
                }
                t = !0, null != e && (i[e] = Array.slice(arguments)), 0 === --o && setZeroTimeout(function() {
                    n.resolve(i);
                });
            };
        }
        var t = !1, n = {}, i = Object.create(null), o = 0;
        n.promise = new Promise(function(e, t) {
            n.resolve = e, n.reject = t;
        });
        var s = e();
        return {
            defer: e,
            then: function() {
                var e = n.promise.then.apply(n.promise, arguments);
                return t || (t = !0, s()), e;
            }
        };
    }, e.extractErrFromCallbackArgs = function(e) {
        var t = null;
        for (var n in e) {
            var i = e[n], o = i[0];
            if (o) {
                t = o;
                break;
            }
        }
        return t;
    }, e.latchedWithRejections = function(e) {
        return new Promise(function(t) {
            var n = Object.create(null), i = 0;
            Object.keys(e).forEach(function(o) {
                i++;
                var s = e[o];
                s.then(function(e) {
                    n[o] = {
                        resolved: !0,
                        value: e
                    }, 0 === --i && t(n);
                }, function(e) {
                    n[o] = {
                        resolved: !1,
                        value: e
                    }, 0 === --i && t(n);
                });
            }), i || t(n);
        });
    };
}), define("mailslice", [ "require", "exports", "module", "rdcommon/log", "./slog", "./util", "./a64", "./allback", "./date", "./syncbase" ], function(e, t, n) {
    function i(e, t, n) {
        this._bridgeHandle = e, e.__listener = this, this._storage = t, this._LOG = F.MailSlice(this, n, e._handle), 
        this.startTS = null, this.startUID = null, this.endTS = null, this.endUID = null, 
        this.waitingOnData = !1, this.ignoreHeaders = !1, this.headers = [], this.desiredHeaders = u.INITIAL_FILL_SIZE, 
        this.headerCount = t.headerCount;
    }
    function o(e, t, n, i, o, s) {
        this._account = e, this._imapDb = i, this.folderId = t, this.folderMeta = n.$meta, 
        this._folderImpl = n.$impl, this._LOG = F.FolderStorage(this, s, t), this._accuracyRanges = n.accuracy, 
        this._headerBlockInfos = n.headerBlocks, this.headerCount = 0, this._headerBlockInfos && this._headerBlockInfos.forEach(function(e) {
            this.headerCount += e.count;
        }.bind(this)), this._bodyBlockInfos = n.bodyBlocks, this._serverIdHeaderBlockMapping = n.serverIdHeaderBlockMapping, 
        this._headerBlocks = {}, this._loadedHeaderBlockInfos = [], this._bodyBlocks = {}, 
        this._loadedBodyBlockInfos = [], this._flushExcessTimeoutId = 0, this._bound_flushExcessOnTimeout = this._flushExcessOnTimeout.bind(this), 
        this._bound_makeHeaderBlock = this._makeHeaderBlock.bind(this), this._bound_insertHeaderInBlock = this._insertHeaderInBlock.bind(this), 
        this._bound_splitHeaderBlock = this._splitHeaderBlock.bind(this), this._bound_deleteHeaderFromBlock = this._deleteHeaderFromBlock.bind(this), 
        this._bound_makeBodyBlock = this._makeBodyBlock.bind(this), this._bound_insertBodyInBlock = this._insertBodyInBlock.bind(this), 
        this._bound_splitBodyBlock = this._splitBodyBlock.bind(this), this._bound_deleteBodyFromBlock = this._deleteBodyFromBlock.bind(this), 
        this._dirty = !1, this._dirtyHeaderBlocks = {}, this._dirtyBodyBlocks = {}, this._pendingLoads = [], 
        this._pendingLoadListeners = {}, this._deferredCalls = [], this._mutexQueue = [], 
        this._slices = [], this._curSyncSlice = null, this._messagePurgeScheduled = !1, 
        this.folderSyncer = o && new o(e, this, this._LOG);
    }
    var s = e("rdcommon/log"), r = e("./slog"), a = e("./util"), c = e("./a64"), l = e("./allback"), d = e("./date"), u = e("./syncbase"), p = a.bsearchForInsert, h = a.bsearchMaybeExists, f = a.cmpHeaderYoungToOld, m = (l.allbackMaker, 
    d.BEFORE), g = d.ON_OR_BEFORE, v = d.SINCE, _ = d.STRICTLY_AFTER, y = d.IN_BS_DATE_RANGE, b = (d.HOUR_MILLIS, 
    d.DAY_MILLIS), x = d.NOW, S = d.quantizeDate, w = d.quantizeDateUp, T = 1, A = -1, E = 2, k = 5, I = 10, C = 4, O = 2, M = 4, D = 8, N = 4, L = t.tupleRangeIntersectsTupleRange = function(e, t) {
        return m(e.endTS, t.startTS) || _(e.startTS, t.endTS) ? !1 : e.endTS === t.startTS && e.endUID < t.startUID || e.startTS === t.endTS && e.startTS > t.endUID ? !1 : !0;
    }, R = .02;
    t.MailSlice = i, i.prototype = {
        type: "folder",
        set atTop(e) {
            return this._bridgeHandle && (this._bridgeHandle.atTop = e), e;
        },
        set atBottom(e) {
            return this._bridgeHandle && (this._bridgeHandle.atBottom = e), e;
        },
        set userCanGrowUpwards(e) {
            return this._bridgeHandle && (this._bridgeHandle.userCanGrowUpwards = e), e;
        },
        set userCanGrowDownwards(e) {
            return this._bridgeHandle && (this._bridgeHandle.userCanGrowDownwards = e), e;
        },
        set headerCount(e) {
            return this._bridgeHandle && (this._bridgeHandle.headerCount = e), e;
        },
        _updateSliceFlags: function() {
            var e = this._bridgeHandle;
            e.atTop = this._storage.headerIsYoungestKnown(this.endTS, this.endUID), e.atBottom = this._storage.headerIsOldestKnown(this.startTS, this.startUID), 
            e.userCanGrowUpwards = e.atTop ? !this._storage.syncedToToday() : !1, e.userCanGrowDownwards = e.atBottom ? !this._storage.syncedToDawnOfTime() : !1;
        },
        reset: function() {
            this._bridgeHandle && this.headers.length && (this._bridgeHandle.sendSplice(0, this.headers.length, [], !1, !0), 
            this.headers.splice(0, this.headers.length), this.startTS = null, this.startUID = null, 
            this.endTS = null, this.endUID = null);
        },
        refresh: function() {
            this._storage.refreshSlice(this);
        },
        reqNoteRanges: function(e, t, n, i) {
            if (this._bridgeHandle) {
                var o;
                if (e >= this.headers.length || this.headers[e].suid !== t) for (e = 0, o = 0; o < this.headers.length; o++) if (this.headers[o].suid === t) {
                    e = o;
                    break;
                }
                if (n >= this.headers.length || this.headers[n].suid !== i) for (o = this.headers.length - 1; o >= 0; o--) if (this.headers[o].suid === i) {
                    n = o;
                    break;
                }
                if (n + 1 < this.headers.length) {
                    this.atBottom = !1, this.userCanGrowDownwards = !1;
                    var s = this.headers.length - n - 1;
                    this.desiredHeaders -= s, this._bridgeHandle.sendSplice(n + 1, s, [], !0, e > 0), 
                    this.headers.splice(n + 1, this.headers.length - n - 1);
                    var r = this.headers[n];
                    this.startTS = r.date, this.startUID = r.id;
                }
                if (e > 0) {
                    this.atTop = !1, this.userCanGrowUpwards = !1, this.desiredHeaders -= e, this._bridgeHandle.sendSplice(0, e, [], !0, !1), 
                    this.headers.splice(0, e);
                    var a = this.headers[0];
                    this.endTS = a.date, this.endUID = a.id;
                }
                this._storage.sliceShrunk(this);
            }
        },
        reqGrow: function(e, t) {
            -1 === e ? e = -u.INITIAL_FILL_SIZE : 1 === e && (e = u.INITIAL_FILL_SIZE), this._storage.growSlice(this, e, t);
        },
        sendEmptyCompletion: function() {
            this.setStatus("synced", !0, !1);
        },
        setStatus: function(e, t, n, i, o, s) {
            if (this._bridgeHandle) {
                switch (e) {
                  case "synced":
                  case "syncfailed":
                    this._updateSliceFlags();
                }
                this._bridgeHandle.sendStatus(e, t, n, o, s);
            }
        },
        setSyncProgress: function(e) {
            this._bridgeHandle && this._bridgeHandle.sendSyncProgress(e);
        },
        batchAppendHeaders: function(e, t, n) {
            if (this._bridgeHandle) {
                this._LOG.headersAppended(e), -1 === t && (t = this.headers.length), this.headers.splice.apply(this.headers, [ t, 0 ].concat(e));
                for (var i = 0; i < e.length; i++) {
                    var o = e[i];
                    null === this.startTS || m(o.date, this.startTS) ? (this.startTS = o.date, this.startUID = o.id) : o.date === this.startTS && o.id < this.startUID && (this.startUID = o.id), 
                    null === this.endTS || _(o.date, this.endTS) ? (this.endTS = o.date, this.endUID = o.id) : o.date === this.endTS && o.id > this.endUID && (this.endUID = o.id);
                }
                this._updateSliceFlags(), this._bridgeHandle.sendSplice(t, 0, e, !0, n);
            }
        },
        onHeaderAdded: function(e) {
            if (this._bridgeHandle) {
                var t = p(this.headers, e, f), n = this.headers.length;
                n >= this.desiredHeaders && t === n || (n >= this.desiredHeaders && this.desiredHeaders++, 
                null === this.startTS || m(e.date, this.startTS) ? (this.startTS = e.date, this.startUID = e.id) : e.date === this.startTS && e.id < this.startUID && (this.startUID = e.id), 
                null === this.endTS || _(e.date, this.endTS) ? (this.endTS = e.date, this.endUID = e.id) : e.date === this.endTS && e.id > this.endUID && (this.endUID = e.id), 
                this._LOG.headerAdded(t, e), this._bridgeHandle.sendSplice(t, 0, [ e ], Boolean(this.waitingOnData), Boolean(this.waitingOnData)), 
                this.headers.splice(t, 0, e));
            }
        },
        onHeaderModified: function(e) {
            if (this._bridgeHandle) {
                var t = h(this.headers, e, f);
                null !== t && (this.headers[t] = e, this._LOG.headerModified(t, e), this._bridgeHandle.sendUpdate([ t, e ]));
            }
        },
        onHeaderRemoved: function(e) {
            if (this._bridgeHandle) {
                var t = h(this.headers, e, f);
                if (null !== t && (this._LOG.headerRemoved(t, e), this._bridgeHandle.sendSplice(t, 1, [], Boolean(this.waitingOnData), Boolean(this.waitingOnData)), 
                this.headers.splice(t, 1), e.date === this.endTS && e.id === this.endUID && (this.headers.length ? (this.endTS = this.headers[0].date, 
                this.endUID = this.headers[0].id) : (this.endTS = null, this.endUID = null)), e.date === this.startTS && e.id === this.startUID)) if (this.headers.length) {
                    var n = this.headers[this.headers.length - 1];
                    this.startTS = n.date, this.startUID = n.id;
                } else this.startTS = null, this.startUID = null;
            }
        },
        die: function() {
            this._bridgeHandle = null, this.desiredHeaders = 0, this._storage.dyingSlice(this), 
            this._LOG.__die();
        },
        get isDead() {
            return null === this._bridgeHandle;
        }
    };
    var B = t.FOLDER_DB_VERSION = 2;
    t.FolderStorage = o, o.isTypeLocalOnly = function(e) {
        if ("string" != typeof e) throw new Error("isTypeLocalOnly() expects a string, not " + e);
        return "outbox" === e || "localdrafts" === e;
    }, o.prototype = {
        get hasActiveSlices() {
            return this._slices.length > 0;
        },
        get isLocalOnly() {
            return o.isTypeLocalOnly(this.folderMeta.type);
        },
        resetAndRefreshActiveSlices: function() {
            if (this._slices.length) for (var e = this._slices.length - 1; e >= 0; e--) {
                var t = this._slices[e];
                t.desiredHeaders = u.INITIAL_FILL_SIZE, t.reset(), "folder" === t.type && this._resetAndResyncSlice(t, !0, null);
            }
        },
        generatePersistenceInfo: function() {
            if (!this._dirty) return null;
            var e = {
                id: this.folderId,
                headerBlocks: this._dirtyHeaderBlocks,
                bodyBlocks: this._dirtyBodyBlocks
            };
            return this._LOG.generatePersistenceInfo(e), this._dirtyHeaderBlocks = {}, this._dirtyBodyBlocks = {}, 
            this._dirty = !1, this.flushExcessCachedBlocks("persist"), this._account.universe.__notifyModifiedFolder(this._account, this.folderMeta), 
            e;
        },
        _invokeNextMutexedCall: function() {
            var e = this._mutexQueue[0], t = this, n = !1;
            this._mutexedCallInProgress = !0, this._LOG.mutexedCall_begin(e.name);
            try {
                var i = function(i) {
                    return n ? (t._LOG.tooManyCallbacks(e.name), void 0) : (t._LOG.mutexedCall_end(e.name), 
                    r.log("mailslice:mutex-released", {
                        folderId: t.folderId,
                        err: i
                    }), n = !0, t._mutexQueue[0] !== e ? (t._LOG.mutexInvariantFail(e.name, t._mutexQueue[0].name), 
                    void 0) : (t._mutexQueue.shift(), t.flushExcessCachedBlocks("mutex"), t._mutexQueue.length ? window.setZeroTimeout(t._invokeNextMutexedCall.bind(t)) : 0 === t._slices.length && t.folderSyncer.allConsumersDead(), 
                    void 0));
                };
                e.func(i);
            } catch (o) {
                this._LOG.mutexedOpErr(o);
            }
        },
        runMutexed: function(e, t) {
            var n = 0 === this._mutexQueue.length;
            this._mutexQueue.push({
                name: e,
                func: t
            }), n && this._invokeNextMutexedCall();
        },
        upgradeIfNeeded: function() {
            (!this.folderMeta.version || B > this.folderMeta.version) && this._account.universe.performFolderUpgrade(this.folderMeta.id);
        },
        _issueNewHeaderId: function() {
            return this._folderImpl.nextId++;
        },
        _makeHeaderBlock: function(e, t, n, i, o, s, r) {
            var a = c.encodeInt(this._folderImpl.nextHeaderBlock++), l = {
                blockId: a,
                startTS: e,
                startUID: t,
                endTS: n,
                endUID: i,
                count: s ? s.length : 0,
                estSize: o || 0
            }, d = {
                ids: s || [],
                headers: r || []
            };
            if (this._dirty = !0, this._headerBlocks[a] = d, this._dirtyHeaderBlocks[a] = d, 
            this._serverIdHeaderBlockMapping && r) for (var u = this._serverIdHeaderBlockMapping, p = 0; p < r.length; p++) {
                var h = r[p];
                h.srvid && (u[h.srvid] = a);
            }
            return l;
        },
        _insertHeaderInBlock: function(e, t, n, i) {
            var o = p(i.headers, e, f);
            i.ids.splice(o, 0, e.id), i.headers.splice(o, 0, e), this._dirty = !0, this._dirtyHeaderBlocks[n.blockId] = i;
        },
        _deleteHeaderFromBlock: function(e, t, n) {
            var i, o = n.ids.indexOf(e);
            return -1 === o ? (this._LOG.badDeletionRequest("header", null, e), void 0) : (i = n.headers[o], 
            i.flags && -1 === i.flags.indexOf("\\Seen") && this.folderMeta.unreadCount--, n.ids.splice(o, 1), 
            n.headers.splice(o, 1), t.estSize -= u.HEADER_EST_SIZE_IN_BYTES, t.count--, this._dirty = !0, 
            this._dirtyHeaderBlocks[t.blockId] = n, 0 === o && t.count && (i = n.headers[0], 
            t.endTS = i.date, t.endUID = i.id), o === t.count && o > 0 && (i = n.headers[o - 1], 
            t.startTS = i.date, t.startUID = i.id), void 0);
        },
        _splitHeaderBlock: function(e, t, n) {
            var i = Math.ceil(n / u.HEADER_EST_SIZE_IN_BYTES);
            if (i > t.headers.length) throw new Error("No need to split!");
            var o = t.headers.length - i, s = t.headers[i], r = this._makeHeaderBlock(e.startTS, e.startUID, s.date, s.id, o * u.HEADER_EST_SIZE_IN_BYTES, t.ids.splice(i, o), t.headers.splice(i, o)), a = t.headers[i - 1];
            return e.count = i, e.estSize = i * u.HEADER_EST_SIZE_IN_BYTES, e.startTS = a.date, 
            e.startUID = a.id, this._dirtyHeaderBlocks[e.blockId] = t, r;
        },
        _makeBodyBlock: function(e, t, n, i, o, s, r) {
            var a = c.encodeInt(this._folderImpl.nextBodyBlock++), l = {
                blockId: a,
                startTS: e,
                startUID: t,
                endTS: n,
                endUID: i,
                count: s ? s.length : 0,
                estSize: o || 0
            }, d = {
                ids: s || [],
                bodies: r || {}
            };
            return this._dirty = !0, this._bodyBlocks[a] = d, this._dirtyBodyBlocks[a] = d, 
            0 !== this._folderImpl.nextBodyBlock % u.BLOCK_PURGE_EVERY_N_NEW_BODY_BLOCKS || this._messagePurgeScheduled || (this._messagePurgeScheduled = !0, 
            this._account.scheduleMessagePurge(this.folderId)), l;
        },
        _insertBodyInBlock: function(e, t, n, i) {
            function o(n, o) {
                var s = n === t ? e.date : i.bodies[n].date, r = o === t ? e.date : i.bodies[o].date, a = r - s;
                return a ? a : a = o - n;
            }
            var s = p(i.ids, t, o);
            i.ids.splice(s, 0, t), i.bodies[t] = e, this._dirty = !0, this._dirtyBodyBlocks[n.blockId] = i;
        },
        _deleteBodyFromBlock: function(e, t, n) {
            var i = n.ids.indexOf(e), o = n.bodies[e];
            return -1 !== i && o ? (n.ids.splice(i, 1), delete n.bodies[e], t.estSize -= o.size, 
            t.count--, this._dirty = !0, this._dirtyBodyBlocks[t.blockId] = n, 0 === i && t.count && (t.endUID = e = n.ids[0], 
            t.endTS = n.bodies[e].date), i === t.count && i > 0 && (t.startUID = e = n.ids[i - 1], 
            t.startTS = n.bodies[e].date), void 0) : (this._LOG.bodyBlockMissing(e, i, !!o), 
            void 0);
        },
        _splitBodyBlock: function(e, t, n) {
            var i, o, s, r = e.startTS, a = e.startUID, c = 0, l = t.ids, d = {}, u = {}, p = null, h = l.length - 1;
            for (i = 0; h > i; i++) if (o = l[i], s = t.bodies[o], c += s.size, d[o] = s, c >= n) {
                i++;
                break;
            }
            for (e.count = p = i, e.startTS = s.date, e.startUID = o; i < l.length; i++) o = l[i], 
            u[o] = t.bodies[o];
            var f = l[p], m = this._makeBodyBlock(r, a, u[f].date, f, e.estSize - c, l.splice(p, l.length - p), u);
            return e.estSize = c, t.bodies = d, this._dirtyBodyBlocks[e.blockId] = t, m;
        },
        flushExcessCachedBlocks: function() {
            function e(e) {
                for (var t = 0; t < n.length; t++) {
                    var i = n[t];
                    if (L(i, e)) return !0;
                }
                return !1;
            }
            function t(e, t, n, i, o, s) {
                for (var r = n.length - 1; r > -1; r--) {
                    var a = n[r];
                    o.hasOwnProperty(a.blockId) || s(a) && (delete i[a.blockId], n.splice(r, 1));
                }
            }
            var n = this._slices.filter(function(e) {
                return "folder" === e.type;
            });
            t("header", this._headerBlockInfos, this._loadedHeaderBlockInfos, this._headerBlocks, this._dirtyHeaderBlocks, function(t) {
                return !e(t);
            });
            var i = n.length ? 1 : 0, o = 0;
            t("body", this._bodyBlockInfos, this._loadedBodyBlockInfos, this._bodyBlocks, this._dirtyBodyBlocks, function() {
                return o += 1, o > i;
            });
        },
        _flushExcessOnTimeout: function() {
            this._flushExcessTimeoutId = 0, this.isDead || 0 !== this._mutexQueue.length || this.flushExcessCachedBlocks("flushExcessOnTimeout");
        },
        _discardCachedBlockUsingDateAndID: function(e, t, n) {
            var i, o, s, r;
            this._LOG.discardFromBlock(e, t, n), "header" === e ? (i = this._headerBlockInfos, 
            o = this._loadedHeaderBlockInfos, s = this._headerBlocks, r = this._dirtyHeaderBlocks) : (i = this._bodyBlockInfos, 
            o = this._loadedBodyBlockInfos, s = this._bodyBlocks, r = this._dirtyBodyBlocks);
            var a = this._findRangeObjIndexForDateAndID(i, t, n), c = (a[0], a[1]);
            if (!c) return this._LOG.badDiscardRequest(e, t, n), void 0;
            var l = c.blockId;
            if (s.hasOwnProperty(l)) {
                if (r.hasOwnProperty(l)) return this._LOG.badDiscardRequest(e, t, n), void 0;
                delete s[l];
                var d = o.indexOf(c);
                -1 !== d && o.splice(d, 1);
            }
        },
        purgeExcessMessages: function(e) {
            this._messagePurgeScheduled = !1;
            var t = Math.max(this._purge_findLastAccessCutPoint(), this._purge_findHardBlockCutPoint(this._headerBlockInfos), this._purge_findHardBlockCutPoint(this._bodyBlockInfos));
            if (0 === t) return e(0, t), void 0;
            t = S(t + b) - this._account.tzOffset;
            var n = this._accuracyRanges, i = this._findFirstObjIndexForDateRange(n, t, t);
            i[1] ? (i[1].startTS = t, n.splice(i[0] + 1, n.length - i[0])) : n.splice(i[0], n.length - i[0]);
            var o = this._headerBlockInfos, s = (this._headerBlocks, 0), r = !1, a = !1, c = function() {
                if (r) return a = !0, void 0;
                for (;;) {
                    if (!o.length) return e(s, t), void 0;
                    var n = o[o.length - 1];
                    if (!this._headerBlocks.hasOwnProperty(n.blockId)) return this._loadBlock("header", n, c), 
                    void 0;
                    var i = this._headerBlocks[n.blockId], l = i.headers[i.headers.length - 1];
                    if (v(l.date, t)) return e(s, t), void 0;
                    if (a = !1, r = !0, s++, this.deleteMessageHeaderAndBodyUsingHeader(l, c), r = !1, 
                    !a) return;
                }
            }.bind(this);
            c();
        },
        _purge_findLastAccessCutPoint: function() {
            var e, t = this._accuracyRanges, n = d.NOW() - u.BLOCK_PURGE_ONLY_AFTER_UNSYNCED_MS;
            for (e = t.length; e >= 1; e--) {
                var i = t[e - 1];
                if (i.fullSync && i.fullSync.updated > n) break;
            }
            if (e === t.length) return 0;
            var o = t[e].endTS, s = u.SYNC_RANGE_ENUMS_TO_MS[this._account.accountDef.syncRange] || u.SYNC_RANGE_ENUMS_TO_MS.auto, r = d.NOW() - s - b;
            return _(o, r) ? r : o;
        },
        _purge_findHardBlockCutPoint: function(e) {
            return e.length <= u.BLOCK_PURGE_HARD_MAX_BLOCK_LIMIT ? 0 : e[u.BLOCK_PURGE_HARD_MAX_BLOCK_LIMIT].startTS;
        },
        _findRangeObjIndexForDate: function(e, t) {
            var n;
            for (n = 0; n < e.length; n++) {
                var i = e[n];
                if (v(t, i.endTS)) return [ n, null ];
                if (v(t, i.startTS)) return [ n, i ];
            }
            return [ n, null ];
        },
        _findRangeObjIndexForDateAndID: function(e, t, n) {
            var i;
            for (i = 0; i < e.length; i++) {
                var o = e[i];
                if (_(t, o.endTS) || t === o.endTS && n > o.endUID) return [ i, null ];
                if (_(t, o.startTS) || t === o.startTS && n >= o.startUID) return [ i, o ];
            }
            return [ i, null ];
        },
        _findFirstObjIndexForDateRange: function(e, t, n) {
            var i;
            for (i = 0; i < e.length; i++) {
                var o = e[i];
                if (_(t, o.endTS)) return [ i, null ];
                if (null === n || _(n, o.startTS)) return [ i, o ];
            }
            return [ i, null ];
        },
        _findLastObjIndexForDateRange: function(e, t, n) {
            var i;
            for (i = e.length - 1; i >= 0; i--) {
                var o = e[i];
                if (g(n, o.startTS)) return [ i + 1, null ];
                if (m(t, o.endTS)) return [ i, o ];
            }
            return [ 0, null ];
        },
        _findFirstObjForDateRange: function(e, t, n) {
            var i, o = null === n ? v : y;
            for (i = 0; i < e.length; i++) {
                var s = e[i].date;
                if (o(s, t, n)) return [ i, e[i] ];
            }
            return [ i, null ];
        },
        _insertIntoBlockUsingDateAndUID: function(e, t, n, i, o, s, r) {
            function a(e) {
                if (null !== x.startTS && (b.startTS = x.startTS), null !== x.startUID && (b.startUID = x.startUID), 
                null !== x.endTS && (b.endTS = x.endTS), null !== x.endUID && (b.endUID = x.endUID), 
                b.estSize += o, b.count++, h(s, n, b, e), b.count > 1 && b.estSize >= u.MAX_BLOCK_SIZE) {
                    var a;
                    a = 0 === y ? u.BLOCK_SPLIT_SMALL_PART : y === c.length - 1 ? u.BLOCK_SPLIT_LARGE_PART : u.BLOCK_SPLIT_EQUAL_PART;
                    var p;
                    p = f(b, e, a), c.splice(y + 1, 0, p), l.push(p), (m(t, p.endTS) || t === p.endTS && n <= p.endUID) && (y++, 
                    b = p, e = d[b.blockId]);
                }
                g && i && (g[i] = b.blockId), r && r(b, e);
            }
            var c, l, d, p, h, f, g;
            "header" === e ? (c = this._headerBlockInfos, l = this._loadedHeaderBlockInfos, 
            d = this._headerBlocks, g = this._serverIdHeaderBlockMapping, p = this._bound_makeHeaderBlock, 
            h = this._bound_insertHeaderInBlock, f = this._bound_splitHeaderBlock) : (c = this._bodyBlockInfos, 
            l = this._loadedBodyBlockInfos, d = this._bodyBlocks, g = null, p = this._bound_makeBodyBlock, 
            h = this._bound_insertBodyInBlock, f = this._bound_splitBodyBlock);
            var v = this._findRangeObjIndexForDateAndID(c, t, n), y = v[0], b = v[1], x = {
                startTS: null,
                startUID: null,
                endTS: null,
                endUID: null
            };
            b || (0 === c.length ? (b = p(t, n, t, n), c.splice(y, 0, b), l.push(b)) : y < c.length && c[y].estSize + o < u.MAX_BLOCK_SIZE ? (b = c[y], 
            _(t, b.endTS) ? (x.endTS = t, x.endUID = n) : t === b.endTS && n > b.endUID && (x.endUID = n)) : y > 0 && c[y - 1].estSize + o < u.MAX_BLOCK_SIZE ? (b = c[--y], 
            m(t, b.startTS) ? (x.startTS = t, x.startUID = n) : t === b.startTS && n < b.startUID && (x.startUID = n)) : y > 0 && y < c.length / 2 || y === c.length ? (b = c[--y], 
            m(t, b.startTS) ? (x.startTS = t, x.startUID = n) : t === b.startTS && n < b.startUID && (x.startUID = n)) : (b = c[y], 
            _(t, b.endTS) ? (x.endTS = t, x.endUID = n) : t === b.endTS && n > b.endUID && (x.endUID = n))), 
            d.hasOwnProperty(b.blockId) ? a.call(this, d[b.blockId]) : this._loadBlock(e, b, a.bind(this));
        },
        _runDeferredCalls: function() {
            for (;this._deferredCalls.length && 0 === this._pendingLoads.length; ) {
                var e = this._deferredCalls.shift();
                try {
                    e();
                } catch (t) {
                    this._LOG.callbackErr(t);
                }
            }
        },
        _findBlockInfoFromBlockId: function(e, t) {
            var n;
            n = "header" === e ? this._headerBlockInfos : this._bodyBlockInfos;
            for (var i = 0; i < n.length; i++) {
                var o = n[i];
                if (o.blockId === t) return o;
            }
            return null;
        },
        _loadBlock: function(e, t, n) {
            function i(n) {
                n || r._LOG.badBlockLoad(e, o), r._LOG.loadBlock_end(e, o, n), "header" === e ? (r._headerBlocks[o] = n, 
                r._loadedHeaderBlockInfos.push(t)) : (r._bodyBlocks[o] = n, r._loadedBodyBlockInfos.push(t)), 
                r._pendingLoads.splice(r._pendingLoads.indexOf(s), 1);
                var i = r._pendingLoadListeners[s];
                delete r._pendingLoadListeners[s];
                for (var a = 0; a < i.length; a++) try {
                    i[a](n);
                } catch (c) {
                    r._LOG.callbackErr(c);
                }
                0 === r._pendingLoads.length && r._runDeferredCalls(), 0 !== r._mutexQueue.length || r._flushExcessTimeoutId || (r._flushExcessTimeoutId = setTimeout(r._bound_flushExcessOnTimeout, 5e3));
            }
            var o = t.blockId, s = e + o;
            if (-1 !== this._pendingLoads.indexOf(s)) return this._pendingLoadListeners[s].push(n), 
            void 0;
            this._pendingLoads.length, this._pendingLoads.push(s), this._pendingLoadListeners[s] = [ n ];
            var r = this;
            this._LOG.loadBlock_begin(e, o), "header" === e ? this._imapDb.loadHeaderBlock(this.folderId, o, i) : this._imapDb.loadBodyBlock(this.folderId, o, i);
        },
        _deleteFromBlock: function(e, t, n, i) {
            function o(t) {
                c(n, u, t), 0 === u.count && (s.splice(d, 1), delete a[u.blockId], r.splice(r.indexOf(u), 1), 
                this._dirty = !0, "header" === e ? this._dirtyHeaderBlocks[u.blockId] = null : this._dirtyBodyBlocks[u.blockId] = null), 
                i && i();
            }
            var s, r, a, c;
            this._LOG.deleteFromBlock(e, t, n), "header" === e ? (s = this._headerBlockInfos, 
            r = this._loadedHeaderBlockInfos, a = this._headerBlocks, c = this._bound_deleteHeaderFromBlock) : (s = this._bodyBlockInfos, 
            r = this._loadedBodyBlockInfos, a = this._bodyBlocks, c = this._bound_deleteBodyFromBlock);
            var l = this._findRangeObjIndexForDateAndID(s, t, n), d = l[0], u = l[1];
            return u ? (a.hasOwnProperty(u.blockId) ? o.call(this, a[u.blockId]) : this._loadBlock(e, u, o.bind(this)), 
            void 0) : (this._LOG.badDeletionRequest(e, t, n), void 0);
        },
        sliceOpenSearch: function(e) {
            this._slices.push(e);
        },
        sliceOpenMostRecent: function(e, t) {
            e.setStatus("synchronizing", !1, !0, !1, R);
            var n = this._sliceOpenMostRecent.bind(this, e, t);
            this.isLocalOnly ? n(function() {}) : this.runMutexed("sync", n);
        },
        _sliceOpenMostRecent: function(e, t, n) {
            this._slices.push(e);
            var i = function(t, i, o) {
                i || (i = t ? "syncfailed" : "synced"), void 0 === o && (o = !1), e.waitingOnData = !1, 
                e.setStatus(i, !0, o, !0), this._curSyncSlice = null, n(t);
            }.bind(this);
            if (this._accuracyRanges.length || this.isLocalOnly) {
                var o;
                return o = this._account.universe.online && this.folderSyncer.syncable && !this.isLocalOnly ? t ? "force" : !0 : !1, 
                e.waitingOnData = "db", this.getMessagesInImapDateRange(0, null, u.INITIAL_FILL_SIZE, u.INITIAL_FILL_SIZE, this.onFetchDBHeaders.bind(this, e, o, i, n)), 
                void 0;
            }
            if (!this._account.universe.online || this.isLocalOnly) return i(), void 0;
            if (!this.folderSyncer.syncable) return console.log("Synchronization is currently blocked; waiting..."), 
            i(null, "syncblocked", !0), void 0;
            var s = e.setSyncProgress.bind(e), r = function(t, n) {
                e.waitingOnData = t, n && (e.ignoreHeaders = !0), this._curSyncSlice = e;
            }.bind(this);
            e._updateSliceFlags(), this.folderSyncer.initialSync(e, u.INITIAL_SYNC_DAYS, r, i, s);
        },
        growSlice: function(e, t, n) {
            n && e.setStatus("synchronizing", !1, !0, !1, R), this.runMutexed("grow", this._growSlice.bind(this, e, t, n));
        },
        _growSlice: function(e, t, n, i) {
            var o, s, r = [], a = function(t, a) {
                if (0 === t.length, r = o === T ? r.concat(t) : t.concat(r), !a) {
                    var c = function(t) {
                        e.desiredHeaders = e.headers.length, e.waitingOnData = !1, e.setStatus(t ? "syncfailed" : "synced", !0, !1, !0), 
                        this._curSyncSlice = null, i(t);
                    }.bind(this), l = e.setSyncProgress.bind(e);
                    if (r.length) {
                        var p;
                        if (this._account.universe.online && this._account.enabled && this.folderSyncer.canGrowSync) {
                            var h, f, m, g = !1;
                            if (o === T) {
                                var y = r[r.length - 1];
                                h = x() - u.OPEN_REFRESH_THRESH_MS + this._account.tzOffset, m = e.startTS + d.DAY_MILLIS + this._account.tzOffset, 
                                f = this.headerIsOldestKnown(y.date, y.id) ? this.getOldestFullSyncDate() : y.date + this._account.tzOffset;
                            } else {
                                h = x() - u.GROW_REFRESH_THRESH_MS + this._account.tzOffset;
                                var b = r[0];
                                f = e.endTS + this._account.tzOffset, m = b.date + d.DAY_MILLIS + this._account.tzOffset;
                            }
                            _(m, h) ? (m = h, g = !0) : m = S(m), p = v(f, m) ? null : this.checkAccuracyCoverageNeedingRefresh(S(f), m, u.GROW_REFRESH_THRESH_MS);
                        } else p = null;
                        return e.batchAppendHeaders(r, o === T ? -1 : 0, !0), e.desiredHeaders = Math.max(e.headers.length, s), 
                        p && p.startTS !== p.endTS ? (n || e.setStatus("synchronizing", !1, !0, !1, R), 
                        this.folderSyncer.refreshSync(e, o, S(p.startTS), g && p.endTS === h ? null : w(p.endTS), null, c, l)) : c(), 
                        void 0;
                    }
                    if (!this._account.universe.online || !this.folderSyncer.canGrowSync || !n) return this.folderSyncer.syncable && e.sendEmptyCompletion(), 
                    i(null), void 0;
                    n || e.setStatus("synchronizing", !1, !0, !1, R), this._curSyncSlice = e, e.waitingOnData = "grow", 
                    e.desiredHeaders += s, this.folderSyncer.growSync(e, o, o === T ? S(e.startTS) : S(e.endTS + d.DAY_MILLIS), u.INITIAL_SYNC_GROWTH_DAYS, c, l);
                }
            }.bind(this);
            0 === this._mutexQueue.length && this.flushExcessCachedBlocks("grow"), 0 > t ? (o = A, 
            s = -t, this.getMessagesAfterMessage(e.endTS, e.endUID, s, a)) : (o = T, s = t, 
            this.getMessagesBeforeMessage(e.startTS, e.startUID, s, a));
        },
        sliceShrunk: function() {
            0 === this._mutexQueue.length && this.flushExcessCachedBlocks("shrunk");
        },
        refreshSlice: function(e) {
            e.setStatus("synchronizing", !1, !0, !1, 0);
            var t = this._refreshSlice.bind(this, e, !1);
            this.isLocalOnly ? t(function() {}) : this.runMutexed("refresh", t);
        },
        _refreshSlice: function(e, t, n) {
            var i = function(t) {
                e._onAddingHeader = null;
                var i = "synced";
                switch (t) {
                  case "aborted":
                  case "unknown":
                    i = "syncfailed";
                }
                return n(t), e.waitingOnData = !1, e.setStatus(i, !0, !1, !1, null, a), void 0;
            }.bind(this);
            if (e.isDead) return console.log("MailSlice: Attempted to refresh a dead slice."), 
            i("unknown"), void 0;
            e.waitingOnData = "refresh";
            var o = e.startTS, s = e.endTS, r = null, a = null;
            if (this.headerIsYoungestKnown(s, e.endUID)) {
                var c = s;
                a = 0, e._onAddingHeader = function(t) {
                    !v(t.date, c) || t.flags && -1 !== t.flags.indexOf("\\Seen") || (a += 1, e.onNewHeader && e.onNewHeader(t));
                }.bind(this), s = null;
            } else s = S(s + b + this._account.tzOffset);
            return this.headerIsOldestKnown(o, e.startUID) ? (r = S(o + this._account.tzOffset), 
            o = this.getOldestFullSyncDate()) : o += this._account.tzOffset, o && (o = S(o)), 
            t && null === this.checkAccuracyCoverageNeedingRefresh(o, s || x() - u.OPEN_REFRESH_THRESH_MS + this._account.tzOffset, u.OPEN_REFRESH_THRESH_MS) ? (i(), 
            void 0) : (this.folderSyncer.refreshSync(e, A, o, s, r, i, e.setSyncProgress.bind(e)), 
            void 0);
        },
        _resetAndResyncSlice: function(e, t, n) {
            this._slices.splice(this._slices.indexOf(e), 1), n ? this._sliceOpenMostRecent(e, t, n) : this.sliceOpenMostRecent(e, t);
        },
        dyingSlice: function(e) {
            var t = this._slices.indexOf(e);
            this._slices.splice(t, 1), "folder" === e.type && this.flushExcessCachedBlocks("deadslice"), 
            0 === this._slices.length && 0 === this._mutexQueue.length && this.folderSyncer.allConsumersDead();
        },
        onFetchDBHeaders: function(e, t, n, i, o, s) {
            var r = !1;
            if (!s && t && (s = !0, r = !0), o.length && e.batchAppendHeaders(o, -1, !0), s) {
                if (r) {
                    e.desiredHeaders = e.headers.length, this._curSyncSlice = null;
                    var a = "force" !== t;
                    this._refreshSlice(e, a, i);
                }
            } else e.desiredHeaders = e.headers.length, n();
        },
        sliceQuicksearch: function() {},
        getYoungestMessageTimestamp: function() {
            return this._headerBlockInfos.length ? this._headerBlockInfos[0].endTS : 0;
        },
        headerIsYoungestKnown: function(e, t) {
            if (!this._headerBlockInfos.length) return null === e && null === t;
            var n = this._headerBlockInfos[0];
            return e === n.endTS && t === n.endUID;
        },
        getOldestMessageTimestamp: function() {
            return this._headerBlockInfos.length ? this._headerBlockInfos[this._headerBlockInfos.length - 1].startTS : 0;
        },
        headerIsOldestKnown: function(e, t) {
            if (!this._headerBlockInfos.length) return null === e && null === t;
            var n = this._headerBlockInfos[this._headerBlockInfos.length - 1];
            return e === n.startTS && t === n.startUID;
        },
        getNewestFullSyncDate: function() {
            return this._accuracyRanges.length ? this._accuracyRanges[0].endTS : 0;
        },
        getOldestFullSyncDate: function() {
            for (var e = this._accuracyRanges.length - 1; e >= 0 && !this._accuracyRanges[e].fullSync; ) e--;
            var t;
            return t = e >= 0 ? this._accuracyRanges[e].startTS : x();
        },
        syncedToToday: function() {
            if (!this.folderSyncer.canGrowSync) return !0;
            var e = this.getNewestFullSyncDate();
            return v(e, S(x() + this._account.tzOffset));
        },
        syncedToDawnOfTime: function() {
            if (!this.folderSyncer.canGrowSync) return !0;
            var e = this.getOldestFullSyncDate();
            return g(e, u.OLDEST_SYNC_DATE + d.DAY_MILLIS);
        },
        getKnownMessageCount: function() {
            for (var e = 0, t = 0; t < this._headerBlockInfos.length; t++) {
                var n = this._headerBlockInfos[t];
                e += n.count;
            }
            return e;
        },
        getMessagesInImapDateRange: function(e, t, n, i, o) {
            function s() {
                for (;;) {
                    if (!l._headerBlocks.hasOwnProperty(r.blockId)) return l._loadBlock("header", r, s), 
                    void 0;
                    var n = l._headerBlocks[r.blockId], i = l._findFirstObjForDateRange(n.headers, e, t), u = i[0], p = i[1];
                    if (!p) return o([], !1), void 0;
                    for (var h = u; h < n.headers.length && c && (p = n.headers[h], !m(p.date, e)); h++, 
                    c--) ;
                    if (c && h < n.headers.length ? a = 0 : a -= h - u, a && (++d >= l._headerBlockInfos.length ? a = 0 : (r = l._headerBlockInfos[d], 
                    _(e, r.endTS) && (a = 0))), o(n.headers.slice(u, h), Boolean(a)), !a) return;
                }
            }
            var r, a = null != n ? n : u.TOO_MANY_MESSAGES, c = null != i ? i : u.TOO_MANY_MESSAGES, l = this, d = null, p = this._findFirstObjIndexForDateRange(this._headerBlockInfos, e, t);
            return d = p[0], (r = p[1]) ? (s(), void 0) : (o([], !1), void 0);
        },
        getAllMessagesInImapDateRange: function(e, t, n) {
            function i(e, t) {
                o = o ? o.concat(e) : e, t || n(o);
            }
            var o = null;
            this.getMessagesInImapDateRange(e, t, null, null, i);
        },
        getMessagesBeforeMessage: function(e, t, n, i) {
            function o() {
                for (;;) {
                    if (!l._headerBlocks.hasOwnProperty(a.blockId)) return l._loadBlock("header", a, o), 
                    void 0;
                    var n = l._headerBlocks[a.blockId];
                    null === d ? null != t ? (d = p(n.headers, {
                        date: e,
                        id: t
                    }, f), n.ids[d] === t && d++) : d = 1 : d = 0;
                    var s = Math.min(n.headers.length - d, c);
                    if (d >= n.headers.length && (s = 0), c -= s, c && (++r >= l._headerBlockInfos.length ? c = 0 : a = l._headerBlockInfos[r]), 
                    i(n.headers.slice(d, d + s), Boolean(c)), !c) return;
                }
            }
            var s, r, a, c = null != n ? n : u.TOO_MANY_MESSAGES, l = this;
            if (e ? (s = this._findRangeObjIndexForDateAndID(this._headerBlockInfos, e, t), 
            r = s[0], a = s[1]) : (r = 0, a = this._headerBlockInfos[0]), !a) {
                if (!(r < this._headerBlockInfos.length)) return i([], !1), void 0;
                a = this._headerBlockInfos[r];
            }
            var d = null;
            o();
        },
        getMessagesAfterMessage: function(e, t, n, i) {
            function o() {
                for (;;) {
                    if (!r._headerBlocks.hasOwnProperty(l.blockId)) return r._loadBlock("header", l, o), 
                    void 0;
                    var n = r._headerBlocks[l.blockId];
                    null === d ? (d = n.ids.indexOf(t), -1 === d && (r._LOG.badIterationStart(e, t), 
                    s = 0), d--) : d = n.headers.length - 1;
                    var a = Math.min(d + 1, s);
                    0 > d && (a = 0), s -= a, s && (--c < 0 ? s = 0 : l = r._headerBlockInfos[c]);
                    var u = n.headers.slice(d - a + 1, d + 1);
                    if (i(u, Boolean(s)), !s) return;
                }
            }
            var s = null != n ? n : u.TOO_MANY_MESSAGES, r = this, a = this._findRangeObjIndexForDateAndID(this._headerBlockInfos, e, t), c = a[0], l = a[1];
            if (!l) return this._LOG.badIterationStart(e, t), i([], !1), void 0;
            var d = null;
            o();
        },
        markSyncRange: function(e, t, n, i) {
            function o(e, t, n, i) {
                return {
                    startTS: e,
                    endTS: t,
                    fullSync: "string" == typeof n ? {
                        highestModseq: n,
                        updated: i
                    } : {
                        highestModseq: n.fullSync.highestModseq,
                        updated: n.fullSync.updated
                    }
                };
            }
            if (t || (t = x() + this._account.tzOffset), e > t) throw new Error("Your timestamps are switched!");
            var s, r, a = this._accuracyRanges, c = this._findFirstObjIndexForDateRange(a, e, t), l = this._findLastObjIndexForDateRange(a, e, t);
            s = c[1] && _(c[1].endTS, t), r = l[1] && m(l[1].startTS, e);
            var d = [], u = l[0] - c[0];
            l[1] && u++, s && (c[1].fullSync && c[1].fullSync.highestModseq === n && c[1].fullSync.updated === i ? t = c[1].endTS : d.push(o(t, c[1].endTS, c[1]))), 
            d.push(o(e, t, n, i)), r && (l[1].fullSync && l[1].fullSync.highestModseq === n && l[1].fullSync.updated === i ? d[d.length - 1].startTS = l[1].startTS : d.push(o(l[1].startTS, e, l[1])));
            var p = c[0] > 0 ? a[c[0] - 1] : null, h = l[1] ? 1 : 0, f = l[0] < a.length - h ? a[l[0] + h] : null;
            p && d[0].endTS === p.startTS && p.fullSync && p.fullSync.highestModseq === n && p.fullSync.updated === i && (d[0].endTS = p.endTS, 
            c[0]--, u++), f && d[d.length - 1].startTS === f.endTS && f.fullSync && f.fullSync.highestModseq === n && f.fullSync.updated === i && (d[d.length - 1].startTS = f.startTS, 
            u++), a.splice.apply(a, [ c[0], u ].concat(d)), this.folderMeta.lastSyncedAt = x(), 
            this._dirty = !0;
        },
        markSyncedToDawnOfTime: function() {
            this._LOG.syncedToDawnOfTime();
            var e = this._accuracyRanges;
            e[e.length - 1].startTS = u.OLDEST_SYNC_DATE, this.folderMeta.lastSyncedAt = x(), 
            this._dirty = !0;
        },
        clearSyncedToDawnOfTime: function(e) {
            var t = this._accuracyRanges;
            if (t.length) {
                var n = t[t.length - 1];
                _(n.endTS, e) ? n.startTS = e : (this._LOG.accuracyRangeSuspect(n), t.pop());
            }
        },
        checkAccuracyCoverageNeedingRefresh: function(e, t, n) {
            var i, o = this._accuracyRanges, s = this._findFirstObjIndexForDateRange(o, e, t), r = this._findLastObjIndexForDateRange(o, e, t), a = x() - n, c = {
                startTS: e,
                endTS: t
            };
            if (s[1]) {
                var l;
                for (l = s[0]; l <= r[0] && (i = o[l], !m(i.endTS, c.endTS)) && i.fullSync && !m(i.fullSync.updated, a); l++) {
                    if (g(i.startTS, c.startTS)) return null;
                    c.endTS = i.startTS;
                }
                for (l = r[0]; l >= 0 && (i = o[l], !_(i.startTS, c.startTS)) && i.fullSync && !m(i.fullSync.updated, a); l--) c.startTS = i.endTS;
            }
            return c;
        },
        getMessage: function(e, t, n, i) {
            function o() {
                if (!--a) {
                    if (!r || !s) return i(null);
                    i({
                        header: s,
                        body: r
                    });
                }
            }
            "function" == typeof n && (i = n, n = void 0);
            var s, r, a = 2;
            this.getMessageHeader(e, t, function(e) {
                s = e, o();
            });
            var c = function(e) {
                r = e, o();
            };
            n && n.withBodyReps ? this.getMessageBodyWithReps(e, t, c) : this.getMessageBody(e, t, c);
        },
        getMessageHeader: function(e, t, n) {
            var i = parseInt(e.substring(e.lastIndexOf("/") + 1)), o = this._findRangeObjIndexForDateAndID(this._headerBlockInfos, t, i);
            if (null !== o[1]) {
                var s = o[1], r = this;
                if (!this._headerBlocks.hasOwnProperty(s.blockId)) return this._loadBlock("header", s, function(e) {
                    var t = e.ids.indexOf(i), o = e.headers[t] || null;
                    o || r._LOG.headerNotFound();
                    try {
                        n(o);
                    } catch (s) {
                        r._LOG.callbackErr(s);
                    }
                }), void 0;
                var a = this._headerBlocks[s.blockId], c = a.ids.indexOf(i), l = a.headers[c] || null;
                l || this._LOG.headerNotFound();
                try {
                    n(l);
                } catch (d) {
                    this._LOG.callbackErr(d);
                }
            } else {
                this._LOG.headerNotFound();
                try {
                    n(null);
                } catch (d) {
                    this._LOG.callbackErr(d);
                }
            }
        },
        getMessageHeaders: function(e, t) {
            for (var n = e.length, i = [], o = function(e) {
                e && i.push(e), --n || t(i);
            }, s = 0; s < e.length; s++) {
                var r = e[s];
                this.getMessageHeader(r.suid, r.date, o);
            }
        },
        addMessageHeader: function(e, t, n) {
            if (null == e.id || null == e.suid) throw new Error("No valid id: " + e.id + " or suid: " + e.suid);
            if (this._pendingLoads.length) return this._deferredCalls.push(this.addMessageHeader.bind(this, e, t, n)), 
            void 0;
            if (e.flags && -1 === e.flags.indexOf("\\Seen") && this.folderMeta.unreadCount++, 
            this._LOG.addMessageHeader(e.date, e.id, e.srvid), this.headerCount += 1, this._curSyncSlice && (this._curSyncSlice.headerCount = this.headerCount, 
            this._curSyncSlice.ignoreHeaders || this._curSyncSlice.onHeaderAdded(e, t, !0, !0)), 
            this._slices.length > (this._curSyncSlice ? 1 : 0)) for (var i = e.date, o = e.id, s = 0; s < this._slices.length; s++) {
                var r = this._slices[s];
                if (r !== this._curSyncSlice) {
                    if ("folder" === r.type && (r.headerCount = this.headerCount), null !== r.startTS) {
                        if (m(i, r.startTS)) {
                            if (r.headers.length >= r.desiredHeaders) continue;
                        } else if (v(i, r.endTS)) {
                            if (!this._headerBlockInfos.length || r.endTS !== this._headerBlockInfos[0].endTS || r.endUID !== this._headerBlockInfos[0].endUID) continue;
                        } else if (i === r.startTS && o < r.startUID || i === r.endTS && o > r.endUID) continue;
                    } else r.desiredHeaders++;
                    if (r._onAddingHeader) try {
                        r._onAddingHeader(e);
                    } catch (a) {
                        this._LOG.callbackErr(a);
                    }
                    try {
                        r.onHeaderAdded(e, t, !1, !0);
                    } catch (a) {
                        this._LOG.callbackErr(a);
                    }
                }
            }
            this._insertIntoBlockUsingDateAndUID("header", e.date, e.id, e.srvid, u.HEADER_EST_SIZE_IN_BYTES, e, n);
        },
        updateMessageHeader: function(e, t, n, i, o, s) {
            function r(r) {
                var a, d = r.ids.indexOf(t);
                if (-1 === d) {
                    if (!(i instanceof Function)) throw new Error("Failed to find ID " + t + "!");
                    i(null);
                } else i instanceof Function ? i(a = r.headers[d]) || (a = null) : a = r.headers[d] = i;
                if (a && (l._dirty = !0, l._dirtyHeaderBlocks[c.blockId] = r, l._LOG.updateMessageHeader(a.date, a.id, a.srvid), 
                l._slices.length > (l._curSyncSlice ? 1 : 0))) for (var u = 0; u < l._slices.length; u++) {
                    var p = l._slices[u];
                    if (!(n && p === l._curSyncSlice || m(e, p.startTS) || _(e, p.endTS) || e === p.startTS && t < p.startUID || e === p.endTS && t > p.endUID)) try {
                        p.onHeaderModified(a, o);
                    } catch (h) {
                        this._LOG.callbackErr(h);
                    }
                }
                s && s();
            }
            if (this._pendingLoads.length) return this._deferredCalls.push(this.updateMessageHeader.bind(this, e, t, n, i, o, s)), 
            void 0;
            var a = this._findRangeObjIndexForDateAndID(this._headerBlockInfos, e, t), c = (a[0], 
            a[1]), l = this;
            if (c) this._headerBlocks.hasOwnProperty(c.blockId) ? r(this._headerBlocks[c.blockId]) : this._loadBlock("header", c, r); else {
                if (!(i instanceof Function)) throw new Error("Failed to find block containing header with date: " + e + " id: " + t);
                i(null);
            }
        },
        updateMessageHeaderByServerId: function(e, t, n, i, o) {
            if (this._pendingLoads.length) return this._deferredCalls.push(this.updateMessageHeaderByServerId.bind(this, e, t, n, i, o)), 
            void 0;
            var s = this._serverIdHeaderBlockMapping[e];
            if (void 0 === e) return this._LOG.serverIdMappingMissing(e), void 0;
            var r = function(s) {
                for (var r = s.headers, a = 0; a < r.length; a++) {
                    var c = r[a];
                    if (c.srvid === e) return this.updateMessageHeader(c.date, c.id, t, n, i, o), void 0;
                }
            }.bind(this);
            if (this._headerBlocks.hasOwnProperty(s)) r(this._headerBlocks[s]); else {
                var a = this._findBlockInfoFromBlockId("header", s);
                this._loadBlock("header", a, r);
            }
        },
        unchangedMessageHeader: function(e) {
            return this._pendingLoads.length ? (this._deferredCalls.push(this.unchangedMessageHeader.bind(this, e)), 
            void 0) : (this._curSyncSlice && !this._curSyncSlice.ignoreHeaders && this._curSyncSlice.onHeaderAdded(e, !0, !1), 
            void 0);
        },
        hasMessageWithServerId: function(e) {
            if (!this._serverIdHeaderBlockMapping) throw new Error("Server ID mapping not supported for this storage!");
            var t = this._serverIdHeaderBlockMapping[e];
            return void 0 === e ? (this._LOG.serverIdMappingMissing(e), !1) : !!t;
        },
        deleteMessageHeaderAndBody: function(e, t, n) {
            this.getMessageHeader(e, t, function(e) {
                e ? this.deleteMessageHeaderAndBodyUsingHeader(e, n) : n();
            }.bind(this));
        },
        deleteMessageHeaderUsingHeader: function(e, t) {
            if (this._pendingLoads.length) return this._deferredCalls.push(this.deleteMessageHeaderUsingHeader.bind(this, e, t)), 
            void 0;
            if (this.headerCount -= 1, this._curSyncSlice && (this._curSyncSlice.headerCount = this.headerCount, 
            this._curSyncSlice.ignoreHeaders || this._curSyncSlice.onHeaderRemoved(e)), this._slices.length > (this._curSyncSlice ? 1 : 0)) for (var n = 0; n < this._slices.length; n++) {
                var i = this._slices[n];
                "folder" === i.type && (i.headerCount = this.headerCount), i !== this._curSyncSlice && (m(e.date, i.startTS) || _(e.date, i.endTS) || e.date === i.startTS && e.id < i.startUID || e.date === i.endTS && e.id > i.endUID || i.onHeaderRemoved(e));
            }
            this._serverIdHeaderBlockMapping && e.srvid && delete this._serverIdHeaderBlockMapping[e.srvid], 
            this._deleteFromBlock("header", e.date, e.id, t);
        },
        deleteMessageHeaderAndBodyUsingHeader: function(e, t) {
            return this._pendingLoads.length ? (this._deferredCalls.push(this.deleteMessageHeaderAndBodyUsingHeader.bind(this, e, t)), 
            void 0) : (this.deleteMessageHeaderUsingHeader(e, function() {
                this._deleteFromBlock("body", e.date, e.id, t);
            }.bind(this)), void 0);
        },
        deleteMessageByServerId: function(e, t) {
            if (!this._serverIdHeaderBlockMapping) throw new Error("Server ID mapping not supported for this storage!");
            if (this._pendingLoads.length) return this._deferredCalls.push(this.deleteMessageByServerId.bind(this, e, t)), 
            void 0;
            var n = this._serverIdHeaderBlockMapping[e];
            if (void 0 === e) return this._LOG.serverIdMappingMissing(e), void 0;
            var i = function(n) {
                for (var i = n.headers, o = 0; o < i.length; o++) {
                    var s = i[o];
                    if (s.srvid === e) return this.deleteMessageHeaderAndBodyUsingHeader(s, t), void 0;
                }
            }.bind(this);
            if (this._headerBlocks.hasOwnProperty(n)) i(this._headerBlocks[n]); else {
                var o = this._findBlockInfoFromBlockId("header", n);
                this._loadBlock("header", o, i);
            }
        },
        addMessageBody: function(e, t, n) {
            function i(e) {
                if (l += C, e) for (var t = 0; t < e.length; t++) {
                    var n = e[t];
                    l += E + 2 * k + (n.name ? n.name.length : 0) + (n.address ? n.address.length : 0);
                }
            }
            function o(e) {
                if (l += C, e) for (var t = 0; t < e.length; t++) {
                    var n = e[t];
                    l += E + 2 * k + n.name.length + n.type.length + I;
                }
            }
            function s(e) {
                l += k + e.length;
            }
            function r(e) {
                if (l += M, e) for (var t = 0; t < e.length; t++) l += k + e[t].length;
            }
            function a(e) {
                l += M + D * (e.length / 2) + N * (e.length / 2);
                for (var t = 1; t < e.length; t += 2) e[t] && (l += e[t].length);
            }
            function c(e) {
                if (e) {
                    l += N * (e.length / 2);
                    for (var t = 0; t < e.length; t++) {
                        var n = e[t];
                        "html" === n.type ? l += N + n.amountDownloaded : n.content && a(n.content);
                    }
                }
            }
            if (this._pendingLoads.length) return this._deferredCalls.push(this.addMessageBody.bind(this, e, t, n)), 
            void 0;
            this._LOG.addMessageBody(e.date, e.id, e.srvid, t);
            var l = E + I + 4 * O;
            t.to && i(t.to), t.cc && i(t.cc), t.bcc && i(t.bcc), t.replyTo && s(t.replyTo), 
            o(t.attachments), o(t.relatedParts), r(t.references), c(t.bodyReps), t.size = l, 
            this._insertIntoBlockUsingDateAndUID("body", e.date, e.id, e.srvid, t.size, t, n);
        },
        messageBodyRepsDownloaded: function(e) {
            if (!e.bodyReps || !e.bodyReps.length) return !0;
            var t = e.bodyReps.every(function(e) {
                return e.isDownloaded;
            });
            if ("pop3" !== this._account.type || "inbox" !== this.folderMeta.type) return t;
            var n = e.attachments.every(function(e) {
                return !!e.file;
            });
            return t && n;
        },
        getMessageBodyWithReps: function(e, t, n) {
            var i = this;
            this.getMessageBody(e, t, function(o) {
                return o ? i.messageBodyRepsDownloaded(o) ? n(o) : (i._account.universe.downloadMessageBodyReps(e, t, function(e, t) {
                    n(t);
                }), void 0) : n(o);
            });
        },
        getMessageBody: function(e, t, n) {
            if (this._pendingLoads.length) return this._deferredCalls.push(this.getMessageBody.bind(this, e, t, n)), 
            void 0;
            var i = parseInt(e.substring(e.lastIndexOf("/") + 1)), o = this._findRangeObjIndexForDateAndID(this._bodyBlockInfos, t, i);
            if (null !== o[1]) {
                var s = o[1], r = this;
                if (!this._bodyBlocks.hasOwnProperty(s.blockId)) return this._loadBlock("body", s, function(e) {
                    var t = e.bodies[i] || null;
                    t || r._LOG.bodyNotFound();
                    try {
                        n(t);
                    } catch (o) {
                        r._LOG.callbackErr(o);
                    }
                }), void 0;
                var a = this._bodyBlocks[s.blockId], c = a.bodies[i] || null;
                c || this._LOG.bodyNotFound();
                try {
                    n(c);
                } catch (l) {
                    this._LOG.callbackErr(l);
                }
            } else {
                this._LOG.bodyNotFound();
                try {
                    n(null);
                } catch (l) {
                    this._LOG.callbackErr(l);
                }
            }
        },
        updateMessageBody: function(e, t, n, i, o) {
            function s() {
                n.flushBecause ? (t = null, l._account.saveAccountState(null, function() {
                    l.getMessageBody(a, e.date, r);
                }, "flushBody")) : r();
            }
            function r(e) {
                e && (t = e), i && l._account.universe && l._account.universe.__notifyModifiedBody(a, i, t), 
                o && o(t);
            }
            if ("function" == typeof i && (o = i, i = null), this._pendingLoads.length) return this._deferredCalls.push(this.updateMessageBody.bind(this, e, t, n, i, o)), 
            void 0;
            var a = e.suid, c = parseInt(a.substring(a.lastIndexOf("/") + 1)), l = this;
            this._deleteFromBlock("body", e.date, c, function() {
                l.addMessageBody(e, t, s);
            });
        },
        shutdown: function() {
            for (var e = this._slices.length - 1; e >= 0; e--) this._slices[e].die();
            this.folderSyncer.shutdown(), this._LOG.__die();
        },
        youAreDeadCleanupAfterYourself: function() {}
    };
    var F = t.LOGFAB = s.register(n, {
        MailSlice: {
            type: s.QUERY,
            events: {
                headersAppended: {},
                headerAdded: {
                    index: !1
                },
                headerModified: {
                    index: !1
                },
                headerRemoved: {
                    index: !1
                }
            },
            TEST_ONLY_events: {
                headersAppended: {
                    headers: !1
                },
                headerAdded: {
                    header: !1
                },
                headerModified: {
                    header: !1
                },
                headerRemoved: {
                    header: !1
                }
            }
        },
        FolderStorage: {
            type: s.DATABASE,
            events: {
                addMessageHeader: {
                    date: !1,
                    id: !1,
                    srvid: !1
                },
                addMessageBody: {
                    date: !1,
                    id: !1,
                    srvid: !1
                },
                updateMessageHeader: {
                    date: !1,
                    id: !1,
                    srvid: !1
                },
                updateMessageBody: {
                    date: !1,
                    id: !1
                },
                generatePersistenceInfo: {},
                deleteFromBlock: {
                    type: !1,
                    date: !1,
                    id: !1
                },
                discardFromBlock: {
                    type: !1,
                    date: !1,
                    id: !1
                },
                headerNotFound: {},
                bodyNotFound: {},
                syncedToDawnOfTime: {}
            },
            TEST_ONLY_events: {
                addMessageBody: {
                    body: !1
                },
                generatePersistenceInfo: {
                    details: !1
                }
            },
            asyncJobs: {
                loadBlock: {
                    type: !1,
                    blockId: !1
                },
                mutexedCall: {
                    name: !0
                }
            },
            TEST_ONLY_asyncJobs: {
                loadBlock: {
                    block: !1
                }
            },
            errors: {
                callbackErr: {
                    ex: s.EXCEPTION
                },
                badBlockLoad: {
                    type: !1,
                    blockId: !1
                },
                badIterationStart: {
                    date: !1,
                    id: !1
                },
                badDeletionRequest: {
                    type: !1,
                    date: !1,
                    id: !1
                },
                badDiscardRequest: {
                    type: !1,
                    date: !1,
                    id: !1
                },
                bodyBlockMissing: {
                    id: !1,
                    idx: !1,
                    dict: !1
                },
                serverIdMappingMissing: {
                    srvid: !1
                },
                accuracyRangeSuspect: {
                    arange: !1
                },
                mutexedOpErr: {
                    err: s.EXCEPTION
                },
                tooManyCallbacks: {
                    name: !1
                },
                mutexInvariantFail: {
                    fireName: !1,
                    curName: !1
                }
            }
        }
    });
}), define("cronsync", [ "rdcommon/log", "./worker-router", "./slice_bridge_proxy", "./mailslice", "./syncbase", "./allback", "module", "exports" ], function(e, t, n, i, o, s, r, a) {
    function c(e) {
        console.log("cronsync: " + e + "\n");
    }
    function l(e, t, n) {
        var o = {
            __sendMessage: function() {}
        }, s = new u(o, "cron"), r = new i.MailSlice(s, e, n), a = s.sendStatus, c = [];
        return r.onNewHeader = function(e) {
            console.log("onNewHeader: " + e), c.push(e);
        }, s.sendStatus = function(e) {
            if (a.apply(this, arguments), t) switch (e) {
              case "synced":
              case "syncfailed":
              case "syncblocked":
                try {
                    t(c);
                } catch (n) {
                    throw console.error("cronsync callback error:", n, "\n", n.stack), t = null, n;
                }
                t = null;
            }
        }, r;
    }
    function d(e, n) {
        this._universe = e, this._LOG = p.CronSync(this, null, n), this._activeSlices = [], 
        this._completedEnsureSync = !0, this._syncAccountsDone = !0, this._onSyncDone = null, 
        this._synced = [], this.sendCronSync = t.registerSimple("cronsync", function(e) {
            var t = e.args;
            switch (e.cmd) {
              case "alarm":
                c("received an alarm via a message handler"), this.onAlarm.apply(this, t);
                break;

              case "syncEnsured":
                c("received an syncEnsured via a message handler"), this.onSyncEnsured.apply(this, t);
            }
        }.bind(this)), this.sendCronSync("hello"), this.ensureSync();
    }
    var u = n.SliceBridgeProxy;
    a.CronSync = d, d.prototype = {
        _killSlices: function() {
            this._LOG.killSlices(this._activeSlices.length), this._activeSlices.forEach(function(e) {
                e.die();
            });
        },
        ensureSync: function() {
            if (this._completedEnsureSync) {
                this._LOG.ensureSync_begin(), this._completedEnsureSync = !1, c("ensureSync called");
                var e = this._universe.accounts, t = {};
                e.forEach(function(e) {
                    var n = e.accountDef.syncInterval, i = "interval" + n;
                    t.hasOwnProperty(i) || (t[i] = []), t[i].push(e.id);
                }), this.sendCronSync("ensureSync", [ t ]);
            }
        },
        syncAccount: function(e, t) {
            if (!this._universe.online || !e.enabled) return c("syncAcount early exit: online: " + this._universe.online + ", enabled: " + e.enabled), 
            this._LOG.syncSkipped(e.id), t(), void 0;
            var n = s.latch(), i = n.defer("inbox"), r = e.getFirstFolderWithType("inbox"), a = e.getFolderStorageForFolderId(r.id);
            this._LOG.syncAccount_begin(e.id), this._LOG.syncAccountHeaders_begin(e.id, null);
            var d = l(a, function(t) {
                this._LOG.syncAccountHeaders_end(e.id, t), this._activeSlices.splice(this._activeSlices.indexOf(d), 1);
                var n = [];
                t.some(function(t, i) {
                    return n.push({
                        date: t.date,
                        from: t.author.name || t.author.address,
                        subject: t.subject,
                        accountId: e.id,
                        messageSuid: t.suid
                    }), i === o.CRONSYNC_MAX_MESSAGES_TO_REPORT_PER_ACCOUNT - 1 ? !0 : void 0;
                }), t.length ? (c("Asking for snippets for " + n.length + " headers"), "pop3+smtp" === e.accountDef.type ? (this._LOG.syncAccount_end(e.id), 
                i([ t.length, n ])) : this._universe.online ? (this._LOG.syncAccountSnippets_begin(e.id), 
                this._universe.downloadBodies(t.slice(0, o.CRONSYNC_MAX_SNIPPETS_TO_FETCH_PER_ACCOUNT), {
                    maximumBytesToFetch: o.MAX_SNIPPET_BYTES
                }, function() {
                    c("Notifying for " + t.length + " headers"), this._LOG.syncAccountSnippets_end(e.id), 
                    this._LOG.syncAccount_end(e.id), i([ t.length, n ]);
                }.bind(this))) : (this._LOG.syncAccount_end(e.id), c("UNIVERSE OFFLINE. Notifying for " + t.length + " headers"), 
                i([ t.length, n ]))) : (this._LOG.syncAccount_end(e.id), i()), d.die();
            }.bind(this), this._LOG);
            this._activeSlices.push(d), a.sliceOpenMostRecent(d, !0);
            var u = e.getFirstFolderWithType("outbox");
            if (u) {
                var p = e.getFolderStorageForFolderId(u.id);
                if (p.getKnownMessageCount() > 0) {
                    var h = n.defer("outbox");
                    this._LOG.sendOutbox_begin(e.id), this._universe.sendOutboxMessages(e, {
                        reason: "syncAccount"
                    }, function() {
                        this._LOG.sendOutbox_end(e.id), h();
                    }.bind(this));
                }
            }
            n.then(function(n) {
                var i = n.inbox[0];
                this._universe.waitForAccountOps(e, function() {
                    e.runAfterSaves(function() {
                        t(i);
                    });
                });
            }.bind(this));
        },
        onAlarm: function(e) {
            if (this._LOG.alarmFired(e), e) {
                var t = this._universe.accounts, n = [], i = [];
                this._cronsyncing = !0, this._LOG.cronSync_begin(), this._universe.__notifyStartedCronSync(e), 
                e.forEach(function(e) {
                    t.some(function(t) {
                        return t.id === e ? (n.push(t), i.push(e), !0) : void 0;
                    });
                }), this._syncAccountsDone = !1, this.ensureSync();
                var o = n.length, s = 0, r = {
                    accountIds: e
                }, a = function() {
                    s += 1, o > s || (this._killSlices(), this._syncAccountsDone = !0, this._onSyncDone = function() {
                        this._synced.length && (r.updates = this._synced, this._synced = []), this._universe.__notifyStoppedCronSync(r), 
                        this._LOG.syncAccounts_end(r);
                    }.bind(this), this._checkSyncDone());
                }.bind(this);
                if (!i.length) return a(), void 0;
                this._LOG.syncAccounts_begin(), n.forEach(function(e) {
                    this.syncAccount(e, function(t) {
                        t && this._synced.push({
                            id: e.id,
                            address: e.identities[0].address,
                            count: t[0],
                            latestMessageInfos: t[1]
                        }), a();
                    }.bind(this));
                }.bind(this));
            }
        },
        _checkSyncDone: function() {
            this._completedEnsureSync && this._syncAccountsDone && this._onSyncDone && (this._onSyncDone(), 
            this._onSyncDone = null, this._LOG.cronSync_end());
        },
        onSyncEnsured: function() {
            this._completedEnsureSync = !0, this._LOG.ensureSync_end(), this._checkSyncDone();
        },
        shutdown: function() {
            t.unregister("cronsync"), this._killSlices();
        }
    };
    var p = a.LOGFAB = e.register(r, {
        CronSync: {
            type: e.DAEMON,
            events: {
                alarmFired: {
                    accountIds: !1
                },
                killSlices: {
                    count: !1
                },
                syncSkipped: {
                    id: !0
                }
            },
            TEST_ONLY_events: {},
            asyncJobs: {
                cronSync: {},
                ensureSync: {},
                syncAccounts: {
                    accountsResults: !1
                },
                syncAccount: {
                    id: !0
                },
                syncAccountHeaders: {
                    id: !0,
                    newHeaders: !1
                },
                syncAccountSnippets: {
                    id: !0
                },
                sendOutbox: {
                    id: !0
                }
            },
            TEST_ONLY_asyncJobs: {},
            errors: {},
            calls: {},
            TEST_ONLY_calls: {}
        }
    });
}), define("accountcommon", [ "./a64", "./slog", "./allback", "require", "module", "exports" ], function(e, t, n, i, o, s) {
    function r(e, t) {
        "activesync" === e ? i([ "activesync/configurator" ], t) : ("pop3+smtp" === e || "imap+smtp" === e) && i([ "composite/configurator" ], t);
    }
    function a(e, t) {
        r(e, function(e) {
            t(e.account.Account);
        });
    }
    function c(t, n, i) {
        var o = [];
        for (var s in Iterator(i)) {
            var r = s[1];
            o.push({
                id: n + "/" + e.encodeInt(t.config.nextIdentityNum++),
                name: r.name,
                address: r.address,
                replyTo: r.replyTo,
                signature: r.signature,
                signatureEnabled: r.signatureEnabled
            });
        }
        return o;
    }
    function l(e, t) {
        function n(t) {
            return t.replace("%EMAILADDRESS%", e.emailAddress).replace("%EMAILLOCALPART%", s).replace("%EMAILDOMAIN%", r).replace("%REALNAME%", e.displayName);
        }
        var i = JSON.parse(JSON.stringify(t)), o = e.emailAddress.split("@"), s = o[0], r = o[1];
        r.toLowerCase();
        var a = {
            incoming: [ "username", "hostname", "server" ],
            outgoing: [ "username", "hostname" ]
        };
        for (var c in a) {
            var l = a[c], d = i[c];
            if (d) for (var u = 0; u < l.length; u++) {
                var p = l[u];
                d.hasOwnProperty(p) && (d[p] = n(d[p]));
            }
        }
        return i;
    }
    function d(e) {
        this._LOG = e, this.timeout = f;
    }
    function u(e, t, n, i) {
        r(n.def.type, function(o) {
            o.configurator.recreateAccount(e, t, n, i);
        });
    }
    function p(e, t, n, i, o) {
        r(n.type, function(s) {
            s.configurator.tryToCreateAccount(e, t, n, i, o);
        });
    }
    var h = n.latchedWithRejections, f = 3e4, m = "https://live.mozillamessaging.com/autoconfig/v1.1/";
    s.accountTypeToClass = a;
    var g = s._autoconfigByDomain = {
        localhost: {
            type: "imap+smtp",
            incoming: {
                hostname: "localhost",
                port: 143,
                socketType: "plain",
                username: "%EMAILLOCALPART%"
            },
            outgoing: {
                hostname: "localhost",
                port: 25,
                socketType: "plain",
                username: "%EMAILLOCALPART%"
            }
        },
        fakeimaphost: {
            type: "imap+smtp",
            incoming: {
                hostname: "localhost",
                port: 0,
                socketType: "plain",
                username: "%EMAILLOCALPART%"
            },
            outgoing: {
                hostname: "localhost",
                port: 0,
                socketType: "plain",
                username: "%EMAILLOCALPART%"
            }
        },
        fakepop3host: {
            type: "pop3+smtp",
            incoming: {
                hostname: "localhost",
                port: 0,
                socketType: "plain",
                username: "%EMAILLOCALPART%"
            },
            outgoing: {
                hostname: "localhost",
                port: 0,
                socketType: "plain",
                username: "%EMAILLOCALPART%"
            }
        },
        slocalhost: {
            type: "imap+smtp",
            incoming: {
                hostname: "localhost",
                port: 993,
                socketType: "SSL",
                username: "%EMAILLOCALPART%"
            },
            outgoing: {
                hostname: "localhost",
                port: 465,
                socketType: "SSL",
                username: "%EMAILLOCALPART%"
            }
        },
        fakeashost: {
            type: "activesync",
            displayName: "Test",
            incoming: {
                server: "http://localhost:8880",
                username: "%EMAILADDRESS%"
            }
        },
        saslocalhost: {
            type: "activesync",
            displayName: "Test",
            incoming: {
                server: "https://localhost:443",
                username: "%EMAILADDRESS%"
            }
        },
        "nonesuch.nonesuch": {
            type: "imap+smtp",
            imapHost: "nonesuch.nonesuch",
            imapPort: 993,
            imapCrypto: !0,
            smtpHost: "nonesuch.nonesuch",
            smtpPort: 465,
            smtpCrypto: !0,
            usernameIsFullEmail: !1
        }
    };
    s.recreateIdentities = c, s.fillConfigPlaceholders = l, s.Autoconfigurator = d, 
    d.prototype = {
        _fatalErrors: [ "bad-user-or-pass", "not-authorized" ],
        _isSuccessOrFatal: function(e) {
            return !e || -1 !== this._fatalErrors.indexOf(e);
        },
        _getXmlConfig: function(e) {
            return new Promise(function(n, i) {
                t.log("autoconfig.xhr:start", {
                    method: "GET",
                    url: e
                });
                var o = new XMLHttpRequest({
                    mozSystem: !0
                });
                o.open("GET", e, !0), o.timeout = this.timeout, o.onload = function() {
                    return t.log("autoconfig.xhr:end", {
                        method: "GET",
                        url: e,
                        status: o.status
                    }), o.status < 200 || o.status >= 300 ? (i("status" + o.status), void 0) : (self.postMessage({
                        uid: 0,
                        type: "configparser",
                        cmd: "accountcommon",
                        args: [ o.responseText ]
                    }), self.addEventListener("message", function s(e) {
                        var t = e.data;
                        if ("configparser" == t.type && "accountcommon" == t.cmd) {
                            self.removeEventListener(e.type, s);
                            var i = t.args, o = i[0];
                            i[1], n(o);
                        }
                    }), void 0);
                }, o.ontimeout = function() {
                    t.log("autoconfig.xhr:end", {
                        method: "GET",
                        url: e,
                        status: "timeout"
                    }), i("timeout");
                }, o.onerror = function() {
                    t.log("autoconfig.xhr:end", {
                        method: "GET",
                        url: e,
                        status: "error"
                    }), i("error");
                };
                try {
                    o.send();
                } catch (s) {
                    t.log("autoconfig.xhr:end", {
                        method: "GET",
                        url: e,
                        status: "sync-error"
                    }), i("status404");
                }
            }.bind(this));
        },
        _getConfigFromLocalFile: function(e) {
            return this._getXmlConfig("/autoconfig/" + encodeURIComponent(e));
        },
        _checkAutodiscoverUrl: function(e) {
            return new Promise(function(n, i) {
                t.log("autoconfig.autodiscoverProbe:start", {
                    method: "POST",
                    url: e
                });
                var o = new XMLHttpRequest({
                    mozSystem: !0
                });
                o.open("POST", e, !0), o.timeout = this.timeout;
                var s = function() {
                    n({
                        type: "activesync",
                        incoming: {
                            autodiscoverEndpoint: e
                        }
                    });
                }.bind(this);
                o.onload = function() {
                    return t.log("autoconfig.autodiscoverProbe:end", {
                        method: "POST",
                        url: e,
                        status: o.status
                    }), 401 === o.status ? (s(), void 0) : (i("status" + o.status), void 0);
                }, o.ontimeout = function() {
                    t.log("autoconfig.autodiscoverProbe:end", {
                        method: "POST",
                        url: e,
                        status: "timeout"
                    }), i("timeout");
                }, o.onerror = function() {
                    t.log("autoconfig.autodiscoverProbe:end", {
                        method: "POST",
                        url: e,
                        status: "error"
                    }), i("error");
                };
                try {
                    o.send(null);
                } catch (r) {
                    t.log("autoconfig.autodiscoverProbe:end", {
                        method: "POST",
                        url: e,
                        status: "sync-error"
                    }), i("status404");
                }
            }.bind(this));
        },
        _probeForAutodiscover: function(e) {
            var t = "https://" + e + "/autodiscover/autodiscover.xml", n = "https://autodiscover." + e + "/autodiscover/autodiscover.xml";
            return h({
                subdir: this._checkAutodiscoverUrl(t),
                domain: this._checkAutodiscoverUrl(n)
            }).then(function(e) {
                return e.subdir.resolved && e.subdir.value ? e.subdir.value : e.domain.resolved && e.domain.value ? e.domain.value : null;
            }.bind(this));
        },
        _getConfigFromISPDB: function(e) {
            return this._getXmlConfig(m + encodeURIComponent(e));
        },
        _getMX: function(e) {
            return new Promise(function(n, i) {
                t.log("autoconfig.mxLookup:begin", {
                    domain: e
                });
                var o = new XMLHttpRequest({
                    mozSystem: !0
                });
                o.open("GET", "https://live.mozillamessaging.com/dns/mx/" + encodeURIComponent(e), !0), 
                o.timeout = this.timeout, o.onload = function() {
                    var i = null;
                    if (200 === o.status) {
                        var s = o.responseText.split("\n")[0];
                        if (s) {
                            s = s.toLowerCase();
                            var r = s.split(".").slice(-2).join(".");
                            r !== e && (i = r);
                        }
                    }
                    t.log("autoconfig.mxLookup:end", {
                        domain: e,
                        raw: s,
                        normalized: r,
                        reporting: i
                    }), n(i);
                }, o.ontimeout = function() {
                    t.log("autoconfig.mxLookup:end", {
                        domain: e,
                        status: "timeout"
                    }), i("timeout");
                }, o.onerror = function() {
                    t.log("autoconfig.mxLookup:end", {
                        domain: e,
                        status: "error"
                    }), i("error");
                }, o.send();
            }.bind(this));
        },
        _getHostedAndISPDBConfigs: function(e, t) {
            var n = "/mail/config-v1.1.xml?emailaddress=" + encodeURIComponent(t), i = "https://autoconfig." + e + n, o = "https://" + e + "/.well-known/autoconfig" + n;
            return h({
                autoconfigSubdomain: this._getXmlConfig(i),
                autoconfigWellKnown: this._getXmlConfig(o),
                ispdb: this._getConfigFromISPDB(e),
                mxDomain: this._getMX(e)
            }).then(function(t) {
                return t.autoconfigSubdomain.resolved && t.autoconfigSubdomain.value ? {
                    type: "config",
                    source: "autoconfig-subdomain",
                    config: t.autoconfigSubdomain.value
                } : t.autoconfigWellKnown.resolved && t.autoconfigWellKnown.value ? {
                    type: "config",
                    source: "autoconfig-wellknown",
                    config: t.autoconfigWellKnown.value
                } : t.ispdb.resolved && t.ispdb.value ? {
                    type: "config",
                    source: "ispdb",
                    config: t.ispdb.value
                } : t.mxDomain.resolved && t.mxDomain.value && t.mxDomain.value !== e ? {
                    type: "mx",
                    domain: t.mxDomain.value
                } : {
                    type: null
                };
            }.bind(this));
        },
        _getConfigFromMX: function(e, t) {
            var n = this;
            this._getMX(e, function(i, o, s) {
                return i ? t(i, null, s) : (console.log("  Found MX for", o), e === o ? t("no-config-info", null, {
                    status: "mxsame"
                }) : (console.log("  Looking in local file store"), n._getConfigFromLocalFile(o, function(e, i, s) {
                    return e ? (console.log("  Looking in the Mozilla ISPDB"), n._getConfigFromDB(o, t), 
                    void 0) : (t(e, i, s), void 0);
                }), void 0));
            });
        },
        _checkGelamConfig: function(e) {
            return g.hasOwnProperty(e) ? g[e] : null;
        },
        learnAboutAccount: function(e) {
            return new Promise(function(n) {
                var i = e.emailAddress, o = i.split("@"), s = (o[0], o[1]), r = s.toLowerCase();
                t.log("autoconfig:begin", {
                    domain: r
                });
                var a = function(i, o) {
                    var s, a = null;
                    i ? (a = l(e, i), s = a.incoming && "xoauth2" === a.incoming.authentication ? "need-oauth2" : "need-password") : s = "no-config-info", 
                    t.log("autoconfig:end", {
                        domain: r,
                        result: s,
                        source: o,
                        configInfo: a
                    }), n({
                        result: s,
                        source: o,
                        configInfo: a
                    });
                }.bind(this), c = function(e) {
                    t.error("autoconfig:end", {
                        domain: r,
                        err: {
                            message: e && e.message,
                            stack: e && e.stack
                        }
                    }), n({
                        result: "no-config-info",
                        configInfo: null
                    });
                }.bind(this), d = function(e) {
                    return t.log("autoconfig:coerceRejection", {
                        err: e
                    }), null;
                }.bind(this), u = this._checkGelamConfig(r);
                if (u) return a(u, "hardcoded"), void 0;
                var p, h = function(e) {
                    return e ? (a(e, "local"), null) : this._getHostedAndISPDBConfigs(r, i).then(f);
                }.bind(this), f = function(e) {
                    return "config" === e.type ? (a(e.config, e.source), null) : "mx" === e.type ? (p = e.domain, 
                    this._getConfigFromLocalFile(p).catch(d).then(m)) : this._probeForAutodiscover(r).then(v);
                }.bind(this), m = function(e) {
                    return e ? (a(e, "mx local"), null) : this._getConfigFromISPDB(p).catch(d).then(g);
                }.bind(this), g = function(e) {
                    return e ? (a(e, "mx ispdb"), null) : this._probeForAutodiscover(r).then(v);
                }.bind(this), v = function(e) {
                    return a(e, e ? "autodiscover" : null), null;
                }.bind(this);
                this._getConfigFromLocalFile(r).catch(d).then(h).catch(c);
            }.bind(this));
        },
        tryToCreateAccount: function(e, n, i) {
            this.learnAboutAccount(n).then(function(o) {
                if ("need-password" === o.result) {
                    var s = o.configInfo;
                    return r(s.type, function(t) {
                        t.configurator.tryToCreateAccount(e, n, s, i, this._LOG);
                    }), void 0;
                }
                t.warn("autoconfig.legacyCreateFail", {
                    result: o.result
                }), i("no-config-info");
            }.bind(this), function(e) {
                i(e, null, null);
            }.bind(this));
        }
    }, s.recreateAccount = u, s.tryToManuallyCreateAccount = p;
}), define("mailuniverse", [ "rdcommon/log", "rdcommon/logreaper", "slog", "./a64", "./date", "./syncbase", "./worker-router", "./maildb", "./cronsync", "./accountcommon", "./allback", "module", "exports" ], function(e, t, n, i, o, s, r, a, c, l, d, u, p) {
    function h(e) {
        return function(t, n, i) {
            for (var o = 0; o < this._bridges.length; o++) {
                var s = this._bridges[o];
                s[e](t, n, i);
            }
        };
    }
    function f(t, i, o) {
        this.accounts = [], this._accountsById = {}, this.identities = [], this._identitiesById = {}, 
        this._opsByAccount = {}, this._opCompletionListenersByAccount = {}, this._opCallbacks = {}, 
        this._bridges = [], this._testModeDisablingLocalOps = !1, this._testModeFakeNavigator = o && o.fakeNavigator || null, 
        this.online = !0, this._onConnectionChange(i), this._mode = "cron", this._deferredOpTimeout = null, 
        this._boundQueueDeferredOps = this._queueDeferredOps.bind(this), this.config = null, 
        this._logReaper = null, this._logBacklog = null, this._LOG = null, this._db = new a.MailDB(o), 
        this._cronSync = null;
        var s = this;
        this._db.getConfig(function(i, o, r) {
            function a() {
                s.config.debugLogging && ("realtime-dangerous" === s.config.debugLogging ? (console.warn("!!!"), 
                console.warn("!!! REALTIME USER-DATA ENTRAINING LOGGING ENABLED !!!"), console.warn("!!!"), 
                console.warn("You are about to see a lot of logs, as they happen!"), console.warn("They will also be circularly buffered for saving."), 
                console.warn(""), console.warn("These logs will contain SENSITIVE DATA.  The CONTENTS"), 
                console.warn("OF EMAILS, maybe some PASSWORDS.  This was turned on"), console.warn("via the secret debug mode UI.  Use it to turn us off:"), 
                console.warn("https://wiki.mozilla.org/Gaia/Email/SecretDebugMode"), e.DEBUG_realtimeLogEverything(dump), 
                n.setSensitiveDataLoggingEnabled(!0)) : "dangerous" !== s.config.debugLogging ? (console.warn("GENERAL LOGGING ENABLED!"), 
                console.warn("(CIRCULAR EVENT LOGGING WITH NON-SENSITIVE DATA)"), e.enableGeneralLogging(), 
                n.setSensitiveDataLoggingEnabled(!1)) : (console.warn("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"), 
                console.warn("DANGEROUS USER-DATA ENTRAINING LOGGING ENABLED !!!"), console.warn("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"), 
                console.warn("This means contents of e-mails and passwords if you"), console.warn("set up a new account.  (The IMAP protocol sanitizes"), 
                console.warn("passwords, but the bridge logger may not.)"), console.warn(""), console.warn("If you forget how to turn us off, see:"), 
                console.warn("https://wiki.mozilla.org/Gaia/Email/SecretDebugMode"), console.warn("..................................................."), 
                e.DEBUG_markAllFabsUnderTest(), n.setSensitiveDataLoggingEnabled(!0)));
            }
            function c() {
                p += 1, p === h && (s._initFromConfig(), t());
            }
            var d, u, p = 0, h = o.length;
            if (i) {
                if (s.config = i, a(), s._LOG = v.MailUniverse(s, null, null), s.config.debugLogging && s._enableCircularLogging(), 
                s._LOG.configLoaded(s.config, o), h) {
                    for (u = 0; h > u; u++) d = o[u], s._loadAccount(d.def, d.folderInfo, null, c);
                    return;
                }
            } else {
                if (s.config = {
                    id: "config",
                    nextAccountNum: 0,
                    nextIdentityNum: 0,
                    debugLogging: r ? r.config.debugLogging : !1
                }, a(), s._LOG = v.MailUniverse(s, null, null), s.config.debugLogging && s._enableCircularLogging(), 
                s._db.saveConfig(s.config), r) {
                    this._LOG.configMigrating_begin(r);
                    var f = r.accountInfos.length, m = r.oldVersion, g = function(e, n) {
                        this._LOG.recreateAccount_end(e.type, e.id, n), 0 === --f && (this._LOG.configMigrating_end(null), 
                        this._initFromConfig(), t());
                    };
                    for (u = 0; u < r.accountInfos.length; u++) {
                        var d = r.accountInfos[u];
                        this._LOG.recreateAccount_begin(d.type, d.id, null), l.recreateAccount(s, m, d, g.bind(this, d));
                    }
                    return;
                }
                s._LOG.configCreated(s.config);
            }
            s._initFromConfig(), t();
        }.bind(this));
    }
    var m = 10, g = 30;
    p.MailUniverse = f, f.prototype = {
        _enableCircularLogging: function() {
            this._logReaper = new t.LogReaper(this._LOG), this._logBacklog = [], window.setInterval(function() {
                var e = this._logReaper.reapHierLogTimeSlice();
                e.logFrag && (this._logBacklog.push(e), this._logBacklog.length > g && this._logBacklog.shift());
            }.bind(this), 1e3);
        },
        createLogBacklogRep: function(t) {
            return {
                type: "backlog",
                id: t,
                schema: e.provideSchemaForAllKnownFabs(),
                backlog: this._logBacklog
            };
        },
        dumpLogToDeviceStorage: function() {
            var e = r.registerCallbackType("devicestorage");
            try {
                var t = new Blob([ JSON.stringify(this.createLogBacklogRep()) ], {
                    type: "application/json",
                    endings: "transparent"
                }), n = "gem-log-" + Date.now() + ".json";
                e("save", [ "sdcard", t, n ], function(e, t, i) {
                    e ? console.log('saved log to "sdcard" devicestorage:', i) : console.error("failed to save log to", n);
                });
            } catch (i) {
                console.error("Problem dumping log to device storage:", i, "\n", i.stack);
            }
        },
        _initFromConfig: function() {
            this._cronSync = new c.CronSync(this, this._LOG);
        },
        exposeConfigForClient: function() {
            return {
                debugLogging: this.config.debugLogging
            };
        },
        modifyConfig: function(e) {
            for (var t in e) {
                var n = e[t];
                switch (t) {
                  case "debugLogging":
                    break;

                  default:
                    continue;
                }
                this.config[t] = n;
            }
            this._db.saveConfig(this.config), this.__notifyConfig();
        },
        __notifyConfig: function() {
            for (var e = this.exposeConfigForClient(), t = 0; t < this._bridges.length; t++) {
                var n = this._bridges[t];
                n.notifyConfig(e);
            }
        },
        setInteractive: function() {
            this._mode = "interactive";
        },
        _onConnectionChange: function(e) {
            var t = this.online;
            if (this.online = this._testModeFakeNavigator ? this._testModeFakeNavigator.onLine : e, 
            console.log("Email knows that it is:", this.online ? "online" : "offline", "and previously was:", t ? "online" : "offline"), 
            this.minimizeNetworkUsage = !0, this.networkCostsMoney = !0, !t && this.online) for (var n = 0; n < this.accounts.length; n++) this._resumeOpProcessingForAccount(this.accounts[n]);
        },
        _dispatchLocalOpForAccount: function(e, t) {
            var n = this._opsByAccount[e.id];
            n.active = !0;
            var i;
            switch (t.lifecycle) {
              case "do":
                i = "local_do", t.localStatus = "doing";
                break;

              case "undo":
                i = "local_undo", t.localStatus = "undoing";
                break;

              default:
                throw new Error("Illegal lifecycle state for local op");
            }
            e.runOp(t, i, this._localOpCompleted.bind(this, e, t));
        },
        _dispatchServerOpForAccount: function(e, t) {
            var n = this._opsByAccount[e.id];
            n.active = !0;
            var i = t.lifecycle;
            "check" === t.serverStatus && (i = "check"), t.serverStatus = i + "ing", e.runOp(t, i, this._serverOpCompleted.bind(this, e, t));
        },
        _resumeOpProcessingForAccount: function(e) {
            var t = this._opsByAccount[e.id];
            if (e.enabled && !t.local.length && t.server.length && "doing" !== t.server[0].serverStatus && "undoing" !== t.server[0].serverStatus) {
                var n = t.server[0];
                this._dispatchServerOpForAccount(e, n);
            }
        },
        areServerJobsWaiting: function(e) {
            var t = this._opsByAccount[e.id];
            return e.enabled ? !!t.server.length : !1;
        },
        registerBridge: function(e) {
            this._bridges.push(e);
        },
        unregisterBridge: function(e) {
            var t = this._bridges.indexOf(e);
            -1 !== t && this._bridges.splice(t, 1);
        },
        learnAboutAccount: function(e) {
            var t = new l.Autoconfigurator(this._LOG);
            return t.learnAboutAccount(e);
        },
        tryToCreateAccount: function(e, t, n) {
            if (!this.online) return n("offline"), void 0;
            if (!e.forceCreate) for (var i = 0; i < this.accounts.length; i++) if (e.emailAddress === this.accounts[i].identities[0].address) return n("user-account-exists"), 
            void 0;
            if (t) l.tryToManuallyCreateAccount(this, e, t, n, this._LOG); else {
                var o = new l.Autoconfigurator(this._LOG);
                o.tryToCreateAccount(this, e, n);
            }
        },
        deleteAccount: function(e) {
            var t = null, n = this._accountsById[e];
            try {
                n.accountDeleted();
            } catch (i) {
                t = i;
            }
            this._db.deleteAccount(e), delete this._accountsById[e];
            var o = this.accounts.indexOf(n);
            this.accounts.splice(o, 1);
            for (var s = 0; s < n.identities.length; s++) {
                var r = n.identities[s];
                o = this.identities.indexOf(r), this.identities.splice(o, 1), delete this._identitiesById[r.id];
            }
            if (delete this._opsByAccount[e], delete this._opCompletionListenersByAccount[e], 
            this.__notifyRemovedAccount(e), t) throw t;
        },
        saveAccountDef: function(e, t, n) {
            this._db.saveAccountDef(this.config, e, t, n);
            var i = this.getAccountForAccountId(e.id);
            this._cronSync && this._cronSync.ensureSync(), i && this.__notifyModifiedAccount(i);
        },
        _loadAccount: function(e, t, n, i) {
            l.accountTypeToClass(e.type, function(o) {
                if (!o) return this._LOG.badAccountType(e.type), void 0;
                var r = new o(this, e, t, this._db, n, this._LOG);
                this.accounts.push(r), this._accountsById[r.id] = r, this._opsByAccount[r.id] = {
                    active: !1,
                    local: [],
                    server: [],
                    deferred: []
                }, this._opCompletionListenersByAccount[r.id] = null;
                for (var a = 0; a < e.identities.length; a++) {
                    var c = e.identities[a];
                    this.identities.push(c), this._identitiesById[c.id] = c;
                }
                this.__notifyAddedAccount(r);
                var l = Date.now() - r.meta.lastFolderSyncAt;
                l >= s.SYNC_FOLDER_LIST_EVERY_MS && this.syncFolderList(r);
                for (var d = 0; d < r.mutations.length; d++) {
                    var u = r.mutations[d];
                    "done" !== u.lifecycle && "undone" !== u.lifecycle && "moot" !== u.lifecycle && (u.serverStatus = "check", 
                    this._queueAccountOp(r, u));
                }
                r.upgradeFolderStoragesIfNeeded(), i(r);
            }.bind(this));
        },
        __reportAccountProblem: function(e, t, n) {
            var i = !1;
            if (-1 !== e.problems.indexOf(t) && (i = !0), this._LOG.reportProblem(t, i, e.id), 
            !i) switch (e.problems.push(t), e.enabled = !1, this.__notifyModifiedAccount(e), 
            t) {
              case "bad-user-or-pass":
              case "needs-oauth-reauth":
              case "bad-address":
              case "imap-disabled":
                this.__notifyBadLogin(e, t, n);
            }
        },
        __removeAccountProblem: function(e, t) {
            var n = e.problems.indexOf(t);
            -1 !== n && (e.problems.splice(n, 1), e.enabled = 0 === e.problems.length, this.__notifyModifiedAccount(e), 
            e.enabled && this._resumeOpProcessingForAccount(e));
        },
        clearAccountProblems: function(e) {
            this._LOG.clearAccountProblems(e.id), e.enabled = !0, e.problems = [], this._resumeOpProcessingForAccount(e);
        },
        __notifyBadLogin: h("notifyBadLogin"),
        __notifyAddedAccount: h("notifyAccountAdded"),
        __notifyModifiedAccount: h("notifyAccountModified"),
        __notifyRemovedAccount: h("notifyAccountRemoved"),
        __notifyAddedFolder: h("notifyFolderAdded"),
        __notifyModifiedFolder: h("notifyFolderModified"),
        __notifyRemovedFolder: h("notifyFolderRemoved"),
        __notifyModifiedBody: h("notifyBodyModified"),
        __notifyStartedCronSync: h("notifyCronSyncStart"),
        __notifyStoppedCronSync: h("notifyCronSyncStop"),
        __notifyBackgroundSendStatus: h("notifyBackgroundSendStatus"),
        saveUniverseState: function(e) {
            var t = null, n = d.latch();
            this._LOG.saveUniverseState_begin();
            for (var i = 0; i < this.accounts.length; i++) {
                var o = this.accounts[i];
                t = o.saveAccountState(t, n.defer(o.id), "saveUniverse");
            }
            n.then(function() {
                this._LOG.saveUniverseState_end(), e && e();
            }.bind(this));
        },
        shutdown: function(e) {
            function t() {
                0 === --n && e();
            }
            for (var n = this.accounts.length, i = 0; i < this.accounts.length; i++) {
                var o = this.accounts[i];
                o.shutdown(e ? t : null);
            }
            this._cronSync && this._cronSync.shutdown(), this._db.close(), this._LOG && this._LOG.__die(), 
            this.accounts.length || e();
        },
        getAccountForAccountId: function(e) {
            return this._accountsById[e];
        },
        getAccountForFolderId: function(e) {
            var t = e.substring(0, e.indexOf("/")), n = this._accountsById[t];
            return n;
        },
        getAccountForMessageSuid: function(e) {
            var t = e.substring(0, e.indexOf("/")), n = this._accountsById[t];
            return n;
        },
        getFolderStorageForFolderId: function(e) {
            var t = this.getAccountForFolderId(e);
            return t.getFolderStorageForFolderId(e);
        },
        getFolderStorageForMessageSuid: function(e) {
            var t = e.substring(0, e.lastIndexOf("/")), n = this.getAccountForFolderId(t);
            return n.getFolderStorageForFolderId(t);
        },
        getAccountForSenderIdentityId: function(e) {
            var t = e.substring(0, e.indexOf("/")), n = this._accountsById[t];
            return n;
        },
        getIdentityForSenderIdentityId: function(e) {
            return this._identitiesById[e];
        },
        _partitionMessagesByAccount: function(e, t) {
            for (var n = [], i = {}, o = 0; o < e.length; o++) {
                var s = e[o], r = s.suid, a = r.substring(0, r.indexOf("/"));
                if (i.hasOwnProperty(a)) i[a].push(s); else {
                    var c = [ s ];
                    n.push({
                        account: this._accountsById[a],
                        messages: c,
                        crossAccount: t && t !== a
                    }), i[a] = c;
                }
            }
            return n;
        },
        _deferOp: function(e, t) {
            this._opsByAccount[e.id].deferred.push(t.longtermId), null !== this._deferredOpTimeout && (this._deferredOpTimeout = window.setTimeout(this._boundQueueDeferredOps, s.DEFERRED_OP_DELAY_MS));
        },
        _queueDeferredOps: function() {
            if (this._deferredOpTimeout = null, "interactive" !== this._mode) return console.log("delaying deferred op since mode is " + this._mode), 
            this._deferredOpTimeout = window.setTimeout(this._boundQueueDeferredOps, s.DEFERRED_OP_DELAY_MS), 
            void 0;
            for (var e = 0; e < this.accounts.length; e++) for (var t = this.accounts[e], n = this._opsByAccount[t.id]; n.deferred.length; ) {
                var i = n.deferred.shift();
                -1 === n.server.indexOf(i) && "undo" !== i.lifecycle && this._queueAccountOp(t, i);
            }
        },
        _localOpCompleted: function(e, t, n, i, o) {
            var r = this._opsByAccount[e.id], a = r.server, c = r.local, l = !1, d = !1, u = "local_" + t.localStatus.slice(0, -3);
            if (n) {
                switch (n) {
                  case "defer":
                    if (++t.tryCount < s.MAX_OP_TRY_COUNT) {
                        this._LOG.opDeferred(t.type, t.longtermId), this._deferOp(e, t), l = !0;
                        break;
                    }

                  default:
                    this._LOG.opGaveUp(t.type, t.longtermId), t.lifecycle = "moot", t.localStatus = "unknown", 
                    t.serverStatus = "moot", l = !0, d = !0;
                }
                o = !1;
            } else switch (t.localStatus) {
              case "doing":
                t.localStatus = "done", "n/a" === t.serverStatus && (t.lifecycle = "done", d = !0);
                break;

              case "undoing":
                t.localStatus = "undone", "n/a" === t.serverStatus && (t.lifecycle = "undone", d = !0);
            }
            if (l) {
                var p = a.indexOf(t);
                -1 !== p && a.splice(p, 1);
            }
            c.shift(), console.log("runOp_end(" + u + ": " + JSON.stringify(t).substring(0, 160) + ")\n"), 
            e._LOG.runOp_end(u, t.type, n, t);
            var h;
            return d && this._opCallbacks.hasOwnProperty(t.longtermId) && (h = this._opCallbacks[t.longtermId], 
            delete this._opCallbacks[t.longtermId]), o ? (e.saveAccountState(null, this._startNextOp.bind(this, e, h, t, n, i), "localOp:" + t.type), 
            void 0) : (this._startNextOp(e, h, t, n, i), void 0);
        },
        _serverOpCompleted: function(e, t, n, i, o) {
            var r = this._opsByAccount[e.id], a = r.server;
            r.local, a[0] !== t && this._LOG.opInvariantFailure();
            var c = !1, l = !0, d = !0, u = t.serverStatus.slice(0, -3);
            if (n) switch (n) {
              case "defer":
                ++t.tryCount < s.MAX_OP_TRY_COUNT ? ("doing" === t.serverStatus && "do" === t.lifecycle && (this._LOG.opDeferred(t.type, t.longtermId), 
                this._deferOp(e, t)), d = !1) : (t.lifecycle = "moot", t.serverStatus = "moot");
                break;

              case "aborted-retry":
                t.tryCount++, c = !0;
                break;

              default:
                t.tryCount += s.OP_UNKNOWN_ERROR_TRY_COUNT_INCREMENT, c = !0;
                break;

              case "failure-give-up":
                this._LOG.opGaveUp(t.type, t.longtermId), t.lifecycle = "moot", t.serverStatus = "moot";
                break;

              case "moot":
                this._LOG.opMooted(t.type, t.longtermId), t.lifecycle = "moot", t.serverStatus = "moot";
            } else {
                switch (t.serverStatus) {
                  case "checking":
                    switch (i) {
                      case "checked-notyet":
                      case "coherent-notyet":
                        t.serverStatus = null;
                        break;

                      case "idempotent":
                        t.serverStatus = "do" === t.lifecycle || "done" === t.lifecycle ? null : "done";
                        break;

                      case "happened":
                        t.serverStatus = "done";
                        break;

                      case "moot":
                        t.lifecycle = "moot", t.serverStatus = "moot";
                        break;

                      case "bailed":
                        this._LOG.opDeferred(t.type, t.longtermId), this._deferOp(e, t), d = !1;
                    }
                    break;

                  case "doing":
                    t.serverStatus = "done", "do" === t.lifecycle && (t.lifecycle = "done");
                    break;

                  case "undoing":
                    t.serverStatus = "undone", "undo" === t.lifecycle && (t.lifecycle = "undone");
                }
                ("do" === t.lifecycle || "undo" === t.lifecycle) && (l = !1);
            }
            c && (t.tryCount < s.MAX_OP_TRY_COUNT ? (t.serverStatus = "check", l = !1) : (this._LOG.opTryLimitReached(t.type, t.longtermId), 
            t.lifecycle = "moot", t.serverStatus = "moot")), l && a.shift(), console.log("runOp_end(" + u + ": " + JSON.stringify(t).substring(0, 160) + ")\n"), 
            e._LOG.runOp_end(u, t.type, n, t), o && (e._saveAccountIsImminent = !0);
            var p;
            return d && (this._opCallbacks.hasOwnProperty(t.longtermId) && (p = this._opCallbacks[t.longtermId], 
            delete this._opCallbacks[t.longtermId]), o) ? (e._saveAccountIsImminent = !1, e.saveAccountState(null, this._startNextOp.bind(this, e, p, t, n, i), "serverOp:" + t.type), 
            void 0) : (this._startNextOp(e, p, t, n, i), void 0);
        },
        _startNextOp: function(e, t, i, o, s) {
            var r, a = this._opsByAccount[e.id], c = a.server, l = a.local;
            if (t) try {
                t(o, s, e, i);
            } catch (d) {
                console.log(d.message, d.stack), this._LOG.opCallbackErr(i.type);
            }
            a.active = !1, l.length ? (r = l[0], this._dispatchLocalOpForAccount(e, r)) : c.length && this.online && e.enabled ? (r = c[0], 
            this._dispatchServerOpForAccount(e, r)) : (this._opCompletionListenersByAccount[e.id] && (this._opCompletionListenersByAccount[e.id](e), 
            this._opCompletionListenersByAccount[e.id] = null), n.log("allOpsCompleted", {
                account: e.id
            }), e.allOperationsCompleted());
        },
        _queueAccountOp: function(e, t, n) {
            var o = this._opsByAccount[e.id];
            if (console.log("queueOp", e.id, t.type, "pre-queues:", "local:", o.local.length, "server:", o.server.length), 
            null === t.longtermId) for (t.longtermId = e.id + "/" + i.encodeInt(e.meta.nextMutationNum++), 
            e.mutations.push(t); e.mutations.length > m && "done" === e.mutations[0].lifecycle || "undone" === e.mutations[0].lifecycle || "moot" === e.mutations[0].lifecycle; ) e.mutations.shift(); else "session" === t.longtermId && (t.longtermId = e.id + "/" + i.encodeInt(e.meta.nextMutationNum++));
            return n && (this._opCallbacks[t.longtermId] = n), !this._testModeDisablingLocalOps && ("do" === t.lifecycle && null === t.localStatus || "undo" === t.lifecycle && "undone" !== t.localStatus && "unknown" !== t.localStatus) && o.local.push(t), 
            "n/a" !== t.serverStatus && "moot" !== t.serverStatus && o.server.push(t), o.active || (o.local.length ? 1 === o.local.length && o.local[0] === t && this._dispatchLocalOpForAccount(e, t) : 1 === o.server.length && o.server[0] === t && this.online && e.enabled && this._dispatchServerOpForAccount(e, t)), 
            t.longtermId;
        },
        waitForAccountOps: function(e, t) {
            var n = this._opsByAccount[e.id];
            n.active || 0 !== n.local.length || 0 !== n.server.length && this.online && e.enabled ? this._opCompletionListenersByAccount[e.id] = t : t();
        },
        syncFolderList: function(e, t) {
            this._queueAccountOp(e, {
                type: "syncFolderList",
                longtermId: "session",
                lifecycle: "do",
                localStatus: "done",
                serverStatus: null,
                tryCount: 0,
                humanOp: "syncFolderList"
            }, t);
        },
        purgeExcessMessages: function(e, t, n) {
            this._queueAccountOp(e, {
                type: "purgeExcessMessages",
                longtermId: "session",
                lifecycle: "do",
                localStatus: null,
                serverStatus: "n/a",
                tryCount: 0,
                humanOp: "purgeExcessMessages",
                folderId: t
            }, n);
        },
        downloadMessageBodyReps: function(e, t, n) {
            var i = this.getAccountForMessageSuid(e);
            this._queueAccountOp(i, {
                type: "downloadBodyReps",
                longtermId: "session",
                lifecycle: "do",
                localStatus: "done",
                serverStatus: null,
                tryCount: 0,
                humanOp: "downloadBodyReps",
                messageSuid: e,
                messageDate: t
            }, n);
        },
        downloadBodies: function(e, t, n) {
            function i() {
                --s || n();
            }
            "function" == typeof t && (n = t, t = null);
            var o = this, s = 0;
            this._partitionMessagesByAccount(e, null).forEach(function(e) {
                s++, o._queueAccountOp(e.account, {
                    type: "downloadBodies",
                    longtermId: "session",
                    lifecycle: "do",
                    localStatus: "done",
                    serverStatus: null,
                    tryCount: 0,
                    humanOp: "downloadBodies",
                    messages: e.messages,
                    options: t
                }, i);
            });
        },
        downloadMessageAttachments: function(e, t, n, i, o) {
            var s = this.getAccountForMessageSuid(e);
            this._queueAccountOp(s, {
                type: "download",
                longtermId: null,
                lifecycle: "do",
                localStatus: null,
                serverStatus: null,
                tryCount: 0,
                humanOp: "download",
                messageSuid: e,
                messageDate: t,
                relPartIndices: n,
                attachmentIndices: i
            }, o);
        },
        modifyMessageTags: function(e, t, n, i) {
            var o = this, s = [];
            return this._partitionMessagesByAccount(t, null).forEach(function(t) {
                var r = o._queueAccountOp(t.account, {
                    type: "modtags",
                    longtermId: null,
                    lifecycle: "do",
                    localStatus: null,
                    serverStatus: null,
                    tryCount: 0,
                    humanOp: e,
                    messages: t.messages,
                    addTags: n,
                    removeTags: i,
                    progress: 0
                });
                s.push(r);
            }), s;
        },
        moveMessages: function(e, t, n) {
            var i = this, o = [], s = this.getAccountForFolderId(t), r = d.latch();
            return this._partitionMessagesByAccount(e, null).forEach(function(e, n) {
                if (e.account !== s) throw new Error("cross-account moves not currently supported!");
                for (var a = s.getFolderStorageForFolderId(t), c = a.isLocalOnly, l = 0; l < e.messages.length && c; l++) {
                    var d = i.getFolderStorageForMessageSuid(e.messages[l].suid);
                    d.isLocalOnly || (c = !1);
                }
                var u = i._queueAccountOp(e.account, {
                    type: "move",
                    longtermId: null,
                    lifecycle: "do",
                    localStatus: null,
                    serverStatus: c ? "n/a" : null,
                    tryCount: 0,
                    humanOp: "move",
                    messages: e.messages,
                    targetFolder: t
                }, r.defer(n));
                o.push(u);
            }), r.then(function(e) {
                var t = {};
                for (var i in e) {
                    var o = e[i][1];
                    for (var s in o) t[s] = o[s];
                }
                n && n(null, t);
            }), o;
        },
        deleteMessages: function(e) {
            var t = this, n = [];
            return this._partitionMessagesByAccount(e, null).forEach(function(e) {
                var i = t._queueAccountOp(e.account, {
                    type: "delete",
                    longtermId: null,
                    lifecycle: "do",
                    localStatus: null,
                    serverStatus: null,
                    tryCount: 0,
                    humanOp: "delete",
                    messages: e.messages
                });
                n.push(i);
            }), n;
        },
        appendMessages: function(e, t, n) {
            var i = this.getAccountForFolderId(e), o = this._queueAccountOp(i, {
                type: "append",
                longtermId: "session",
                lifecycle: "do",
                localStatus: "done",
                serverStatus: null,
                tryCount: 0,
                humanOp: "append",
                messages: t,
                folderId: e
            }, n);
            return [ o ];
        },
        saveSentDraft: function(e, t, n, i) {
            var o = this.getAccountForMessageSuid(t.suid), s = this._queueAccountOp(o, {
                type: "saveSentDraft",
                longtermId: null,
                lifecycle: "do",
                localStatus: null,
                serverStatus: "n/a",
                tryCount: 0,
                humanOp: "saveSentDraft",
                folderId: e,
                headerInfo: t,
                bodyInfo: n
            }, i);
            return [ s ];
        },
        attachBlobToDraft: function(e, t, n, i) {
            this._queueAccountOp(e, {
                type: "attachBlobToDraft",
                longtermId: "session",
                lifecycle: "do",
                localStatus: null,
                serverStatus: "n/a",
                tryCount: 0,
                humanOp: "attachBlobToDraft",
                existingNamer: t,
                attachmentDef: n
            }, i);
        },
        detachAttachmentFromDraft: function(e, t, n, i) {
            this._queueAccountOp(e, {
                type: "detachAttachmentFromDraft",
                longtermId: "session",
                lifecycle: "do",
                localStatus: null,
                serverStatus: "n/a",
                tryCount: 0,
                humanOp: "detachAttachmentFromDraft",
                existingNamer: t,
                attachmentIndex: n
            }, i);
        },
        saveDraft: function(e, t, n, i) {
            var s = e.getFirstFolderWithType("localdrafts"), r = e.getFolderStorageForFolderId(s.id), a = r._issueNewHeaderId(), c = {
                id: a,
                suid: r.folderId + "/" + a,
                date: o.NOW()
            };
            return this._queueAccountOp(e, {
                type: "saveDraft",
                longtermId: null,
                lifecycle: "do",
                localStatus: null,
                serverStatus: "n/a",
                tryCount: 0,
                humanOp: "saveDraft",
                existingNamer: t,
                newDraftInfo: c,
                draftRep: n
            }, i), {
                suid: c.suid,
                date: c.date
            };
        },
        sendOutboxMessages: function(e, t, n) {
            t = t || {}, console.log("outbox: sendOutboxMessages(", JSON.stringify(t), ")"), 
            this.online || this.notifyOutboxSyncDone(e), this._queueAccountOp(e, {
                type: "sendOutboxMessages",
                longtermId: "session",
                lifecycle: "do",
                localStatus: "n/a",
                serverStatus: null,
                tryCount: 0,
                beforeMessage: t.beforeMessage,
                emitNotifications: t.emitNotifications,
                humanOp: "sendOutboxMessages"
            }, n);
        },
        notifyOutboxSyncDone: function(e) {
            this.__notifyBackgroundSendStatus({
                accountId: e.id,
                state: "syncDone"
            });
        },
        setOutboxSyncEnabled: function(e, t, n) {
            this._queueAccountOp(e, {
                type: "setOutboxSyncEnabled",
                longtermId: "session",
                lifecycle: "do",
                localStatus: null,
                serverStatus: "n/a",
                outboxSyncEnabled: t,
                tryCount: 0,
                humanOp: "setOutboxSyncEnabled"
            }, n);
        },
        deleteDraft: function(e, t, n) {
            this._queueAccountOp(e, {
                type: "deleteDraft",
                longtermId: null,
                lifecycle: "do",
                localStatus: null,
                serverStatus: "n/a",
                tryCount: 0,
                humanOp: "deleteDraft",
                messageNamer: t
            }, n);
        },
        createFolder: function(e, t, n, i, o, s) {
            var r = this.getAccountForAccountId(e), a = this._queueAccountOp(r, {
                type: "createFolder",
                longtermId: null,
                lifecycle: "do",
                localStatus: null,
                serverStatus: null,
                tryCount: 0,
                humanOp: "createFolder",
                parentFolderId: t,
                folderName: n,
                folderType: i,
                containOtherFolders: o
            }, s);
            return [ a ];
        },
        undoMutation: function(e) {
            for (var t = 0; t < e.length; t++) for (var n = e[t], i = this.getAccountForFolderId(n), o = this._opsByAccount[i.id], s = 0; s < i.mutations.length; s++) {
                var r = i.mutations[s];
                if (r.longtermId === n) {
                    if ("undo" === r.lifecycle || "undone" === r.lifecycle) continue;
                    if ("done" === r.lifecycle) {
                        r.lifecycle = "undo", this._queueAccountOp(i, r);
                        continue;
                    }
                    var a = o.local.indexOf(r);
                    if (-1 !== a) {
                        r.lifecycle = "undone", o.local.splice(a, 1);
                        continue;
                    }
                    r.lifecycle = "undo", this._queueAccountOp(i, r);
                }
            }
        },
        performFolderUpgrade: function(e, t) {
            var n = this.getAccountForFolderId(e);
            this._queueAccountOp(n, {
                type: "upgradeDB",
                longtermId: "session",
                lifecycle: "do",
                localStatus: null,
                serverStatus: "n/a",
                tryCount: 0,
                humanOp: "append",
                folderId: e
            }, t);
        }
    };
    var v = p.LOGFAB = e.register(u, {
        MailUniverse: {
            type: e.ACCOUNT,
            events: {
                configCreated: {},
                configLoaded: {},
                createAccount: {
                    type: !0,
                    id: !1
                },
                reportProblem: {
                    type: !0,
                    suppressed: !0,
                    id: !1
                },
                clearAccountProblems: {
                    id: !1
                },
                opDeferred: {
                    type: !0,
                    id: !1
                },
                opTryLimitReached: {
                    type: !0,
                    id: !1
                },
                opGaveUp: {
                    type: !0,
                    id: !1
                },
                opMooted: {
                    type: !0,
                    id: !1
                }
            },
            TEST_ONLY_events: {
                configCreated: {
                    config: !1
                },
                configMigrating: {
                    lazyCarryover: !1
                },
                configLoaded: {
                    config: !1,
                    accounts: !1
                },
                createAccount: {
                    name: !1
                }
            },
            asyncJobs: {
                configMigrating: {},
                recreateAccount: {
                    type: !0,
                    id: !1,
                    err: !1
                },
                saveUniverseState: {}
            },
            errors: {
                badAccountType: {
                    type: !0
                },
                opCallbackErr: {
                    type: !1
                },
                opInvariantFailure: {}
            }
        }
    });
}), define("worker-setup", [ "./worker-router", "./mailbridge", "./mailuniverse", "exports" ], function(e, t, n) {
    function i(e) {
        r++;
        var n = new t.MailBridge(e), i = s.register(function(e) {
            n.__receiveMessage(e.msg);
        }), o = i.sendMessage;
        n.__sendMessage = function(e) {
            n._LOG.send(e.type, e), o(null, e);
        }, n.__sendMessage({
            type: "hello",
            config: e.exposeConfigForClient()
        });
    }
    function o() {
        i(a), console.log("Mail universe/bridge created and notified!");
    }
    var s = e.registerInstanceType("bridge"), r = 0, a = null, c = e.registerSimple("control", function(e) {
        var t = e.args;
        switch (e.cmd) {
          case "hello":
            a = new n.MailUniverse(o, t[0]);
            break;

          case "online":
          case "offline":
            a._onConnectionChange(t[0]);
        }
    });
    c("hello");
}), function(e, t) {
    "function" == typeof define && define.amd ? define("bleach/css-parser/tokenizer", [ "exports" ], t) : "undefined" != typeof exports ? t(exports) : t(e);
}(this, function(e) {
    function t(e) {
        return j(e, 48, 57);
    }
    function n(e) {
        return t(e) || j(e, 65, 70) || j(e, 97, 102);
    }
    function i(e) {
        return j(e, 65, 90);
    }
    function o(e) {
        return j(e, 97, 122);
    }
    function s(e) {
        return i(e) || o(e);
    }
    function r(e) {
        return e >= 160;
    }
    function a(e) {
        return s(e) || r(e) || 95 == e;
    }
    function c(e) {
        return a(e) || t(e) || 45 == e;
    }
    function l(e) {
        return j(e, 0, 8) || j(e, 14, 31) || j(e, 127, 159);
    }
    function d(e) {
        return 10 == e || 12 == e;
    }
    function u(e) {
        return d(e) || 9 == e || 32 == e;
    }
    function p(e) {
        return d(e) || isNaN(e);
    }
    function h(e, i) {
        void 0 == i && (i = {
            transformFunctionWhitespace: !1,
            scientificNotation: !1
        });
        for (var o, s, r = -1, h = [], f = "data", m = 0, M = 0, j = 0, G = function() {
            m += 1, j = M, M = 0;
        }, W = {
            line: m,
            column: M
        }, Y = function(t) {
            return void 0 === t && (t = 1), e.charCodeAt(r + t);
        }, X = function(t) {
            return void 0 === t && (t = 1), r += t, o = e.charCodeAt(r), d(o) ? G() : M += t, 
            !0;
        }, V = function() {
            return r -= 1, d(o) ? (m -= 1, M = j) : M -= 1, W.line = m, W.column = M, !0;
        }, K = function() {
            return r >= e.length;
        }, J = function() {}, $ = function(e) {
            return e ? e.finish() : e = s.finish(), i.loc === !0 && (e.loc = {}, e.loc.start = {
                line: W.line,
                column: W.column,
                idx: W.idx
            }, W = {
                line: m,
                column: M,
                idx: r
            }, e.loc.end = W), h.push(e), s = void 0, !0;
        }, Q = function(e) {
            return s = e, !0;
        }, Z = function() {
            return !0;
        }, et = function() {
            return !0;
        }, tt = function(e) {
            return f = e, !0;
        }, nt = function() {
            if (X(), n(o)) {
                for (var e = [], t = 0; 6 > t && n(o); t++) e.push(o), X();
                var i = parseInt(e.map(String.fromCharCode).join(""), 16);
                return i > z && (i = 65533), u(o) || V(), i;
            }
            return o;
        }; ;) {
            if (r > 2 * e.length) return "I'm infinite-looping!";
            switch (X(), f) {
              case "data":
                if (u(o)) for ($(new _()); u(Y()); ) X(); else if (34 == o) tt("double-quote-string"); else if (35 == o) tt("hash"); else if (39 == o) tt("single-quote-string"); else if (40 == o) $(new k()); else if (41 == o) $(new I()); else if (43 == o) t(Y()) || 46 == Y() && t(Y(2)) ? tt("number") && V() : $(new O(o)); else if (45 == o) 45 == Y(1) && 62 == Y(2) ? X(2) && $(new b()) : t(Y()) || 46 == Y(1) && t(Y(2)) ? tt("number") && V() : tt("ident") && V(); else if (46 == o) t(Y()) ? tt("number") && V() : $(new O(o)); else if (47 == o) 42 == Y() ? X() && tt("comment") : $(new O(o)); else if (58 == o) $(new x()); else if (59 == o) $(new S()); else if (60 == o) 33 == Y(1) && 45 == Y(2) && 45 == Y(3) ? X(3) && $(new y()) : $(new O(o)); else if (64 == o) tt("at-keyword"); else if (91 == o) $(new A()); else if (92 == o) p(Y()) ? Z() && $(new O(o)) : tt("ident") && V(); else if (93 == o) $(new E()); else if (123 == o) $(new w()); else if (125 == o) $(new T()); else if (t(o)) tt("number") && V(); else if (85 == o || 117 == o) 43 == Y(1) && n(Y(2)) ? X() && tt("unicode-range") : tt("ident") && V(); else if (a(o)) tt("ident") && V(); else {
                    if (K()) return $(new C()), h;
                    $(new O(o));
                }
                break;

              case "double-quote-string":
                void 0 == s && Q(new B()), 34 == o ? $() && tt("data") : K() ? Z() && $() && tt("data") && V() : d(o) ? Z() && $(new g()) && tt("data") && V() : 92 == o ? p(Y()) ? Z() && $(new g()) && tt("data") : d(Y()) ? X() : s.append(nt()) : s.append(o);
                break;

              case "single-quote-string":
                void 0 == s && Q(new B()), 39 == o ? $() && tt("data") : K() ? Z() && $() && tt("data") : d(o) ? Z() && $(new g()) && tt("data") && V() : 92 == o ? p(Y()) ? Z() && $(new g()) && tt("data") : d(Y()) ? X() : s.append(nt()) : s.append(o);
                break;

              case "hash":
                c(o) ? Q(new R(o)) && tt("hash-rest") : 92 == o ? p(Y()) ? Z() && $(new O(35)) && tt("data") && V() : Q(new R(nt())) && tt("hash-rest") : $(new O(35)) && tt("data") && V();
                break;

              case "hash-rest":
                c(o) ? s.append(o) : 92 == o ? p(Y()) ? Z() && $() && tt("data") && V() : s.append(nt()) : $() && tt("data") && V();
                break;

              case "comment":
                42 == o ? 47 == Y() ? X() && tt("data") : J() : K() ? Z() && tt("data") && V() : J();
                break;

              case "at-keyword":
                45 == o ? a(Y()) ? Q(new L(45)) && tt("at-keyword-rest") : 92 != Y(1) || p(Y(2)) ? Z() && $(new O(64)) && tt("data") && V() : Q(new AtKeywordtoken(45)) && tt("at-keyword-rest") : a(o) ? Q(new L(o)) && tt("at-keyword-rest") : 92 == o ? p(Y()) ? Z() && $(new O(35)) && tt("data") && V() : Q(new L(nt())) && tt("at-keyword-rest") : $(new O(64)) && tt("data") && V();
                break;

              case "at-keyword-rest":
                c(o) ? s.append(o) : 92 == o ? p(Y()) ? Z() && $() && tt("data") && V() : s.append(nt()) : $() && tt("data") && V();
                break;

              case "ident":
                45 == o ? a(Y()) ? Q(new D(o)) && tt("ident-rest") : 92 != Y(1) || p(Y(2)) ? $(new O(45)) && tt("data") : Q(new D(o)) && tt("ident-rest") : a(o) ? Q(new D(o)) && tt("ident-rest") : 92 == o ? p(Y()) ? Z() && tt("data") && V() : Q(new D(nt())) && tt("ident-rest") : et("Hit the generic 'else' clause in ident state.") && tt("data") && V();
                break;

              case "ident-rest":
                c(o) ? s.append(o) : 92 == o ? p(Y()) ? Z() && $() && tt("data") && V() : s.append(nt()) : 40 == o ? s.ASCIImatch("url") ? tt("url") : $(new N(s)) && tt("data") : u(o) && i.transformFunctionWhitespace ? tt("transform-function-whitespace") && V() : $() && tt("data") && V();
                break;

              case "transform-function-whitespace":
                u(Y()) ? J() : 40 == o ? $(new N(s)) && tt("data") : $() && tt("data") && V();
                break;

              case "number":
                Q(new P()), 45 == o ? t(Y()) ? X() && s.append([ 45, o ]) && tt("number-rest") : 46 == Y(1) && t(Y(2)) ? X(2) && s.append([ 45, 46, o ]) && tt("number-fraction") : tt("data") && V() : 43 == o ? t(Y()) ? X() && s.append([ 43, o ]) && tt("number-rest") : 46 == Y(1) && t(Y(2)) ? X(2) && s.append([ 43, 46, o ]) && tt("number-fraction") : tt("data") && V() : t(o) ? s.append(o) && tt("number-rest") : 46 == o ? t(Y()) ? X() && s.append([ 46, o ]) && tt("number-fraction") : tt("data") && V() : tt("data") && V();
                break;

              case "number-rest":
                t(o) ? s.append(o) : 46 == o ? t(Y()) ? X() && s.append([ 46, o ]) && tt("number-fraction") : $() && tt("data") && V() : 37 == o ? $(new U(s)) && tt("data") : 69 == o || 101 == o ? t(Y()) ? X() && s.append([ 37, o ]) && tt("sci-notation") : 43 != Y(1) && 45 != Y(1) || !t(Y(2)) ? Q(new H(s, o)) && tt("dimension") : s.append([ 37, Y(1), Y(2) ]) && X(2) && tt("sci-notation") : 45 == o ? a(Y()) ? X() && Q(new H(s, [ 45, o ])) && tt("dimension") : 92 == Y(1) && p(Y(2)) ? Z() && $() && tt("data") && V() : 92 == Y(1) ? X() && Q(new H(s, [ 45, nt() ])) && tt("dimension") : $() && tt("data") && V() : a(o) ? Q(new H(s, o)) && tt("dimension") : 92 == o ? p(Y) ? Z() && $() && tt("data") && V() : Q(new H(s, nt)) && tt("dimension") : $() && tt("data") && V();
                break;

              case "number-fraction":
                s.type = "number", t(o) ? s.append(o) : 37 == o ? $(new U(s)) && tt("data") : 69 == o || 101 == o ? t(Y()) ? X() && s.append([ 101, o ]) && tt("sci-notation") : 43 != Y(1) && 45 != Y(1) || !t(Y(2)) ? Q(new H(s, o)) && tt("dimension") : s.append([ 101, Y(1), Y(2) ]) && X(2) && tt("sci-notation") : 45 == o ? a(Y()) ? X() && Q(new H(s, [ 45, o ])) && tt("dimension") : 92 == Y(1) && p(Y(2)) ? Z() && $() && tt("data") && V() : 92 == Y(1) ? X() && Q(new H(s, [ 45, nt() ])) && tt("dimension") : $() && tt("data") && V() : a(o) ? Q(new H(s, o)) && tt("dimension") : 92 == o ? p(Y) ? Z() && $() && tt("data") && V() : Q(new H(s, nt())) && tt("dimension") : $() && tt("data") && V();
                break;

              case "dimension":
                c(o) ? s.append(o) : 92 == o ? p(Y()) ? Z() && $() && tt("data") && V() : s.append(nt()) : $() && tt("data") && V();
                break;

              case "sci-notation":
                s.type = "number", t(o) ? s.append(o) : $() && tt("data") && V();
                break;

              case "url":
                K() ? Z() && $(new v()) && tt("data") : 34 == o ? tt("url-double-quote") : 39 == o ? tt("url-single-quote") : 41 == o ? $(new F()) && tt("data") : u(o) ? J() : tt("url-unquoted") && V();
                break;

              case "url-double-quote":
                s instanceof F || Q(new F()), K() ? Z() && $(new v()) && tt("data") : 34 == o ? tt("url-end") : d(o) ? Z() && tt("bad-url") : 92 == o ? d(Y()) ? X() : p(Y()) ? Z() && $(new v()) && tt("data") && V() : s.append(nt()) : s.append(o);
                break;

              case "url-single-quote":
                s instanceof F || Q(new F()), K() ? Z() && $(new v()) && tt("data") : 39 == o ? tt("url-end") : d(o) ? Z() && tt("bad-url") : 92 == o ? d(Y()) ? X() : p(Y()) ? Z() && $(new v()) && tt("data") && V() : s.append(nt()) : s.append(o);
                break;

              case "url-end":
                K() ? Z() && $(new v()) && tt("data") : u(o) ? J() : 41 == o ? $() && tt("data") : Z() && tt("bad-url") && V();
                break;

              case "url-unquoted":
                s instanceof F || Q(new F()), K() ? Z() && $(new v()) && tt("data") : u(o) ? tt("url-end") : 41 == o ? $() && tt("data") : 34 == o || 39 == o || 40 == o || l(o) ? Z() && tt("bad-url") : 92 == o ? p(Y()) ? Z() && tt("bad-url") : s.append(nt()) : s.append(o);
                break;

              case "bad-url":
                K() ? Z() && $(new v()) && tt("data") : 41 == o ? $(new v()) && tt("data") : 92 == o ? p(Y()) ? J() : nt() : J();
                break;

              case "unicode-range":
                for (var it = [ o ], ot = [ o ], st = 1; 6 > st && n(Y()); st++) X(), it.push(o), 
                ot.push(o);
                if (63 == Y()) {
                    for (;6 > st && 63 == Y(); st++) X(), it.push("0".charCodeAt(0)), ot.push("f".charCodeAt(0));
                    $(new q(it, ot)) && tt("data");
                } else if (45 == Y(1) && n(Y(2))) {
                    X(), X(), ot = [ o ];
                    for (var st = 1; 6 > st && n(Y()); st++) X(), ot.push(o);
                    $(new q(it, ot)) && tt("data");
                } else $(new q(it)) && tt("data");
                break;

              default:
                et("Unknown state '" + f + "'");
            }
        }
    }
    function f(e) {
        return String.fromCharCode.apply(null, e.filter(function(e) {
            return e;
        }));
    }
    function m() {
        return this;
    }
    function g() {
        return this;
    }
    function v() {
        return this;
    }
    function _() {
        return this;
    }
    function y() {
        return this;
    }
    function b() {
        return this;
    }
    function x() {
        return this;
    }
    function S() {
        return this;
    }
    function w() {
        return this;
    }
    function T() {
        return this;
    }
    function A() {
        return this;
    }
    function E() {
        return this;
    }
    function k() {
        return this;
    }
    function I() {
        return this;
    }
    function C() {
        return this;
    }
    function O(e) {
        return this.value = String.fromCharCode(e), this;
    }
    function M() {
        return this;
    }
    function D(e) {
        this.value = [], this.append(e);
    }
    function N(e) {
        this.value = e.finish().value;
    }
    function L(e) {
        this.value = [], this.append(e);
    }
    function R(e) {
        this.value = [], this.append(e);
    }
    function B(e) {
        this.value = [], this.append(e);
    }
    function F(e) {
        this.value = [], this.append(e);
    }
    function P(e) {
        this.value = [], this.append(e), this.type = "integer";
    }
    function U(e) {
        e.finish(), this.value = e.value, this.repr = e.repr;
    }
    function H(e, t) {
        e.finish(), this.num = e.value, this.unit = [], this.repr = e.repr, this.append(t);
    }
    function q(e, t) {
        return e = parseInt(f(e), 16), t = void 0 === t ? e + 1 : parseInt(f(t), 16), e > z && (t = e), 
        e > t && (t = e), t > z && (t = z), this.start = e, this.end = t, this;
    }
    var j = function(e, t, n) {
        return e >= t && n >= e;
    }, z = 1114111;
    m.prototype.finish = function() {
        return this;
    }, m.prototype.toString = function() {
        return this.tokenType;
    }, m.prototype.toJSON = function() {
        return this.toString();
    }, g.prototype = new m(), g.prototype.tokenType = "BADSTRING", v.prototype = new m(), 
    v.prototype.tokenType = "BADURL", _.prototype = new m(), _.prototype.tokenType = "WHITESPACE", 
    _.prototype.toString = function() {
        return "WS";
    }, y.prototype = new m(), y.prototype.tokenType = "CDO", b.prototype = new m(), 
    b.prototype.tokenType = "CDC", x.prototype = new m(), x.prototype.tokenType = ":", 
    S.prototype = new m(), S.prototype.tokenType = ";", w.prototype = new m(), w.prototype.tokenType = "{", 
    T.prototype = new m(), T.prototype.tokenType = "}", A.prototype = new m(), A.prototype.tokenType = "[", 
    E.prototype = new m(), E.prototype.tokenType = "]", k.prototype = new m(), k.prototype.tokenType = "(", 
    I.prototype = new m(), I.prototype.tokenType = ")", C.prototype = new m(), C.prototype.tokenType = "EOF", 
    O.prototype = new m(), O.prototype.tokenType = "DELIM", O.prototype.toString = function() {
        return "DELIM(" + this.value + ")";
    }, M.prototype = new m(), M.prototype.append = function(e) {
        if (e instanceof Array) for (var t = 0; t < e.length; t++) this.value.push(e[t]); else this.value.push(e);
        return !0;
    }, M.prototype.finish = function() {
        return this.value = this.valueAsString(), this;
    }, M.prototype.ASCIImatch = function(e) {
        return this.valueAsString().toLowerCase() == e.toLowerCase();
    }, M.prototype.valueAsString = function() {
        return "string" == typeof this.value ? this.value : f(this.value);
    }, M.prototype.valueAsCodes = function() {
        if ("string" == typeof this.value) {
            for (var e = [], t = 0; t < this.value.length; t++) e.push(this.value.charCodeAt(t));
            return e;
        }
        return this.value.filter(function(e) {
            return e;
        });
    }, D.prototype = new M(), D.prototype.tokenType = "IDENT", D.prototype.toString = function() {
        return "IDENT(" + this.value + ")";
    }, N.prototype = new M(), N.prototype.tokenType = "FUNCTION", N.prototype.toString = function() {
        return "FUNCTION(" + this.value + ")";
    }, L.prototype = new M(), L.prototype.tokenType = "AT-KEYWORD", L.prototype.toString = function() {
        return "AT(" + this.value + ")";
    }, R.prototype = new M(), R.prototype.tokenType = "HASH", R.prototype.toString = function() {
        return "HASH(" + this.value + ")";
    }, B.prototype = new M(), B.prototype.tokenType = "STRING", B.prototype.toString = function() {
        return '"' + this.value + '"';
    }, F.prototype = new M(), F.prototype.tokenType = "URL", F.prototype.toString = function() {
        return "URL(" + this.value + ")";
    }, P.prototype = new M(), P.prototype.tokenType = "NUMBER", P.prototype.toString = function() {
        return "integer" == this.type ? "INT(" + this.value + ")" : "NUMBER(" + this.value + ")";
    }, P.prototype.finish = function() {
        return this.repr = this.valueAsString(), this.value = 1 * this.repr, 0 != Math.abs(this.value) % 1 && (this.type = "number"), 
        this;
    }, U.prototype = new m(), U.prototype.tokenType = "PERCENTAGE", U.prototype.toString = function() {
        return "PERCENTAGE(" + this.value + ")";
    }, H.prototype = new m(), H.prototype.tokenType = "DIMENSION", H.prototype.toString = function() {
        return "DIM(" + this.num + "," + this.unit + ")";
    }, H.prototype.append = function(e) {
        if (e instanceof Array) for (var t = 0; t < e.length; t++) this.unit.push(e[t]); else this.unit.push(e);
        return !0;
    }, H.prototype.finish = function() {
        return this.unit = f(this.unit), this.repr += this.unit, this;
    }, q.prototype = new m(), q.prototype.tokenType = "UNICODE-RANGE", q.prototype.toString = function() {
        return this.start + 1 == this.end ? "UNICODE-RANGE(" + this.start.toString(16).toUpperCase() + ")" : this.start < this.end ? "UNICODE-RANGE(" + this.start.toString(16).toUpperCase() + "-" + this.end.toString(16).toUpperCase() + ")" : "UNICODE-RANGE()";
    }, q.prototype.contains = function(e) {
        return e >= this.start && e < this.end;
    }, e.tokenize = h, e.EOFToken = C;
}), function(e, t) {
    "function" == typeof define && define.amd ? define("bleach/css-parser/parser", [ "require", "exports" ], t) : "undefined" != typeof exports ? t(require, exports) : t(e);
}(this, function(e, t) {
    function n(e, t) {
        function n() {
            switch (p.tokenType) {
              case "(":
              case "[":
              case "{":
                return i();

              case "FUNCTION":
                return u();

              default:
                return p;
            }
        }
        function i() {
            for (var e = {
                "(": ")",
                "[": "]",
                "{": "}"
            }[p.tokenType], t = new c(p.tokenType); ;) switch (_(), p.tokenType) {
              case "EOF":
              case e:
                return t;

              default:
                t.append(n());
            }
        }
        function u() {
            for (var e = new l(p.value), t = new d(); ;) switch (_(), p.tokenType) {
              case "EOF":
              case ")":
                return e.append(t), e;

              case "DELIM":
                "," == p.value ? (e.append(t), t = new d()) : t.append(p);
                break;

              default:
                t.append(n());
            }
        }
        var p, h, f = t || "top-level", m = -1;
        switch (f) {
          case "top-level":
            h = new o();
            break;

          case "declaration":
            h = new r();
        }
        h.startTok = e[0];
        for (var g = [ h ], v = g[0], _ = function(t) {
            return void 0 === t && (t = 1), m += t, p = m < e.length ? e[m] : new EOFToken(), 
            !0;
        }, y = function() {
            return m--, !0;
        }, b = function() {
            return e[m + 1];
        }, x = function(e) {
            return void 0 === e ? "" !== v.fillType ? f = v.fillType : "STYLESHEET" == v.type && (f = "top-level") : f = e, 
            !0;
        }, S = function(e) {
            return v = e, v.startTok = p, g.push(v), !0;
        }, w = function() {
            return !0;
        }, T = function() {
            var e = g.pop();
            return e.endTok = p, v = g[g.length - 1], v.append(e), !0;
        }, A = function() {
            return g.pop(), v = g[g.length - 1], !0;
        }, E = function() {
            for (;g.length > 1; ) T();
            v.endTok = p;
        }; ;) switch (_(), f) {
          case "top-level":
            switch (p.tokenType) {
              case "CDO":
              case "CDC":
              case "WHITESPACE":
                break;

              case "AT-KEYWORD":
                S(new s(p.value)) && x("at-rule");
                break;

              case "{":
                w("Attempt to open a curly-block at top-level.") && n();
                break;

              case "EOF":
                return E(), h;

              default:
                S(new r()) && x("selector") && y();
            }
            break;

          case "at-rule":
            switch (p.tokenType) {
              case ";":
                T() && x();
                break;

              case "{":
                "" !== v.fillType ? x(v.fillType) : w("Attempt to open a curly-block in a statement-type at-rule.") && A() && x("next-block") && y();
                break;

              case "EOF":
                return E(), h;

              default:
                v.appendPrelude(n());
            }
            break;

          case "rule":
            switch (p.tokenType) {
              case "WHITESPACE":
                break;

              case "}":
                T() && x();
                break;

              case "AT-KEYWORD":
                S(new s(p.value)) && x("at-rule");
                break;

              case "EOF":
                return E(), h;

              default:
                S(new r()) && x("selector") && y();
            }
            break;

          case "selector":
            switch (p.tokenType) {
              case "{":
                x("declaration");
                break;

              case "EOF":
                return A() && E(), h;

              default:
                v.appendSelector(n());
            }
            break;

          case "declaration":
            switch (p.tokenType) {
              case "WHITESPACE":
              case ";":
                break;

              case "}":
                T() && x();
                break;

              case "AT-RULE":
                S(new s(p.value)) && x("at-rule");
                break;

              case "IDENT":
                S(new a(p.value)) && x("after-declaration-name");
                break;

              case "EOF":
                return E(), h;

              default:
                w() && A() && x("next-declaration");
            }
            break;

          case "after-declaration-name":
            switch (p.tokenType) {
              case "WHITESPACE":
                break;

              case ":":
                x("declaration-value");
                break;

              case ";":
                w("Incomplete declaration - semicolon after property name.") && A() && x();
                break;

              case "EOF":
                return A() && E(), h;

              default:
                w("Invalid declaration - additional token after property name") && A() && x("next-declaration");
            }
            break;

          case "declaration-value":
            switch (p.tokenType) {
              case "DELIM":
                "!" == p.value && "IDENTIFIER" == b().tokenType && "important" == b().value.toLowerCase() ? (_(), 
                v.important = !0, x("declaration-end")) : v.append(p);
                break;

              case ";":
                T() && x();
                break;

              case "}":
                T() && T() && x();
                break;

              case "EOF":
                return E(), h;

              default:
                v.append(n());
            }
            break;

          case "declaration-end":
            switch (p.tokenType) {
              case "WHITESPACE":
                break;

              case ";":
                T() && x();
                break;

              case "}":
                T() && T() && x();
                break;

              case "EOF":
                return E(), h;

              default:
                w("Invalid declaration - additional token after !important.") && A() && x("next-declaration");
            }
            break;

          case "next-block":
            switch (p.tokenType) {
              case "{":
                n() && x();
                break;

              case "EOF":
                return E(), h;

              default:
                n();
            }
            break;

          case "next-declaration":
            switch (p.tokenType) {
              case ";":
                x("declaration");
                break;

              case "}":
                x("declaration") && y();
                break;

              case "EOF":
                return E(), h;

              default:
                n();
            }
            break;

          default:
            return;
        }
    }
    function i() {
        return this;
    }
    function o() {
        return this.value = [], this;
    }
    function s(e) {
        return this.name = e, this.prelude = [], this.value = [], e in s.registry && (this.fillType = s.registry[e]), 
        this;
    }
    function r() {
        return this.selector = [], this.value = [], this;
    }
    function a(e) {
        return this.name = e, this.value = [], this;
    }
    function c(e) {
        return this.name = e, this.value = [], this;
    }
    function l(e) {
        return this.name = e, this.value = [], this;
    }
    function d() {
        return this.value = [], this;
    }
    e("./tokenizer"), i.prototype.fillType = "", i.prototype.toString = function(e) {
        return JSON.stringify(this.toJSON(), null, e);
    }, i.prototype.append = function(e) {
        return this.value.push(e), this;
    }, o.prototype = new i(), o.prototype.type = "STYLESHEET", o.prototype.toJSON = function() {
        return {
            type: "stylesheet",
            value: this.value.map(function(e) {
                return e.toJSON();
            })
        };
    }, s.prototype = new i(), s.prototype.type = "AT-RULE", s.prototype.appendPrelude = function(e) {
        return this.prelude.push(e), this;
    }, s.prototype.toJSON = function() {
        return {
            type: "at",
            name: this.name,
            prelude: this.prelude.map(function(e) {
                return e.toJSON();
            }),
            value: this.value.map(function(e) {
                return e.toJSON();
            })
        };
    }, s.registry = {
        "import": "",
        media: "rule",
        "font-face": "declaration",
        page: "declaration",
        keyframes: "rule",
        namespace: "",
        "counter-style": "declaration",
        supports: "rule",
        document: "rule",
        "font-feature-values": "declaration",
        viewport: "",
        "region-style": "rule"
    }, r.prototype = new i(), r.prototype.type = "STYLE-RULE", r.prototype.fillType = "declaration", 
    r.prototype.appendSelector = function(e) {
        return this.selector.push(e), this;
    }, r.prototype.toJSON = function() {
        return {
            type: "selector",
            selector: this.selector.map(function(e) {
                return e.toJSON();
            }),
            value: this.value.map(function(e) {
                return e.toJSON();
            })
        };
    }, a.prototype = new i(), a.prototype.type = "DECLARATION", a.prototype.toJSON = function() {
        return {
            type: "declaration",
            name: this.name,
            value: this.value.map(function(e) {
                return e.toJSON();
            })
        };
    }, c.prototype = new i(), c.prototype.type = "BLOCK", c.prototype.toJSON = function() {
        return {
            type: "block",
            name: this.name,
            value: this.value.map(function(e) {
                return e.toJSON();
            })
        };
    }, l.prototype = new i(), l.prototype.type = "FUNCTION", l.prototype.toJSON = function() {
        return {
            type: "func",
            name: this.name,
            value: this.value.map(function(e) {
                return e.toJSON();
            })
        };
    }, d.prototype = new i(), d.prototype.type = "FUNCTION-ARG", d.prototype.toJSON = function() {
        return this.value.map(function(e) {
            return e.toJSON();
        });
    }, t.parse = n;
}), "object" == typeof exports && "function" != typeof define && (define = function(e) {
    e(require, exports, module);
}), define("bleach", [ "require", "exports", "module", "./bleach/css-parser/tokenizer", "./bleach/css-parser/parser" ], function(e, t) {
    function n() {
        p = {}, Object.keys(m).forEach(function(e) {
            p[m[e]] = e;
        });
    }
    function i(e) {
        return e.replace(/[<>"']|&(?![#a-zA-Z0-9]+;)/g, function(e) {
            return "&#" + e.charCodeAt(0) + ";";
        });
    }
    var o = e("./bleach/css-parser/tokenizer"), s = e("./bleach/css-parser/parser"), r = [ "a", "abbr", "acronym", "b", "blockquote", "code", "em", "i", "li", "ol", "strong", "ul" ], a = {
        a: [ "href", "title" ],
        abbr: [ "title" ],
        acronym: [ "title" ]
    }, c = [], l = {
        tags: r,
        prune: [],
        attributes: a,
        styles: c,
        strip: !1,
        stripComments: !0
    };
    t.clean = function(e, n) {
        return e ? (e = e.replace(/<!DOCTYPE\s+[^>]*>/gi, ""), t.cleanNode(e, n)) : "";
    }, t.cleanNode = function(e, t) {
        try {
            t = t || l;
            var n, i = t.hasOwnProperty("attributes") ? t.attributes : l.attributes;
            Array.isArray(i) ? (n = i, i = {}) : n = i.hasOwnProperty("*") ? i["*"] : [];
            var o = {
                ignoreComment: "stripComments" in t ? t.stripComments : l.stripComments,
                allowedStyles: t.styles || l.styles,
                allowedTags: t.tags || l.tags,
                stripMode: "strip" in t ? t.strip : l.strip,
                pruneTags: t.prune || l.prune,
                allowedAttributesByTag: i,
                wildAttributes: n,
                callbackRegexp: t.callbackRegexp || null,
                callback: t.callbackRegexp && t.callback || null,
                maxLength: t.maxLength || 0
            }, s = new u(o);
            return h.HTMLParser(e, s), s.output;
        } catch (r) {
            throw console.error(r, "\n", r.stack), r;
        }
    };
    var d = /\s+/g, u = function(e) {
        this.output = "", this.ignoreComment = e.ignoreComment, this.allowedStyles = e.allowedStyles, 
        this.allowedTags = e.allowedTags, this.stripMode = e.stripMode, this.pruneTags = e.pruneTags, 
        this.allowedAttributesByTag = e.allowedAttributesByTag, this.wildAttributes = e.wildAttributes, 
        this.callbackRegexp = e.callbackRegexp, this.callback = e.callback, this.isInsideStyleTag = !1, 
        this.isInsidePrunedTag = 0, this.isInsideStrippedTag = 0, this.maxLength = e.maxLength || 0, 
        this.complete = !1, this.ignoreFragments = this.maxLength > 0;
    };
    u.prototype = {
        start: function(e, t, n) {
            if (-1 !== this.pruneTags.indexOf(e)) return n || this.isInsidePrunedTag++, void 0;
            if (!this.isInsidePrunedTag) {
                if (-1 === this.allowedTags.indexOf(e)) return this.stripMode ? (n || this.isInsideStrippedTag++, 
                void 0) : (this.output += "&lt;" + (n ? "/" : "") + e + "&gt;", void 0);
                this.isInsideStyleTag = "style" == e && !n;
                var i = this.callbackRegexp;
                i && i.test(e) && (t = this.callback(e, t));
                for (var o = this.allowedAttributesByTag[e], s = this.wildAttributes, r = "<" + e, a = 0; a < t.length; a++) {
                    var c = t[a], l = c.name.toLowerCase();
                    if (c.safe || -1 !== s.indexOf(l) || o && -1 !== o.indexOf(l)) if ("style" == l) {
                        var d = "";
                        try {
                            d = f.parseAttribute(c.escaped, this.allowedStyles);
                        } catch (u) {
                            console.log('CSSParser.parseAttribute failed for: "' + c.escaped + '", skipping. Error: ' + u);
                        }
                        r += " " + l + '="' + d + '"';
                    } else r += " " + l + '="' + c.escaped + '"';
                }
                r += (n ? "/" : "") + ">", this.output += r;
            }
        },
        end: function(e) {
            if (-1 !== this.pruneTags.indexOf(e)) return this.isInsidePrunedTag--, void 0;
            if (!this.isInsidePrunedTag) {
                if (-1 === this.allowedTags.indexOf(e)) return this.isInsideStrippedTag ? (this.isInsideStrippedTag--, 
                void 0) : (this.output += "&lt;/" + e + "&gt;", void 0);
                this.isInsideStyleTag && (this.isInsideStyleTag = !1), this.output += "</" + e + ">";
            }
        },
        chars: function(e) {
            if (!this.isInsidePrunedTag && !this.complete) {
                if (this.isInsideStyleTag) return this.output += f.parseBody(e, this.allowedStyles), 
                void 0;
                if (this.maxLength) {
                    if (this.insideTagForSnippet) return -1 !== e.indexOf(">") && (this.insideTagForSnippet = !1), 
                    void 0;
                    if ("<" === e.charAt(0)) return this.insideTagForSnippet = !0, void 0;
                    var t = e.replace(d, " "), n = this.output.length;
                    n && " " === t[0] && " " === this.output[n - 1] && (t = t.substring(1)), this.output += t, 
                    this.output.length >= this.maxLength && (this.output = this.output.substring(0, this.maxLength), 
                    this.complete = !0);
                } else this.output += i(e);
            }
        },
        comment: function(e) {
            this.isInsidePrunedTag || this.ignoreComment || (this.output += "<!--" + e + "-->");
        }
    };
    var p, h = function() {
        function e(e) {
            for (var t = {}, n = e.split(","), i = 0; i < n.length; i++) t[n[i]] = !0;
            return t;
        }
        var t = /^<(?:[-A-Za-z0-9_]+:)?([-A-Za-z0-9_]+)([^>]*)>/, n = /^<\/(?:[-A-Za-z0-9_]+:)?([-A-Za-z0-9_]+)[^>]*>/, i = /(?:[-A-Za-z0-9_]+:)?([-A-Za-z0-9_]+)(?:\s*=\s*(?:(?:"([^"]*)")|(?:'([^']*)')|([^>\s]+)))?/g, o = e("area,base,basefont,br,col,frame,hr,img,input,isindex,link,meta,param,embed"), s = e("address,applet,blockquote,button,center,dd,del,dir,div,dl,dt,fieldset,form,frameset,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,p,pre,script,table,tbody,td,tfoot,th,thead,tr,ul"), r = e("abbr,acronym,applet,b,basefont,bdo,big,br,button,cite,code,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,var"), a = e("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr"), c = e("checked,compact,declare,defer,disabled,ismap,multiple,nohref,noresize,noshade,nowrap,readonly,selected"), l = e("script,style");
        return this.HTMLParser = function(e, d) {
            function u(e, t, n) {
                if (t = t.toLowerCase(), s[t]) for (;g.last() && r[g.last()]; ) p("", g.last());
                a[t] && g.last() == t && p("", t);
                var l = o[t];
                if (n.length && "/" === n[n.length - 1] && (l = !0, n = n.slice(0, -1)), l || g.push(t), 
                d.start) {
                    var u = [];
                    n.replace(i, function(e, t) {
                        var n = arguments[2] ? arguments[2] : arguments[3] ? arguments[3] : arguments[4] ? arguments[4] : c[t] ? t : "";
                        u.push({
                            name: t,
                            value: n,
                            escaped: n.replace(/"/g, "&quot;"),
                            safe: !1
                        });
                    }), d.start && d.start(t, u, l);
                }
            }
            function p(e, t) {
                if (t) {
                    t = t.toLowerCase();
                    for (var n = g.length - 1; n >= 0 && g[n] != t; n--) ;
                } else var n = 0;
                if (n >= 0) {
                    for (var i = g.length - 1; i >= n; i--) d.end && d.end(g[i]);
                    g.length = n;
                }
            }
            var h, f, m, g = [], v = e;
            for (g.last = function() {
                return this[this.length - 1];
            }; e; ) {
                if (f = !0, g.last() && l[g.last()]) {
                    var _ = !1;
                    if (e = e.replace(new RegExp("^([^]*?)</" + g.last() + "[^>]*>", "i"), function(e, t) {
                        return _ || (t = t.replace(/<!--([^]*?)-->/g, "$1").replace(/<!\[CDATA\[([^]*?)]]>/g, "$1"), 
                        d.chars && (d.chars(t), _ = d.complete)), "";
                    }), d.complete) return this;
                    p("", g.last());
                } else if (0 == e.lastIndexOf("<!--", 0) ? (h = e.indexOf("-->"), h >= 5 ? (d.comment && d.comment(e.substring(4, h)), 
                e = e.substring(h + 3), f = !1) : (d.comment && d.comment(e.substring(4, -1)), e = "", 
                f = !1)) : 0 == e.lastIndexOf("</", 0) ? (m = e.match(n), m && (e = e.substring(m[0].length), 
                m[0].replace(n, p), f = !1)) : 0 == e.lastIndexOf("<", 0) && (m = e.match(t), m && (e = e.substring(m[0].length), 
                m[0].replace(t, u), f = !1)), f) {
                    if (h = e.indexOf("<"), 0 === h) {
                        var y = e.substring(0, 1);
                        e = e.substring(1);
                    } else {
                        var y = 0 > h ? e : e.substring(0, h);
                        e = 0 > h ? "" : e.substring(h);
                    }
                    if (d.chars && (d.chars(y), d.complete)) return this;
                }
                if (e == v) {
                    if (d.ignoreFragments) return;
                    throw console.log(e), console.log(v), "Parse Error: " + e;
                }
                v = e;
            }
            p();
        }, this;
    }(), f = {
        parseAttribute: function(e, t) {
            var n = o.tokenize(e, {
                loc: !0
            }), i = s.parse(n, "declaration"), r = [];
            this._filterDeclarations(null, i.value, t, e, r);
            var a = r.join("");
            return a;
        },
        _filterDeclarations: function(e, t, n, i, o) {
            for (var s = 0; s < t.length; s++) {
                var r = t[s];
                "DECLARATION" === r.type && -1 !== n.indexOf(r.name) && o.push(i.substring(r.startTok.loc.start.idx, e && e.endTok === r.endTok ? r.endTok.loc.start.idx : r.endTok.loc.end.idx + 1));
            }
        },
        parseBody: function(e, t) {
            var n = "";
            try {
                for (var i = o.tokenize(e, {
                    loc: !0
                }), r = s.parse(i), a = [], c = 0; c < r.value.length; c++) {
                    var l = r.value[c];
                    "STYLE-RULE" === l.type && (a.push(e.substring(l.startTok.loc.start.idx, l.value.length ? l.value[0].startTok.loc.start.idx : l.endTok.loc.start.idx)), 
                    this._filterDeclarations(l, l.value, t, e, a), a.push(e.substring(l.endTok.loc.start.idx, l.endTok.loc.end.idx + 1)));
                }
                n = a.join("");
            } catch (d) {
                console.log("bleach CSS parsing failed, skipping. Error: " + d), n = "";
            }
            return n;
        }
    }, m = {
        34: "quot",
        38: "amp",
        39: "apos",
        60: "lt",
        62: "gt",
        160: "nbsp",
        161: "iexcl",
        162: "cent",
        163: "pound",
        164: "curren",
        165: "yen",
        166: "brvbar",
        167: "sect",
        168: "uml",
        169: "copy",
        170: "ordf",
        171: "laquo",
        172: "not",
        173: "shy",
        174: "reg",
        175: "macr",
        176: "deg",
        177: "plusmn",
        178: "sup2",
        179: "sup3",
        180: "acute",
        181: "micro",
        182: "para",
        183: "middot",
        184: "cedil",
        185: "sup1",
        186: "ordm",
        187: "raquo",
        188: "frac14",
        189: "frac12",
        190: "frac34",
        191: "iquest",
        192: "Agrave",
        193: "Aacute",
        194: "Acirc",
        195: "Atilde",
        196: "Auml",
        197: "Aring",
        198: "AElig",
        199: "Ccedil",
        200: "Egrave",
        201: "Eacute",
        202: "Ecirc",
        203: "Euml",
        204: "Igrave",
        205: "Iacute",
        206: "Icirc",
        207: "Iuml",
        208: "ETH",
        209: "Ntilde",
        210: "Ograve",
        211: "Oacute",
        212: "Ocirc",
        213: "Otilde",
        214: "Ouml",
        215: "times",
        216: "Oslash",
        217: "Ugrave",
        218: "Uacute",
        219: "Ucirc",
        220: "Uuml",
        221: "Yacute",
        222: "THORN",
        223: "szlig",
        224: "agrave",
        225: "aacute",
        226: "acirc",
        227: "atilde",
        228: "auml",
        229: "aring",
        230: "aelig",
        231: "ccedil",
        232: "egrave",
        233: "eacute",
        234: "ecirc",
        235: "euml",
        236: "igrave",
        237: "iacute",
        238: "icirc",
        239: "iuml",
        240: "eth",
        241: "ntilde",
        242: "ograve",
        243: "oacute",
        244: "ocirc",
        245: "otilde",
        246: "ouml",
        247: "divide",
        248: "oslash",
        249: "ugrave",
        250: "uacute",
        251: "ucirc",
        252: "uuml",
        253: "yacute",
        254: "thorn",
        255: "yuml",
        402: "fnof",
        913: "Alpha",
        914: "Beta",
        915: "Gamma",
        916: "Delta",
        917: "Epsilon",
        918: "Zeta",
        919: "Eta",
        920: "Theta",
        921: "Iota",
        922: "Kappa",
        923: "Lambda",
        924: "Mu",
        925: "Nu",
        926: "Xi",
        927: "Omicron",
        928: "Pi",
        929: "Rho",
        931: "Sigma",
        932: "Tau",
        933: "Upsilon",
        934: "Phi",
        935: "Chi",
        936: "Psi",
        937: "Omega",
        945: "alpha",
        946: "beta",
        947: "gamma",
        948: "delta",
        949: "epsilon",
        950: "zeta",
        951: "eta",
        952: "theta",
        953: "iota",
        954: "kappa",
        955: "lambda",
        956: "mu",
        957: "nu",
        958: "xi",
        959: "omicron",
        960: "pi",
        961: "rho",
        962: "sigmaf",
        963: "sigma",
        964: "tau",
        965: "upsilon",
        966: "phi",
        967: "chi",
        968: "psi",
        969: "omega",
        977: "thetasym",
        978: "upsih",
        982: "piv",
        8226: "bull",
        8230: "hellip",
        8242: "prime",
        8243: "Prime",
        8254: "oline",
        8260: "frasl",
        8472: "weierp",
        8465: "image",
        8476: "real",
        8482: "trade",
        8501: "alefsym",
        8592: "larr",
        8593: "uarr",
        8594: "rarr",
        8595: "darr",
        8596: "harr",
        8629: "crarr",
        8656: "lArr",
        8657: "uArr",
        8658: "rArr",
        8659: "dArr",
        8660: "hArr",
        8704: "forall",
        8706: "part",
        8707: "exist",
        8709: "empty",
        8711: "nabla",
        8712: "isin",
        8713: "notin",
        8715: "ni",
        8719: "prod",
        8721: "sum",
        8722: "minus",
        8727: "lowast",
        8730: "radic",
        8733: "prop",
        8734: "infin",
        8736: "ang",
        8743: "and",
        8744: "or",
        8745: "cap",
        8746: "cup",
        8747: "int",
        8756: "there4",
        8764: "sim",
        8773: "cong",
        8776: "asymp",
        8800: "ne",
        8801: "equiv",
        8804: "le",
        8805: "ge",
        8834: "sub",
        8835: "sup",
        8836: "nsub",
        8838: "sube",
        8839: "supe",
        8853: "oplus",
        8855: "otimes",
        8869: "perp",
        8901: "sdot",
        8968: "lceil",
        8969: "rceil",
        8970: "lfloor",
        8971: "rfloor",
        9001: "lang",
        9002: "rang",
        9674: "loz",
        9824: "spades",
        9827: "clubs",
        9829: "hearts",
        9830: "diams",
        338: "OElig",
        339: "oelig",
        352: "Scaron",
        353: "scaron",
        376: "Yuml",
        710: "circ",
        732: "tilde",
        8194: "ensp",
        8195: "emsp",
        8201: "thinsp",
        8204: "zwnj",
        8205: "zwj",
        8206: "lrm",
        8207: "rlm",
        8211: "ndash",
        8212: "mdash",
        8216: "lsquo",
        8217: "rsquo",
        8218: "sbquo",
        8220: "ldquo",
        8221: "rdquo",
        8222: "bdquo",
        8224: "dagger",
        8225: "Dagger",
        8240: "permil",
        8249: "lsaquo",
        8250: "rsaquo",
        8364: "euro"
    }, g = /\&([#a-zA-Z0-9]+);/g;
    t.unescapeHTMLEntities = function(e) {
        return e.replace(g, function(e, t) {
            var i = "";
            if ("#" === t.charAt(0)) {
                var o = t.charAt(1);
                i = "x" === o || "X" === o ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(parseInt(t.substring(1), 10));
            } else p || n(), p.hasOwnProperty(t) && (i = String.fromCharCode(p[t]));
            return i;
        });
    }, t.escapePlaintextIntoElementContext = function(e) {
        return e.replace(/[&<>"'\/]/g, function(e) {
            var t = e.charCodeAt(0);
            return "&" + (m[t] || "#" + t) + ";";
        });
    }, t.escapePlaintextIntoAttribute = function(e) {
        return e.replace(/[\u0000-\u002F\u003A-\u0040\u005B-\u0060\u007B-\u0100]/g, function(e) {
            var t = e.charCodeAt(0);
            return "&" + (m[t] || "#" + t) + ";";
        });
    };
}), define("htmlchew", [ "exports", "bleach" ], function(e, t) {
    function n(e, t) {
        for (var n = e.length, i = 0; n > i; i++) {
            var o = e[i];
            if (o.name.toLowerCase() === t) return o;
        }
        return null;
    }
    function i(e, t) {
        var i;
        if (p.test(e)) {
            t = t.filter(function(e) {
                switch (e.name.toLowerCase()) {
                  case "cid-src":
                  case "ext-src":
                    return !1;

                  case "class":
                    i = e;

                  default:
                    return !0;
                }
            });
            var o = n(t, "src");
            o && (l.test(o.escaped) ? (o.name = "cid-src", i ? i.escaped += " moz-embedded-image" : t.push({
                name: "class",
                escaped: "moz-embedded-image"
            }), o.escaped = o.escaped.substring(4)) : d.test(o.escaped) && (o.name = "ext-src", 
            i ? i.escaped += " moz-external-image" : t.push({
                name: "class",
                escaped: "moz-external-image"
            })));
        } else {
            t = t.filter(function(e) {
                switch (e.name.toLowerCase()) {
                  case "cid-src":
                  case "ext-src":
                    return !1;

                  case "class":
                    i = e;

                  default:
                    return !0;
                }
            });
            var s = n(t, "href");
            if (s) {
                var r = s.escaped;
                d.test(r) || u.test(r) ? (s.name = "ext-href", i ? i.escaped += " moz-external-link" : t.push({
                    name: "class",
                    escaped: "moz-external-link"
                })) : t.splice(t.indexOf(s), 1);
            }
        }
        return t;
    }
    var o = [ "a", "abbr", "acronym", "area", "article", "aside", "b", "bdi", "bdo", "big", "blockquote", "br", "caption", "center", "cite", "code", "col", "colgroup", "dd", "del", "details", "dfn", "dir", "div", "dl", "dt", "em", "figcaption", "figure", "font", "footer", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr", "i", "img", "ins", "kbd", "label", "legend", "li", "listing", "map", "mark", "nav", "nobr", "noscript", "ol", "output", "p", "pre", "q", "rp", "rt", "ruby", "s", "samp", "section", "small", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "time", "title", "tr", "tt", "u", "ul", "var", "wbr" ], s = [ "button", "datalist", "script", "select", "svg", "title" ], r = {
        "*": [ "abbr", "align", "alt", "axis", "bgcolor", "border", "cellpadding", "cellspacing", "charoff", "class", "clear", "color", "cols", "colspan", "compact", "coords", "datetime", "dir", "face", "frame", "headers", "height", "hspace", "id", "lang", "media", "nohref", "noshade", "nowrap", "open", "pointsize", "pubdate", "reversed", "rows", "rowspan", "rules", "size", "scope", "scoped", "shape", "span", "start", "summary", "style", "title", "valign", "value", "vspace", "width" ],
        a: [ "ext-href", "hreflang" ],
        area: [ "ext-href", "hreflang" ],
        blockquote: [ "cite", "type" ],
        img: [ "cid-src", "ext-src", "ismap", "usemap" ],
        meta: [ "charset" ],
        ol: [ "type" ],
        style: [ "type" ]
    }, a = [ "background-color", "border", "border-bottom", "border-bottom-color", "border-bottom-left-radius", "border-bottom-right-radius", "border-bottom-style", "border-bottom-width", "border-color", "border-left", "border-left-color", "border-left-style", "border-left-width", "border-radius", "border-right", "border-right-color", "border-right-style", "border-right-width", "border-style", "border-top", "border-top-color", "border-top-left-radius", "border-top-right-radius", "border-top-style", "border-top-width", "border-width", "clear", "color", "display", "float", "font-family", "font-size", "font-style", "font-weight", "height", "line-height", "list-style-position", "list-style-type", "margin", "margin-bottom", "margin-left", "margin-right", "margin-top", "padding", "padding-bottom", "padding-left", "padding-right", "padding-top", "text-align", "text-align-last", "text-decoration", "text-decoration-color", "text-decoration-line", "text-decoration-style", "text-indent", "vertical-align", "white-space", "width", "word-break", "word-spacing", "word-wrap" ], c = /^(?:a|area|img)$/, l = /^cid:/i, d = /^http(?:s)?/i, u = /^mailto:/i, p = /^img$/, h = {
        tags: o,
        strip: !0,
        stripComments: !0,
        prune: s,
        attributes: r,
        styles: a,
        asNode: !0,
        callbackRegexp: c,
        callback: i
    }, f = {
        tags: [],
        strip: !0,
        stripComments: !0,
        prune: [ "style", "button", "datalist", "script", "select", "svg", "title" ],
        asNode: !0,
        maxLength: 100
    };
    e.sanitizeAndNormalizeHtml = function(e) {
        return t.clean(e, h);
    }, e.generateSnippet = function(e) {
        return t.unescapeHTMLEntities(t.clean(e, f));
    };
    var m = {
        tags: [],
        strip: !0,
        stripComments: !0,
        prune: [ "style", "button", "datalist", "script", "select", "svg", "title" ],
        asNode: !0
    }, g = {
        tags: [],
        strip: !0,
        stripComments: !0,
        prune: [ "style", "button", "datalist", "script", "select", "svg", "title", "blockquote" ],
        asNode: !0
    };
    e.generateSearchableTextVersion = function(e, n) {
        var i;
        i = n ? m : g;
        var o = t.clean(e, i);
        return t.unescapeHTMLEntities(o);
    }, e.wrapTextIntoSafeHTMLString = function(e, n, i, o) {
        void 0 === i && (i = !0), n = n || "div", e = t.escapePlaintextIntoElementContext(e), 
        e = i ? e.replace(/\n/g, "<br/>") : e;
        var s = "";
        if (o) for (var r = o.length, a = 0; r > a; a += 2) s += " " + o[a] + '="' + t.escapePlaintextIntoAttribute(o[a + 1]) + '"';
        return "<" + n + s + ">" + e + "</" + n + ">";
    };
    var v = /"/g;
    e.escapeAttrValue = function(e) {
        return e.replace(v, "&quot;");
    };
}), define("searchfilter", [ "rdcommon/log", "./util", "./allback", "./syncbase", "./date", "./htmlchew", "module", "exports" ], function(e, t, n, i, o, s, r, a) {
    function c(e, t) {
        var n = e.header, i = t.header, o = i.date - n.date;
        return o ? o : i.id - n.id;
    }
    function l(e, t, n) {
        if (!t) return null;
        if (e instanceof RegExp) return e.exec(n ? t.slice(n) : t);
        var i = t.indexOf(e, n);
        if (-1 == i) return null;
        var o = [ e ];
        return o.index = i - n, o;
    }
    function d(e) {
        this.phrase = e;
    }
    function u(e, t, n, i, o) {
        this.phrase = e, this.stopAfter = t, this.checkTo = n, this.checkCc = i, this.checkBcc = o;
    }
    function p(e, t, n, i, o, s) {
        i > t && (i = t);
        var r = e.indexOf(" ", t - i);
        -1 === r || r >= t - 1 ? r = t - i : r++;
        var a;
        t + n + o >= e.length ? a = e.length : (a = e.lastIndexOf(" ", t + n + o - 1), t + n >= a && (a = t + n + o));
        var c = e.substring(r, a);
        return {
            text: c,
            offset: r,
            matchRuns: [ {
                start: t - r,
                length: n
            } ],
            path: s
        };
    }
    function h(e, t, n, i) {
        this.phrase = e, this.stopAfter = t, this.contextBefore = n, this.contextAfter = i;
    }
    function f(e, t, n, i, o) {
        this.phrase = e, this.stopAfter = n, this.contextBefore = i, this.contextAfter = o, 
        this.matchQuotes = t;
    }
    function m(e) {
        this.filters = e, this.bodiesNeeded = !1, this.messagesChecked = 0;
        for (var t = 0; t < e.length; t++) {
            var n = e[t];
            n.needsBody && (this.bodiesNeeded = !0);
        }
    }
    function g(e, t, n, o, s) {
        console.log("sf: creating SearchSlice:", n), this._bridgeHandle = e, e.__listener = this, 
        e.userCanGrowDownwards = !1, this._storage = t, this._LOG = T.SearchSlice(this, s, e._handle), 
        this.startTS = null, this.startUID = null, this.endTS = null, this.endUID = null, 
        n instanceof RegExp || (n = new RegExp(n.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&"), "i"));
        var r = [];
        o.author && r.push(new d(n)), o.recipients && r.push(new u(n, 1, !0, !0, !0)), o.subject && r.push(new h(n, 1, S, w)), 
        o.body && (r.push(new f(n, "yes-quotes" === o.body, 1, S, w)), this._pendingBodyLoadLatch = null), 
        this.filterer = new m(r), this._bound_gotOlderMessages = this._gotMessages.bind(this, 1), 
        this._bound_gotNewerMessages = this._gotMessages.bind(this, -1), this.desiredHeaders = i.INITIAL_FILL_SIZE, 
        this.reset();
    }
    var v = o.BEFORE, _ = (o.ON_OR_BEFORE, o.SINCE, o.STRICTLY_AFTER), y = t.bsearchMaybeExists, b = t.bsearchForInsert;
    a.AuthorFilter = d, d.prototype = {
        needsBody: !1,
        testMessage: function(e, t, n) {
            var i, o = e.author, s = this.phrase;
            return (i = l(s, o.name, 0)) ? (n.author = {
                text: o.name,
                offset: 0,
                matchRuns: [ {
                    start: i.index,
                    length: i[0].length
                } ],
                path: null
            }, !0) : (i = l(s, o.address, 0)) ? (n.author = {
                text: o.address,
                offset: 0,
                matchRuns: [ {
                    start: i.index,
                    length: i[0].length
                } ],
                path: null
            }, !0) : (n.author = null, !1);
        }
    }, a.RecipientFilter = u, u.prototype = {
        needsBody: !0,
        testMessage: function(e, t, n) {
            function i(e) {
                for (var t, n = 0; n < e.length; n++) {
                    var i = e[n];
                    if (t = l(o, i.name, 0)) {
                        if (r.push({
                            text: i.name,
                            offset: 0,
                            matchRuns: [ {
                                start: t.index,
                                length: t[0].length
                            } ],
                            path: null
                        }), r.length < s) continue;
                        return;
                    }
                    if ((t = l(o, i.address, 0)) && (r.push({
                        text: i.address,
                        offset: 0,
                        matchRuns: [ {
                            start: t.index,
                            length: t[0].length
                        } ],
                        path: null
                    }), r.length >= s)) return;
                }
            }
            var o = this.phrase, s = this.stopAfter, r = [];
            return this.checkTo && e.to && i(e.to), this.checkCc && e.cc && r.length < s && i(e.cc), 
            this.checkBcc && e.bcc && r.length < s && i(e.bcc), r.length ? (n.recipients = r, 
            !0) : (n.recipients = null, !1);
        }
    }, a.SubjectFilter = h, h.prototype = {
        needsBody: !1,
        testMessage: function(e, t, n) {
            var i = e.subject;
            if (!i) return !1;
            for (var o = this.phrase, s = i.length, r = this.stopAfter, a = this.contextBefore, c = this.contextAfter, d = [], u = 0; s > u && d.length < r; ) {
                var h = l(o, i, u);
                if (!h) break;
                d.push(p(i, u + h.index, h[0].length, a, c, null)), u += h.index + h[0].length;
            }
            return d.length ? (n.subject = d, !0) : (n.subject = null, !1);
        }
    };
    var x = 1;
    a.BodyFilter = f, f.prototype = {
        needsBody: !0,
        testMessage: function(e, t, n) {
            for (var i, o, r = this.phrase, a = this.stopAfter, c = this.contextBefore, d = this.contextAfter, u = [], h = this.matchQuotes, f = 0; f < t.bodyReps.length; f++) {
                var m = t.bodyReps[f].type, g = t.bodyReps[f].content;
                if ("plain" === m) for (var v = 0; v < g.length && u.length < a; v += 2) {
                    var _ = 15 & g[v], y = g[v + 1], b = null;
                    if (h || _ === x) for (i = 0; i < y.length && u.length < a && (o = l(r, y, i), o); ) null === b && (b = [ f, v ]), 
                    u.push(p(y, i + o.index, o[0].length, c, d, b)), i += o.index + o[0].length;
                } else if ("html" === m) {
                    var S = s.generateSearchableTextVersion(g, this.matchQuotes);
                    for (i = 0; i < g.length && u.length < a && (o = l(r, S, i), o); ) u.push(p(S, i + o.index, o[0].length, c, d, null)), 
                    i += o.index + o[0].length;
                }
            }
            return u.length ? (n.body = u, !0) : (n.body = null, !1);
        }
    }, a.MessageFilterer = m, m.prototype = {
        testMessage: function(e, t) {
            this.messagesChecked++;
            var n = !1, i = {}, o = this.filters;
            try {
                for (var s = 0; s < o.length; s++) {
                    var r = o[s];
                    r.testMessage(e, t, i) && (n = !0);
                }
            } catch (a) {
                console.error("filter exception", a, "\n", a.stack);
            }
            return n ? i : !1;
        }
    };
    var S = 16, w = 40;
    a.SearchSlice = g, g.prototype = {
        type: "search",
        set atTop(e) {
            this._bridgeHandle.atTop = e;
        },
        get atBottom() {
            return this._bridgeHandle.atBottom;
        },
        set atBottom(e) {
            this._bridgeHandle.atBottom = e;
        },
        set headerCount(e) {
            return this._bridgeHandle && (this._bridgeHandle.headerCount = e), e;
        },
        IMAGINARY_MESSAGE_COUNT_WHEN_NOT_AT_BOTTOM: 1,
        reset: function() {
            this.headers = [], this.headerCount = 0, this._loading = !0, this.startTS = null, 
            this.startUID = null, this.endTS = null, this.endUID = null, this._storage.getMessagesInImapDateRange(0, null, this.desiredHeaders, this.desiredHeaders, this._gotMessages.bind(this, 1));
        },
        _gotMessages: function(e, t, i) {
            if (this._bridgeHandle) {
                var o = i ? "sf: " : "sf:";
                if (console.log(o, "gotMessages", t.length, "more coming?", i), t.length) if (-1 === e) this.endTS = t[0].date, 
                this.endUID = t[0].id; else {
                    var s = t[t.length - 1];
                    this.startTS = s.date, this.startUID = s.id, null === this.endTS && (this.endTS = t[0].date, 
                    this.endUID = t[0].id);
                }
                var r = function(t, n) {
                    if (this._bridgeHandle) {
                        var s = [];
                        for (c = 0; c < t.length; c++) {
                            var r = t[c], a = n ? n[r.id][0] : null;
                            this._headersChecked++;
                            var l = this.filterer.testMessage(r, a);
                            l && s.push({
                                header: r,
                                matches: l
                            });
                        }
                        var d = this.atTop = this._storage.headerIsYoungestKnown(this.endTS, this.endUID), u = this.atBottom = this._storage.headerIsOldestKnown(this.startTS, this.startUID), p = -1 === e ? !d : !u, h = this.headers.length + s.length, f = !i && h < this.desiredHeaders && p;
                        if (s.length) {
                            console.log(o, "willHave", h, "of", this.desiredHeaders, "want more?", f);
                            var m = -1 === e ? 0 : this.headers.length;
                            this._LOG.headersAppended(m, s), this.headers.splice.apply(this.headers, [ m, 0 ].concat(s)), 
                            this.headerCount = this.headers.length + (u ? 0 : this.IMAGINARY_MESSAGE_COUNT_WHEN_NOT_AT_BOTTOM), 
                            this._bridgeHandle.sendSplice(m, 0, s, !0, i || f), f ? (console.log(o, "requesting more because want more"), 
                            this.reqGrow(e, !1, !0)) : i || (console.log(o, "stopping (already reported), no want more.", "can get more?", p), 
                            this._loading = !1, this.desiredHeaders = this.headers.length);
                        } else i || (this.headerCount = this.headers.length + (u ? 0 : this.IMAGINARY_MESSAGE_COUNT_WHEN_NOT_AT_BOTTOM), 
                        f ? (console.log(o, "requesting more because no matches but want more"), this._pendingBodyLoadLatch = null, 
                        this.reqGrow(e, !1, !0)) : (console.log(o, "stopping, no matches, no want more.", "can get more?", p), 
                        this._bridgeHandle.sendStatus("synced", !0, !1), this._loading = !1, this.desiredHeaders = this.headers.length));
                    }
                }.bind(this);
                if (this.filterer.bodiesNeeded) if (t.length) {
                    for (var a = this._pendingBodyLoadLatch = n.latch(), c = 0; c < t.length; c++) {
                        var l = t[c];
                        this._storage.getMessageBody(l.suid, l.date, a.defer(l.id));
                    }
                    a.then(r.bind(null, t));
                } else {
                    var d = r.bind(null, t, null);
                    this._pendingBodyLoadLatch ? this._pendingBodyLoadLatch.then(d) : d();
                } else r(t, null);
            }
        },
        refresh: function() {},
        onHeaderAdded: function(e, t) {
            if (this._bridgeHandle && !this._loading) {
                null === this.startTS || v(e.date, this.startTS) ? (this.startTS = e.date, this.startUID = e.id) : e.date === this.startTS && e.id < this.startUID && (this.startUID = e.id), 
                null === this.endTS || _(e.date, this.endTS) ? (this.endTS = e.date, this.endUID = e.id) : e.date === this.endTS && e.id > this.endUID && (this.endUID = e.id);
                var n = this.filterer.testMessage(e, t);
                if (!n) return this.desiredHeaders = this.headers.length, void 0;
                var i = {
                    header: e,
                    matches: n
                }, o = b(this.headers, i, c);
                this.desiredHeaders = this.headers.length, this._LOG.headerAdded(o, i), this.headers.splice(o, 0, i), 
                this.headerCount = this.headers.length + (this.atBottom ? 0 : this.IMAGINARY_MESSAGE_COUNT_WHEN_NOT_AT_BOTTOM), 
                this._bridgeHandle.sendSplice(o, 0, [ i ], !1, !1);
            }
        },
        onHeaderModified: function(e, t) {
            if (this._bridgeHandle && !this._loading) {
                var n = {
                    header: e,
                    matches: null
                }, i = y(this.headers, n, c);
                if (null !== i) {
                    var o = this.headers[i];
                    return o.header = e, this._LOG.headerModified(i, o), this._bridgeHandle.sendUpdate([ i, o ]), 
                    void 0;
                }
                this.filterer.bodiesNeeded && t && this.onHeaderAdded(e, t);
            }
        },
        onHeaderRemoved: function(e) {
            if (this._bridgeHandle) {
                if (e.date === this.endTS && e.id === this.endUID && (this.headers.length ? (this.endTS = this.headers[0].header.date, 
                this.endUID = this.headers[0].header.id) : (this.endTS = null, this.endUID = null)), 
                e.date === this.startTS && e.id === this.startUID) if (this.headers.length) {
                    var t = this.headers[this.headers.length - 1];
                    this.startTS = t.header.date, this.startUID = t.header.id;
                } else this.startTS = null, this.startUID = null;
                var n = {
                    header: e,
                    matches: null
                }, i = y(this.headers, n, c);
                null !== i && (this._LOG.headerRemoved(i, n), this.headers.splice(i, 1), this.headerCount = this.headers.length + (this.atBottom ? 0 : this.IMAGINARY_MESSAGE_COUNT_WHEN_NOT_AT_BOTTOM), 
                this._bridgeHandle.sendSplice(i, 1, [], !1, !1));
            }
        },
        reqNoteRanges: function(e, t, n, i) {
            var o;
            if (e >= this.headers.length || this.headers[e].suid !== t) for (e = 0, o = 0; o < this.headers.length; o++) if (this.headers[o].suid === t) {
                e = o;
                break;
            }
            if (n >= this.headers.length || this.headers[n].suid !== i) for (o = this.headers.length - 1; o >= 0; o--) if (this.headers[o].suid === i) {
                n = o;
                break;
            }
            if (n + 1 < this.headers.length) {
                this.atBottom = !1, this.userCanGrowDownwards = !1;
                var s = this.headers.length - n - 1;
                this.desiredHeaders -= s, this.headers.splice(n + 1, this.headers.length - n - 1), 
                this.headerCount = this.headers.length + this.IMAGINARY_MESSAGE_COUNT_WHEN_NOT_AT_BOTTOM, 
                this._bridgeHandle.sendSplice(n + 1, s, [], !0, e > 0);
                var r = this.headers[n].header;
                this.startTS = r.date, this.startUID = r.id;
            }
            if (e > 0) {
                this.atTop = !1, this.desiredHeaders -= e, this.headers.splice(0, e), this.headerCount = this.headers.length + (this.atBottom ? 0 : this.IMAGINARY_MESSAGE_COUNT_WHEN_NOT_AT_BOTTOM), 
                this._bridgeHandle.sendSplice(0, e, [], !0, !1);
                var a = this.headers[0].header;
                this.endTS = a.date, this.endUID = a.id;
            }
        },
        reqGrow: function(e, t, n) {
            if (n || !this._loading) {
                this._loading = !0;
                var o;
                0 > e ? (o = -1 === e ? i.INITIAL_FILL_SIZE : -e, n || (this.desiredHeaders += o), 
                this._storage.getMessagesAfterMessage(this.endTS, this.endUID, o, this._gotMessages.bind(this, -1))) : (o = 1 >= e ? i.INITIAL_FILL_SIZE : e, 
                n || (this.desiredHeaders += o), this._storage.getMessagesBeforeMessage(this.startTS, this.startUID, o, this._gotMessages.bind(this, 1)));
            }
        },
        die: function() {
            this._storage.dyingSlice(this), this._bridgeHandle = null, this._LOG.__die();
        }
    };
    var T = a.LOGFAB = e.register(r, {
        SearchSlice: {
            type: e.QUERY,
            events: {
                headersAppended: {
                    index: !1
                },
                headerAdded: {
                    index: !1
                },
                headerModified: {
                    index: !1
                },
                headerRemoved: {
                    index: !1
                }
            },
            TEST_ONLY_events: {
                headersAppended: {
                    headers: !1
                },
                headerAdded: {
                    header: !1
                },
                headerModified: {
                    header: !1
                },
                headerRemoved: {
                    header: !1
                }
            }
        }
    });
}), define("wakelocks", [ "require", "./worker-router" ], function(e) {
    function t(e) {
        this.timeoutMs = e.timeout || t.DEFAULT_TIMEOUT_MS;
        var n = this.locks = {};
        this._timeout = null, this._readyPromise = Promise.all(e.locks.map(function(e) {
            return new Promise(function(t) {
                i("requestWakeLock", [ e ], function(i) {
                    n[e] = i, t();
                });
            });
        })).then(function() {
            this._debug("Acquired", this, "for", this.timeoutMs + "ms"), this.renew();
        }.bind(this));
    }
    var n = e("./worker-router"), i = n.registerCallbackType("wakelocks");
    return t.DEFAULT_TIMEOUT_MS = 45e3, t.prototype = {
        renew: function(e, t) {
            "function" == typeof e && (t = e, e = null), this._readyPromise.then(function() {
                this._timeout && (clearTimeout(this._timeout), this._debug("Renewing", this, "for another", this.timeoutMs + "ms" + (e ? " (reason: " + e + ")" : "") + ",", "would have expired in " + (this.timeoutMs - (Date.now() - this._timeLastRenewed)) + "ms if not renewed.")), 
                this._timeLastRenewed = Date.now(), this._timeout = setTimeout(function() {
                    this._debug("*** Unlocking", this, "due to a TIMEOUT. Did you remember to unlock? ***"), 
                    this.unlock.bind(this);
                }.bind(this), this.timeoutMs), t && t();
            }.bind(this));
        },
        unlock: function(e) {
            return this._readyPromise.then(function() {
                var t = this.toString(), n = this.locks;
                return this.locks = {}, clearTimeout(this._timeout), Promise.all(Object.keys(n).map(function(e) {
                    return new Promise(function(t) {
                        i("unlock", [ n[e] ], function() {
                            t();
                        });
                    });
                })).then(function() {
                    this._debug("Unlocked", t + ".", e ? "Reason: " + e : "");
                }.bind(this));
            }.bind(this));
        },
        toString: function() {
            return Object.keys(this.locks).join("+") || "(no locks)";
        },
        _debug: function() {
            var e = Array.slice(arguments);
            console.log.apply(console, [ "SmartWakeLock:" ].concat(e));
        }
    }, {
        SmartWakeLock: t
    };
}), define("headerCounter", [ "module", "exports" ], function(e, t) {
    t.countHeaders = function(e, t, n, o) {
        function s(n, o, s, a) {
            var l = a ? "sf: " : "sf:";
            if (console.log(l, "gotMessages", s.length, "more coming?", a), s.length) {
                var p = s[s.length - 1];
                d = p.date, u = p.id;
            }
            var h = function(s) {
                for (i = 0; i < s.length; i++) {
                    var p = s[i], h = t(p);
                    h && c++;
                }
                var f = e.headerIsOldestKnown(d, u), m = !f, g = !a && m;
                g ? (console.log(l, "requesting more because want more"), r(n, !1, !0, o)) : a || o(c);
            };
            h(s);
        }
        function r(t, n, i, o) {
            e.flushExcessCachedBlocks("countHeaders"), e.getMessagesBeforeMessage(d, u, l, s.bind(null, 1, o));
        }
        var a = null;
        "function" == typeof n ? o = n : a = n.fetchSize;
        var c = 0, l = a || 100, d = null, u = null;
        e.getMessagesInImapDateRange(0, null, l, l, s.bind(null, 1, o));
    };
}), define("jobmixins", [ "./worker-router", "./util", "./allback", "./wakelocks", "./date", "./syncbase", "./mailslice", "./headerCounter", "exports", "require" ], function(e, t, n, i, o, s, r, a, c, l) {
    var d = e.registerCallbackType("devicestorage");
    c.local_do_modtags = function(e, t, n) {
        var i = n ? e.removeTags : e.addTags, o = n ? e.addTags : e.removeTags;
        this._partitionAndAccessFoldersSequentially(e.messages, !1, function(e, t, n, s, r) {
            function a() {
                0 === --c && r();
            }
            for (var c = n.length, l = 0; l < n.length; l++) {
                var d, u, p, h = n[l], f = !1;
                if (i) for (d = 0; d < i.length; d++) u = i[d], "\\Seen" === u && t.folderMeta.unreadCount--, 
                p = h.flags.indexOf(u), -1 === p && (h.flags.push(u), h.flags.sort(), f = !0);
                if (o) for (d = 0; d < o.length; d++) u = o[d], "\\Seen" === u && t.folderMeta.unreadCount++, 
                p = h.flags.indexOf(u), -1 !== p && (h.flags.splice(p, 1), f = !0);
                t.updateMessageHeader(h.date, h.id, !1, h, null, a);
            }
        }, function() {
            t(null, null, !0);
        }, null, n, "modtags");
    }, c.local_undo_modtags = function(e, t) {
        return this.local_do_modtags(e, t, !0);
    }, c.local_do_move = function(e, t, n) {
        e.guids = {};
        var i = !this.resilientServerIds, o = this._stateDelta, s = this;
        o.moveMap || (o.moveMap = {}), o.serverIdMap || (o.serverIdMap = {}), n || (n = e.targetFolder), 
        this._partitionAndAccessFoldersSequentially(e.messages, !1, function(t, r, a, c, l) {
            function d(e, t) {
                g = t, u();
            }
            function u() {
                return m >= a.length ? (l(), void 0) : (v = a[m++], r.getMessageBody(v.suid, v.date, p), 
                void 0);
            }
            function p(t) {
                _ = t, v.srvid && (o.serverIdMap[v.suid] = v.srvid), r === g || "localdrafts" === r.folderMeta.type && "outbox" !== g.folderMeta.type || "outbox" === r.folderMeta.type && "localdrafts" !== g.folderMeta.type ? "move" === e.type ? u() : r.deleteMessageHeaderAndBodyUsingHeader(v, u) : r.deleteMessageHeaderAndBodyUsingHeader(v, h);
            }
            function h() {
                var e = v.suid;
                v.id = g._issueNewHeaderId(), v.suid = g.folderId + "/" + v.id, i && (v.srvid = null), 
                o.moveMap[e] = v.suid, y = 2, g.addMessageHeader(v, _, f), g.addMessageBody(v, _, f);
            }
            function f() {
                0 === --y && u();
            }
            var m = 0, g = null, v = null, _ = null, y = 0;
            r.folderId === n ? (g = r, u()) : s._accessFolderForMutation(n, !1, d, null, "local move target");
        }, function() {
            t(null, o.moveMap, !0);
        }, null, !1, "local move source");
    }, c.local_undo_move = function(e, t) {
        t(null);
    }, c.local_do_delete = function(e, t) {
        var n = this.account.getFirstFolderWithType("trash");
        return n ? (this.local_do_move(e, t, n.id), void 0) : (this.account.ensureEssentialOnlineFolders(), 
        t("defer"), void 0);
    }, c.local_undo_delete = function(e, t) {
        var n = this.account.getFirstFolderWithType("trash");
        return n ? (this.local_undo_move(e, t, n.id), void 0) : (t("unknown"), void 0);
    }, c.do_download = function(e, t) {
        function n() {
            o.updateMessageBody(s, r, {
                flushBecause: "blobs"
            }, {
                changeDetails: {
                    attachments: e.attachmentIndices
                }
            }, function() {
                t(_, null, !0);
            });
        }
        var i, o, s, r, a, c = this, l = e.messageSuid.lastIndexOf("/"), d = e.messageSuid.substring(0, l), p = function(t, n) {
            i = t, o = n, o.getMessageHeader(e.messageSuid, e.messageDate, g);
        }, h = function() {
            t("aborted-retry");
        }, f = [], m = [], g = function(t) {
            s = t, a = s.srvid, o.getMessageBody(e.messageSuid, e.messageDate, v);
        }, v = function(t) {
            r = t;
            var n, o;
            for (n = 0; n < e.relPartIndices.length; n++) o = r.relatedParts[e.relPartIndices[n]], 
            o.file || (f.push(o), m.push("idb"));
            for (n = 0; n < e.attachmentIndices.length; n++) o = r.attachments[e.attachmentIndices[n]], 
            o.file || (f.push(o), m.push("sdcard"));
            i.downloadMessageAttachments(a, f, y);
        }, _ = null, y = function(e, i) {
            function o() {
                --s || n();
            }
            if (i.length !== f.length) return t(e, null, !1), void 0;
            _ = e;
            for (var s = 1, r = 0; r < f.length; r++) {
                var a = f[r], l = i[r], d = m[r];
                l && (a.sizeEstimate = l.size, a.type = l.type, "idb" === d ? a.file = l : (s++, 
                u(c._LOG, l, d, a.name, a, o)));
            }
            o();
        };
        c._accessFolderForMutation(d, !0, p, h, "download");
    };
    var u = c.saveToDeviceStorage = function(e, t, n, i, s, r, a) {
        var c = function(c, l, d) {
            if (c) e.savedAttachment(n, t.type, t.size), console.log("saved attachment to", n, d, "type:", t.type), 
            s.file = [ n, d ], r(); else {
                if (e.saveFailure(n, t.type, l, i), console.warn("failed to save attachment to", n, i, "type:", t.type), 
                a) return r(l), void 0;
                var p = i.lastIndexOf(".");
                -1 === p && (p = i.length), i = i.substring(0, p) + "-" + o.NOW() + i.substring(p), 
                u(e, t, n, i, s, r, !0);
            }
        };
        d("save", [ n, t, i ], c);
    };
    c.local_do_download = function(e, t) {
        t(null);
    }, c.check_download = function(e, t) {
        t(null, "coherent-notyet");
    }, c.local_undo_download = function(e, t) {
        t(null);
    }, c.undo_download = function(e, t) {
        t(null);
    }, c.local_do_downloadBodies = function(e, t) {
        t(null);
    }, c.do_downloadBodies = function(e, t) {
        var n = null, i = 0;
        this._partitionAndAccessFoldersSequentially(e.messages, !0, function(t, o, s, r, a) {
            t.downloadBodies(s, e.options, function(e, t) {
                i += t, e && !n && (n = e), a();
            });
        }, function() {
            t(n, null, i > 0);
        }, function() {
            n = "aborted-retry";
        }, !1, "downloadBodies", !0);
    }, c.check_downloadBodies = function(e, t) {
        t(null, "coherent-notyet");
    }, c.check_downloadBodyReps = function(e, t) {
        t(null, "coherent-notyet");
    }, c.do_downloadBodyReps = function(e, t) {
        var n, i, o = this, s = e.messageSuid.lastIndexOf("/"), r = e.messageSuid.substring(0, s), a = function(t, o) {
            n = t, i = o, i.getMessageHeader(e.messageSuid, e.messageDate, l);
        }, c = function() {
            t("aborted-retry");
        }, l = function(e) {
            return e ? (i.getMessageBody(e.suid, e.date, function(t) {
                i.messageBodyRepsDownloaded(t) ? d(null, t, !0) : n.downloadBodyReps(e, d);
            }), void 0) : (t(), void 0);
        }, d = function(e, n, i) {
            if (e) return console.error("Error downloading reps", e), t("unknown"), void 0;
            var o = !i;
            t(null, n, o);
        };
        o._accessFolderForMutation(r, !0, a, c, "downloadBodyReps");
    }, c.local_do_downloadBodyReps = function(e, t) {
        t(null);
    }, c.do_sendOutboxMessages = function(e, t) {
        var n = this.account, r = n.getFirstFolderWithType("outbox");
        if (!r) return t("moot"), void 0;
        if (!n.outboxSyncEnabled) return console.log("outbox: Outbox syncing temporarily disabled; not syncing."), 
        t(null), void 0;
        var a = n.outboxNeedsFreshSync;
        a && (console.log("outbox: This is the first outbox sync for this account."), n.outboxNeedsFreshSync = !1);
        var c = new i.SmartWakeLock({
            locks: [ "cpu", "wifi" ]
        });
        this._accessFolderForMutation(r.id, !1, function(i, r) {
            l([ "jobs/outbox" ], function(i) {
                i.sendNextAvailableOutboxMessage(n.compositeAccount || n, r, e.beforeMessage, e.emitNotifications, a, c).then(function(e) {
                    var i = e.moreExpected, a = e.messageNamer;
                    c.unlock("send complete"), i ? n.universe.sendOutboxMessages(n, {
                        beforeMessage: a
                    }) : (n.universe.notifyOutboxSyncDone(n), r.markSyncRange(s.OLDEST_SYNC_DATE, null, "XXX", o.NOW())), 
                    t(null, null, !0);
                }).catch(function(e) {
                    console.error("Exception while sending a message.", "Send failure: " + e, e.stack), 
                    c.unlock(e), t("aborted-retry");
                });
            });
        }, null, "sendOutboxMessages");
    }, c.check_sendOutboxMessages = function(e, t) {
        t(null, "moot");
    }, c.local_undo_sendOutboxMessages = function(e, t) {
        t(null);
    }, c.local_do_setOutboxSyncEnabled = function(e, t) {
        this.account.outboxSyncEnabled = e.outboxSyncEnabled, t(null);
    }, c.postJobCleanup = function(e) {
        if (!e) {
            var t, n;
            if (this._stateDelta.serverIdMap) {
                t = this._stateDelta.serverIdMap, n = this._state.suidToServerId;
                for (var i in t) {
                    var o = t[i];
                    null === o ? delete n[i] : n[i] = o;
                }
            }
            if (this._stateDelta.moveMap) {
                t = this._stateDelta.moveMap, n = this._state.moveMap;
                for (var s in t) {
                    var r = t[s];
                    n[s] = r;
                }
            }
        }
        for (var a = 0; a < this._heldMutexReleasers.length; a++) this._heldMutexReleasers[a](e);
        this._heldMutexReleasers = [], this._stateDelta.serverIdMap = null, this._stateDelta.moveMap = null;
    }, c.allJobsDone = function() {
        this._state.suidToServerId = {}, this._state.moveMap = {};
    }, c._partitionAndAccessFoldersSequentially = function(e, n, i, o, s, r, a, c) {
        var l, d, u = t.partitionMessagesByFolderId(e), p = this, h = null, f = null, m = null, g = 0, v = null, _ = !1;
        r && u.reverse();
        var y = function() {
            if (!_) {
                if (g >= u.length) return _ = !0, o(null), void 0;
                if (g) {
                    l = null;
                    var e = p._heldMutexReleasers.pop();
                    e && e(), l = null;
                }
                v = u[g++], f = v.messages, m = null, v.folderId !== h && (h = v.folderId, p._accessFolderForMutation(h, n, x, b, a));
            }
        }, b = function() {
            if (!_) {
                if (s) try {
                    s();
                } catch (e) {
                    p._LOG.callbackErr(e);
                }
                _ = !0, o("connection-lost");
            }
        }, x = function(e, t) {
            if (!_) if (l = e, d = t, n && !c) {
                var o = [], s = p._state.suidToServerId;
                m = [];
                for (var r = 0; r < f.length; r++) {
                    var a = f[r], u = s[a.suid];
                    u ? m.push(u) : (m.push(null), o.push(a));
                }
                if (o.length) d.getMessageHeaders(o, S); else try {
                    i(l, d, m, f, y);
                } catch (h) {
                    console.error("PAAFS error:", h, "\n", h.stack);
                }
            } else d.getMessageHeaders(f, w);
        }, S = function(e) {
            if (!_) {
                for (var t = m.indexOf(null), n = 0; n < e.length; n++) {
                    var o = e[n];
                    if (o) {
                        var s = o.srvid;
                        m[t] = s, s || console.warn("Header", e[n].suid, "missing server id in job!");
                    }
                    t = m.indexOf(null, t + 1);
                }
                if (!m.length) return y(), void 0;
                try {
                    i(l, d, m, f, y);
                } catch (r) {
                    console.error("PAAFS error:", r, "\n", r.stack);
                }
            }
        }, w = function(e) {
            if (!_) {
                if (!e.length) return y(), void 0;
                e.sort(function(e, t) {
                    return e.date > t.date;
                });
                try {
                    i(l, d, e, f, y);
                } catch (t) {
                    console.error("PAAFS error:", t, "\n", t.stack);
                }
            }
        };
        y();
    }, c.local_do_upgradeDB = function(e, t) {
        var n = this.account.getFolderStorageForFolderId(e.folderId), i = function(e) {
            return e.flags && -1 === e.flags.indexOf("\\Seen");
        };
        a.countHeaders(n, i, function(e) {
            n._dirty = !0, n.folderMeta.version = r.FOLDER_DB_VERSION, n.folderMeta.unreadCount = e, 
            t(null, null, !0);
        });
    };
}), define("jobs/outbox", [ "require" ], function(e) {
    function t(e, s, r, a, c, l) {
        return n(s, r).then(function(n) {
            if (!n) return {
                moreExpected: !1,
                messageNamer: null
            };
            var r = !s.headerIsOldestKnown(n.date, n.id);
            return n.sendStatus || (n.sendStatus = {}), "sending" !== n.sendStatus.state || c ? i(e, s, n, l).then(o.bind(null, e, s, a)).then(function(e) {
                return {
                    moreExpected: r,
                    messageNamer: {
                        suid: e.suid,
                        date: e.date
                    }
                };
            }) : t(e, s, {
                suid: n.suid,
                date: n.date
            }, a, c, l);
        });
    }
    function n(e, t) {
        return new Promise(function(n) {
            if (t) {
                var i = parseInt(t.suid.substring(t.suid.lastIndexOf("/") + 1));
                e.getMessagesBeforeMessage(t.date, i, 1, function(e) {
                    n(e[0] || null);
                });
            } else e.getMessagesInImapDateRange(0, null, 1, 1, function(e) {
                n(e[0]);
            });
        });
    }
    function i(t, n, i, o) {
        return new Promise(function(s, r) {
            n.getMessage(i.suid, i.date, function(n) {
                return n && n.body ? (e([ "../drafts/composer" ], function(e) {
                    var i = new e.Composer(n, t, t.identities[0]);
                    i.setSmartWakeLock(o), s(i);
                }), void 0) : (console.error("Failed to create composer; no body available."), r(), 
                void 0);
            });
        });
    }
    function o(e, t, n, i) {
        var o = i.header, r = s.bind(null, e, t, i, o, n), a = t.getOldestMessageTimestamp();
        return a > 0 && a < o.date.valueOf(), r({
            state: "sending",
            err: null,
            badAddresses: null,
            sendFailures: o.sendStatus && o.sendStatus.sendFailures || 0
        }), new Promise(function(n) {
            e.sendMessage(i, function(e, s) {
                e ? (console.log("Message failed to send (" + e + ")"), r({
                    state: "error",
                    err: e,
                    badAddresses: s,
                    sendFailures: (o.sendStatus.sendFailures || 0) + 1
                }), n(i.header)) : (console.log("Message sent; deleting from outbox."), r({
                    state: "success",
                    err: null,
                    badAddresses: null
                }), t.deleteMessageHeaderAndBodyUsingHeader(o, function() {
                    n(i.header);
                }));
            });
        });
    }
    function s(e, t, n, i, o, s) {
        i.sendStatus = {
            state: s.state,
            err: s.err,
            badAddresses: s.badAddresses,
            sendFailures: s.sendFailures
        }, e.universe.__notifyBackgroundSendStatus({
            state: s.state,
            err: s.err,
            badAddresses: s.badAddresses,
            sendFailures: s.sendFailures,
            accountId: e.id,
            suid: i.suid,
            emitNotifications: o,
            messageId: n.messageId,
            sentDate: n.sentDate
        }), t.updateMessageHeader(i.date, i.id, !1, i, null);
    }
    return {
        sendNextAvailableOutboxMessage: t
    };
}), define("db/mail_rep", [], function() {
    function e(e) {
        if (!e.author) throw new Error("No author?!");
        if (!e.date) throw new Error("No date?!");
        return {
            id: e.id,
            srvid: e.srvid || null,
            suid: e.suid || null,
            guid: e.guid || null,
            author: e.author,
            to: e.to || null,
            cc: e.cc || null,
            bcc: e.bcc || null,
            replyTo: e.replyTo || null,
            date: e.date,
            flags: e.flags || [],
            hasAttachments: e.hasAttachments || !1,
            subject: null != e.subject ? e.subject : null,
            snippet: null != e.snippet ? e.snippet : null
        };
    }
    function t(e) {
        if (!e.date) throw new Error("No date?!");
        if (!e.attachments || !e.bodyReps) throw new Error("No attachments / bodyReps?!");
        return {
            date: e.date,
            size: e.size || 0,
            attachments: e.attachments,
            relatedParts: e.relatedParts || null,
            references: e.references || null,
            bodyReps: e.bodyReps
        };
    }
    function n(e) {
        if ("plain" !== e.type && "html" !== e.type) throw new Error("Bad body type: " + e.type);
        if (void 0 === e.sizeEstimate) throw new Error("Need size estimate!");
        return {
            type: e.type,
            part: e.part || null,
            sizeEstimate: e.sizeEstimate,
            amountDownloaded: e.amountDownloaded || 0,
            isDownloaded: e.isDownloaded || !1,
            _partInfo: e._partInfo || null,
            content: e.content || ""
        };
    }
    function i(e) {
        if (void 0 === e.sizeEstimate) throw new Error("Need size estimate!");
        return {
            name: null != e.name ? e.name : null,
            contentId: e.contentId || null,
            type: e.type || "application/octet-stream",
            part: e.part || null,
            encoding: e.encoding || null,
            sizeEstimate: e.sizeEstimate,
            file: e.file || null,
            charset: e.charset || null,
            textFormat: e.textFormat || null
        };
    }
    return {
        makeHeaderInfo: e,
        makeBodyInfo: t,
        makeBodyPart: n,
        makeAttachmentPart: i
    };
}), define("drafts/draft_rep", [ "require", "../db/mail_rep" ], function(e) {
    function t(e, t, n, i, s) {
        var r = s.getIdentityForSenderIdentityId(n.senderId), a = o.makeHeaderInfo({
            id: i.id,
            srvid: null,
            suid: i.suid,
            guid: e ? e.guid : null,
            author: {
                name: r.name,
                address: r.address
            },
            to: n.to,
            cc: n.cc,
            bcc: n.bcc,
            replyTo: r.replyTo,
            date: i.date,
            flags: [],
            hasAttachments: e ? e.hasAttachments : !1,
            subject: n.subject,
            snippet: n.body.text.substring(0, 100)
        }), c = o.makeBodyInfo({
            date: i.date,
            size: 0,
            attachments: t ? t.attachments.concat() : [],
            relatedParts: t ? t.relatedParts.concat() : [],
            references: n.referencesStr,
            bodyReps: []
        });
        return c.bodyReps.push(o.makeBodyPart({
            type: "plain",
            part: null,
            sizeEstimate: n.body.text.length,
            amountDownloaded: n.body.text.length,
            isDownloaded: !0,
            _partInfo: {},
            content: [ 1, n.body.text ]
        })), n.body.html && c.bodyReps.push(o.makeBodyPart({
            type: "html",
            part: null,
            sizeEstimate: n.body.html.length,
            amountDownloaded: n.body.html.length,
            isDownloaded: !0,
            _partInfo: {},
            content: n.body.html
        })), {
            header: a,
            body: c
        };
    }
    function n(e, t, n) {
        var i = {
            text: "",
            html: null
        };
        n.bodyReps.length >= 1 && "plain" === n.bodyReps[0].type && 2 === n.bodyReps[0].content.length && 1 === n.bodyReps[0].content[0] && (i.text = n.bodyReps[0].content[1]), 
        2 == n.bodyReps.length && "html" === n.bodyReps[1].type && (i.html = n.bodyReps[1].content);
        var o = [];
        n.attachments.forEach(function(e) {
            o.push({
                name: e.name,
                blob: e.file
            });
        }), {
            identity: e.identities[0],
            subject: t.subject,
            body: i,
            to: t.to,
            cc: t.cc,
            bcc: t.bcc,
            referencesStr: n.references,
            attachments: o
        };
    }
    function i(e, t, n) {
        var i = o.makeHeaderInfo(e);
        i.id = n.id, i.suid = n.suid, i.flags = [ "\\Seen" ];
        var s = o.makeBodyInfo(t);
        return s.attachments && (s.attachments = s.attachments.map(function(e) {
            var t = o.makeAttachmentPart(e);
            return t.type = "application/x-gelam-no-download", t.file = null, t;
        })), s.relatedParts && (s.relatedParts = []), s.bodyReps = s.bodyReps.map(function(e) {
            return o.makeBodyPart(e);
        }), {
            header: i,
            body: s
        };
    }
    var o = e("../db/mail_rep");
    return {
        mergeDraftStates: t,
        convertHeaderAndBodyToDraftRep: n,
        cloneDraftMessageForSentFolderWithoutAttachments: i
    };
}), define("safe-base64", [ "require", "exports", "module" ], function(e, t) {
    t.decode = function(e) {
        for (var t = 0, n = 0, i = 0, o = new Uint8Array(Math.ceil(3 * e.length / 4)), s = 0; s < e.length; s++) {
            var r, a = e.charCodeAt(s);
            if (a >= 65 && 90 >= a) r = a - 65; else if (a >= 97 && 122 >= a) r = a - 97 + 26; else if (a >= 48 && 57 >= a) r = a - 48 + 52; else if (43 === a) r = 62; else {
                if (47 !== a) {
                    if (61 === a) {
                        n = 0;
                        continue;
                    }
                    continue;
                }
                r = 63;
            }
            t = t << 6 | r, n += 6, n >= 8 && (n -= 8, o[i++] = t >> n, 2 === n ? t &= 3 : 4 === n && (t &= 15));
        }
        return i < o.length ? o.subarray(0, i) : o;
    }, t.encode = function(e) {
        var t, n;
        for (t = new Array(e.length), n = 0; n < e.length; n++) t[n] = String.fromCharCode(e[n]);
        return window.btoa(t.join(""));
    }, t.mimeStyleBase64Encode = function(e) {
        function t(e) {
            r[c++] = 25 >= e ? 65 + e : 51 >= e ? 71 + e : 61 >= e ? -4 + e : 62 === e ? 43 : 47;
        }
        var n = Math.floor(e.length / 57), i = e.length - 57 * n, o = 78 * n;
        i && (o += 4 * Math.ceil(i / 3) + 2);
        var s, r = new Uint8Array(o), a = 0, c = 0;
        for (s = e.length; s >= 3; s -= 3) {
            var l = e[a++], d = e[a++], u = e[a++];
            t(l >> 2), t((3 & l) << 4 | d >> 4), t((15 & d) << 2 | u >> 6), t(63 & u), (0 === a % 57 || 3 === s) && (r[c++] = 13, 
            r[c++] = 10);
        }
        switch (s) {
          case 2:
            l = e[a++], d = e[a++], t(l >> 2), t((3 & l) << 4 | d >> 4), t(0 | (15 & d) << 2), 
            r[c++] = 61, r[c++] = 13, r[c++] = 10;
            break;

          case 1:
            l = e[a++], t(l >> 2), t(0 | (3 & l) << 4), r[c++] = 61, r[c++] = 61, r[c++] = 13, 
            r[c++] = 10;
        }
        return r;
    };
}), define("async_blob_fetcher", [ "exports" ], function() {
    function e(e, t) {
        var n = URL.createObjectURL(e), i = new XMLHttpRequest();
        i.open("GET", n, !0), i.responseType = "arraybuffer", i.onload = function() {
            return 0 !== i.status && (i.status < 200 || i.status >= 300) ? (t(i.status), void 0) : (t(null, new Uint8Array(i.response)), 
            void 0);
        }, i.onerror = function() {
            t("error");
        };
        try {
            i.send();
        } catch (o) {
            console.error("XHR send() failure on blob"), t("error");
        }
        URL.revokeObjectURL(n);
    }
    return {
        asyncFetchBlobAsUint8Array: e
    };
}), define("drafts/jobs", [ "require", "exports", "module", "../db/mail_rep", "../drafts/draft_rep", "safe-base64", "../async_blob_fetcher" ], function(e, t) {
    var n = e("../db/mail_rep"), i = e("../drafts/draft_rep"), o = e("safe-base64"), s = e("../async_blob_fetcher").asyncFetchBlobAsUint8Array, r = t.draftsMixins = {};
    r.BLOB_BASE64_BATCH_CONVERT_SIZE = 524286, r.local_do_attachBlobToDraft = function(e, t) {
        var i = this.account.getFirstFolderWithType("localdrafts");
        if (!i) return t("moot"), void 0;
        var r = this;
        this._accessFolderForMutation(i.id, !1, function(i, a) {
            function c(i) {
                return p = i.header, h = i.body, p && h ? (h.attaching = n.makeAttachmentPart({
                    name: e.attachmentDef.name,
                    type: f.type,
                    sizeEstimate: f.size,
                    file: []
                }), l(h), void 0) : (t("failure-give-up"), void 0);
            }
            function l(e) {
                h = e;
                var t = Math.min(f.size, m + r.BLOB_BASE64_BATCH_CONVERT_SIZE);
                console.log("attachBlobToDraft: fetching", m, "to", t, "of", f.size);
                var n = f.slice(m, t);
                m = t, s(n, d);
            }
            function d(e, n) {
                if (console.log("attachBlobToDraft: fetched"), e) return t("failure-give-up"), void 0;
                var i = m >= f.size, s = o.mimeStyleBase64Encode(n);
                h.attaching.file.push(new Blob([ s ], {
                    type: f.type
                }));
                var r;
                if (i) {
                    var c = h.attachments.length;
                    h.attachments.push(h.attaching), delete h.attaching, r = {
                        changeDetails: {
                            attachments: [ c ]
                        }
                    };
                } else r = null;
                console.log("attachBlobToDraft: flushing"), a.updateMessageBody(p, h, {
                    flushBecause: "blobs"
                }, r, i ? u : l), h = null;
            }
            function u() {
                console.log("attachBlobToDraft: blob fully attached"), t(null);
            }
            var p, h, f = e.attachmentDef.blob;
            console.log("attachBlobToDraft: retrieving message"), a.getMessage(e.existingNamer.suid, e.existingNamer.date, {}, c);
            var m = 0;
        }, null, "attachBlobToDraft");
    }, r.do_attachBlobToDraft = function(e, t) {
        t(null);
    }, r.check_attachBlobToDraft = function(e, t) {
        t(null, "moot");
    }, r.local_undo_attachBlobToDraft = function(e, t) {
        t(null);
    }, r.undo_attachBlobToDraft = function(e, t) {
        t(null);
    }, r.local_do_detachAttachmentFromDraft = function(e, t) {
        var n = this.account.getFirstFolderWithType("localdrafts");
        return n ? (this._accessFolderForMutation(n.id, !1, function(n, i) {
            function o(n) {
                return r = n.header, a = n.body, r && a ? (a.attachments.splice(e.attachmentIndex, 1), 
                console.log("detachAttachmentFromDraft: flushing"), i.updateMessageBody(r, a, {
                    flushBecause: "blobs"
                }, {
                    changeDetails: {
                        detachedAttachments: [ e.attachmentIndex ]
                    }
                }, s), void 0) : (t("failure-give-up"), void 0);
            }
            function s() {
                console.log("detachAttachmentFromDraft: blob fully detached"), t(null);
            }
            var r, a;
            console.log("detachAttachmentFromDraft: retrieving message"), i.getMessage(e.existingNamer.suid, e.existingNamer.date, {}, o);
        }, null, "detachAttachmentFromDraft"), void 0) : (t("moot"), void 0);
    }, r.do_detachAttachmentFromDraft = function(e, t) {
        t(null);
    }, r.check_detachAttachmentFromDraft = function(e, t) {
        t(null);
    }, r.local_undo_detachAttachmentFromDraft = function(e, t) {
        t(null);
    }, r.undo_detachAttachmentFromDraft = function(e, t) {
        t(null);
    }, r.local_do_saveDraft = function(e, t) {
        var n = this.account.getFirstFolderWithType("localdrafts");
        if (!n) return t("moot"), void 0;
        var o = this;
        this._accessFolderForMutation(n.id, !1, function(n, s) {
            function r(n) {
                function r() {
                    0 === --a && t(null, c, !0);
                }
                var c = i.mergeDraftStates(n.header, n.body, e.draftRep, e.newDraftInfo, o.account.universe);
                e.existingNamer && (a++, s.deleteMessageHeaderAndBody(e.existingNamer.suid, e.existingNamer.date, r)), 
                s.addMessageHeader(c.header, c.body, r), s.addMessageBody(c.header, c.body, r);
            }
            var a = 2;
            e.existingNamer ? s.getMessage(e.existingNamer.suid, e.existingNamer.date, null, r) : r({
                header: null,
                body: null
            });
        }, null, "saveDraft");
    }, r.do_saveDraft = function(e, t) {
        t(null);
    }, r.check_saveDraft = function(e, t) {
        t(null, "moot");
    }, r.local_undo_saveDraft = function(e, t) {
        t(null);
    }, r.undo_saveDraft = function(e, t) {
        t(null);
    }, r.local_do_deleteDraft = function(e, t) {
        var n = this.account.getFirstFolderWithType("localdrafts");
        return n ? (this._accessFolderForMutation(n.id, !1, function(n, i) {
            i.deleteMessageHeaderAndBody(e.messageNamer.suid, e.messageNamer.date, function() {
                t(null, null, !0);
            });
        }, null, "deleteDraft"), void 0) : (t("moot"), void 0);
    }, r.do_deleteDraft = function(e, t) {
        t(null);
    }, r.check_deleteDraft = function(e, t) {
        t(null, "moot");
    }, r.local_undo_deleteDraft = function(e, t) {
        t(null);
    }, r.undo_deleteDraft = function(e, t) {
        t(null);
    };
}), define("disaster-recovery", [ "require", "./slog" ], function(e) {
    var t = e("./slog"), n = new WeakMap(), i = new WeakMap(), o = {
        setCurrentAccountOp: function(e, t, n) {
            i.set(e, {
                op: t,
                callback: n
            });
        },
        clearCurrentAccountOp: function(e) {
            i.delete(e);
        },
        associateSocketWithAccount: function(e, t) {
            n.set(e, t);
        },
        catchSocketExceptions: function(e, t) {
            try {
                t();
            } catch (i) {
                var o = n.get(e);
                try {
                    e.close();
                } catch (s) {
                    console.error("Error attempting to close socket:", s);
                }
                this.handleDisastrousError(i, o);
            }
        },
        handleDisastrousError: function(e, n) {
            var o, s;
            if (n) {
                var r = i.get(n);
                r && (o = r.op, s = r.callback);
            }
            t.error("disaster-recovery:exception", {
                accountId: n && n.id,
                op: o,
                error: e,
                errorName: e && e.name,
                errorMessage: e && e.message,
                stack: e.stack
            }), console.error("*** Disastrous Error for email accountId", n && n.id, "-- attempting to recover..."), 
            n ? o ? (console.warn("Force-completing in-progress op:", o), s("disastrous-error"), 
            t.log("disaster-recovery:finished-job", {
                error: e
            })) : console.warn("No job operation was currently running.") : console.warn("No account associated with this error; nothing to abort.");
        }
    };
    return o;
}), define("accountmixins", [ "require", "exports", "module", "./disaster-recovery" ], function(e, t) {
    function n(e, t) {
        window.setZeroTimeout(function() {
            t(null, null);
        });
    }
    var i = e("./disaster-recovery");
    t.accountConstructorMixin = function(e) {
        e.outboxNeedsFreshSync = !0, e.outboxSyncEnabled = !0;
    }, t.runOp = function(e, t, o) {
        console.log("runOp(" + t + ": " + JSON.stringify(e).substring(0, 160) + ")");
        var s = t + "_" + e.type, r = this._jobDriver[s];
        r || (console.warn("Unsupported op:", e.type, "mode:", t), r = n);
        var a = !1, c = function(n, s, r) {
            return a ? (console.warn("Job already completed, ignoring secondary completion:", t, JSON.stringify(e).substring(0, 160), n, s), 
            void 0) : (a = !0, i.clearCurrentAccountOp(this), this._jobDriver.postJobCleanup(n), 
            window.setZeroTimeout(function() {
                o(n, s, r);
            }), void 0);
        }.bind(this);
        i.setCurrentAccountOp(this, e, c), this._LOG.runOp_begin(t, e.type, null, e);
        try {
            r.call(this._jobDriver, e, c);
        } catch (l) {
            i.clearCurrentAccountOp(this), this._LOG.opError(t, e.type, l);
        }
    }, t.getFirstFolderWithType = function(e) {
        for (var t = this.folders, n = 0; n < t.length; n++) if (t[n].type === e) return t[n];
        return null;
    }, t.getFolderByPath = function(e) {
        for (var t = this.folders, n = 0; n < t.length; n++) if (t[n].path === e) return t[n];
        return null;
    }, t.normalizeFolderHierarchy = function() {
        var e = this.getFirstFolderWithType("drafts") || this.getFirstFolderWithType("sent");
        if (e) {
            var t = this.getFolderMetaForFolderId(e.parentId), n = [ this.getFirstFolderWithType("localdrafts"), this.getFirstFolderWithType("outbox") ];
            n.forEach(function(n) {
                n && n.parentId !== e.parentId && (console.log("Moving folder", n.name, "underneath", t && t.name || "(root)"), 
                this.universe.__notifyRemovedFolder(this, n), t ? (n.path = t.path + (t.delim || "/") + n.name, 
                n.delim = t.delim || "/", n.parentId = t.id, n.depth = t.depth + 1) : (n.path = n.name, 
                n.delim = "/", n.parentId = null, n.depth = 0), this.universe.__notifyAddedFolder(this, n));
            }, this);
        }
    }, t.saveAccountState = function(e, t, n) {
        if (!this._alive) return this._LOG.accountDeleted("saveAccountState"), null;
        this._LOG.saveAccountState_begin(n, null), this._saveAccountStateActive = !0, this._deferredSaveAccountCalls || (this._deferredSaveAccountCalls = []), 
        t && this.runAfterSaves(t);
        for (var i = [], o = 0; o < this.folders.length; o++) {
            var s = this.folders[o], r = this._folderStorages[s.id], a = r.generatePersistenceInfo();
            a && i.push(a);
        }
        var c = i.length, l = this._db.saveAccountFolderStates(this.id, this._folderInfos, i, this._deadFolderIds, function() {
            this._saveAccountStateActive = !1, this._LOG.saveAccountState_end(n, c);
            var e = this._deferredSaveAccountCalls;
            this._deferredSaveAccountCalls = [], e.forEach(function(e) {
                e();
            });
        }.bind(this), e);
        return i = null, this._deadFolderIds = null, l;
    }, t.runAfterSaves = function(e) {
        this._saveAccountStateActive || this._saveAccountIsImminent ? this._deferredSaveAccountCalls.push(e) : e();
    }, t.upgradeFolderStoragesIfNeeded = function() {
        for (var e in this._folderStorages) {
            var t = this._folderStorages[e];
            t.upgradeIfNeeded();
        }
    };
}), define("quotechew", [ "exports" ], function(e) {
    function t(e, t, n, i) {
        var o = e.indexOf(t, n);
        return -1 === o ? i : o;
    }
    function n(e, t, n) {
        for (var i = t - 1, o = 0; ;) {
            if (i = e.indexOf(A, i + 1), -1 === i || i >= n) return o;
            o++;
        }
        return null;
    }
    function i(e, t) {
        return e.charCodeAt(0) === v ? M[t] : O[t];
    }
    function o(e, t) {
        var n = D[t], i = N[t];
        return e.replace(E, function(t, o) {
            return e.charCodeAt(o + 1) === v ? i : n;
        });
    }
    var s = 1, r = 2, a = 3, c = 4, l = 20, d = 5, u = 6, p = 7, h = 8, f = ">".charCodeAt(0), m = " ".charCodeAt(0), g = " ".charCodeAt(0), v = "\n".charCodeAt(0), _ = /^[_-]{6,}$/, y = /mailing list$/, b = /wrote/, x = /^-- $/, S = 20, w = /^(?:Sent from (?:Mobile|my .+))$/, T = /^(?:This message|Este mensaje)/, A = "\n", E = /\n/g;
    e.quoteProcessTextBody = function(e) {
        function i() {
            for (var e = 1, t = 1, n = !0, i = 1; i < A.length; i++) {
                var o = A.charCodeAt(i);
                if (o === f) e++, t++, n = !0; else {
                    if (o !== m) break;
                    if (!n) break;
                    t++, n = !1;
                }
            }
            return t && (A = A.substring(t)), e;
        }
        function o(e) {
            function t(t, o) {
                for (var s = e.substring(i, a), r = i - 1; e.charCodeAt(r - 1) === v; ) r--;
                var d = e.substring(0, r), u = n(e, d.length, i - 1);
                e = d, a = e.length, o ? (I[b] = (255 & u) << 8 | 255 & I[b], I[b + 1] = s + "\n" + I[b + 1]) : I.splice(b, 0, (255 & u) << 8 | t, s), 
                l = !1, c = S, h = null, f = i;
            }
            var i, o, s, a = e.length, c = S, l = !1, h = null, f = null, m = !1, b = I.length;
            for (i = e.lastIndexOf("\n") + 1, o = e.length; o > 0 && c; o = i - 1, i = e.lastIndexOf("\n", o - 1) + 1, 
            c--) if (s = e.substring(i, o), s.length && (1 !== s.length || s.charCodeAt(0) !== g)) if (x.test(s)) o + 1 === f ? t(null, !0) : t(r); else {
                if (_.test(s)) {
                    if (h) {
                        if (T.test(h)) {
                            t(d);
                            continue;
                        }
                        if (y.test(h)) {
                            t(u);
                            continue;
                        }
                    }
                    return e;
                }
                if (!l) {
                    if (!m && w.test(s)) {
                        t(p), m = !0;
                        continue;
                    }
                    l = !0;
                }
                h = s;
            }
            return e;
        }
        function c(t, i, r) {
            if (null === O) F && (I.length && F--, I.push((255 & F) << 8 | s), I.push("")); else {
                void 0 === i && (i = E);
                var a = e.substring(O, D), c = r ? 1 : 0;
                D + 1 !== i && (c += n(e, D + 1, i)), I.push((255 & F) << 8 | (255 & c) << 16 | s);
                var l = I.push(a) - 1;
                if (t) {
                    var d = o(a);
                    if (a.length !== d.length) {
                        if (c) {
                            var u = I.length - 2;
                            I[u] = (255 & c) << 16 | I[u], I[l - 1] = (255 & F) << 8 | s;
                        }
                        if (d.length) I[l] = d; else {
                            if (F) {
                                var p = 255 & I[l + 1] >> 8;
                                p += F, I[l + 1] = (255 & p) << 8 | 4294902015 & I[l + 1];
                            }
                            I.splice(l - 1, 2);
                        }
                    }
                }
            }
            F = 0, O = null, M = null, D = null, N = null;
        }
        function h(e) {
            for (var t = 0; R.length && !R[R.length - 1]; ) R.pop(), t++;
            I.push((255 & t) << 24 | (255 & P) << 16 | L - 1 << 8 | l), I.push(R.join("\n")), 
            L = e, R = L ? [] : null, P = 0, B = !0;
        }
        var A, E, k, I = [], C = e.length, O = null, M = null, D = null, N = null, L = 0, R = null, B = !1, F = 0, P = 0;
        for (E = 0, k = t(e, "\n", E, e.length); C > E; E = k + 1, k = t(e, "\n", E, e.length)) if (A = e.substring(E, k), 
        !A.length || 1 === A.length && A.charCodeAt(0) === g) L && h(0), null === O && F++; else if (A.charCodeAt(0) === f) {
            var U = i();
            if (L) U !== L && h(U); else {
                if (M && b.test(M)) {
                    var H = D;
                    D = N, null === D && (O = null);
                    var q = M;
                    c(!B, H);
                    var j = 0;
                    H + 1 !== E && (j = n(e, H + 1, E)), I.push(j << 8 | a), I.push(q);
                } else c(!B);
                R = [], L = U;
            }
            R.length || A.length ? R.push(A) : P++;
        } else L && (h(0), D = null), null === O && (O = E), M = A, N = D, D = k;
        return L ? h(0) : c(!0, e.length, e.charCodeAt(e.length - 1) === v), I;
    };
    var k = 8, I = /\s+/g;
    e.generateSnippet = function(e, t) {
        for (var n = 0; n < e.length; n += 2) {
            var i = 15 & e[n], o = e[n + 1];
            switch (i) {
              case s:
                if (!o.length) break;
                if (o.length < t) return o.trim().replace(I, " ");
                var r = o.lastIndexOf(" ", t);
                return k > t - r ? o.substring(0, r).trim().replace(I, " ") : o.substring(0, t).trim().replace(I, " ");
            }
        }
        return "";
    };
    var C = 5, O = [ "> ", ">> ", ">>> ", ">>>> ", ">>>>> ", ">>>>>> ", ">>>>>>> ", ">>>>>>>> ", ">>>>>>>>> " ], M = [ ">", ">>", ">>>", ">>>>", ">>>>>", ">>>>>>", ">>>>>>>", ">>>>>>>>", ">>>>>>>>>" ], D = [ "\n> ", "\n>> ", "\n>>> ", "\n>>>> ", "\n>>>>> ", "\n>>>>>> ", "\n>>>>>>> ", "\n>>>>>>>> " ], N = [ "\n>", "\n>>", "\n>>>", "\n>>>>", "\n>>>>>", "\n>>>>>>", "\n>>>>>>>", "\n>>>>>>>>" ];
    e.generateReplyText = function(e) {
        for (var t = [], n = 0; n < e.length; n += 2) {
            var l = 15 & e[n], f = e[n + 1];
            switch (l) {
              case s:
              case r:
              case a:
                t.push(i(f, 0)), t.push(o(f, 0));
                break;

              case c:
                var m = (255 & e[n] >> 8) + 1;
                C > m && (t.push(i(f, m)), t.push(o(f, m)));
                break;

              case d:
              case u:
              case p:
              case h:            }
        }
        return t.join("");
    }, e.generateForwardBodyText = function(e) {
        for (var t, n = [], l = 0; l < e.length; l += 2) {
            l && n.push(A);
            var f = 15 & e[l], m = e[l + 1];
            switch (f) {
              case s:
                for (t = 255 & e[l] >> 8; t; t--) n.push(A);
                for (n.push(m), t = 255 & e[l] >> 16; t; t--) n.push(A);
                break;

              case a:
                for (n.push(m), t = 255 & e[l] >> 8; t; t--) n.push(A);
                break;

              case r:
              case d:
              case u:
              case p:
              case h:
                for (t = 255 & e[l] >> 8; t; t--) n.push(A);
                for (n.push(m), t = 255 & e[l] >> 16; t; t--) n.push(A);
                break;

              case c:
                var g = Math.min(255 & e[l] >> 8, 8);
                for (t = 255 & e[l] >> 16; t; t--) n.push(M[g]), n.push(A);
                for (n.push(i(m, g)), n.push(o(m, g)), t = 255 & e[l] >> 24; t; t--) n.push(A), 
                n.push(M[g]);
            }
        }
        return n.join("");
    };
}), define("mailchew", [ "exports", "./util", "./mailchew-strings", "./quotechew", "./htmlchew" ], function(e, t, n, i, o) {
    var s = 100;
    e.generateBaseComposeBody = function(e) {
        if (e.signatureEnabled && e.signature && e.signature.length > 0) {
            var t = "\n\n--\n" + e.signature;
            return t;
        }
        return "";
    };
    var r = /^[Rr][Ee]:/;
    e.generateReplySubject = function(e) {
        var t = "Re: ";
        return e ? r.test(e) ? e : t + e : t;
    };
    var a = /^[Ff][Ww][Dd]:/;
    e.generateForwardSubject = function(e) {
        var t = "Fwd: ";
        return e ? a.test(e) ? e : t + e : t;
    };
    var c = "{name} wrote", l = "Original Message", d = {
        subject: "Subject",
        date: "Date",
        from: "From",
        replyTo: "Reply-To",
        to: "To",
        cc: "CC"
    };
    e.setLocalizedStrings = function(e) {
        c = e.wrote, l = e.originalMessage, d = e.forwardHeaderLabels;
    }, n.strings && e.setLocalizedStrings(n.strings), n.events.on("strings", function(t) {
        e.setLocalizedStrings(t);
    }), e.generateReplyBody = function(e, t, n, s, r) {
        for (var a = t.name ? t.name.trim() : t.address, l = "\n\n" + c.replace("{name}", a) + ":\n", d = null, u = 0; u < e.length; u++) {
            var p = e[u].type, h = e[u].content;
            if ("plain" === p) {
                var f = i.generateReplyText(h);
                d ? d += o.wrapTextIntoSafeHTMLString(f) + "\n" : l += f;
            } else "html" === p && (d || (d = "", "\n" === l.slice(-1) && (l = l.slice(0, -1))), 
            d += "<blockquote ", r && (d += 'cite="mid:' + o.escapeAttrValue(r) + '" '), d += 'type="cite">' + h + "</blockquote>");
        }
        return s.signature && s.signatureEnabled && (d ? d += o.wrapTextIntoSafeHTMLString(s.signature, "pre", !1, [ "class", "moz-signature", "cols", "72" ]) : l += "\n\n-- \n" + s.signature), 
        {
            text: l,
            html: d
        };
    }, e.generateForwardMessage = function(e, n, s, r, a, c) {
        var u = "\n\n", p = null;
        c.signature && c.signatureEnabled && (u += "-- \n" + c.signature + "\n\n"), u += "-------- " + l + " --------\n", 
        u += d.subject + ": " + s + "\n", u += d.date + ": " + new Date(n) + "\n", u += d.from + ": " + t.formatAddresses([ e ]) + "\n", 
        r.replyTo && (u += d.replyTo + ": " + t.formatAddresses([ r.replyTo ]) + "\n"), 
        r.to && (u += d.to + ": " + t.formatAddresses(r.to) + "\n"), r.cc && (u += d.cc + ": " + t.formatAddresses(r.cc) + "\n"), 
        u += "\n";
        for (var h = a.bodyReps, f = 0; f < h.length; f++) {
            var m = h[f].type, g = h[f].content;
            if ("plain" === m) {
                var v = i.generateForwardBodyText(g);
                p ? p += o.wrapTextIntoSafeHTMLString(v) + "\n" : u += v;
            } else "html" === m && (p || (p = "", "\n" === u.slice(-1) && (u = u.slice(0, -1))), 
            p += g);
        }
        return {
            text: u,
            html: p
        };
    };
    var u = '<html><body><body bgcolor="#FFFFFF" text="#000000">', p = "</body></html>";
    e.mergeUserTextWithHTML = function(e, t) {
        return u + o.wrapTextIntoSafeHTMLString(e, "div") + t + p;
    }, e.processMessageContent = function(e, t, n, r, a) {
        "\n" === e.slice(-1) && (e = e.slice(0, -1));
        var c, l;
        switch (t) {
          case "plain":
            try {
                c = i.quoteProcessTextBody(e);
            } catch (d) {
                a.textChewError(d), c = [];
            }
            if (r) try {
                l = i.generateSnippet(c, s);
            } catch (d) {
                a.textSnippetError(d), l = "";
            }
            break;

          case "html":
            if (r) try {
                l = o.generateSnippet(e);
            } catch (d) {
                a.htmlSnippetError(d), l = "";
            }
            if (n) try {
                c = o.sanitizeAndNormalizeHtml(e);
            } catch (d) {
                a.htmlParseError(d), c = "";
            }
        }
        return {
            content: c,
            snippet: l
        };
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("addressparser", t) : "object" == typeof exports ? module.exports = t() : e.addressparser = t();
}(this, function() {
    var e = {};
    return e.parse = function(t) {
        var n = new e.Tokenizer(t), i = n.tokenize(), o = [], s = [], r = [];
        return i.forEach(function(e) {
            "operator" !== e.type || "," !== e.value && ";" !== e.value ? s.push(e) : (s.length && o.push(s), 
            s = []);
        }), s.length && o.push(s), o.forEach(function(t) {
            t = e._handleAddress(t), t.length && (r = r.concat(t));
        }), r;
    }, e._handleAddress = function(t) {
        var n, i, o, s, r = !1, a = "text", c = [], l = {
            address: [],
            comment: [],
            group: [],
            text: []
        };
        for (o = 0, s = t.length; s > o; o++) if (n = t[o], "operator" === n.type) switch (n.value) {
          case "<":
            a = "address";
            break;

          case "(":
            a = "comment";
            break;

          case ":":
            a = "group", r = !0;
            break;

          default:
            a = "text";
        } else n.value && l[a].push(n.value);
        if (!l.text.length && l.comment.length && (l.text = l.comment, l.comment = []), 
        r) l.text = l.text.join(" "), c.push({
            name: l.text || i && i.name,
            group: l.group.length ? e.parse(l.group.join(",")) : []
        }); else {
            if (!l.address.length && l.text.length) {
                for (o = l.text.length - 1; o >= 0; o--) if (l.text[o].match(/^[^@\s]+@[^@\s]+$/)) {
                    l.address = l.text.splice(o, 1);
                    break;
                }
                var d = function(e) {
                    return l.address.length ? e : (l.address = [ e.trim() ], " ");
                };
                if (!l.address.length) for (o = l.text.length - 1; o >= 0 && (l.text[o] = l.text[o].replace(/\s*\b[^@\s]+@[^@\s]+\b\s*/, d).trim(), 
                !l.address.length); o--) ;
            }
            if (!l.text.length && l.comment.length && (l.text = l.comment, l.comment = []), 
            l.address.length > 1 && (l.text = l.text.concat(l.address.splice(1))), l.text = l.text.join(" "), 
            l.address = l.address.join(" "), !l.address && r) return [];
            i = {
                address: l.address || l.text || "",
                name: l.text || l.address || ""
            }, i.address === i.name && ((i.address || "").match(/@/) ? i.name = "" : i.address = ""), 
            c.push(i);
        }
        return c;
    }, e.Tokenizer = function(e) {
        this.str = (e || "").toString(), this.operatorCurrent = "", this.operatorExpecting = "", 
        this.node = null, this.escaped = !1, this.list = [];
    }, e.Tokenizer.prototype.operators = {
        '"': '"',
        "(": ")",
        "<": ">",
        ",": "",
        ":": ";"
    }, e.Tokenizer.prototype.tokenize = function() {
        for (var e, t = [], n = 0, i = this.str.length; i > n; n++) e = this.str.charAt(n), 
        this.checkChar(e);
        return this.list.forEach(function(e) {
            e.value = (e.value || "").toString().trim(), e.value && t.push(e);
        }), t;
    }, e.Tokenizer.prototype.checkChar = function(e) {
        if ((e in this.operators || "\\" === e) && this.escaped) this.escaped = !1; else {
            if (this.operatorExpecting && e === this.operatorExpecting) return this.node = {
                type: "operator",
                value: e
            }, this.list.push(this.node), this.node = null, this.operatorExpecting = "", this.escaped = !1, 
            void 0;
            if (!this.operatorExpecting && e in this.operators) return this.node = {
                type: "operator",
                value: e
            }, this.list.push(this.node), this.node = null, this.operatorExpecting = this.operators[e], 
            this.escaped = !1, void 0;
        }
        return this.escaped || "\\" !== e ? (this.node || (this.node = {
            type: "text",
            value: ""
        }, this.list.push(this.node)), this.escaped && "\\" !== e && (this.node.value += "\\"), 
        this.node.value += e, this.escaped = !1, void 0) : (this.escaped = !0, void 0);
    }, e;
}), define("tcp-socket", [ "require", "exports", "module", "worker-router", "disaster-recovery" ], function(e) {
    function t(e, t, n) {
        n = n || {}, n.binaryType = "arraybuffer", this.host = e, this.port = t, this.ssl = !!n.useSecureTransport, 
        this.binaryType = n.binaryType, this.bufferedAmount = 0, this.readyState = "connecting";
        var s = i.register(function(e) {
            var t = e.cmd, n = this["_" + t], i = this[t];
            n && n.call(this, e.args), o.catchSocketExceptions(this, function() {
                i && i.call(this, {
                    data: e.args
                });
            });
        }.bind(this));
        this._sendMessage = s.sendMessage, this._unregisterWithRouter = s.unregister, this._sendMessage("open", [ e, t, n ]);
    }
    var n = e("worker-router"), i = n.registerInstanceType("netsocket"), o = e("disaster-recovery");
    return t.prototype = {
        _onopen: function() {
            this.readyState = "open";
        },
        _onclose: function() {
            this._unregisterWithRouter(), this.readyState = "closed";
        },
        upgradeToSecure: function() {
            this._sendMessage("upgradeToSecure", []);
        },
        suspend: function() {
            throw new Error("tcp-socket.js does not support suspend().");
        },
        resume: function() {
            throw new Error("tcp-socket.js does not support resume().");
        },
        close: function() {
            "closed" !== this.readyState && this._sendMessage("close");
        },
        send: function(e) {
            if (e instanceof Blob) this._sendMessage("write", [ e ]); else if (e instanceof ArrayBuffer) this._sendMessage("write", [ e, 0, e.byteLength ]); else if (0 !== e.byteOffset || e.length !== e.buffer.byteLength) {
                var t = e.buffer.slice(e.byteOffset, e.byteOffset + e.length);
                this._sendMessage("write", [ t, 0, t.byteLength ], [ t ]);
            } else this._sendMessage("write", [ e.buffer, e.byteOffset, e.length ]);
            return !0;
        }
    }, {
        open: function(e, n, i) {
            return new t(e, n, i);
        }
    };
}), define("mix", [], function() {
    return function(e, t, n) {
        return Object.keys(t).forEach(function(i) {
            (!e.hasOwnProperty(i) || n) && (e[i] = t[i]);
        }), e;
    };
}), define("axe-logger", [], function() {
    return {
        debug: function() {},
        log: function() {},
        warn: console.warn.bind(console),
        error: console.error.bind(console)
    };
}), define("axe", [ "axe-logger" ], function(e) {
    return e;
}), define("errorutils", [ "exports" ], function(e) {
    var t = {
        offline: {
            reachable: !1,
            retry: !0,
            report: !1
        },
        "server-maintenance": {
            reachable: !0,
            retry: !0,
            report: !1
        },
        "unresponsive-server": {
            reachable: !1,
            retry: !0,
            report: !1
        },
        "port-not-listening": {
            reachable: !1,
            retry: !0,
            report: !1
        },
        "bad-user-or-pass": {
            reachable: !0,
            retry: !1,
            report: !0
        },
        "needs-oauth-reauth": {
            reachable: !0,
            retry: !1,
            report: !0
        },
        "imap-disabled": {
            reachable: !0,
            retry: !1,
            report: !0
        },
        "pop3-disabled": {
            reachable: !0,
            retry: !1,
            report: !0
        },
        "not-authorized": {
            reachable: !0,
            retry: !1,
            report: !0
        },
        "bad-security": {
            reachable: !0,
            retry: !1,
            report: !0
        },
        "no-config-info": {
            reachable: !1,
            retry: !1,
            report: !1
        },
        "user-account-exists": {
            reachable: !1,
            retry: !1,
            report: !1
        },
        "pop-server-not-great": {
            reachable: !0,
            retry: !1,
            report: !1
        },
        "no-dns-entry": {
            reachable: !1,
            retry: !1,
            report: !1
        },
        "bad-address": {
            reachable: !0,
            retry: !1,
            report: !1
        },
        "server-problem": {
            reachable: !0,
            retry: !1,
            report: !1
        },
        unknown: {
            reachable: !1,
            retry: !1,
            report: !1
        }
    };
    e.shouldReportProblem = function(e) {
        return (t[e] || t.unknown).report;
    }, e.shouldRetry = function(e) {
        return (t[e] || t.unknown).retry;
    }, e.wasErrorFromReachableState = function(e) {
        return (t[e] || t.unknown).reachable;
    }, e.analyzeException = function(e) {
        if ("Connection refused" === e) e = {
            name: "ConnectionRefusedError"
        }; else if ("string" == typeof e) return e;
        return e.name ? /^Security/.test(e.name) ? "bad-security" : /^ConnectionRefused/i.test(e.name) ? "unresponsive-server" : null : null;
    };
}), define("db/folder_info_rep", [ "require" ], function() {
    function e(e) {
        return {
            id: e.id || null,
            serverId: e.serverId || null,
            name: e.name || null,
            type: e.type || null,
            path: e.path || null,
            parentId: e.parentId || null,
            depth: e.depth || 0,
            lastSyncedAt: e.lastSyncedAt || 0,
            unreadCount: e.unreadCount || 0,
            syncKey: e.syncKey || null,
            version: e.version || null
        };
    }
    return {
        makeFolderMeta: e
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("mimetypes", t) : "object" == typeof exports ? module.exports = t() : e.mimetypes = t();
}(this, function() {
    function e(e) {
        if (e = (e || "").toString().toLowerCase().replace(/\s/g, ""), !(e in n)) return "bin";
        if ("string" == typeof n[e]) return n[e];
        for (var t = e.split("/"), i = 0, o = n[e].length; o > i; i++) if (t[1] === n[e][i]) return n[e][i];
        return n[e][0];
    }
    function t(e) {
        if (e = (e || "").toString().toLowerCase().replace(/\s/g, "").replace(/^\./g, ""), 
        !(e in i)) return "application/octet-stream";
        if ("string" == typeof i[e]) return i[e];
        for (var t, n = 0, o = i[e].length; o > n; n++) if (t = i[e][n].split("/"), t[1] === e) return i[e][n];
        return i[e][0];
    }
    var n = {
        "application/acad": "dwg",
        "application/andrew-inset": "",
        "application/applixware": "aw",
        "application/arj": "arj",
        "application/atom+xml": "xml",
        "application/atomcat+xml": "atomcat",
        "application/atomsvc+xml": "atomsvc",
        "application/base64": [ "mm", "mme" ],
        "application/binhex": "hqx",
        "application/binhex4": "hqx",
        "application/book": [ "boo", "book" ],
        "application/ccxml+xml,": "ccxml",
        "application/cdf": "cdf",
        "application/cdmi-capability": "cdmia",
        "application/cdmi-container": "cdmic",
        "application/cdmi-domain": "cdmid",
        "application/cdmi-object": "cdmio",
        "application/cdmi-queue": "cdmiq",
        "application/clariscad": "ccad",
        "application/commonground": "dp",
        "application/cu-seeme": "cu",
        "application/davmount+xml": "davmount",
        "application/drafting": "drw",
        "application/dsptype": "tsp",
        "application/dssc+der": "dssc",
        "application/dssc+xml": "xdssc",
        "application/dxf": "dxf",
        "application/ecmascript": [ "js", "es" ],
        "application/emma+xml": "emma",
        "application/envoy": "evy",
        "application/epub+zip": "epub",
        "application/excel": [ "xl", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xls", "xlt", "xlv", "xlw" ],
        "application/exi": "exi",
        "application/font-tdpfr": "pfr",
        "application/fractals": "fif",
        "application/freeloader": "frl",
        "application/futuresplash": "spl",
        "application/gnutar": "tgz",
        "application/groupwise": "vew",
        "application/hlp": "hlp",
        "application/hta": "hta",
        "application/hyperstudio": "stk",
        "application/i-deas": "unv",
        "application/iges": [ "iges", "igs" ],
        "application/inf": "inf",
        "application/internet-property-stream": "acx",
        "application/ipfix": "ipfix",
        "application/java": "class",
        "application/java-archive": "jar",
        "application/java-byte-code": "class",
        "application/java-serialized-object": "ser",
        "application/java-vm": "class",
        "application/javascript": "js",
        "application/json": "json",
        "application/lha": "lha",
        "application/lzx": "lzx",
        "application/mac-binary": "bin",
        "application/mac-binhex": "hqx",
        "application/mac-binhex40": "hqx",
        "application/mac-compactpro": "cpt",
        "application/macbinary": "bin",
        "application/mads+xml": "mads",
        "application/marc": "mrc",
        "application/marcxml+xml": "mrcx",
        "application/mathematica": "ma",
        "application/mathml+xml": "mathml",
        "application/mbedlet": "mbd",
        "application/mbox": "mbox",
        "application/mcad": "mcd",
        "application/mediaservercontrol+xml": "mscml",
        "application/metalink4+xml": "meta4",
        "application/mets+xml": "mets",
        "application/mime": "aps",
        "application/mods+xml": "mods",
        "application/mp21": "m21",
        "application/mp4": "mp4",
        "application/mspowerpoint": [ "pot", "pps", "ppt", "ppz" ],
        "application/msword": [ "doc", "dot", "w6w", "wiz", "word" ],
        "application/mswrite": "wri",
        "application/mxf": "mxf",
        "application/netmc": "mcp",
        "application/octet-stream": [ "*" ],
        "application/oda": "oda",
        "application/oebps-package+xml": "opf",
        "application/ogg": "ogx",
        "application/olescript": "axs",
        "application/onenote": "onetoc",
        "application/patch-ops-error+xml": "xer",
        "application/pdf": "pdf",
        "application/pgp-encrypted": "",
        "application/pgp-signature": "pgp",
        "application/pics-rules": "prf",
        "application/pkcs-12": "p12",
        "application/pkcs-crl": "crl",
        "application/pkcs10": "p10",
        "application/pkcs7-mime": [ "p7c", "p7m" ],
        "application/pkcs7-signature": "p7s",
        "application/pkcs8": "p8",
        "application/pkix-attr-cert": "ac",
        "application/pkix-cert": [ "cer", "crt" ],
        "application/pkix-crl": "crl",
        "application/pkix-pkipath": "pkipath",
        "application/pkixcmp": "pki",
        "application/plain": "text",
        "application/pls+xml": "pls",
        "application/postscript": [ "ai", "eps", "ps" ],
        "application/powerpoint": "ppt",
        "application/pro_eng": [ "part", "prt" ],
        "application/prs.cww": "cww",
        "application/pskc+xml": "pskcxml",
        "application/rdf+xml": "rdf",
        "application/reginfo+xml": "rif",
        "application/relax-ng-compact-syntax": "rnc",
        "application/resource-lists+xml": "rl",
        "application/resource-lists-diff+xml": "rld",
        "application/ringing-tones": "rng",
        "application/rls-services+xml": "rs",
        "application/rsd+xml": "rsd",
        "application/rss+xml": "xml",
        "application/rtf": [ "rtf", "rtx" ],
        "application/sbml+xml": "sbml",
        "application/scvp-cv-request": "scq",
        "application/scvp-cv-response": "scs",
        "application/scvp-vp-request": "spq",
        "application/scvp-vp-response": "spp",
        "application/sdp": "sdp",
        "application/sea": "sea",
        "application/set": "set",
        "application/set-payment-initiation": "setpay",
        "application/set-registration-initiation": "setreg",
        "application/shf+xml": "shf",
        "application/sla": "stl",
        "application/smil": [ "smi", "smil" ],
        "application/smil+xml": "smi",
        "application/solids": "sol",
        "application/sounder": "sdr",
        "application/sparql-query": "rq",
        "application/sparql-results+xml": "srx",
        "application/srgs": "gram",
        "application/srgs+xml": "grxml",
        "application/sru+xml": "sru",
        "application/ssml+xml": "ssml",
        "application/step": [ "step", "stp" ],
        "application/streamingmedia": "ssm",
        "application/tei+xml": "tei",
        "application/thraud+xml": "tfi",
        "application/timestamped-data": "tsd",
        "application/toolbook": "tbk",
        "application/vda": "vda",
        "application/vnd.3gpp.pic-bw-large": "plb",
        "application/vnd.3gpp.pic-bw-small": "psb",
        "application/vnd.3gpp.pic-bw-var": "pvb",
        "application/vnd.3gpp2.tcap": "tcap",
        "application/vnd.3m.post-it-notes": "pwn",
        "application/vnd.accpac.simply.aso": "aso",
        "application/vnd.accpac.simply.imp": "imp",
        "application/vnd.acucobol": "acu",
        "application/vnd.acucorp": "atc",
        "application/vnd.adobe.air-application-installer-package+zip": "air",
        "application/vnd.adobe.fxp": "fxp",
        "application/vnd.adobe.xdp+xml": "xdp",
        "application/vnd.adobe.xfdf": "xfdf",
        "application/vnd.ahead.space": "ahead",
        "application/vnd.airzip.filesecure.azf": "azf",
        "application/vnd.airzip.filesecure.azs": "azs",
        "application/vnd.amazon.ebook": "azw",
        "application/vnd.americandynamics.acc": "acc",
        "application/vnd.amiga.ami": "ami",
        "application/vnd.android.package-archive": "apk",
        "application/vnd.anser-web-certificate-issue-initiation": "cii",
        "application/vnd.anser-web-funds-transfer-initiation": "fti",
        "application/vnd.antix.game-component": "atx",
        "application/vnd.apple.installer+xml": "mpkg",
        "application/vnd.apple.mpegurl": "m3u8",
        "application/vnd.aristanetworks.swi": "swi",
        "application/vnd.audiograph": "aep",
        "application/vnd.blueice.multipass": "mpm",
        "application/vnd.bmi": "bmi",
        "application/vnd.businessobjects": "rep",
        "application/vnd.chemdraw+xml": "cdxml",
        "application/vnd.chipnuts.karaoke-mmd": "mmd",
        "application/vnd.cinderella": "cdy",
        "application/vnd.claymore": "cla",
        "application/vnd.cloanto.rp9": "rp9",
        "application/vnd.clonk.c4group": "c4g",
        "application/vnd.cluetrust.cartomobile-config": "c11amc",
        "application/vnd.cluetrust.cartomobile-config-pkg": "c11amz",
        "application/vnd.commonspace": "csp",
        "application/vnd.contact.cmsg": "cdbcmsg",
        "application/vnd.cosmocaller": "cmc",
        "application/vnd.crick.clicker": "clkx",
        "application/vnd.crick.clicker.keyboard": "clkk",
        "application/vnd.crick.clicker.palette": "clkp",
        "application/vnd.crick.clicker.template": "clkt",
        "application/vnd.crick.clicker.wordbank": "clkw",
        "application/vnd.criticaltools.wbs+xml": "wbs",
        "application/vnd.ctc-posml": "pml",
        "application/vnd.cups-ppd": "ppd",
        "application/vnd.curl.car": "car",
        "application/vnd.curl.pcurl": "pcurl",
        "application/vnd.data-vision.rdz": "rdz",
        "application/vnd.denovo.fcselayout-link": "fe_launch",
        "application/vnd.dna": "dna",
        "application/vnd.dolby.mlp": "mlp",
        "application/vnd.dpgraph": "dpg",
        "application/vnd.dreamfactory": "dfac",
        "application/vnd.dvb.ait": "ait",
        "application/vnd.dvb.service": "svc",
        "application/vnd.dynageo": "geo",
        "application/vnd.ecowin.chart": "mag",
        "application/vnd.enliven": "nml",
        "application/vnd.epson.esf": "esf",
        "application/vnd.epson.msf": "msf",
        "application/vnd.epson.quickanime": "qam",
        "application/vnd.epson.salt": "slt",
        "application/vnd.epson.ssf": "ssf",
        "application/vnd.eszigno3+xml": "es3",
        "application/vnd.ezpix-album": "ez2",
        "application/vnd.ezpix-package": "ez3",
        "application/vnd.fdf": "fdf",
        "application/vnd.fdsn.seed": "seed",
        "application/vnd.flographit": "gph",
        "application/vnd.fluxtime.clip": "ftc",
        "application/vnd.framemaker": "fm",
        "application/vnd.frogans.fnc": "fnc",
        "application/vnd.frogans.ltf": "ltf",
        "application/vnd.fsc.weblaunch": "fsc",
        "application/vnd.fujitsu.oasys": "oas",
        "application/vnd.fujitsu.oasys2": "oa2",
        "application/vnd.fujitsu.oasys3": "oa3",
        "application/vnd.fujitsu.oasysgp": "fg5",
        "application/vnd.fujitsu.oasysprs": "bh2",
        "application/vnd.fujixerox.ddd": "ddd",
        "application/vnd.fujixerox.docuworks": "xdw",
        "application/vnd.fujixerox.docuworks.binder": "xbd",
        "application/vnd.fuzzysheet": "fzs",
        "application/vnd.genomatix.tuxedo": "txd",
        "application/vnd.geogebra.file": "ggb",
        "application/vnd.geogebra.tool": "ggt",
        "application/vnd.geometry-explorer": "gex",
        "application/vnd.geonext": "gxt",
        "application/vnd.geoplan": "g2w",
        "application/vnd.geospace": "g3w",
        "application/vnd.gmx": "gmx",
        "application/vnd.google-earth.kml+xml": "kml",
        "application/vnd.google-earth.kmz": "kmz",
        "application/vnd.grafeq": "gqf",
        "application/vnd.groove-account": "gac",
        "application/vnd.groove-help": "ghf",
        "application/vnd.groove-identity-message": "gim",
        "application/vnd.groove-injector": "grv",
        "application/vnd.groove-tool-message": "gtm",
        "application/vnd.groove-tool-template": "tpl",
        "application/vnd.groove-vcard": "vcg",
        "application/vnd.hal+xml": "hal",
        "application/vnd.handheld-entertainment+xml": "zmm",
        "application/vnd.hbci": "hbci",
        "application/vnd.hhe.lesson-player": "les",
        "application/vnd.hp-hpgl": [ "hgl", "hpg", "hpgl" ],
        "application/vnd.hp-hpid": "hpid",
        "application/vnd.hp-hps": "hps",
        "application/vnd.hp-jlyt": "jlt",
        "application/vnd.hp-pcl": "pcl",
        "application/vnd.hp-pclxl": "pclxl",
        "application/vnd.hydrostatix.sof-data": "sfd-hdstx",
        "application/vnd.hzn-3d-crossword": "x3d",
        "application/vnd.ibm.minipay": "mpy",
        "application/vnd.ibm.modcap": "afp",
        "application/vnd.ibm.rights-management": "irm",
        "application/vnd.ibm.secure-container": "sc",
        "application/vnd.iccprofile": "icc",
        "application/vnd.igloader": "igl",
        "application/vnd.immervision-ivp": "ivp",
        "application/vnd.immervision-ivu": "ivu",
        "application/vnd.insors.igm": "igm",
        "application/vnd.intercon.formnet": "xpw",
        "application/vnd.intergeo": "i2g",
        "application/vnd.intu.qbo": "qbo",
        "application/vnd.intu.qfx": "qfx",
        "application/vnd.ipunplugged.rcprofile": "rcprofile",
        "application/vnd.irepository.package+xml": "irp",
        "application/vnd.is-xpr": "xpr",
        "application/vnd.isac.fcs": "fcs",
        "application/vnd.jam": "jam",
        "application/vnd.jcp.javame.midlet-rms": "rms",
        "application/vnd.jisp": "jisp",
        "application/vnd.joost.joda-archive": "joda",
        "application/vnd.kahootz": "ktz",
        "application/vnd.kde.karbon": "karbon",
        "application/vnd.kde.kchart": "chrt",
        "application/vnd.kde.kformula": "kfo",
        "application/vnd.kde.kivio": "flw",
        "application/vnd.kde.kontour": "kon",
        "application/vnd.kde.kpresenter": "kpr",
        "application/vnd.kde.kspread": "ksp",
        "application/vnd.kde.kword": "kwd",
        "application/vnd.kenameaapp": "htke",
        "application/vnd.kidspiration": "kia",
        "application/vnd.kinar": "kne",
        "application/vnd.koan": "skp",
        "application/vnd.kodak-descriptor": "sse",
        "application/vnd.las.las+xml": "lasxml",
        "application/vnd.llamagraphics.life-balance.desktop": "lbd",
        "application/vnd.llamagraphics.life-balance.exchange+xml": "lbe",
        "application/vnd.lotus-1-2-3": "123",
        "application/vnd.lotus-approach": "apr",
        "application/vnd.lotus-freelance": "pre",
        "application/vnd.lotus-notes": "nsf",
        "application/vnd.lotus-organizer": "org",
        "application/vnd.lotus-screencam": "scm",
        "application/vnd.lotus-wordpro": "lwp",
        "application/vnd.macports.portpkg": "portpkg",
        "application/vnd.mcd": "mcd",
        "application/vnd.medcalcdata": "mc1",
        "application/vnd.mediastation.cdkey": "cdkey",
        "application/vnd.mfer": "mwf",
        "application/vnd.mfmp": "mfm",
        "application/vnd.micrografx.flo": "flo",
        "application/vnd.micrografx.igx": "igx",
        "application/vnd.mif": "mif",
        "application/vnd.mobius.daf": "daf",
        "application/vnd.mobius.dis": "dis",
        "application/vnd.mobius.mbk": "mbk",
        "application/vnd.mobius.mqy": "mqy",
        "application/vnd.mobius.msl": "msl",
        "application/vnd.mobius.plc": "plc",
        "application/vnd.mobius.txf": "txf",
        "application/vnd.mophun.application": "mpn",
        "application/vnd.mophun.certificate": "mpc",
        "application/vnd.mozilla.xul+xml": "xul",
        "application/vnd.ms-artgalry": "cil",
        "application/vnd.ms-cab-compressed": "cab",
        "application/vnd.ms-excel": [ "xla", "xlc", "xlm", "xls", "xlt", "xlw", "xlb", "xll" ],
        "application/vnd.ms-excel.addin.macroenabled.12": "xlam",
        "application/vnd.ms-excel.sheet.binary.macroenabled.12": "xlsb",
        "application/vnd.ms-excel.sheet.macroenabled.12": "xlsm",
        "application/vnd.ms-excel.template.macroenabled.12": "xltm",
        "application/vnd.ms-fontobject": "eot",
        "application/vnd.ms-htmlhelp": "chm",
        "application/vnd.ms-ims": "ims",
        "application/vnd.ms-lrm": "lrm",
        "application/vnd.ms-officetheme": "thmx",
        "application/vnd.ms-outlook": "msg",
        "application/vnd.ms-pki.certstore": "sst",
        "application/vnd.ms-pki.pko": "pko",
        "application/vnd.ms-pki.seccat": "cat",
        "application/vnd.ms-pki.stl": "stl",
        "application/vnd.ms-pkicertstore": "sst",
        "application/vnd.ms-pkiseccat": "cat",
        "application/vnd.ms-pkistl": "stl",
        "application/vnd.ms-powerpoint": [ "pot", "pps", "ppt", "ppa", "pwz" ],
        "application/vnd.ms-powerpoint.addin.macroenabled.12": "ppam",
        "application/vnd.ms-powerpoint.presentation.macroenabled.12": "pptm",
        "application/vnd.ms-powerpoint.slide.macroenabled.12": "sldm",
        "application/vnd.ms-powerpoint.slideshow.macroenabled.12": "ppsm",
        "application/vnd.ms-powerpoint.template.macroenabled.12": "potm",
        "application/vnd.ms-project": "mpp",
        "application/vnd.ms-word.document.macroenabled.12": "docm",
        "application/vnd.ms-word.template.macroenabled.12": "dotm",
        "application/vnd.ms-works": [ "wcm", "wdb", "wks", "wps" ],
        "application/vnd.ms-wpl": "wpl",
        "application/vnd.ms-xpsdocument": "xps",
        "application/vnd.mseq": "mseq",
        "application/vnd.musician": "mus",
        "application/vnd.muvee.style": "msty",
        "application/vnd.neurolanguage.nlu": "nlu",
        "application/vnd.noblenet-directory": "nnd",
        "application/vnd.noblenet-sealer": "nns",
        "application/vnd.noblenet-web": "nnw",
        "application/vnd.nokia.configuration-message": "ncm",
        "application/vnd.nokia.n-gage.data": "ngdat",
        "application/vnd.nokia.n-gage.symbian.install": "n-gage",
        "application/vnd.nokia.radio-preset": "rpst",
        "application/vnd.nokia.radio-presets": "rpss",
        "application/vnd.nokia.ringing-tone": "rng",
        "application/vnd.novadigm.edm": "edm",
        "application/vnd.novadigm.edx": "edx",
        "application/vnd.novadigm.ext": "ext",
        "application/vnd.oasis.opendocument.chart": "odc",
        "application/vnd.oasis.opendocument.chart-template": "otc",
        "application/vnd.oasis.opendocument.database": "odb",
        "application/vnd.oasis.opendocument.formula": "odf",
        "application/vnd.oasis.opendocument.formula-template": "odft",
        "application/vnd.oasis.opendocument.graphics": "odg",
        "application/vnd.oasis.opendocument.graphics-template": "otg",
        "application/vnd.oasis.opendocument.image": "odi",
        "application/vnd.oasis.opendocument.image-template": "oti",
        "application/vnd.oasis.opendocument.presentation": "odp",
        "application/vnd.oasis.opendocument.presentation-template": "otp",
        "application/vnd.oasis.opendocument.spreadsheet": "ods",
        "application/vnd.oasis.opendocument.spreadsheet-template": "ots",
        "application/vnd.oasis.opendocument.text": "odt",
        "application/vnd.oasis.opendocument.text-master": "odm",
        "application/vnd.oasis.opendocument.text-template": "ott",
        "application/vnd.oasis.opendocument.text-web": "oth",
        "application/vnd.olpc-sugar": "xo",
        "application/vnd.oma.dd2+xml": "dd2",
        "application/vnd.openofficeorg.extension": "oxt",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
        "application/vnd.openxmlformats-officedocument.presentationml.slide": "sldx",
        "application/vnd.openxmlformats-officedocument.presentationml.slideshow": "ppsx",
        "application/vnd.openxmlformats-officedocument.presentationml.template": "potx",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.template": "xltx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.template": "dotx",
        "application/vnd.osgeo.mapguide.package": "mgp",
        "application/vnd.osgi.dp": "dp",
        "application/vnd.palm": "pdb",
        "application/vnd.pawaafile": "paw",
        "application/vnd.pg.format": "str",
        "application/vnd.pg.osasli": "ei6",
        "application/vnd.picsel": "efif",
        "application/vnd.pmi.widget": "wg",
        "application/vnd.pocketlearn": "plf",
        "application/vnd.powerbuilder6": "pbd",
        "application/vnd.previewsystems.box": "box",
        "application/vnd.proteus.magazine": "mgz",
        "application/vnd.publishare-delta-tree": "qps",
        "application/vnd.pvi.ptid1": "ptid",
        "application/vnd.quark.quarkxpress": "qxd",
        "application/vnd.realvnc.bed": "bed",
        "application/vnd.recordare.musicxml": "mxl",
        "application/vnd.recordare.musicxml+xml": "musicxml",
        "application/vnd.rig.cryptonote": "cryptonote",
        "application/vnd.rim.cod": "cod",
        "application/vnd.rn-realmedia": "rm",
        "application/vnd.rn-realplayer": "rnx",
        "application/vnd.route66.link66+xml": "link66",
        "application/vnd.sailingtracker.track": "st",
        "application/vnd.seemail": "see",
        "application/vnd.sema": "sema",
        "application/vnd.semd": "semd",
        "application/vnd.semf": "semf",
        "application/vnd.shana.informed.formdata": "ifm",
        "application/vnd.shana.informed.formtemplate": "itp",
        "application/vnd.shana.informed.interchange": "iif",
        "application/vnd.shana.informed.package": "ipk",
        "application/vnd.simtech-mindmapper": "twd",
        "application/vnd.smaf": "mmf",
        "application/vnd.smart.teacher": "teacher",
        "application/vnd.solent.sdkm+xml": "sdkm",
        "application/vnd.spotfire.dxp": "dxp",
        "application/vnd.spotfire.sfs": "sfs",
        "application/vnd.stardivision.calc": "sdc",
        "application/vnd.stardivision.draw": "sda",
        "application/vnd.stardivision.impress": "sdd",
        "application/vnd.stardivision.math": "smf",
        "application/vnd.stardivision.writer": "sdw",
        "application/vnd.stardivision.writer-global": "sgl",
        "application/vnd.stepmania.stepchart": "sm",
        "application/vnd.sun.xml.calc": "sxc",
        "application/vnd.sun.xml.calc.template": "stc",
        "application/vnd.sun.xml.draw": "sxd",
        "application/vnd.sun.xml.draw.template": "std",
        "application/vnd.sun.xml.impress": "sxi",
        "application/vnd.sun.xml.impress.template": "sti",
        "application/vnd.sun.xml.math": "sxm",
        "application/vnd.sun.xml.writer": "sxw",
        "application/vnd.sun.xml.writer.global": "sxg",
        "application/vnd.sun.xml.writer.template": "stw",
        "application/vnd.sus-calendar": "sus",
        "application/vnd.svd": "svd",
        "application/vnd.symbian.install": "sis",
        "application/vnd.syncml+xml": "xsm",
        "application/vnd.syncml.dm+wbxml": "bdm",
        "application/vnd.syncml.dm+xml": "xdm",
        "application/vnd.tao.intent-module-archive": "tao",
        "application/vnd.tmobile-livetv": "tmo",
        "application/vnd.trid.tpt": "tpt",
        "application/vnd.triscape.mxs": "mxs",
        "application/vnd.trueapp": "tra",
        "application/vnd.ufdl": "ufd",
        "application/vnd.uiq.theme": "utz",
        "application/vnd.umajin": "umj",
        "application/vnd.unity": "unityweb",
        "application/vnd.uoml+xml": "uoml",
        "application/vnd.vcx": "vcx",
        "application/vnd.visio": "vsd",
        "application/vnd.visionary": "vis",
        "application/vnd.vsf": "vsf",
        "application/vnd.wap.wbxml": "wbxml",
        "application/vnd.wap.wmlc": "wmlc",
        "application/vnd.wap.wmlscriptc": "wmlsc",
        "application/vnd.webturbo": "wtb",
        "application/vnd.wolfram.player": "nbp",
        "application/vnd.wordperfect": "wpd",
        "application/vnd.wqd": "wqd",
        "application/vnd.wt.stf": "stf",
        "application/vnd.xara": [ "web", "xar" ],
        "application/vnd.xfdl": "xfdl",
        "application/vnd.yamaha.hv-dic": "hvd",
        "application/vnd.yamaha.hv-script": "hvs",
        "application/vnd.yamaha.hv-voice": "hvp",
        "application/vnd.yamaha.openscoreformat": "osf",
        "application/vnd.yamaha.openscoreformat.osfpvg+xml": "osfpvg",
        "application/vnd.yamaha.smaf-audio": "saf",
        "application/vnd.yamaha.smaf-phrase": "spf",
        "application/vnd.yellowriver-custom-menu": "cmp",
        "application/vnd.zul": "zir",
        "application/vnd.zzazz.deck+xml": "zaz",
        "application/vocaltec-media-desc": "vmd",
        "application/vocaltec-media-file": "vmf",
        "application/voicexml+xml": "vxml",
        "application/widget": "wgt",
        "application/winhlp": "hlp",
        "application/wordperfect": [ "wp", "wp5", "wp6", "wpd" ],
        "application/wordperfect6.0": [ "w60", "wp5" ],
        "application/wordperfect6.1": "w61",
        "application/wsdl+xml": "wsdl",
        "application/wspolicy+xml": "wspolicy",
        "application/x-123": "wk1",
        "application/x-7z-compressed": "7z",
        "application/x-abiword": "abw",
        "application/x-ace-compressed": "ace",
        "application/x-aim": "aim",
        "application/x-authorware-bin": "aab",
        "application/x-authorware-map": "aam",
        "application/x-authorware-seg": "aas",
        "application/x-bcpio": "bcpio",
        "application/x-binary": "bin",
        "application/x-binhex40": "hqx",
        "application/x-bittorrent": "torrent",
        "application/x-bsh": [ "bsh", "sh", "shar" ],
        "application/x-bytecode.elisp": "elc",
        "applicaiton/x-bytecode.python": "pyc",
        "application/x-bzip": "bz",
        "application/x-bzip2": [ "boz", "bz2" ],
        "application/x-cdf": "cdf",
        "application/x-cdlink": "vcd",
        "application/x-chat": [ "cha", "chat" ],
        "application/x-chess-pgn": "pgn",
        "application/x-cmu-raster": "ras",
        "application/x-cocoa": "cco",
        "application/x-compactpro": "cpt",
        "application/x-compress": "z",
        "application/x-compressed": [ "tgz", "gz", "z", "zip" ],
        "application/x-conference": "nsc",
        "application/x-cpio": "cpio",
        "application/x-cpt": "cpt",
        "application/x-csh": "csh",
        "application/x-debian-package": "deb",
        "application/x-deepv": "deepv",
        "application/x-director": [ "dcr", "dir", "dxr" ],
        "application/x-doom": "wad",
        "application/x-dtbncx+xml": "ncx",
        "application/x-dtbook+xml": "dtb",
        "application/x-dtbresource+xml": "res",
        "application/x-dvi": "dvi",
        "application/x-elc": "elc",
        "application/x-envoy": [ "env", "evy" ],
        "application/x-esrehber": "es",
        "application/x-excel": [ "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xls", "xlt", "xlv", "xlw" ],
        "application/x-font-bdf": "bdf",
        "application/x-font-ghostscript": "gsf",
        "application/x-font-linux-psf": "psf",
        "application/x-font-otf": "otf",
        "application/x-font-pcf": "pcf",
        "application/x-font-snf": "snf",
        "application/x-font-ttf": "ttf",
        "application/x-font-type1": "pfa",
        "application/x-font-woff": "woff",
        "application/x-frame": "mif",
        "application/x-freelance": "pre",
        "application/x-futuresplash": "spl",
        "application/x-gnumeric": "gnumeric",
        "application/x-gsp": "gsp",
        "application/x-gss": "gss",
        "application/x-gtar": "gtar",
        "application/x-gzip": [ "gz", "gzip" ],
        "application/x-hdf": "hdf",
        "application/x-helpfile": [ "help", "hlp" ],
        "application/x-httpd-imap": "imap",
        "application/x-ima": "ima",
        "application/x-internet-signup": [ "ins", "isp" ],
        "application/x-internett-signup": "ins",
        "application/x-inventor": "iv",
        "application/x-ip2": "ip",
        "application/x-iphone": "iii",
        "application/x-java-class": "class",
        "application/x-java-commerce": "jcm",
        "application/x-java-jnlp-file": "jnlp",
        "application/x-javascript": "js",
        "application/x-koan": [ "skd", "skm", "skp", "skt" ],
        "application/x-ksh": "ksh",
        "application/x-latex": [ "latex", "ltx" ],
        "application/x-lha": "lha",
        "application/x-lisp": "lsp",
        "application/x-livescreen": "ivy",
        "application/x-lotus": "wq1",
        "application/x-lotusscreencam": "scm",
        "application/x-lzh": "lzh",
        "application/x-lzx": "lzx",
        "application/x-mac-binhex40": "hqx",
        "application/x-macbinary": "bin",
        "application/x-magic-cap-package-1.0": "mc$",
        "application/x-mathcad": "mcd",
        "application/x-meme": "mm",
        "application/x-midi": [ "mid", "midi" ],
        "application/x-mif": "mif",
        "application/x-mix-transfer": "nix",
        "application/x-mobipocket-ebook": "prc",
        "application/x-mplayer2": "asx",
        "application/x-ms-application": "application",
        "application/x-ms-wmd": "wmd",
        "application/x-ms-wmz": "wmz",
        "application/x-ms-xbap": "xbap",
        "application/x-msaccess": "mdb",
        "application/x-msbinder": "obd",
        "application/x-mscardfile": "crd",
        "application/x-msclip": "clp",
        "application/x-msdownload": [ "dll", "exe" ],
        "application/x-msexcel": [ "xla", "xls", "xlw" ],
        "application/x-msmediaview": [ "m13", "m14", "mvb" ],
        "application/x-msmetafile": "wmf",
        "application/x-msmoney": "mny",
        "application/x-mspowerpoint": "ppt",
        "application/x-mspublisher": "pub",
        "application/x-msschedule": "scd",
        "application/x-msterminal": "trm",
        "application/x-mswrite": "wri",
        "application/x-navi-animation": "ani",
        "application/x-navidoc": "nvd",
        "application/x-navimap": "map",
        "application/x-navistyle": "stl",
        "application/x-netcdf": [ "cdf", "nc" ],
        "application/x-newton-compatible-pkg": "pkg",
        "application/x-nokia-9000-communicator-add-on-software": "aos",
        "application/x-omc": "omc",
        "application/x-omcdatamaker": "omcd",
        "application/x-omcregerator": "omcr",
        "application/x-pagemaker": [ "pm4", "pm5" ],
        "application/x-pcl": "pcl",
        "application/x-perfmon": [ "pma", "pmc", "pml", "pmr", "pmw" ],
        "application/x-pixclscript": "plx",
        "application/x-pkcs10": "p10",
        "application/x-pkcs12": [ "p12", "pfx" ],
        "application/x-pkcs7-certificates": [ "p7b", "spc" ],
        "application/x-pkcs7-certreqresp": "p7r",
        "application/x-pkcs7-mime": [ "p7c", "p7m" ],
        "application/x-pkcs7-signature": [ "p7s", "p7a" ],
        "application/x-pointplus": "css",
        "application/x-portable-anymap": "pnm",
        "application/x-project": [ "mpc", "mpt", "mpv", "mpx" ],
        "application/x-qpro": "wb1",
        "application/x-rar-compressed": "rar",
        "application/x-rtf": "rtf",
        "application/x-sdp": "sdp",
        "application/x-sea": "sea",
        "application/x-seelogo": "sl",
        "application/x-sh": "sh",
        "application/x-shar": [ "shar", "sh" ],
        "application/x-shockwave-flash": "swf",
        "application/x-silverlight-app": "xap",
        "application/x-sit": "sit",
        "application/x-sprite": [ "spr", "sprite" ],
        "application/x-stuffit": "sit",
        "application/x-stuffitx": "sitx",
        "application/x-sv4cpio": "sv4cpio",
        "application/x-sv4crc": "sv4crc",
        "application/x-tar": "tar",
        "application/x-tbook": [ "sbk", "tbk" ],
        "application/x-tcl": "tcl",
        "application/x-tex": "tex",
        "application/x-tex-tfm": "tfm",
        "application/x-texinfo": [ "texi", "texinfo" ],
        "application/x-troff": [ "roff", "t", "tr" ],
        "application/x-troff-man": "man",
        "application/x-troff-me": "me",
        "application/x-troff-ms": "ms",
        "application/x-troff-msvideo": "avi",
        "application/x-ustar": "ustar",
        "application/x-visio": [ "vsd", "vst", "vsw" ],
        "application/x-vnd.audioexplosion.mzz": "mzz",
        "application/x-vnd.ls-xpix": "xpix",
        "application/x-vrml": "vrml",
        "application/x-wais-source": [ "src", "wsrc" ],
        "application/x-winhelp": "hlp",
        "application/x-wintalk": "wtk",
        "application/x-world": [ "svr", "wrl" ],
        "application/x-wpwin": "wpd",
        "application/x-wri": "wri",
        "application/x-x509-ca-cert": [ "cer", "crt", "der" ],
        "application/x-x509-user-cert": "crt",
        "application/x-xfig": "fig",
        "application/x-xpinstall": "xpi",
        "application/x-zip-compressed": "zip",
        "application/xcap-diff+xml": "xdf",
        "application/xenc+xml": "xenc",
        "application/xhtml+xml": "xhtml",
        "application/xml": "xml",
        "application/xml-dtd": "dtd",
        "application/xop+xml": "xop",
        "application/xslt+xml": "xslt",
        "application/xspf+xml": "xspf",
        "application/xv+xml": "mxml",
        "application/yang": "yang",
        "application/yin+xml": "yin",
        "application/ynd.ms-pkipko": "pko",
        "application/zip": "zip",
        "audio/adpcm": "adp",
        "audio/aiff": [ "aif", "aifc", "aiff" ],
        "audio/basic": [ "au", "snd" ],
        "audio/it": "it",
        "audio/make": [ "funk", "my", "pfunk" ],
        "audio/make.my.funk": "pfunk",
        "audio/mid": [ "mid", "rmi" ],
        "audio/midi": [ "kar", "mid", "midi" ],
        "audio/mod": "mod",
        "audio/mp4": "mp4a",
        "audio/mpeg": [ "mp3", "m2a", "mp2", "mpa", "mpg", "mpga" ],
        "audio/mpeg3": "mp3",
        "audio/nspaudio": [ "la", "lma" ],
        "audio/ogg": "oga",
        "audio/s3m": "s3m",
        "audio/tsp-audio": "tsi",
        "audio/tsplayer": "tsp",
        "audio/vnd.dece.audio": "uva",
        "audio/vnd.digital-winds": "eol",
        "audio/vnd.dra": "dra",
        "audio/vnd.dts": "dts",
        "audio/vnd.dts.hd": "dtshd",
        "audio/vnd.lucent.voice": "lvp",
        "audio/vnd.ms-playready.media.pya": "pya",
        "audio/vnd.nuera.ecelp4800": "ecelp4800",
        "audio/vnd.nuera.ecelp7470": "ecelp7470",
        "audio/vnd.nuera.ecelp9600": "ecelp9600",
        "audio/vnd.qcelp": "qcp",
        "audio/vnd.rip": "rip",
        "audio/voc": "voc",
        "audio/voxware": "vox",
        "audio/wav": "wav",
        "audio/webm": "weba",
        "audio/x-aac": "aac",
        "audio/x-adpcm": "snd",
        "audio/x-aiff": [ "aif", "aifc", "aiff" ],
        "audio/x-au": "au",
        "audio/x-gsm": [ "gsd", "gsm" ],
        "audio/x-jam": "jam",
        "audio/x-liveaudio": "lam",
        "audio/x-mid": [ "mid", "midi" ],
        "audio/x-midi": [ "mid", "midi" ],
        "audio/x-mod": "mod",
        "audio/x-mpeg": "mp2",
        "audio/x-mpeg-3": "mp3",
        "audio/x-mpegurl": "m3u",
        "audio/x-mpequrl": "m3u",
        "audio/x-ms-wax": "wax",
        "audio/x-ms-wma": "wma",
        "audio/x-nspaudio": [ "la", "lma" ],
        "audio/x-pn-realaudio": [ "ra", "ram", "rm", "rmm", "rmp" ],
        "audio/x-pn-realaudio-plugin": [ "ra", "rmp", "rpm" ],
        "audio/x-psid": "sid",
        "audio/x-realaudio": "ra",
        "audio/x-twinvq": "vqf",
        "audio/x-twinvq-plugin": [ "vqe", "vql" ],
        "audio/x-vnd.audioexplosion.mjuicemediafile": "mjf",
        "audio/x-voc": "voc",
        "audio/x-wav": "wav",
        "audio/xm": "xm",
        "chemical/x-cdx": "cdx",
        "chemical/x-cif": "cif",
        "chemical/x-cmdf": "cmdf",
        "chemical/x-cml": "cml",
        "chemical/x-csml": "csml",
        "chemical/x-pdb": [ "pdb", "xyz" ],
        "chemical/x-xyz": "xyz",
        "drawing/x-dwf": "dwf",
        "i-world/i-vrml": "ivr",
        "image/bmp": [ "bmp", "bm" ],
        "image/cgm": "cgm",
        "image/cis-cod": "cod",
        "image/cmu-raster": [ "ras", "rast" ],
        "image/fif": "fif",
        "image/florian": [ "flo", "turbot" ],
        "image/g3fax": "g3",
        "image/gif": "gif",
        "image/ief": [ "ief", "iefs" ],
        "image/jpeg": [ "jpe", "jpeg", "jpg", "jfif", "jfif-tbnl" ],
        "image/jutvision": "jut",
        "image/ktx": "ktx",
        "image/naplps": [ "nap", "naplps" ],
        "image/pict": [ "pic", "pict" ],
        "image/pipeg": "jfif",
        "image/pjpeg": [ "jfif", "jpe", "jpeg", "jpg" ],
        "image/png": [ "png", "x-png" ],
        "image/prs.btif": "btif",
        "image/svg+xml": "svg",
        "image/tiff": [ "tif", "tiff" ],
        "image/vasa": "mcf",
        "image/vnd.adobe.photoshop": "psd",
        "image/vnd.dece.graphic": "uvi",
        "image/vnd.djvu": "djvu",
        "image/vnd.dvb.subtitle": "sub",
        "image/vnd.dwg": [ "dwg", "dxf", "svf" ],
        "image/vnd.dxf": "dxf",
        "image/vnd.fastbidsheet": "fbs",
        "image/vnd.fpx": "fpx",
        "image/vnd.fst": "fst",
        "image/vnd.fujixerox.edmics-mmr": "mmr",
        "image/vnd.fujixerox.edmics-rlc": "rlc",
        "image/vnd.ms-modi": "mdi",
        "image/vnd.net-fpx": [ "fpx", "npx" ],
        "image/vnd.rn-realflash": "rf",
        "image/vnd.rn-realpix": "rp",
        "image/vnd.wap.wbmp": "wbmp",
        "image/vnd.xiff": "xif",
        "image/webp": "webp",
        "image/x-cmu-raster": "ras",
        "image/x-cmx": "cmx",
        "image/x-dwg": [ "dwg", "dxf", "svf" ],
        "image/x-freehand": "fh",
        "image/x-icon": "ico",
        "image/x-jg": "art",
        "image/x-jps": "jps",
        "image/x-niff": [ "nif", "niff" ],
        "image/x-pcx": "pcx",
        "image/x-pict": [ "pct", "pic" ],
        "image/x-portable-anymap": "pnm",
        "image/x-portable-bitmap": "pbm",
        "image/x-portable-graymap": "pgm",
        "image/x-portable-greymap": "pgm",
        "image/x-portable-pixmap": "ppm",
        "image/x-quicktime": [ "qif", "qti", "qtif" ],
        "image/x-rgb": "rgb",
        "image/x-tiff": [ "tif", "tiff" ],
        "image/x-windows-bmp": "bmp",
        "image/x-xbitmap": "xbm",
        "image/x-xbm": "xbm",
        "image/x-xpixmap": [ "xpm", "pm" ],
        "image/x-xwd": "xwd",
        "image/x-xwindowdump": "xwd",
        "image/xbm": "xbm",
        "image/xpm": "xpm",
        "message/rfc822": [ "mht", "mhtml", "nws", "mime", "eml" ],
        "model/iges": [ "iges", "igs" ],
        "model/mesh": "msh",
        "model/vnd.collada+xml": "dae",
        "model/vnd.dwf": "dwf",
        "model/vnd.gdl": "gdl",
        "model/vnd.gtw": "gtw",
        "model/vnd.mts": "mts",
        "model/vnd.vtu": "vtu",
        "model/vrml": [ "vrml", "wrl", "wrz" ],
        "model/x-pov": "pov",
        "multipart/x-gzip": "gzip",
        "multipart/x-ustar": "ustar",
        "multipart/x-zip": "zip",
        "music/crescendo": [ "mid", "midi" ],
        "music/x-karaoke": "kar",
        "paleovu/x-pv": "pvu",
        "text/asp": "asp",
        "text/calendar": "ics",
        "text/css": "css",
        "text/csv": "csv",
        "text/ecmascript": "js",
        "text/h323": "323",
        "text/html": [ "htm", "html", "stm", "acgi", "htmls", "htx", "shtml" ],
        "text/iuls": "uls",
        "text/javascript": "js",
        "text/mcf": "mcf",
        "text/n3": "n3",
        "text/pascal": "pas",
        "text/plain": [ "bas", "c", "h", "txt", "c++", "cc", "com", "conf", "cxx", "def", "f", "f90", "for", "g", "hh", "idc", "jav", "java", "list", "log", "lst", "m", "mar", "pl", "sdml", "text" ],
        "text/plain-bas": "par",
        "text/prs.lines.tag": "dsc",
        "text/richtext": [ "rtx", "rt", "rtf" ],
        "text/scriplet": "wsc",
        "text/scriptlet": "sct",
        "text/sgml": [ "sgm", "sgml" ],
        "text/tab-separated-values": "tsv",
        "text/troff": "t",
        "text/turtle": "ttl",
        "text/uri-list": [ "uni", "unis", "uri", "uris" ],
        "text/vnd.abc": "abc",
        "text/vnd.curl": "curl",
        "text/vnd.curl.dcurl": "dcurl",
        "text/vnd.curl.mcurl": "mcurl",
        "text/vnd.curl.scurl": "scurl",
        "text/vnd.fly": "fly",
        "text/vnd.fmi.flexstor": "flx",
        "text/vnd.graphviz": "gv",
        "text/vnd.in3d.3dml": "3dml",
        "text/vnd.in3d.spot": "spot",
        "text/vnd.rn-realtext": "rt",
        "text/vnd.sun.j2me.app-descriptor": "jad",
        "text/vnd.wap.wml": "wml",
        "text/vnd.wap.wmlscript": "wmls",
        "text/webviewhtml": "htt",
        "text/x-asm": [ "asm", "s" ],
        "text/x-audiosoft-intra": "aip",
        "text/x-c": [ "c", "cc", "cpp" ],
        "text/x-component": "htc",
        "text/x-fortran": [ "f", "f77", "f90", "for" ],
        "text/x-h": [ "h", "hh" ],
        "text/x-java-source": [ "jav", "java" ],
        "text/x-java-source,java": "java",
        "text/x-la-asf": "lsx",
        "text/x-m": "m",
        "text/x-pascal": "p",
        "text/x-script": "hlb",
        "text/x-script.csh": "csh",
        "text/x-script.elisp": "el",
        "text/x-script.guile": "scm",
        "text/x-script.ksh": "ksh",
        "text/x-script.lisp": "lsp",
        "text/x-script.perl": "pl",
        "text/x-script.perl-module": "pm",
        "text/x-script.phyton": "py",
        "text/x-script.rexx": "rexx",
        "text/x-script.scheme": "scm",
        "text/x-script.sh": "sh",
        "text/x-script.tcl": "tcl",
        "text/x-script.tcsh": "tcsh",
        "text/x-script.zsh": "zsh",
        "text/x-server-parsed-html": [ "shtml", "ssi" ],
        "text/x-setext": "etx",
        "text/x-sgml": [ "sgm", "sgml" ],
        "text/x-speech": [ "spc", "talk" ],
        "text/x-uil": "uil",
        "text/x-uuencode": [ "uu", "uue" ],
        "text/x-vcalendar": "vcs",
        "text/x-vcard": "vcf",
        "text/xml": "xml",
        "video/3gpp": "3gp",
        "video/3gpp2": "3g2",
        "video/animaflex": "afl",
        "video/avi": "avi",
        "video/avs-video": "avs",
        "video/dl": "dl",
        "video/fli": "fli",
        "video/gl": "gl",
        "video/h261": "h261",
        "video/h263": "h263",
        "video/h264": "h264",
        "video/jpeg": "jpgv",
        "video/jpm": "jpm",
        "video/mj2": "mj2",
        "video/mp4": "mp4",
        "video/mpeg": [ "mp2", "mpa", "mpe", "mpeg", "mpg", "mpv2", "m1v", "m2v", "mp3" ],
        "video/msvideo": "avi",
        "video/ogg": "ogv",
        "video/quicktime": [ "mov", "qt", "moov" ],
        "video/vdo": "vdo",
        "video/vivo": [ "viv", "vivo" ],
        "video/vnd.dece.hd": "uvh",
        "video/vnd.dece.mobile": "uvm",
        "video/vnd.dece.pd": "uvp",
        "video/vnd.dece.sd": "uvs",
        "video/vnd.dece.video": "uvv",
        "video/vnd.fvt": "fvt",
        "video/vnd.mpegurl": "mxu",
        "video/vnd.ms-playready.media.pyv": "pyv",
        "video/vnd.rn-realvideo": "rv",
        "video/vnd.uvvu.mp4": "uvu",
        "video/vnd.vivo": [ "viv", "vivo" ],
        "video/vosaic": "vos",
        "video/webm": "webm",
        "video/x-amt-demorun": "xdr",
        "video/x-amt-showrun": "xsr",
        "video/x-atomic3d-feature": "fmf",
        "video/x-dl": "dl",
        "video/x-dv": [ "dif", "dv" ],
        "video/x-f4v": "f4v",
        "video/x-fli": "fli",
        "video/x-flv": "flv",
        "video/x-gl": "gl",
        "video/x-isvideo": "isu",
        "video/x-la-asf": [ "lsf", "lsx" ],
        "video/x-m4v": "m4v",
        "video/x-motion-jpeg": "mjpg",
        "video/x-mpeg": [ "mp2", "mp3" ],
        "video/x-mpeq2a": "mp2",
        "video/x-ms-asf": [ "asf", "asr", "asx" ],
        "video/x-ms-asf-plugin": "asx",
        "video/x-ms-wm": "wm",
        "video/x-ms-wmv": "wmv",
        "video/x-ms-wmx": "wmx",
        "video/x-ms-wvx": "wvx",
        "video/x-msvideo": "avi",
        "video/x-qtc": "qtc",
        "video/x-scm": "scm",
        "video/x-sgi-movie": [ "movie", "mv" ],
        "windows/metafile": "wmf",
        "www/mime": "mime",
        "x-conference/x-cooltalk": "ice",
        "x-music/x-midi": [ "mid", "midi" ],
        "x-world/x-3dmf": [ "3dm", "3dmf", "qd3", "qd3d" ],
        "x-world/x-svr": "svr",
        "x-world/x-vrml": [ "flr", "vrml", "wrl", "wrz", "xaf", "xof" ],
        "x-world/x-vrt": "vrt",
        "xgl/drawing": "xgz",
        "xgl/movie": "xmz"
    }, i = {
        "": [ "application/andrew-inset", "application/pgp-encrypted" ],
        "*": "application/octet-stream",
        "123": "application/vnd.lotus-1-2-3",
        "323": "text/h323",
        "3dm": "x-world/x-3dmf",
        "3dmf": "x-world/x-3dmf",
        "3dml": "text/vnd.in3d.3dml",
        "3g2": "video/3gpp2",
        "3gp": "video/3gpp",
        "7z": "application/x-7z-compressed",
        a: "application/octet-stream",
        aab: "application/x-authorware-bin",
        aac: "audio/x-aac",
        aam: "application/x-authorware-map",
        aas: "application/x-authorware-seg",
        abc: "text/vnd.abc",
        abw: "application/x-abiword",
        ac: "application/pkix-attr-cert",
        acc: "application/vnd.americandynamics.acc",
        ace: "application/x-ace-compressed",
        acgi: "text/html",
        acu: "application/vnd.acucobol",
        acx: "application/internet-property-stream",
        adp: "audio/adpcm",
        aep: "application/vnd.audiograph",
        afl: "video/animaflex",
        afp: "application/vnd.ibm.modcap",
        ahead: "application/vnd.ahead.space",
        ai: "application/postscript",
        aif: [ "audio/aiff", "audio/x-aiff" ],
        aifc: [ "audio/aiff", "audio/x-aiff" ],
        aiff: [ "audio/aiff", "audio/x-aiff" ],
        aim: "application/x-aim",
        aip: "text/x-audiosoft-intra",
        air: "application/vnd.adobe.air-application-installer-package+zip",
        ait: "application/vnd.dvb.ait",
        ami: "application/vnd.amiga.ami",
        ani: "application/x-navi-animation",
        aos: "application/x-nokia-9000-communicator-add-on-software",
        apk: "application/vnd.android.package-archive",
        application: "application/x-ms-application",
        apr: "application/vnd.lotus-approach",
        aps: "application/mime",
        arc: "application/octet-stream",
        arj: [ "application/arj", "application/octet-stream" ],
        art: "image/x-jg",
        asf: "video/x-ms-asf",
        asm: "text/x-asm",
        aso: "application/vnd.accpac.simply.aso",
        asp: "text/asp",
        asr: "video/x-ms-asf",
        asx: [ "video/x-ms-asf", "application/x-mplayer2", "video/x-ms-asf-plugin" ],
        atc: "application/vnd.acucorp",
        atomcat: "application/atomcat+xml",
        atomsvc: "application/atomsvc+xml",
        atx: "application/vnd.antix.game-component",
        au: [ "audio/basic", "audio/x-au" ],
        avi: [ "video/avi", "video/msvideo", "application/x-troff-msvideo", "video/x-msvideo" ],
        avs: "video/avs-video",
        aw: "application/applixware",
        axs: "application/olescript",
        azf: "application/vnd.airzip.filesecure.azf",
        azs: "application/vnd.airzip.filesecure.azs",
        azw: "application/vnd.amazon.ebook",
        bas: "text/plain",
        bcpio: "application/x-bcpio",
        bdf: "application/x-font-bdf",
        bdm: "application/vnd.syncml.dm+wbxml",
        bed: "application/vnd.realvnc.bed",
        bh2: "application/vnd.fujitsu.oasysprs",
        bin: [ "application/octet-stream", "application/mac-binary", "application/macbinary", "application/x-macbinary", "application/x-binary" ],
        bm: "image/bmp",
        bmi: "application/vnd.bmi",
        bmp: [ "image/bmp", "image/x-windows-bmp" ],
        boo: "application/book",
        book: "application/book",
        box: "application/vnd.previewsystems.box",
        boz: "application/x-bzip2",
        bsh: "application/x-bsh",
        btif: "image/prs.btif",
        bz: "application/x-bzip",
        bz2: "application/x-bzip2",
        c: [ "text/plain", "text/x-c" ],
        "c++": "text/plain",
        c11amc: "application/vnd.cluetrust.cartomobile-config",
        c11amz: "application/vnd.cluetrust.cartomobile-config-pkg",
        c4g: "application/vnd.clonk.c4group",
        cab: "application/vnd.ms-cab-compressed",
        car: "application/vnd.curl.car",
        cat: [ "application/vnd.ms-pkiseccat", "application/vnd.ms-pki.seccat" ],
        cc: [ "text/plain", "text/x-c" ],
        ccad: "application/clariscad",
        cco: "application/x-cocoa",
        ccxml: "application/ccxml+xml,",
        cdbcmsg: "application/vnd.contact.cmsg",
        cdf: [ "application/cdf", "application/x-cdf", "application/x-netcdf" ],
        cdkey: "application/vnd.mediastation.cdkey",
        cdmia: "application/cdmi-capability",
        cdmic: "application/cdmi-container",
        cdmid: "application/cdmi-domain",
        cdmio: "application/cdmi-object",
        cdmiq: "application/cdmi-queue",
        cdx: "chemical/x-cdx",
        cdxml: "application/vnd.chemdraw+xml",
        cdy: "application/vnd.cinderella",
        cer: [ "application/pkix-cert", "application/x-x509-ca-cert" ],
        cgm: "image/cgm",
        cha: "application/x-chat",
        chat: "application/x-chat",
        chm: "application/vnd.ms-htmlhelp",
        chrt: "application/vnd.kde.kchart",
        cif: "chemical/x-cif",
        cii: "application/vnd.anser-web-certificate-issue-initiation",
        cil: "application/vnd.ms-artgalry",
        cla: "application/vnd.claymore",
        "class": [ "application/octet-stream", "application/java", "application/java-byte-code", "application/java-vm", "application/x-java-class" ],
        clkk: "application/vnd.crick.clicker.keyboard",
        clkp: "application/vnd.crick.clicker.palette",
        clkt: "application/vnd.crick.clicker.template",
        clkw: "application/vnd.crick.clicker.wordbank",
        clkx: "application/vnd.crick.clicker",
        clp: "application/x-msclip",
        cmc: "application/vnd.cosmocaller",
        cmdf: "chemical/x-cmdf",
        cml: "chemical/x-cml",
        cmp: "application/vnd.yellowriver-custom-menu",
        cmx: "image/x-cmx",
        cod: [ "image/cis-cod", "application/vnd.rim.cod" ],
        com: [ "application/octet-stream", "text/plain" ],
        conf: "text/plain",
        cpio: "application/x-cpio",
        cpp: "text/x-c",
        cpt: [ "application/mac-compactpro", "application/x-compactpro", "application/x-cpt" ],
        crd: "application/x-mscardfile",
        crl: [ "application/pkix-crl", "application/pkcs-crl" ],
        crt: [ "application/pkix-cert", "application/x-x509-user-cert", "application/x-x509-ca-cert" ],
        cryptonote: "application/vnd.rig.cryptonote",
        csh: [ "text/x-script.csh", "application/x-csh" ],
        csml: "chemical/x-csml",
        csp: "application/vnd.commonspace",
        css: [ "text/css", "application/x-pointplus" ],
        csv: "text/csv",
        cu: "application/cu-seeme",
        curl: "text/vnd.curl",
        cww: "application/prs.cww",
        cxx: "text/plain",
        dae: "model/vnd.collada+xml",
        daf: "application/vnd.mobius.daf",
        davmount: "application/davmount+xml",
        dcr: "application/x-director",
        dcurl: "text/vnd.curl.dcurl",
        dd2: "application/vnd.oma.dd2+xml",
        ddd: "application/vnd.fujixerox.ddd",
        deb: "application/x-debian-package",
        deepv: "application/x-deepv",
        def: "text/plain",
        der: "application/x-x509-ca-cert",
        dfac: "application/vnd.dreamfactory",
        dif: "video/x-dv",
        dir: "application/x-director",
        dis: "application/vnd.mobius.dis",
        djvu: "image/vnd.djvu",
        dl: [ "video/dl", "video/x-dl" ],
        dll: "application/x-msdownload",
        dms: "application/octet-stream",
        dna: "application/vnd.dna",
        doc: "application/msword",
        docm: "application/vnd.ms-word.document.macroenabled.12",
        docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        dot: "application/msword",
        dotm: "application/vnd.ms-word.template.macroenabled.12",
        dotx: "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
        dp: [ "application/commonground", "application/vnd.osgi.dp" ],
        dpg: "application/vnd.dpgraph",
        dra: "audio/vnd.dra",
        drw: "application/drafting",
        dsc: "text/prs.lines.tag",
        dssc: "application/dssc+der",
        dtb: "application/x-dtbook+xml",
        dtd: "application/xml-dtd",
        dts: "audio/vnd.dts",
        dtshd: "audio/vnd.dts.hd",
        dump: "application/octet-stream",
        dv: "video/x-dv",
        dvi: "application/x-dvi",
        dwf: [ "model/vnd.dwf", "drawing/x-dwf" ],
        dwg: [ "application/acad", "image/vnd.dwg", "image/x-dwg" ],
        dxf: [ "application/dxf", "image/vnd.dwg", "image/vnd.dxf", "image/x-dwg" ],
        dxp: "application/vnd.spotfire.dxp",
        dxr: "application/x-director",
        ecelp4800: "audio/vnd.nuera.ecelp4800",
        ecelp7470: "audio/vnd.nuera.ecelp7470",
        ecelp9600: "audio/vnd.nuera.ecelp9600",
        edm: "application/vnd.novadigm.edm",
        edx: "application/vnd.novadigm.edx",
        efif: "application/vnd.picsel",
        ei6: "application/vnd.pg.osasli",
        el: "text/x-script.elisp",
        elc: [ "application/x-elc", "application/x-bytecode.elisp" ],
        eml: "message/rfc822",
        emma: "application/emma+xml",
        env: "application/x-envoy",
        eol: "audio/vnd.digital-winds",
        eot: "application/vnd.ms-fontobject",
        eps: "application/postscript",
        epub: "application/epub+zip",
        es: [ "application/ecmascript", "application/x-esrehber" ],
        es3: "application/vnd.eszigno3+xml",
        esf: "application/vnd.epson.esf",
        etx: "text/x-setext",
        evy: [ "application/envoy", "application/x-envoy" ],
        exe: [ "application/octet-stream", "application/x-msdownload" ],
        exi: "application/exi",
        ext: "application/vnd.novadigm.ext",
        ez2: "application/vnd.ezpix-album",
        ez3: "application/vnd.ezpix-package",
        f: [ "text/plain", "text/x-fortran" ],
        f4v: "video/x-f4v",
        f77: "text/x-fortran",
        f90: [ "text/plain", "text/x-fortran" ],
        fbs: "image/vnd.fastbidsheet",
        fcs: "application/vnd.isac.fcs",
        fdf: "application/vnd.fdf",
        fe_launch: "application/vnd.denovo.fcselayout-link",
        fg5: "application/vnd.fujitsu.oasysgp",
        fh: "image/x-freehand",
        fif: [ "application/fractals", "image/fif" ],
        fig: "application/x-xfig",
        fli: [ "video/fli", "video/x-fli" ],
        flo: [ "image/florian", "application/vnd.micrografx.flo" ],
        flr: "x-world/x-vrml",
        flv: "video/x-flv",
        flw: "application/vnd.kde.kivio",
        flx: "text/vnd.fmi.flexstor",
        fly: "text/vnd.fly",
        fm: "application/vnd.framemaker",
        fmf: "video/x-atomic3d-feature",
        fnc: "application/vnd.frogans.fnc",
        "for": [ "text/plain", "text/x-fortran" ],
        fpx: [ "image/vnd.fpx", "image/vnd.net-fpx" ],
        frl: "application/freeloader",
        fsc: "application/vnd.fsc.weblaunch",
        fst: "image/vnd.fst",
        ftc: "application/vnd.fluxtime.clip",
        fti: "application/vnd.anser-web-funds-transfer-initiation",
        funk: "audio/make",
        fvt: "video/vnd.fvt",
        fxp: "application/vnd.adobe.fxp",
        fzs: "application/vnd.fuzzysheet",
        g: "text/plain",
        g2w: "application/vnd.geoplan",
        g3: "image/g3fax",
        g3w: "application/vnd.geospace",
        gac: "application/vnd.groove-account",
        gdl: "model/vnd.gdl",
        geo: "application/vnd.dynageo",
        gex: "application/vnd.geometry-explorer",
        ggb: "application/vnd.geogebra.file",
        ggt: "application/vnd.geogebra.tool",
        ghf: "application/vnd.groove-help",
        gif: "image/gif",
        gim: "application/vnd.groove-identity-message",
        gl: [ "video/gl", "video/x-gl" ],
        gmx: "application/vnd.gmx",
        gnumeric: "application/x-gnumeric",
        gph: "application/vnd.flographit",
        gqf: "application/vnd.grafeq",
        gram: "application/srgs",
        grv: "application/vnd.groove-injector",
        grxml: "application/srgs+xml",
        gsd: "audio/x-gsm",
        gsf: "application/x-font-ghostscript",
        gsm: "audio/x-gsm",
        gsp: "application/x-gsp",
        gss: "application/x-gss",
        gtar: "application/x-gtar",
        gtm: "application/vnd.groove-tool-message",
        gtw: "model/vnd.gtw",
        gv: "text/vnd.graphviz",
        gxt: "application/vnd.geonext",
        gz: [ "application/x-gzip", "application/x-compressed" ],
        gzip: [ "multipart/x-gzip", "application/x-gzip" ],
        h: [ "text/plain", "text/x-h" ],
        h261: "video/h261",
        h263: "video/h263",
        h264: "video/h264",
        hal: "application/vnd.hal+xml",
        hbci: "application/vnd.hbci",
        hdf: "application/x-hdf",
        help: "application/x-helpfile",
        hgl: "application/vnd.hp-hpgl",
        hh: [ "text/plain", "text/x-h" ],
        hlb: "text/x-script",
        hlp: [ "application/winhlp", "application/hlp", "application/x-helpfile", "application/x-winhelp" ],
        hpg: "application/vnd.hp-hpgl",
        hpgl: "application/vnd.hp-hpgl",
        hpid: "application/vnd.hp-hpid",
        hps: "application/vnd.hp-hps",
        hqx: [ "application/mac-binhex40", "application/binhex", "application/binhex4", "application/mac-binhex", "application/x-binhex40", "application/x-mac-binhex40" ],
        hta: "application/hta",
        htc: "text/x-component",
        htke: "application/vnd.kenameaapp",
        htm: "text/html",
        html: "text/html",
        htmls: "text/html",
        htt: "text/webviewhtml",
        htx: "text/html",
        hvd: "application/vnd.yamaha.hv-dic",
        hvp: "application/vnd.yamaha.hv-voice",
        hvs: "application/vnd.yamaha.hv-script",
        i2g: "application/vnd.intergeo",
        icc: "application/vnd.iccprofile",
        ice: "x-conference/x-cooltalk",
        ico: "image/x-icon",
        ics: "text/calendar",
        idc: "text/plain",
        ief: "image/ief",
        iefs: "image/ief",
        ifm: "application/vnd.shana.informed.formdata",
        iges: [ "application/iges", "model/iges" ],
        igl: "application/vnd.igloader",
        igm: "application/vnd.insors.igm",
        igs: [ "application/iges", "model/iges" ],
        igx: "application/vnd.micrografx.igx",
        iif: "application/vnd.shana.informed.interchange",
        iii: "application/x-iphone",
        ima: "application/x-ima",
        imap: "application/x-httpd-imap",
        imp: "application/vnd.accpac.simply.imp",
        ims: "application/vnd.ms-ims",
        inf: "application/inf",
        ins: [ "application/x-internet-signup", "application/x-internett-signup" ],
        ip: "application/x-ip2",
        ipfix: "application/ipfix",
        ipk: "application/vnd.shana.informed.package",
        irm: "application/vnd.ibm.rights-management",
        irp: "application/vnd.irepository.package+xml",
        isp: "application/x-internet-signup",
        isu: "video/x-isvideo",
        it: "audio/it",
        itp: "application/vnd.shana.informed.formtemplate",
        iv: "application/x-inventor",
        ivp: "application/vnd.immervision-ivp",
        ivr: "i-world/i-vrml",
        ivu: "application/vnd.immervision-ivu",
        ivy: "application/x-livescreen",
        jad: "text/vnd.sun.j2me.app-descriptor",
        jam: [ "application/vnd.jam", "audio/x-jam" ],
        jar: "application/java-archive",
        jav: [ "text/plain", "text/x-java-source" ],
        java: [ "text/plain", "text/x-java-source,java", "text/x-java-source" ],
        jcm: "application/x-java-commerce",
        jfif: [ "image/pipeg", "image/jpeg", "image/pjpeg" ],
        "jfif-tbnl": "image/jpeg",
        jisp: "application/vnd.jisp",
        jlt: "application/vnd.hp-jlyt",
        jnlp: "application/x-java-jnlp-file",
        joda: "application/vnd.joost.joda-archive",
        jpe: [ "image/jpeg", "image/pjpeg" ],
        jpeg: [ "image/jpeg", "image/pjpeg" ],
        jpg: [ "image/jpeg", "image/pjpeg" ],
        jpgv: "video/jpeg",
        jpm: "video/jpm",
        jps: "image/x-jps",
        js: [ "application/javascript", "application/ecmascript", "text/javascript", "text/ecmascript", "application/x-javascript" ],
        json: "application/json",
        jut: "image/jutvision",
        kar: [ "audio/midi", "music/x-karaoke" ],
        karbon: "application/vnd.kde.karbon",
        kfo: "application/vnd.kde.kformula",
        kia: "application/vnd.kidspiration",
        kml: "application/vnd.google-earth.kml+xml",
        kmz: "application/vnd.google-earth.kmz",
        kne: "application/vnd.kinar",
        kon: "application/vnd.kde.kontour",
        kpr: "application/vnd.kde.kpresenter",
        ksh: [ "application/x-ksh", "text/x-script.ksh" ],
        ksp: "application/vnd.kde.kspread",
        ktx: "image/ktx",
        ktz: "application/vnd.kahootz",
        kwd: "application/vnd.kde.kword",
        la: [ "audio/nspaudio", "audio/x-nspaudio" ],
        lam: "audio/x-liveaudio",
        lasxml: "application/vnd.las.las+xml",
        latex: "application/x-latex",
        lbd: "application/vnd.llamagraphics.life-balance.desktop",
        lbe: "application/vnd.llamagraphics.life-balance.exchange+xml",
        les: "application/vnd.hhe.lesson-player",
        lha: [ "application/octet-stream", "application/lha", "application/x-lha" ],
        lhx: "application/octet-stream",
        link66: "application/vnd.route66.link66+xml",
        list: "text/plain",
        lma: [ "audio/nspaudio", "audio/x-nspaudio" ],
        log: "text/plain",
        lrm: "application/vnd.ms-lrm",
        lsf: "video/x-la-asf",
        lsp: [ "application/x-lisp", "text/x-script.lisp" ],
        lst: "text/plain",
        lsx: [ "video/x-la-asf", "text/x-la-asf" ],
        ltf: "application/vnd.frogans.ltf",
        ltx: "application/x-latex",
        lvp: "audio/vnd.lucent.voice",
        lwp: "application/vnd.lotus-wordpro",
        lzh: [ "application/octet-stream", "application/x-lzh" ],
        lzx: [ "application/lzx", "application/octet-stream", "application/x-lzx" ],
        m: [ "text/plain", "text/x-m" ],
        m13: "application/x-msmediaview",
        m14: "application/x-msmediaview",
        m1v: "video/mpeg",
        m21: "application/mp21",
        m2a: "audio/mpeg",
        m2v: "video/mpeg",
        m3u: [ "audio/x-mpegurl", "audio/x-mpequrl" ],
        m3u8: "application/vnd.apple.mpegurl",
        m4v: "video/x-m4v",
        ma: "application/mathematica",
        mads: "application/mads+xml",
        mag: "application/vnd.ecowin.chart",
        man: "application/x-troff-man",
        map: "application/x-navimap",
        mar: "text/plain",
        mathml: "application/mathml+xml",
        mbd: "application/mbedlet",
        mbk: "application/vnd.mobius.mbk",
        mbox: "application/mbox",
        mc$: "application/x-magic-cap-package-1.0",
        mc1: "application/vnd.medcalcdata",
        mcd: [ "application/mcad", "application/vnd.mcd", "application/x-mathcad" ],
        mcf: [ "image/vasa", "text/mcf" ],
        mcp: "application/netmc",
        mcurl: "text/vnd.curl.mcurl",
        mdb: "application/x-msaccess",
        mdi: "image/vnd.ms-modi",
        me: "application/x-troff-me",
        meta4: "application/metalink4+xml",
        mets: "application/mets+xml",
        mfm: "application/vnd.mfmp",
        mgp: "application/vnd.osgeo.mapguide.package",
        mgz: "application/vnd.proteus.magazine",
        mht: "message/rfc822",
        mhtml: "message/rfc822",
        mid: [ "audio/mid", "audio/midi", "music/crescendo", "x-music/x-midi", "audio/x-midi", "application/x-midi", "audio/x-mid" ],
        midi: [ "audio/midi", "music/crescendo", "x-music/x-midi", "audio/x-midi", "application/x-midi", "audio/x-mid" ],
        mif: [ "application/vnd.mif", "application/x-mif", "application/x-frame" ],
        mime: [ "message/rfc822", "www/mime" ],
        mj2: "video/mj2",
        mjf: "audio/x-vnd.audioexplosion.mjuicemediafile",
        mjpg: "video/x-motion-jpeg",
        mlp: "application/vnd.dolby.mlp",
        mm: [ "application/base64", "application/x-meme" ],
        mmd: "application/vnd.chipnuts.karaoke-mmd",
        mme: "application/base64",
        mmf: "application/vnd.smaf",
        mmr: "image/vnd.fujixerox.edmics-mmr",
        mny: "application/x-msmoney",
        mod: [ "audio/mod", "audio/x-mod" ],
        mods: "application/mods+xml",
        moov: "video/quicktime",
        mov: "video/quicktime",
        movie: "video/x-sgi-movie",
        mp2: [ "video/mpeg", "audio/mpeg", "video/x-mpeg", "audio/x-mpeg", "video/x-mpeq2a" ],
        mp3: [ "audio/mpeg", "audio/mpeg3", "video/mpeg", "audio/x-mpeg-3", "video/x-mpeg" ],
        mp4: [ "video/mp4", "application/mp4" ],
        mp4a: "audio/mp4",
        mpa: [ "video/mpeg", "audio/mpeg" ],
        mpc: [ "application/vnd.mophun.certificate", "application/x-project" ],
        mpe: "video/mpeg",
        mpeg: "video/mpeg",
        mpg: [ "video/mpeg", "audio/mpeg" ],
        mpga: "audio/mpeg",
        mpkg: "application/vnd.apple.installer+xml",
        mpm: "application/vnd.blueice.multipass",
        mpn: "application/vnd.mophun.application",
        mpp: "application/vnd.ms-project",
        mpt: "application/x-project",
        mpv: "application/x-project",
        mpv2: "video/mpeg",
        mpx: "application/x-project",
        mpy: "application/vnd.ibm.minipay",
        mqy: "application/vnd.mobius.mqy",
        mrc: "application/marc",
        mrcx: "application/marcxml+xml",
        ms: "application/x-troff-ms",
        mscml: "application/mediaservercontrol+xml",
        mseq: "application/vnd.mseq",
        msf: "application/vnd.epson.msf",
        msg: "application/vnd.ms-outlook",
        msh: "model/mesh",
        msl: "application/vnd.mobius.msl",
        msty: "application/vnd.muvee.style",
        mts: "model/vnd.mts",
        mus: "application/vnd.musician",
        musicxml: "application/vnd.recordare.musicxml+xml",
        mv: "video/x-sgi-movie",
        mvb: "application/x-msmediaview",
        mwf: "application/vnd.mfer",
        mxf: "application/mxf",
        mxl: "application/vnd.recordare.musicxml",
        mxml: "application/xv+xml",
        mxs: "application/vnd.triscape.mxs",
        mxu: "video/vnd.mpegurl",
        my: "audio/make",
        mzz: "application/x-vnd.audioexplosion.mzz",
        "n-gage": "application/vnd.nokia.n-gage.symbian.install",
        n3: "text/n3",
        nap: "image/naplps",
        naplps: "image/naplps",
        nbp: "application/vnd.wolfram.player",
        nc: "application/x-netcdf",
        ncm: "application/vnd.nokia.configuration-message",
        ncx: "application/x-dtbncx+xml",
        ngdat: "application/vnd.nokia.n-gage.data",
        nif: "image/x-niff",
        niff: "image/x-niff",
        nix: "application/x-mix-transfer",
        nlu: "application/vnd.neurolanguage.nlu",
        nml: "application/vnd.enliven",
        nnd: "application/vnd.noblenet-directory",
        nns: "application/vnd.noblenet-sealer",
        nnw: "application/vnd.noblenet-web",
        npx: "image/vnd.net-fpx",
        nsc: "application/x-conference",
        nsf: "application/vnd.lotus-notes",
        nvd: "application/x-navidoc",
        nws: "message/rfc822",
        o: "application/octet-stream",
        oa2: "application/vnd.fujitsu.oasys2",
        oa3: "application/vnd.fujitsu.oasys3",
        oas: "application/vnd.fujitsu.oasys",
        obd: "application/x-msbinder",
        oda: "application/oda",
        odb: "application/vnd.oasis.opendocument.database",
        odc: "application/vnd.oasis.opendocument.chart",
        odf: "application/vnd.oasis.opendocument.formula",
        odft: "application/vnd.oasis.opendocument.formula-template",
        odg: "application/vnd.oasis.opendocument.graphics",
        odi: "application/vnd.oasis.opendocument.image",
        odm: "application/vnd.oasis.opendocument.text-master",
        odp: "application/vnd.oasis.opendocument.presentation",
        ods: "application/vnd.oasis.opendocument.spreadsheet",
        odt: "application/vnd.oasis.opendocument.text",
        oga: "audio/ogg",
        ogv: "video/ogg",
        ogx: "application/ogg",
        omc: "application/x-omc",
        omcd: "application/x-omcdatamaker",
        omcr: "application/x-omcregerator",
        onetoc: "application/onenote",
        opf: "application/oebps-package+xml",
        org: "application/vnd.lotus-organizer",
        osf: "application/vnd.yamaha.openscoreformat",
        osfpvg: "application/vnd.yamaha.openscoreformat.osfpvg+xml",
        otc: "application/vnd.oasis.opendocument.chart-template",
        otf: "application/x-font-otf",
        otg: "application/vnd.oasis.opendocument.graphics-template",
        oth: "application/vnd.oasis.opendocument.text-web",
        oti: "application/vnd.oasis.opendocument.image-template",
        otp: "application/vnd.oasis.opendocument.presentation-template",
        ots: "application/vnd.oasis.opendocument.spreadsheet-template",
        ott: "application/vnd.oasis.opendocument.text-template",
        oxt: "application/vnd.openofficeorg.extension",
        p: "text/x-pascal",
        p10: [ "application/pkcs10", "application/x-pkcs10" ],
        p12: [ "application/pkcs-12", "application/x-pkcs12" ],
        p7a: "application/x-pkcs7-signature",
        p7b: "application/x-pkcs7-certificates",
        p7c: [ "application/pkcs7-mime", "application/x-pkcs7-mime" ],
        p7m: [ "application/pkcs7-mime", "application/x-pkcs7-mime" ],
        p7r: "application/x-pkcs7-certreqresp",
        p7s: [ "application/pkcs7-signature", "application/x-pkcs7-signature" ],
        p8: "application/pkcs8",
        par: "text/plain-bas",
        part: "application/pro_eng",
        pas: "text/pascal",
        paw: "application/vnd.pawaafile",
        pbd: "application/vnd.powerbuilder6",
        pbm: "image/x-portable-bitmap",
        pcf: "application/x-font-pcf",
        pcl: [ "application/vnd.hp-pcl", "application/x-pcl" ],
        pclxl: "application/vnd.hp-pclxl",
        pct: "image/x-pict",
        pcurl: "application/vnd.curl.pcurl",
        pcx: "image/x-pcx",
        pdb: [ "application/vnd.palm", "chemical/x-pdb" ],
        pdf: "application/pdf",
        pfa: "application/x-font-type1",
        pfr: "application/font-tdpfr",
        pfunk: [ "audio/make", "audio/make.my.funk" ],
        pfx: "application/x-pkcs12",
        pgm: [ "image/x-portable-graymap", "image/x-portable-greymap" ],
        pgn: "application/x-chess-pgn",
        pgp: "application/pgp-signature",
        pic: [ "image/pict", "image/x-pict" ],
        pict: "image/pict",
        pkg: "application/x-newton-compatible-pkg",
        pki: "application/pkixcmp",
        pkipath: "application/pkix-pkipath",
        pko: [ "application/ynd.ms-pkipko", "application/vnd.ms-pki.pko" ],
        pl: [ "text/plain", "text/x-script.perl" ],
        plb: "application/vnd.3gpp.pic-bw-large",
        plc: "application/vnd.mobius.plc",
        plf: "application/vnd.pocketlearn",
        pls: "application/pls+xml",
        plx: "application/x-pixclscript",
        pm: [ "text/x-script.perl-module", "image/x-xpixmap" ],
        pm4: "application/x-pagemaker",
        pm5: "application/x-pagemaker",
        pma: "application/x-perfmon",
        pmc: "application/x-perfmon",
        pml: [ "application/vnd.ctc-posml", "application/x-perfmon" ],
        pmr: "application/x-perfmon",
        pmw: "application/x-perfmon",
        png: "image/png",
        pnm: [ "application/x-portable-anymap", "image/x-portable-anymap" ],
        portpkg: "application/vnd.macports.portpkg",
        pot: [ "application/vnd.ms-powerpoint", "application/mspowerpoint" ],
        potm: "application/vnd.ms-powerpoint.template.macroenabled.12",
        potx: "application/vnd.openxmlformats-officedocument.presentationml.template",
        pov: "model/x-pov",
        ppa: "application/vnd.ms-powerpoint",
        ppam: "application/vnd.ms-powerpoint.addin.macroenabled.12",
        ppd: "application/vnd.cups-ppd",
        ppm: "image/x-portable-pixmap",
        pps: [ "application/vnd.ms-powerpoint", "application/mspowerpoint" ],
        ppsm: "application/vnd.ms-powerpoint.slideshow.macroenabled.12",
        ppsx: "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
        ppt: [ "application/vnd.ms-powerpoint", "application/mspowerpoint", "application/powerpoint", "application/x-mspowerpoint" ],
        pptm: "application/vnd.ms-powerpoint.presentation.macroenabled.12",
        pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ppz: "application/mspowerpoint",
        prc: "application/x-mobipocket-ebook",
        pre: [ "application/vnd.lotus-freelance", "application/x-freelance" ],
        prf: "application/pics-rules",
        prt: "application/pro_eng",
        ps: "application/postscript",
        psb: "application/vnd.3gpp.pic-bw-small",
        psd: [ "application/octet-stream", "image/vnd.adobe.photoshop" ],
        psf: "application/x-font-linux-psf",
        pskcxml: "application/pskc+xml",
        ptid: "application/vnd.pvi.ptid1",
        pub: "application/x-mspublisher",
        pvb: "application/vnd.3gpp.pic-bw-var",
        pvu: "paleovu/x-pv",
        pwn: "application/vnd.3m.post-it-notes",
        pwz: "application/vnd.ms-powerpoint",
        py: "text/x-script.phyton",
        pya: "audio/vnd.ms-playready.media.pya",
        pyc: "applicaiton/x-bytecode.python",
        pyv: "video/vnd.ms-playready.media.pyv",
        qam: "application/vnd.epson.quickanime",
        qbo: "application/vnd.intu.qbo",
        qcp: "audio/vnd.qcelp",
        qd3: "x-world/x-3dmf",
        qd3d: "x-world/x-3dmf",
        qfx: "application/vnd.intu.qfx",
        qif: "image/x-quicktime",
        qps: "application/vnd.publishare-delta-tree",
        qt: "video/quicktime",
        qtc: "video/x-qtc",
        qti: "image/x-quicktime",
        qtif: "image/x-quicktime",
        qxd: "application/vnd.quark.quarkxpress",
        ra: [ "audio/x-realaudio", "audio/x-pn-realaudio", "audio/x-pn-realaudio-plugin" ],
        ram: "audio/x-pn-realaudio",
        rar: "application/x-rar-compressed",
        ras: [ "image/cmu-raster", "application/x-cmu-raster", "image/x-cmu-raster" ],
        rast: "image/cmu-raster",
        rcprofile: "application/vnd.ipunplugged.rcprofile",
        rdf: "application/rdf+xml",
        rdz: "application/vnd.data-vision.rdz",
        rep: "application/vnd.businessobjects",
        res: "application/x-dtbresource+xml",
        rexx: "text/x-script.rexx",
        rf: "image/vnd.rn-realflash",
        rgb: "image/x-rgb",
        rif: "application/reginfo+xml",
        rip: "audio/vnd.rip",
        rl: "application/resource-lists+xml",
        rlc: "image/vnd.fujixerox.edmics-rlc",
        rld: "application/resource-lists-diff+xml",
        rm: [ "application/vnd.rn-realmedia", "audio/x-pn-realaudio" ],
        rmi: "audio/mid",
        rmm: "audio/x-pn-realaudio",
        rmp: [ "audio/x-pn-realaudio-plugin", "audio/x-pn-realaudio" ],
        rms: "application/vnd.jcp.javame.midlet-rms",
        rnc: "application/relax-ng-compact-syntax",
        rng: [ "application/ringing-tones", "application/vnd.nokia.ringing-tone" ],
        rnx: "application/vnd.rn-realplayer",
        roff: "application/x-troff",
        rp: "image/vnd.rn-realpix",
        rp9: "application/vnd.cloanto.rp9",
        rpm: "audio/x-pn-realaudio-plugin",
        rpss: "application/vnd.nokia.radio-presets",
        rpst: "application/vnd.nokia.radio-preset",
        rq: "application/sparql-query",
        rs: "application/rls-services+xml",
        rsd: "application/rsd+xml",
        rt: [ "text/richtext", "text/vnd.rn-realtext" ],
        rtf: [ "application/rtf", "text/richtext", "application/x-rtf" ],
        rtx: [ "text/richtext", "application/rtf" ],
        rv: "video/vnd.rn-realvideo",
        s: "text/x-asm",
        s3m: "audio/s3m",
        saf: "application/vnd.yamaha.smaf-audio",
        saveme: "application/octet-stream",
        sbk: "application/x-tbook",
        sbml: "application/sbml+xml",
        sc: "application/vnd.ibm.secure-container",
        scd: "application/x-msschedule",
        scm: [ "application/vnd.lotus-screencam", "video/x-scm", "text/x-script.guile", "application/x-lotusscreencam", "text/x-script.scheme" ],
        scq: "application/scvp-cv-request",
        scs: "application/scvp-cv-response",
        sct: "text/scriptlet",
        scurl: "text/vnd.curl.scurl",
        sda: "application/vnd.stardivision.draw",
        sdc: "application/vnd.stardivision.calc",
        sdd: "application/vnd.stardivision.impress",
        sdkm: "application/vnd.solent.sdkm+xml",
        sdml: "text/plain",
        sdp: [ "application/sdp", "application/x-sdp" ],
        sdr: "application/sounder",
        sdw: "application/vnd.stardivision.writer",
        sea: [ "application/sea", "application/x-sea" ],
        see: "application/vnd.seemail",
        seed: "application/vnd.fdsn.seed",
        sema: "application/vnd.sema",
        semd: "application/vnd.semd",
        semf: "application/vnd.semf",
        ser: "application/java-serialized-object",
        set: "application/set",
        setpay: "application/set-payment-initiation",
        setreg: "application/set-registration-initiation",
        "sfd-hdstx": "application/vnd.hydrostatix.sof-data",
        sfs: "application/vnd.spotfire.sfs",
        sgl: "application/vnd.stardivision.writer-global",
        sgm: [ "text/sgml", "text/x-sgml" ],
        sgml: [ "text/sgml", "text/x-sgml" ],
        sh: [ "application/x-shar", "application/x-bsh", "application/x-sh", "text/x-script.sh" ],
        shar: [ "application/x-bsh", "application/x-shar" ],
        shf: "application/shf+xml",
        shtml: [ "text/html", "text/x-server-parsed-html" ],
        sid: "audio/x-psid",
        sis: "application/vnd.symbian.install",
        sit: [ "application/x-stuffit", "application/x-sit" ],
        sitx: "application/x-stuffitx",
        skd: "application/x-koan",
        skm: "application/x-koan",
        skp: [ "application/vnd.koan", "application/x-koan" ],
        skt: "application/x-koan",
        sl: "application/x-seelogo",
        sldm: "application/vnd.ms-powerpoint.slide.macroenabled.12",
        sldx: "application/vnd.openxmlformats-officedocument.presentationml.slide",
        slt: "application/vnd.epson.salt",
        sm: "application/vnd.stepmania.stepchart",
        smf: "application/vnd.stardivision.math",
        smi: [ "application/smil", "application/smil+xml" ],
        smil: "application/smil",
        snd: [ "audio/basic", "audio/x-adpcm" ],
        snf: "application/x-font-snf",
        sol: "application/solids",
        spc: [ "text/x-speech", "application/x-pkcs7-certificates" ],
        spf: "application/vnd.yamaha.smaf-phrase",
        spl: [ "application/futuresplash", "application/x-futuresplash" ],
        spot: "text/vnd.in3d.spot",
        spp: "application/scvp-vp-response",
        spq: "application/scvp-vp-request",
        spr: "application/x-sprite",
        sprite: "application/x-sprite",
        src: "application/x-wais-source",
        sru: "application/sru+xml",
        srx: "application/sparql-results+xml",
        sse: "application/vnd.kodak-descriptor",
        ssf: "application/vnd.epson.ssf",
        ssi: "text/x-server-parsed-html",
        ssm: "application/streamingmedia",
        ssml: "application/ssml+xml",
        sst: [ "application/vnd.ms-pkicertstore", "application/vnd.ms-pki.certstore" ],
        st: "application/vnd.sailingtracker.track",
        stc: "application/vnd.sun.xml.calc.template",
        std: "application/vnd.sun.xml.draw.template",
        step: "application/step",
        stf: "application/vnd.wt.stf",
        sti: "application/vnd.sun.xml.impress.template",
        stk: "application/hyperstudio",
        stl: [ "application/vnd.ms-pkistl", "application/sla", "application/vnd.ms-pki.stl", "application/x-navistyle" ],
        stm: "text/html",
        stp: "application/step",
        str: "application/vnd.pg.format",
        stw: "application/vnd.sun.xml.writer.template",
        sub: "image/vnd.dvb.subtitle",
        sus: "application/vnd.sus-calendar",
        sv4cpio: "application/x-sv4cpio",
        sv4crc: "application/x-sv4crc",
        svc: "application/vnd.dvb.service",
        svd: "application/vnd.svd",
        svf: [ "image/vnd.dwg", "image/x-dwg" ],
        svg: "image/svg+xml",
        svr: [ "x-world/x-svr", "application/x-world" ],
        swf: "application/x-shockwave-flash",
        swi: "application/vnd.aristanetworks.swi",
        sxc: "application/vnd.sun.xml.calc",
        sxd: "application/vnd.sun.xml.draw",
        sxg: "application/vnd.sun.xml.writer.global",
        sxi: "application/vnd.sun.xml.impress",
        sxm: "application/vnd.sun.xml.math",
        sxw: "application/vnd.sun.xml.writer",
        t: [ "text/troff", "application/x-troff" ],
        talk: "text/x-speech",
        tao: "application/vnd.tao.intent-module-archive",
        tar: "application/x-tar",
        tbk: [ "application/toolbook", "application/x-tbook" ],
        tcap: "application/vnd.3gpp2.tcap",
        tcl: [ "text/x-script.tcl", "application/x-tcl" ],
        tcsh: "text/x-script.tcsh",
        teacher: "application/vnd.smart.teacher",
        tei: "application/tei+xml",
        tex: "application/x-tex",
        texi: "application/x-texinfo",
        texinfo: "application/x-texinfo",
        text: [ "application/plain", "text/plain" ],
        tfi: "application/thraud+xml",
        tfm: "application/x-tex-tfm",
        tgz: [ "application/gnutar", "application/x-compressed" ],
        thmx: "application/vnd.ms-officetheme",
        tif: [ "image/tiff", "image/x-tiff" ],
        tiff: [ "image/tiff", "image/x-tiff" ],
        tmo: "application/vnd.tmobile-livetv",
        torrent: "application/x-bittorrent",
        tpl: "application/vnd.groove-tool-template",
        tpt: "application/vnd.trid.tpt",
        tr: "application/x-troff",
        tra: "application/vnd.trueapp",
        trm: "application/x-msterminal",
        tsd: "application/timestamped-data",
        tsi: "audio/tsp-audio",
        tsp: [ "application/dsptype", "audio/tsplayer" ],
        tsv: "text/tab-separated-values",
        ttf: "application/x-font-ttf",
        ttl: "text/turtle",
        turbot: "image/florian",
        twd: "application/vnd.simtech-mindmapper",
        txd: "application/vnd.genomatix.tuxedo",
        txf: "application/vnd.mobius.txf",
        txt: "text/plain",
        ufd: "application/vnd.ufdl",
        uil: "text/x-uil",
        uls: "text/iuls",
        umj: "application/vnd.umajin",
        uni: "text/uri-list",
        unis: "text/uri-list",
        unityweb: "application/vnd.unity",
        unv: "application/i-deas",
        uoml: "application/vnd.uoml+xml",
        uri: "text/uri-list",
        uris: "text/uri-list",
        ustar: [ "application/x-ustar", "multipart/x-ustar" ],
        utz: "application/vnd.uiq.theme",
        uu: [ "application/octet-stream", "text/x-uuencode" ],
        uue: "text/x-uuencode",
        uva: "audio/vnd.dece.audio",
        uvh: "video/vnd.dece.hd",
        uvi: "image/vnd.dece.graphic",
        uvm: "video/vnd.dece.mobile",
        uvp: "video/vnd.dece.pd",
        uvs: "video/vnd.dece.sd",
        uvu: "video/vnd.uvvu.mp4",
        uvv: "video/vnd.dece.video",
        vcd: "application/x-cdlink",
        vcf: "text/x-vcard",
        vcg: "application/vnd.groove-vcard",
        vcs: "text/x-vcalendar",
        vcx: "application/vnd.vcx",
        vda: "application/vda",
        vdo: "video/vdo",
        vew: "application/groupwise",
        vis: "application/vnd.visionary",
        viv: [ "video/vivo", "video/vnd.vivo" ],
        vivo: [ "video/vivo", "video/vnd.vivo" ],
        vmd: "application/vocaltec-media-desc",
        vmf: "application/vocaltec-media-file",
        voc: [ "audio/voc", "audio/x-voc" ],
        vos: "video/vosaic",
        vox: "audio/voxware",
        vqe: "audio/x-twinvq-plugin",
        vqf: "audio/x-twinvq",
        vql: "audio/x-twinvq-plugin",
        vrml: [ "model/vrml", "x-world/x-vrml", "application/x-vrml" ],
        vrt: "x-world/x-vrt",
        vsd: [ "application/vnd.visio", "application/x-visio" ],
        vsf: "application/vnd.vsf",
        vst: "application/x-visio",
        vsw: "application/x-visio",
        vtu: "model/vnd.vtu",
        vxml: "application/voicexml+xml",
        w60: "application/wordperfect6.0",
        w61: "application/wordperfect6.1",
        w6w: "application/msword",
        wad: "application/x-doom",
        wav: [ "audio/wav", "audio/x-wav" ],
        wax: "audio/x-ms-wax",
        wb1: "application/x-qpro",
        wbmp: "image/vnd.wap.wbmp",
        wbs: "application/vnd.criticaltools.wbs+xml",
        wbxml: "application/vnd.wap.wbxml",
        wcm: "application/vnd.ms-works",
        wdb: "application/vnd.ms-works",
        web: "application/vnd.xara",
        weba: "audio/webm",
        webm: "video/webm",
        webp: "image/webp",
        wg: "application/vnd.pmi.widget",
        wgt: "application/widget",
        wiz: "application/msword",
        wk1: "application/x-123",
        wks: "application/vnd.ms-works",
        wm: "video/x-ms-wm",
        wma: "audio/x-ms-wma",
        wmd: "application/x-ms-wmd",
        wmf: [ "windows/metafile", "application/x-msmetafile" ],
        wml: "text/vnd.wap.wml",
        wmlc: "application/vnd.wap.wmlc",
        wmls: "text/vnd.wap.wmlscript",
        wmlsc: "application/vnd.wap.wmlscriptc",
        wmv: "video/x-ms-wmv",
        wmx: "video/x-ms-wmx",
        wmz: "application/x-ms-wmz",
        woff: "application/x-font-woff",
        word: "application/msword",
        wp: "application/wordperfect",
        wp5: [ "application/wordperfect", "application/wordperfect6.0" ],
        wp6: "application/wordperfect",
        wpd: [ "application/wordperfect", "application/vnd.wordperfect", "application/x-wpwin" ],
        wpl: "application/vnd.ms-wpl",
        wps: "application/vnd.ms-works",
        wq1: "application/x-lotus",
        wqd: "application/vnd.wqd",
        wri: [ "application/mswrite", "application/x-wri", "application/x-mswrite" ],
        wrl: [ "model/vrml", "x-world/x-vrml", "application/x-world" ],
        wrz: [ "model/vrml", "x-world/x-vrml" ],
        wsc: "text/scriplet",
        wsdl: "application/wsdl+xml",
        wspolicy: "application/wspolicy+xml",
        wsrc: "application/x-wais-source",
        wtb: "application/vnd.webturbo",
        wtk: "application/x-wintalk",
        wvx: "video/x-ms-wvx",
        "x-png": "image/png",
        x3d: "application/vnd.hzn-3d-crossword",
        xaf: "x-world/x-vrml",
        xap: "application/x-silverlight-app",
        xar: "application/vnd.xara",
        xbap: "application/x-ms-xbap",
        xbd: "application/vnd.fujixerox.docuworks.binder",
        xbm: [ "image/xbm", "image/x-xbm", "image/x-xbitmap" ],
        xdf: "application/xcap-diff+xml",
        xdm: "application/vnd.syncml.dm+xml",
        xdp: "application/vnd.adobe.xdp+xml",
        xdr: "video/x-amt-demorun",
        xdssc: "application/dssc+xml",
        xdw: "application/vnd.fujixerox.docuworks",
        xenc: "application/xenc+xml",
        xer: "application/patch-ops-error+xml",
        xfdf: "application/vnd.adobe.xfdf",
        xfdl: "application/vnd.xfdl",
        xgz: "xgl/drawing",
        xhtml: "application/xhtml+xml",
        xif: "image/vnd.xiff",
        xl: "application/excel",
        xla: [ "application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel" ],
        xlam: "application/vnd.ms-excel.addin.macroenabled.12",
        xlb: [ "application/excel", "application/vnd.ms-excel", "application/x-excel" ],
        xlc: [ "application/vnd.ms-excel", "application/excel", "application/x-excel" ],
        xld: [ "application/excel", "application/x-excel" ],
        xlk: [ "application/excel", "application/x-excel" ],
        xll: [ "application/excel", "application/vnd.ms-excel", "application/x-excel" ],
        xlm: [ "application/vnd.ms-excel", "application/excel", "application/x-excel" ],
        xls: [ "application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel" ],
        xlsb: "application/vnd.ms-excel.sheet.binary.macroenabled.12",
        xlsm: "application/vnd.ms-excel.sheet.macroenabled.12",
        xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        xlt: [ "application/vnd.ms-excel", "application/excel", "application/x-excel" ],
        xltm: "application/vnd.ms-excel.template.macroenabled.12",
        xltx: "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
        xlv: [ "application/excel", "application/x-excel" ],
        xlw: [ "application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel" ],
        xm: "audio/xm",
        xml: [ "application/xml", "text/xml", "application/atom+xml", "application/rss+xml" ],
        xmz: "xgl/movie",
        xo: "application/vnd.olpc-sugar",
        xof: "x-world/x-vrml",
        xop: "application/xop+xml",
        xpi: "application/x-xpinstall",
        xpix: "application/x-vnd.ls-xpix",
        xpm: [ "image/xpm", "image/x-xpixmap" ],
        xpr: "application/vnd.is-xpr",
        xps: "application/vnd.ms-xpsdocument",
        xpw: "application/vnd.intercon.formnet",
        xslt: "application/xslt+xml",
        xsm: "application/vnd.syncml+xml",
        xspf: "application/xspf+xml",
        xsr: "video/x-amt-showrun",
        xul: "application/vnd.mozilla.xul+xml",
        xwd: [ "image/x-xwd", "image/x-xwindowdump" ],
        xyz: [ "chemical/x-xyz", "chemical/x-pdb" ],
        yang: "application/yang",
        yin: "application/yin+xml",
        z: [ "application/x-compressed", "application/x-compress" ],
        zaz: "application/vnd.zzazz.deck+xml",
        zip: [ "application/zip", "multipart/x-zip", "application/x-zip-compressed", "application/x-compressed" ],
        zir: "application/vnd.zul",
        zmm: "application/vnd.handheld-entertainment+xml",
        zoo: "application/octet-stream",
        zsh: "text/x-script.zsh"
    };
    return {
        detectExtension: e,
        detectMimeType: t
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("utf7", t) : "object" == typeof exports ? module.exports = t() : e.utf7 = t();
}(this, function() {
    function e(e) {
        var t, n, i, o, s, r = new Uint8Array(2 * e.length), a = "";
        for (t = 0, n = 0, i = e.length; i > t; t++) o = e.charCodeAt(t), r[n++] = o >> 8, 
        r[n++] = 255 & o;
        for (t = 0, i = r.length; i > t; t++) a += String.fromCharCode(r[t]);
        return s = "", s = "undefined" != typeof window && btoa ? btoa(a) : new Buffer(a, "binary").toString("base64"), 
        s.replace(/=+$/, "");
    }
    function t(e) {
        for (var t, n, i = 0, o = 0, s = 0, r = new Uint8Array(Math.ceil(3 * e.length / 4)), a = 0, c = e.length; c > a; a++) {
            if (t = e.charCodeAt(a), t >= 65 && 90 >= t) n = t - 65; else if (t >= 97 && 122 >= t) n = t - 97 + 26; else if (t >= 48 && 57 >= t) n = t - 48 + 52; else if (43 === t) n = 62; else {
                if (47 !== t) {
                    if (61 === t) {
                        o = 0;
                        continue;
                    }
                    continue;
                }
                n = 63;
            }
            i = i << 6 | n, o += 6, o >= 8 && (o -= 8, r[s++] = i >> o, 2 === o ? i &= 3 : 4 === o && (i &= 15));
        }
        return s < r.length ? r.subarray(0, s) : r;
    }
    function n(e) {
        for (var n = t(e), i = [], o = 0, s = n.length; s > o; ) i.push(String.fromCharCode(n[o++] << 8 | n[o++]));
        return i.join("");
    }
    function i(e) {
        return e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
    }
    var o = "A-Za-z0-9" + i("'(),-./:?"), s = i("!\"#$%&*;<=>@[]^_'{|}"), r = i(" \r\n	"), a = {}, c = new RegExp("[^" + r + o + s + "]+", "g");
    return {
        encode: function(t, n) {
            return n || (n = ""), a[n] || (a[n] = new RegExp("[^" + o + i(n) + "]+", "g")), 
            t.replace(a[n], function(t) {
                return "+" + ("+" === t ? "" : e(t)) + "-";
            });
        },
        encodeAll: function(t) {
            return t.replace(c, function(t) {
                return "+" + ("+" === t ? "" : e(t)) + "-";
            });
        },
        decode: function(e) {
            return e.replace(/\+([A-Za-z0-9\/]*)-?/gi, function(e, t) {
                return "" === t ? "+" : n(t);
            });
        },
        imap: {
            encode: function(t) {
                return t.replace(/&/g, "&-").replace(/[^\x20-\x7e]+/g, function(t) {
                    return t = ("&" === t ? "" : e(t)).replace(/\//g, ","), "&" + t + "-";
                });
            },
            decode: function(e) {
                return e.replace(/&([^-]*)-/g, function(e, t) {
                    return "" === t ? "&" : n(t.replace(/,/g, "/"));
                });
            }
        }
    };
}), define("stringencoding", [ "require", "utf7", "mimefuncs" ], function(e) {
    var t = e("utf7");
    return {
        TextEncoder: function(e) {
            var t = new TextEncoder(e);
            this.encode = t.encode.bind(t);
        },
        TextDecoder: function(n) {
            if (n = n && n.toLowerCase(), "utf-7" === n || "utf7" === n) this.decode = function(n) {
                var i = e("mimefuncs");
                return t.decode(i.fromTypedArray(n));
            }; else {
                var i = new TextDecoder(n);
                this.decode = i.decode.bind(i);
            }
        }
    };
}), function(e, t) {
    var n;
    "function" == typeof define && define.amd ? define("mimefuncs", [ "stringencoding" ], function(n) {
        return t(n.TextEncoder, n.TextDecoder, e.btoa);
    }) : "object" == typeof exports && "undefined" != typeof navigator ? (n = require("wo-stringencoding"), 
    module.exports = t(n.TextEncoder, n.TextDecoder, e.btoa)) : "object" == typeof exports ? (n = require("wo-stringencoding"), 
    module.exports = t(n.TextEncoder, n.TextDecoder, function(e) {
        var t = require("buffer").Buffer;
        return new t(e, "binary").toString("base64");
    })) : e.mimefuncs = t(e.TextEncoder, e.TextDecoder, e.btoa);
}(this, function(e, t, n) {
    function i(e) {
        for (var t, n, i = String(e), o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", s = 0, r = o, a = ""; i.charAt(0 | s) || (r = "=", 
        s % 1); a += r.charAt(63 & t >> 8 - 8 * (s % 1))) {
            if (n = i.charCodeAt(s += .75), n > 255) throw new Error("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
            t = t << 8 | n;
        }
        return a;
    }
    n = n || i;
    var o = {
        mimeEncode: function(e, t) {
            t = t || "UTF-8";
            for (var n, i = o.charset.convert(e || "", t), s = [ [ 9 ], [ 10 ], [ 13 ], [ 32 ], [ 33 ], [ 35, 60 ], [ 62 ], [ 64, 94 ], [ 96, 126 ] ], r = "", a = 0, c = i.length; c > a; a++) n = i[a], 
            r += o._checkRanges(n, s) && (32 !== n && 9 !== n || a !== c - 1 && 10 !== i[a + 1] && 13 !== i[a + 1]) ? String.fromCharCode(n) : "=" + (16 > n ? "0" : "") + n.toString(16).toUpperCase();
            return r;
        },
        mimeDecode: function(e, t) {
            e = (e || "").toString(), t = t || "UTF-8";
            for (var n, i, s = (e.match(/\=[\da-fA-F]{2}/g) || []).length, r = e.length - 2 * s, a = new Uint8Array(r), c = 0, l = 0, d = e.length; d > l; l++) n = e.charAt(l), 
            "=" === n && (i = e.substr(l + 1, 2)) && /[\da-fA-F]{2}/.test(i) ? (a[c++] = parseInt(i, 16), 
            l += 2) : a[c++] = n.charCodeAt(0);
            return o.charset.decode(a, t);
        },
        base64Encode: function(e, t) {
            var n, i;
            return n = "binary" !== t && "string" != typeof e ? o.charset.convert(e || "", t) : e, 
            i = o.base64.encode(n), o._addSoftLinebreaks(i, "base64");
        },
        base64Decode: function(e, t) {
            var n = o.base64.decode(e || "", "buffer");
            return o.charset.decode(n, t);
        },
        quotedPrintableEncode: function(e, t) {
            var n = o.mimeEncode(e, t);
            return n = n.replace(/\r?\n|\r/g, "\r\n").replace(/[\t ]+$/gm, function(e) {
                return e.replace(/ /g, "=20").replace(/\t/g, "=09");
            }), o._addSoftLinebreaks(n, "qp");
        },
        quotedPrintableDecode: function(e, t) {
            return e = (e || "").toString(), e = e.replace(/[\t ]+$/gm, "").replace(/\=(?:\r?\n|$)/g, ""), 
            o.mimeDecode(e, t);
        },
        mimeWordEncode: function(e, t, n, i) {
            t = (t || "Q").toString().toUpperCase().trim().charAt(0), i || "string" != typeof n || n.match(/^[0-9]+$/) || (i = n, 
            n = void 0), n = n || 0;
            var s, r, a, c, l = "UTF-8";
            if (n && n > 7 + l.length && (n -= 7 + l.length), "Q" === t ? (s = o.mimeEncode(e, i), 
            s = s.replace(/[\r\n\t_]/g, function(e) {
                var t = e.charCodeAt(0);
                return "=" + (16 > t ? "0" : "") + t.toString(16).toUpperCase();
            }).replace(/\s/g, "_")) : "B" === t && (s = "string" == typeof e ? e : o.decode(e, i), 
            n = Math.max(3, 3 * ((n - n % 4) / 4))), n && s.length > n) if ("Q" === t) s = o._splitMimeEncodedString(s, n).join("?= =?" + l + "?" + t + "?"); else {
                for (c = [], r = 0, a = s.length; a > r; r += n) c.push(o.base64.encode(s.substr(r, n)));
                if (c.length > 1) return "=?" + l + "?" + t + "?" + c.join("?= =?" + l + "?" + t + "?") + "?=";
                s = c.join("");
            } else "B" === t && (s = o.base64.encode(s));
            return "=?" + l + "?" + t + "?" + s + ("?=" === s.substr(-2) ? "" : "?=");
        },
        mimeWordsEncode: function(e, t, n, i) {
            i || "string" != typeof n || n.match(/^[0-9]+$/) || (i = n, n = void 0), n = n || 0;
            var s, r = o.charset.decode(o.charset.convert(e || "", i));
            return s = r.replace(/([^\s\u0080-\uFFFF]*[\u0080-\uFFFF]+[^\s\u0080-\uFFFF]*(?:\s+[^\s\u0080-\uFFFF]*[\u0080-\uFFFF]+[^\s\u0080-\uFFFF]*\s*)?)+/g, function(e) {
                return e.length ? o.mimeWordEncode(e, t || "Q", n) : "";
            });
        },
        mimeWordDecode: function(e) {
            e = (e || "").toString().trim();
            var t, n, i;
            return (i = e.match(/^\=\?([\w_\-\*]+)\?([QqBb])\?([^\?]+)\?\=$/i)) ? (t = i[1].split("*").shift(), 
            n = (i[2] || "Q").toString().toUpperCase(), e = (i[3] || "").replace(/_/g, " "), 
            "B" === n ? o.base64Decode(e, t) : "Q" === n ? o.mimeDecode(e, t) : e) : e;
        },
        mimeWordsDecode: function(e) {
            return e = (e || "").toString(), e = e.replace(/(=\?[^?]+\?[QqBb]\?[^?]+\?=)\s+(?==\?[^?]+\?[QqBb]\?[^?]+\?=)/g, "$1").replace(/\=\?([\w_\-\*]+)\?([QqBb])\?[^\?]+\?\=/g, function(e) {
                return o.mimeWordDecode(e);
            });
        },
        foldLines: function(e, t, n) {
            e = (e || "").toString(), t = t || 76;
            for (var i, o, s = 0, r = e.length, a = ""; r > s; ) {
                if (i = e.substr(s, t), i.length < t) {
                    a += i;
                    break;
                }
                (o = i.match(/^[^\n\r]*(\r?\n|\r)/)) ? (i = o[0], a += i, s += i.length) : ((o = i.match(/(\s+)[^\s]*$/)) && o[0].length - (n ? (o[1] || "").length : 0) < i.length ? i = i.substr(0, i.length - (o[0].length - (n ? (o[1] || "").length : 0))) : (o = e.substr(s + i.length).match(/^[^\s]+(\s*)/)) && (i += o[0].substr(0, o[0].length - (n ? 0 : (o[1] || "").length))), 
                a += i, s += i.length, r > s && (a += "\r\n"));
            }
            return a;
        },
        headerLineEncode: function(e, t, n) {
            var i = o.mimeWordsEncode(t, "Q", 52, n);
            return o.foldLines(e + ": " + i, 76);
        },
        headerLineDecode: function(e) {
            var t = (e || "").toString().replace(/(?:\r?\n|\r)[ \t]*/g, " ").trim(), n = t.match(/^\s*([^:]+):(.*)$/), i = (n && n[1] || "").trim(), o = (n && n[2] || "").trim();
            return {
                key: i,
                value: o
            };
        },
        headerLinesDecode: function(e) {
            var t, n, i, s, r, a = e.split(/\r?\n|\r/), c = {};
            for (s = a.length - 1; s >= 0; s--) s && a[s].match(/^\s/) && (a[s - 1] += "\r\n" + a[s], 
            a.splice(s, 1));
            for (s = 0, r = a.length; r > s; s++) i = o.headerLineDecode(a[s]), t = (i.key || "").toString().toLowerCase().trim(), 
            n = i.value || "", c[t] = c[t] ? [].concat(c[t], n) : n;
            return c;
        },
        toTypedArray: function(e) {
            for (var t = new Uint8Array(e.length), n = 0, i = e.length; i > n; n++) t[n] = e.charCodeAt(n);
            return t;
        },
        fromTypedArray: function(e) {
            var t, n, i = "";
            for (e.buffer || (e = new Uint8Array(e)), t = 0, n = e.length; n > t; t++) i += String.fromCharCode(e[t]);
            return i;
        },
        parseHeaderValue: function(e) {
            for (var t, n = {
                value: !1,
                params: {}
            }, i = !1, o = "", s = "value", r = !1, a = !1, c = 0, l = e.length; l > c; c++) if (t = e.charAt(c), 
            "key" === s) {
                if ("=" === t) {
                    i = o.trim().toLowerCase(), s = "value", o = "";
                    continue;
                }
                o += t;
            } else {
                if (a) o += t; else {
                    if ("\\" === t) {
                        a = !0;
                        continue;
                    }
                    r && t === r ? r = !1 : r || '"' !== t ? r || ";" !== t ? o += t : (i === !1 ? n.value = o.trim() : n.params[i] = o.trim(), 
                    s = "key", o = "") : r = t;
                }
                a = !1;
            }
            return "value" === s ? i === !1 ? n.value = o.trim() : n.params[i] = o.trim() : o.trim() && (n.params[o.trim().toLowerCase()] = ""), 
            Object.keys(n.params).forEach(function(e) {
                var t, i, o, s;
                (o = e.match(/(\*(\d+)|\*(\d+)\*|\*)$/)) && (t = e.substr(0, o.index), i = Number(o[2] || o[3]) || 0, 
                n.params[t] && "object" == typeof n.params[t] || (n.params[t] = {
                    charset: !1,
                    values: []
                }), s = n.params[e], 0 === i && "*" === o[0].substr(-1) && (o = s.match(/^([^']*)'[^']*'(.*)$/)) && (n.params[t].charset = o[1] || "iso-8859-1", 
                s = o[2]), n.params[t].values[i] = s, delete n.params[e]);
            }), Object.keys(n.params).forEach(function(e) {
                var t;
                n.params[e] && Array.isArray(n.params[e].values) && (t = n.params[e].values.map(function(e) {
                    return e || "";
                }).join(""), n.params[e] = n.params[e].charset ? "=?" + n.params[e].charset + "?Q?" + t.replace(/[=\?_\s]/g, function(e) {
                    var t = e.charCodeAt(0).toString(16);
                    return " " === e ? "_" : "%" + (t.length < 2 ? "0" : "") + t;
                }).replace(/%/g, "=") + "?=" : t);
            }.bind(this)), n;
        },
        continuationEncode: function(e, t, n, i) {
            var s, r, a = [], c = "string" == typeof t ? t : o.decode(t, i), l = 0, d = !1;
            if (n = n || 50, /^[\w.\- ]*$/.test(t)) {
                if (c.length <= n) return [ {
                    key: e,
                    value: /[\s";=]/.test(c) ? '"' + c + '"' : c
                } ];
                c = c.replace(new RegExp(".{" + n + "}", "g"), function(e) {
                    return a.push({
                        line: e
                    }), "";
                }), c && a.push({
                    line: c
                });
            } else {
                r = "utf-8''", d = !0, l = 0;
                for (var u = 0, p = c.length; p > u; u++) {
                    if (s = c[u], d) s = encodeURIComponent(s); else if (s = " " === s ? s : encodeURIComponent(s), 
                    s !== c[u]) {
                        if (!((encodeURIComponent(r) + s).length >= n)) {
                            d = !0, u = l, r = "";
                            continue;
                        }
                        a.push({
                            line: r,
                            encoded: d
                        }), r = "", l = u - 1;
                    }
                    (r + s).length >= n ? (a.push({
                        line: r,
                        encoded: d
                    }), r = s = " " === c[u] ? " " : encodeURIComponent(c[u]), s === c[u] ? (d = !1, 
                    l = u - 1) : d = !0) : r += s;
                }
                r && a.push({
                    line: r,
                    encoded: d
                });
            }
            return a.map(function(t, n) {
                return {
                    key: e + "*" + n + (t.encoded ? "*" : ""),
                    value: /[\s";=]/.test(t.line) ? '"' + t.line + '"' : t.line
                };
            });
        },
        _splitMimeEncodedString: function(e, t) {
            var n, i, o, s, r = [];
            for (t = Math.max(t || 0, 12); e.length; ) {
                for (n = e.substr(0, t), (i = n.match(/\=[0-9A-F]?$/i)) && (n = n.substr(0, i.index)), 
                s = !1; !s; ) s = !0, (i = e.substr(n.length).match(/^\=([0-9A-F]{2})/i)) && (o = parseInt(i[1], 16), 
                194 > o && o > 127 && (n = n.substr(0, n.length - 3), s = !1));
                n.length && r.push(n), e = e.substr(n.length);
            }
            return r;
        },
        _addSoftLinebreaks: function(e, t) {
            var n = 76;
            return t = (t || "base64").toString().toLowerCase().trim(), "qp" === t ? o._addQPSoftLinebreaks(e, n) : o._addBase64SoftLinebreaks(e, n);
        },
        _addBase64SoftLinebreaks: function(e, t) {
            return e = (e || "").toString().trim(), e.replace(new RegExp(".{" + t + "}", "g"), "$&\r\n").trim();
        },
        _addQPSoftLinebreaks: function(e, t) {
            e = (e || "").toString(), t = t || 76;
            for (var n, i, o, s = 0, r = e.length, a = Math.floor(t / 3), c = ""; r > s; ) if (o = e.substr(s, t), 
            n = o.match(/\r\n/)) o = o.substr(0, n.index + n[0].length), c += o, s += o.length; else if ("\n" !== o.substr(-1)) if (n = o.substr(-a).match(/\n.*?$/)) o = o.substr(0, o.length - (n[0].length - 1)), 
            c += o, s += o.length; else {
                if (o.length > t - a && (n = o.substr(-a).match(/[ \t\.,!\?][^ \t\.,!\?]*$/))) o = o.substr(0, o.length - (n[0].length - 1)); else if ("\r" === o.substr(-1)) o = o.substr(0, o.length - 1); else if (o.match(/\=[\da-f]{0,2}$/i)) for ((n = o.match(/\=[\da-f]{0,1}$/i)) && (o = o.substr(0, o.length - n[0].length)); o.length > 3 && o.length < r - s && !o.match(/^(?:=[\da-f]{2}){1,4}$/i) && (n = o.match(/\=[\da-f]{2}$/gi)) && (i = parseInt(n[0].substr(1, 2), 16), 
                !(128 > i)) && (o = o.substr(0, o.length - 3), !(i >= 192)); ) ;
                s + o.length < r && "\n" !== o.substr(-1) ? (o.length === t && o.match(/\=[\da-f]{2}$/i) ? o = o.substr(0, o.length - 3) : o.length === t && (o = o.substr(0, o.length - 1)), 
                s += o.length, o += "=\r\n") : s += o.length, c += o;
            } else c += o, s += o.length;
            return c;
        },
        _checkRanges: function(e, t) {
            for (var n = t.length - 1; n >= 0; n--) if (t[n].length) {
                if (1 === t[n].length && e === t[n][0]) return !0;
                if (2 === t[n].length && e >= t[n][0] && e <= t[n][1]) return !0;
            }
            return !1;
        }
    };
    return o.charset = {
        encode: function(t) {
            return new e("UTF-8").encode(t);
        },
        decode: function(e, n) {
            n = o.charset.normalizeCharset(n || "UTF-8"), e.buffer || (e = new Uint8Array(e));
            try {
                return new t(n).decode(e);
            } catch (i) {
                return o.fromTypedArray(e);
            }
        },
        convert: function(e, t) {
            t = o.charset.normalizeCharset(t || "UTF-8");
            var n;
            return "string" != typeof e ? t.match(/^utf[\-_]?8$/) ? e : (n = o.charset.decode(e, t), 
            o.charset.encode(n)) : o.charset.encode(e);
        },
        normalizeCharset: function(e) {
            var t;
            return (t = e.match(/^utf[\-_]?(\d+)$/i)) ? "UTF-" + t[1] : (t = e.match(/^win[\-_]?(\d+)$/i)) ? "WINDOWS-" + t[1] : (t = e.match(/^latin[\-_]?(\d+)$/i)) ? "ISO-8859-" + t[1] : e;
        }
    }, o.base64 = {
        encode: function(e) {
            if (!e) return "";
            if ("string" == typeof e) return n(unescape(encodeURIComponent(e)));
            var t = e.byteLength, i = "";
            e.buffer || (e.buffer = new Uint8Array(e));
            for (var o = 0; t > o; o++) i += String.fromCharCode(e[o]);
            return n(i);
        },
        decode: function(e, t) {
            t = (t || "buffer").toLowerCase().trim();
            var n = o.base64.toTypedArray(e);
            return "string" === t ? o.charset.decode(n) : n;
        },
        toTypedArray: function(e) {
            for (var t, n, i = 0, o = 0, s = 0, r = new Uint8Array(Math.ceil(3 * e.length / 4)), a = 0, c = e.length; c > a; a++) {
                if (t = e.charCodeAt(a), t >= 65 && 90 >= t) n = t - 65; else if (t >= 97 && 122 >= t) n = t - 97 + 26; else if (t >= 48 && 57 >= t) n = t - 48 + 52; else if (43 === t) n = 62; else {
                    if (47 !== t) {
                        if (61 === t) {
                            o = 0;
                            continue;
                        }
                        continue;
                    }
                    n = 63;
                }
                i = i << 6 | n, o += 6, o >= 8 && (o -= 8, r[s++] = i >> o, 2 === o ? i &= 3 : 4 === o && (i &= 15));
            }
            return s < r.length ? r.subarray(0, s) : r;
        }
    }, o;
});