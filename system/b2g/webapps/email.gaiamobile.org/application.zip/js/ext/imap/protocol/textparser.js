define([ "mimeparser", "mimefuncs", "exports" ], function(e, n, t) {
    function s(n) {
        this._partDef = n;
        var t = this._parser = new e();
        this._totalBytes = 0;
        var s = "", r = "";
        n.params && n.params.charset && (s = '; charset="' + n.params.charset.toLowerCase() + '"'), 
        n.params && n.params.format && (r = '; format="' + n.params.format.toLowerCase() + '"'), 
        t.write("Content-Type: " + n.type.toLowerCase() + "/" + n.subtype.toLowerCase() + s + r + "\r\n"), 
        n.encoding && t.write("Content-Transfer-Encoding: " + n.encoding + "\r\n"), t.write("\r\n"), 
        n.pendingBuffer && this.parse(n.pendingBuffer);
    }
    s.prototype = {
        parse: function(e) {
            this._totalBytes += e.length, this._parser.write(e);
        },
        complete: function() {
            this._parser.end();
            var e = n.charset.decode(this._parser.node.content, "utf-8");
            return {
                bytesFetched: this._totalBytes,
                text: e
            };
        }
    }, t.TextParser = s;
});