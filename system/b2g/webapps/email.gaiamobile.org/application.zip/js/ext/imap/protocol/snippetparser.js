define([ "./textparser" ], function(e) {
    function n(e, n) {
        var t = new Uint8Array(e.byteLength + n.byteLength);
        return t.set(new Uint8Array(e), 0), t.set(new Uint8Array(n), e.byteLength), t.buffer;
    }
    function t() {
        r.apply(this, arguments);
    }
    var r = e.TextParser;
    return t.prototype = {
        parse: function(e) {
            this._buffer = this._buffer ? n(this._buffer, e) : e, r.prototype.parse.apply(this, arguments);
        },
        complete: function() {
            var e = r.prototype.complete.apply(this, arguments);
            return e.buffer = this._buffer, e;
        }
    }, {
        SnippetParser: t
    };
});