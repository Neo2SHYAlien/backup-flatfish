define([ "browserbox", "slog", "./client", "../syncbase", "exports" ], function(e, n, i, r, t) {
    function o(e) {
        return new Promise(function(n, i) {
            e.selectMailbox("INBOX", {
                readOnly: !0
            }, function(e, r) {
                e ? i(e) : n(r);
            });
        });
    }
    function u(e, i, t) {
        return new Promise(function(o) {
            function u(n) {
                e.search({
                    uid: Math.max(1, n - 49) + ":" + n
                }, {
                    byUid: !0
                }, function(e, i) {
                    if (i.length) a = i, s("uid", a.pop()); else {
                        var t = n - 50;
                        0 > t ? o(r.DEFAULT_TZ_OFFSET) : u(t);
                    }
                });
            }
            function s(i, t) {
                n.log("probe:imap:checking-tz", {
                    how: i,
                    id: t
                }), e.listMessages(t, [ "uid", "body.peek[header.fields (Received)]" ], {
                    byUid: "uid" === i
                }, function(e, u) {
                    if (e) return n.warn("probe:imap:timezone-fail", {}), o(r.DEFAULT_TZ_OFFSET), void 0;
                    var d = null, l = u[0]["body[header.fields (received)]"];
                    !e && u[0] && (d = c(l)), n.log("probe:imap:timezone", {
                        how: i,
                        tzMillis: d
                    }), null !== d ? o(d) : --f < 0 ? o(r.DEFAULT_TZ_OFFSET) : "uid" === i ? a.length ? s(a.pop()) : o(r.DEFAULT_TZ_OFFSET) : t > 1 ? s("seq", t - 1) : o(r.DEFAULT_TZ_OFFSET);
                });
            }
            var a = null, f = 32;
            "uid" === i ? u(t) : s("seq", t);
        });
    }
    t.probeAccount = function(e, t) {
        n.info("probe:imap:connecting", {
            connInfo: t
        });
        var c;
        return i.createImapConnection(e, t, function() {
            n.warn("probe:imap:credentials-updated");
        }).then(function(e) {
            return c = e, o(c);
        }).then(function(e) {
            return 0 === e.exists ? r.DEFAULT_TZ_OFFSET : e.uidNext ? u(c, "uid", e.uidNext - 1) : u(c, "seq", e.exists);
        }).then(function(e) {
            return n.info("probe:imap:success", {
                timezoneOffset: e / 36e5
            }), {
                conn: c,
                timezoneOffset: e
            };
        }).catch(function(e) {
            throw e = i.normalizeImapError(c, e), n.error("probe:imap:error", {
                error: e
            }), c && c.close(), e;
        });
    };
    var c = t.extractTZFromString = function(e) {
        var n = / ([+-]\d{4})/.exec(e);
        if (n) {
            var i = 1e3 * 60 * 60 * parseInt(n[1].substring(1, 3), 10) + 1e3 * 60 * parseInt(n[1].substring(3, 5), 10);
            return "-" === n[1].substring(0, 1) && (i *= -1), i;
        }
        return null;
    };
});