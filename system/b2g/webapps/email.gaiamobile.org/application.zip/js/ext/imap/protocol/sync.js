define([ "../imapchew", "../../allback", "exports" ], function(e, n, s) {
    function t(e) {
        this.storage = e.storage, this.connection = e.connection, this.knownHeaders = e.knownHeaders || [], 
        this.knownUIDs = e.knownUIDs || [], this.newUIDs = e.newUIDs || [], this._progress = e.initialProgress || .25, 
        this._progressCost = (this.knownUIDs.length ? r : 0) + a * this.knownUIDs.length + (this.newUIDs.length ? d : 0) + l * this.newUIDs.length, 
        this.onprogress = null, this.oncomplete = null, this._beginSync();
    }
    var o = [ "BODYSTRUCTURE", "INTERNALDATE", "FLAGS", "BODY.PEEK[HEADER.FIELDS (FROM TO CC BCC SUBJECT REPLY-TO MESSAGE-ID REFERENCES)]" ], i = [ "FLAGS" ], r = 20, a = 1, d = 20, l = 5;
    t.prototype = {
        _updateProgress: function(e) {
            this._progress += e, this.onprogress && this.onprogress(.25 + .75 * (this._progress / this._progressCost));
        },
        _beginSync: function() {
            var e = n.latch();
            this.newUIDs.length && this._handleNewUids(e.defer("new")), this.knownUIDs.length && this._handleKnownUids(e.defer("known")), 
            e.then(function() {
                this.oncomplete && this.oncomplete(this.newUIDs.length, this.knownUIDs.length);
            }.bind(this));
        },
        _handleNewUids: function(s) {
            var t = [], i = this;
            this.connection.listMessages(this.newUIDs, o, {
                byUid: !0
            }, function(o, r) {
                if (o) return console.warn("New UIDs fetch error, ideally harmless:", o), s(), void 0;
                var a = n.latch();
                r.forEach(function(n) {
                    var s = n.flags.indexOf("\\Recent");
                    -1 !== s && n.flags.splice(s, 1);
                    try {
                        var o = e.chewHeaderAndBodyStructure(n, i.storage.folderId, i.storage._issueNewHeaderId());
                        o.header.bytesToDownloadForBodyDisplay = e.calculateBytesToDownloadForImapBodyDisplay(o.bodyInfo), 
                        t.push(o), i.storage.addMessageHeader(o.header, o.bodyInfo, a.defer()), i.storage.addMessageBody(o.header, o.bodyInfo, a.defer());
                    } catch (r) {
                        console.warn("message problem, skipping message", r, "\n", r.stack);
                    }
                }.bind(this)), a.then(s);
            }.bind(this));
        },
        _handleKnownUids: function(e) {
            var s = this;
            this.connection.listMessages(s.knownUIDs, i, {
                byUid: !0
            }, function(t, o) {
                if (t) return console.warn("Known UIDs fetch error, ideally harmless:", t), e(), 
                void 0;
                var i = n.latch();
                o.forEach(function(e, n) {
                    console.log("FETCHED", n, "known id", s.knownHeaders[n].id, "known srvid", s.knownHeaders[n].srvid, "actual id", e.uid);
                    var t = e.flags.indexOf("\\Recent");
                    if (-1 !== t && e.flags.splice(t, 1), s.knownHeaders[n].srvid !== e.uid && (n = s.knownUIDs.indexOf(e.uid), 
                    -1 === n)) return console.warn("Server fetch reports unexpected message:", e.uid), 
                    void 0;
                    var o = s.knownHeaders[n], r = o.flags.slice();
                    r.sort(), e.flags.sort(), -1 === o.flags.indexOf("\\Seen") && -1 !== e.flags.indexOf("\\Seen") ? s.storage.folderMeta.unreadCount-- : -1 !== o.flags.indexOf("\\Seen") && -1 === e.flags.indexOf("\\Seen") && s.storage.folderMeta.unreadCount++, 
                    o.flags.toString() !== e.flags.toString() ? (console.warn('  FLAGS: "' + o.flags.toString() + '" VS "' + e.flags.toString() + '"'), 
                    o.flags = e.flags, s.storage.updateMessageHeader(o.date, o.id, !0, o, null, i.defer())) : s.storage.unchangedMessageHeader(o);
                }), s._updateProgress(r + a * s.knownUIDs.length), i.then(e);
            }.bind(this));
        }
    }, s.Sync = t;
});