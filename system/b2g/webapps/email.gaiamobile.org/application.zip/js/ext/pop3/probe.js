define([ "./pop3", "../syncbase", "slog", "../errorutils", "exports" ], function(e, t, n, s, i) {
    function a(e) {
        return e && e.name ? "bad-user-or-pass" === e.name && e.message && r.test(e.message) ? "pop3-disabled" : "bad-user-or-pass" === e.name && e.message && o.test(e.message) ? "pop3-disabled" : "unresponsive-server" === e.name && e.exception && e.exception.name && /security/i.test(e.exception.name) ? "bad-security" : ("unresponsive-server" === e.name || "bad-user-or-pass" === e.name) && e.message && /\[(LOGIN-DELAY|SYS|IN-USE)/i.test(e.message) ? "server-maintenance" : e.name : null;
    }
    i.probeAccount = function(s, i) {
        var a = {
            host: i.hostname,
            port: i.port,
            crypto: i.crypto,
            username: s.username,
            password: s.password,
            connTimeout: t.CONNECT_TIMEOUT_MS
        };
        n.info("probe:pop3:connecting", {
            connInfo: i
        });
        var r, o, l = new Promise(function(e, t) {
            r = e, o = t;
        }), c = new e.Pop3Client(a, function(e) {
            return e ? (o(e), void 0) : (c.protocol.sendRequest("UIDL", [ "1" ], !1, function(e, t) {
                t ? c.protocol.sendRequest("TOP", [ "1", "0" ], !0, function(e, t) {
                    t ? r(c) : e.err ? (n.error("probe:pop3:server-not-great", {
                        why: "no TOP"
                    }), o("pop-server-not-great")) : o(t.err);
                }) : c.protocol.sendRequest("UIDL", [], !0, function(e, t) {
                    t ? r(c) : e.err ? (n.error("probe:pop3:server-not-great", {
                        why: "no UIDL"
                    }), o("pop-server-not-great")) : o(t.err);
                });
            }), void 0);
        });
        return l.then(function(e) {
            return n.info("probe:pop3:success"), {
                conn: e,
                timezoneOffset: null
            };
        }).catch(function(e) {
            return e = d(e), n.info("probe:pop3:error", {
                error: e
            }), c && c.close(), Promise.reject(e);
        });
    };
    var r = /\[SYS\/PERM\] Your account is not enabled for POP/, o = /\[SYS\/PERM\] POP access is disabled for your domain\./, d = i.normalizePop3Error = function(e) {
        var t = a(e) || s.analyzeException(e) || "unknown";
        return n.log("probe:pop3:normalized-error", {
            error: e,
            reportAs: t
        }), t;
    };
});