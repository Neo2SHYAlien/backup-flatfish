define("errbackoff", [ "./date", "rdcommon/log", "module", "exports" ], function(e, t, n, o) {
    function i(e, t, n) {
        this.state = "healthy", this._iNextBackoff = 0, this._LOG = a.BackoffEndpoint(this, n, e), 
        this._LOG.state(this.state), this._badResources = {}, this.listener = t;
    }
    var r = o.BACKOFF_DURATIONS = [ {
        fixedMS: 0,
        randomMS: 0
    }, {
        fixedMS: 800,
        randomMS: 400
    }, {
        fixedMS: 4500,
        randomMS: 1e3
    } ], s = window.setTimeout.bind(window);
    o.TEST_useTimeoutFunc = function(e) {
        s = e;
        for (var t = 0; t < r.length; t++) r[t].randomMS = 0;
    }, i.prototype = {
        _setState: function(e) {
            this.state !== e && (this.state = e, this._LOG.state(e), this.listener && this.listener.onEndpointStateChange(e));
        },
        noteConnectSuccess: function() {
            this._setState("healthy"), this._iNextBackoff = 0;
        },
        noteConnectFailureMaybeRetry: function(e) {
            return this._LOG.connectFailure(e), "shutdown" === this.state ? !1 : e ? (this._setState("broken"), 
            !1) : (this._iNextBackoff > 0 && this._setState(e ? "broken" : "unreachable"), this._iNextBackoff >= r.length ? !1 : !0);
        },
        noteBrokenConnection: function() {
            this._LOG.connectFailure(!0), this._setState("broken"), this._iNextBackoff = r.length;
        },
        scheduleConnectAttempt: function(e) {
            if ("shutdown" !== this.state) {
                if (this._iNextBackoff >= r.length) return e(), void 0;
                var t = r[this._iNextBackoff++], n = t.fixedMS + Math.floor(Math.random() * t.randomMS);
                s(e, n);
            }
        },
        noteBadResource: function(t) {
            var n = e.NOW();
            if (this._badResources.hasOwnProperty(t)) {
                var o = this._badResources[t];
                o.count++, o.last = n;
            } else this._badResources[t] = {
                count: 1,
                last: n
            };
        },
        resourceIsOkayToUse: function(t) {
            return this._badResources.hasOwnProperty(t) ? (this._badResources[t], e.NOW(), void 0) : !0;
        },
        shutdown: function() {
            this._setState("shutdown");
        }
    }, o.createEndpoint = function(e, t, n) {
        return new i(e, t, n);
    };
    var a = o.LOGFAB = t.register(n, {
        BackoffEndpoint: {
            type: t.TASK,
            subtype: t.CLIENT,
            stateVars: {
                state: !1
            },
            events: {
                connectFailure: {
                    reachable: !0
                }
            },
            errors: {}
        }
    });
}), define("composite/incoming", [ "rdcommon/log", "../a64", "../accountmixins", "../mailslice", "../searchfilter", "../util", "../db/folder_info_rep", "require", "exports" ], function(e, t, n, o, i, r, s, a, c) {
    function u(e, t) {
        return e.path.localeCompare(t.path);
    }
    function d(e, t, n, i, r, s, a, c) {
        this.universe = t, this.compositeAccount = n, this.id = i, this.accountDef = n.accountDef, 
        this.enabled = !0, this._alive = !0, this._credentials = r, this._connInfo = s, 
        this._db = c;
        var u = this._folderStorages = {}, d = this.folders = [];
        this.FolderSyncer = e, this._deadFolderIds = null, this._folderInfos = a, this.meta = this._folderInfos.$meta, 
        this.mutations = this._folderInfos.$mutations;
        for (var l in a) if ("$" !== l[0]) {
            var h = a[l];
            u[l] = new o.FolderStorage(this, l, h, this._db, e, this._LOG), d.push(h.$meta);
        }
        this.folders.sort(function(e, t) {
            return e.path.localeCompare(t.path);
        });
        var p = this.getFirstFolderWithType("inbox");
        p || this._learnAboutFolder("INBOX", "INBOX", null, "inbox", "/", 0, !0);
    }
    var l = r.bsearchForInsert;
    c.CompositeIncomingAccount = d, d.prototype = {
        runOp: n.runOp,
        getFirstFolderWithType: n.getFirstFolderWithType,
        getFolderByPath: n.getFolderByPath,
        saveAccountState: n.saveAccountState,
        runAfterSaves: n.runAfterSaves,
        _learnAboutFolder: function(e, n, i, r, a, c, d) {
            var h = this.id + "/" + t.encodeInt(this.meta.nextFolderNum++), p = this._folderInfos[h] = {
                $meta: s.makeFolderMeta({
                    id: h,
                    name: e,
                    type: r,
                    path: n,
                    parentId: i,
                    delim: a,
                    depth: c,
                    lastSyncedAt: 0,
                    version: o.FOLDER_DB_VERSION
                }),
                $impl: {
                    nextId: 0,
                    nextHeaderBlock: 0,
                    nextBodyBlock: 0
                },
                accuracy: [],
                headerBlocks: [],
                bodyBlocks: [],
                serverIdHeaderBlockMapping: null
            };
            this._folderStorages[h] = new o.FolderStorage(this, h, p, this._db, this.FolderSyncer, this._LOG);
            var f = p.$meta, m = l(this.folders, f, u);
            return this.folders.splice(m, 0, f), d || this.universe.__notifyAddedFolder(this, f), 
            f;
        },
        _forgetFolder: function(e, t) {
            var n = this._folderInfos[e], o = n.$meta;
            delete this._folderInfos[e];
            var i = this._folderStorages[e];
            delete this._folderStorages[e];
            var r = this.folders.indexOf(o);
            this.folders.splice(r, 1), null === this._deadFolderIds && (this._deadFolderIds = []), 
            this._deadFolderIds.push(e), i.youAreDeadCleanupAfterYourself(), t || this.universe.__notifyRemovedFolder(this, o);
        },
        _recreateFolder: function(e, t) {
            this._LOG.recreateFolder(e);
            var n = this._folderInfos[e];
            n.$impl = {
                nextId: 0,
                nextHeaderBlock: 0,
                nextBodyBlock: 0
            }, n.accuracy = [], n.headerBlocks = [], n.bodyBlocks = [], null === this._deadFolderIds && (this._deadFolderIds = []), 
            this._deadFolderIds.push(e);
            var i = this;
            this.saveAccountState(null, function() {
                var r = new o.FolderStorage(i, e, n, i._db, i.FolderSyncer, i._LOG);
                for (var s in Iterator(i._folderStorages[e]._slices)) {
                    var a = s[1];
                    a._storage = r, a.reset(), r.sliceOpenMostRecent(a);
                }
                i._folderStorages[e]._slices = [], i._folderStorages[e] = r, t(r);
            }, "recreateFolder");
        },
        __checkpointSyncCompleted: function(e, t) {
            this.saveAccountState(null, e, t || "checkpointSync");
        },
        deleteFolder: function(e, t) {
            function n(e) {
                s = e, s.delBox(r.path, o);
            }
            function o(e) {
                e ? i("unknown") : i(null);
            }
            function i(n) {
                s && (a.__folderDoneWithConnection(s, !1, !1), s = null), n || (a._LOG.deleteFolder(r.path), 
                a._forgetFolder(e)), t && t(n, r);
            }
            if (!this._folderInfos.hasOwnProperty(e)) throw new Error("No such folder: " + e);
            if (!this.universe.online) return t && t("offline"), void 0;
            var r = this._folderInfos[e].$meta, s = null, a = this;
            this.__folderDemandsConnection(null, "deleteFolder", n);
        },
        getFolderStorageForFolderId: function(e) {
            if (this._folderStorages.hasOwnProperty(e)) return this._folderStorages[e];
            throw new Error("No folder with id: " + e);
        },
        getFolderStorageForMessageSuid: function(e) {
            var t = e.substring(0, e.lastIndexOf("/"));
            if (this._folderStorages.hasOwnProperty(t)) return this._folderStorages[t];
            throw new Error("No folder with id: " + t);
        },
        getFolderMetaForFolderId: function(e) {
            return this._folderInfos.hasOwnProperty(e) ? this._folderInfos[e].$meta : null;
        },
        sliceFolderMessages: function(e, t) {
            var n = this._folderStorages[e], i = new o.MailSlice(t, n, this._LOG);
            n.sliceOpenMostRecent(i);
        },
        searchFolderMessages: function(e, t, n, o) {
            var r = this._folderStorages[e], s = new i.SearchSlice(t, r, n, o, this._LOG);
            return r.sliceOpenSearch(s), s;
        },
        shutdownFolders: function() {
            for (var e = 0; e < this.folders.length; e++) {
                var t = this.folders[e], n = this._folderStorages[t.id];
                n.shutdown();
            }
        },
        scheduleMessagePurge: function(e, t) {
            this.universe.purgeExcessMessages(this.compositeAccount, e, t);
        },
        onEndpointStateChange: function(e) {
            switch (e) {
              case "healthy":
                this.universe.__removeAccountProblem(this.compositeAccount, "connection", "incoming");
                break;

              case "unreachable":
              case "broken":
                this.universe.__reportAccountProblem(this.compositeAccount, "connection", "incoming");
            }
        }
    }, c.LOGFAB_DEFINITION = {
        CompositeIncomingAccount: {
            type: e.ACCOUNT,
            events: {
                createFolder: {},
                deleteFolder: {},
                recreateFolder: {
                    id: !1
                },
                createConnection: {},
                reuseConnection: {},
                releaseConnection: {},
                deadConnection: {
                    why: !0
                },
                unknownDeadConnection: {},
                connectionMismatch: {},
                accountDeleted: {
                    where: !1
                },
                maximumConnsNoNew: {}
            },
            TEST_ONLY_events: {
                deleteFolder: {
                    path: !1
                },
                createConnection: {
                    label: !1
                },
                reuseConnection: {
                    label: !1
                },
                releaseConnection: {
                    folderId: !1,
                    label: !1
                },
                deadConnection: {
                    folder: !1
                },
                connectionMismatch: {}
            },
            errors: {
                connectionError: {},
                folderAlreadyHasConn: {
                    folderId: !1
                },
                opError: {
                    mode: !1,
                    type: !1,
                    ex: e.EXCEPTION
                }
            },
            asyncJobs: {
                checkAccount: {
                    err: null
                },
                runOp: {
                    mode: !0,
                    type: !0,
                    error: !0,
                    op: !1
                },
                saveAccountState: {
                    reason: !0,
                    folderSaveCount: !0
                }
            },
            TEST_ONLY_asyncJobs: {}
        }
    };
}), define("imap/folder", [ "rdcommon/log", "../a64", "../allback", "../date", "../syncbase", "../util", "module", "require", "exports" ], function(e, t, n, o, i, r, s, a, c) {
    function u(e) {
        for (var t = 0, n = e.length, o = 0; n > o; o++) {
            var i = e[o];
            null !== i ? t && (e[o - t] = i) : t++;
        }
        return t && e.splice(n - t, t), e;
    }
    function d(e) {
        return e = e || {}, e.not = {
            deleted: !0
        }, e;
    }
    function l(e, t, n) {
        this._account = e, this._storage = t, this._LOG = M.ImapFolderConn(this, n, t.folderId), 
        this._conn = null, this.box = null, this._deathback = null;
    }
    function h(e, t, n) {
        this._account = e, this.folderStorage = t, this._LOG = M.ImapFolderSyncer(this, n, t.folderId), 
        this._syncSlice = null, this._curSyncAccuracyStamp = null, this._curSyncDir = 1, 
        this._curSyncIsGrow = null, this._nextSyncAnchorTS = null, this._fallbackOriginTS = null, 
        this._syncThroughTS = null, this._curSyncDayStep = null, this._curSyncDoNotGrowBoundary = null, 
        this._curSyncDoneCallback = null, this.folderConn = new l(e, t, this._LOG);
    }
    function p() {}
    var f = null, m = null, g = null, _ = null, y = null, v = n.allbackMaker, b = (r.bsearchForInsert, 
    r.bsearchMaybeExists, r.cmpHeaderYoungToOld, o.DAY_MILLIS), S = o.NOW, T = (o.BEFORE, 
    o.ON_OR_BEFORE, o.SINCE), w = o.TIME_DIR_AT_OR_BEYOND, A = (o.TIME_DIR_ADD, o.TIME_DIR_DELTA, 
    o.makeDaysAgo), E = o.makeDaysBefore, C = o.quantizeDate, I = 1, O = -1, x = Math.pow(2, 32) - 1;
    l.prototype = {
        acquireConn: function(e, t, n, o) {
            var i = this;
            this._deathback = t, this._account.__folderDemandsConnection(this._storage.folderId, n, function(t) {
                i._conn = t, i._conn.selectMailbox(i._storage.folderMeta.path, function(t, n) {
                    if (t) {
                        if (console.error("Problem entering folder", i._storage.folderMeta.path), i._conn = null, 
                        i._account.__folderDoneWithConnection(i._conn, !1, !0), i._deathback) {
                            var o = i._deathback;
                            i.clearErrorHandler(), o();
                        }
                    } else i.box = n, e(i, i._storage);
                });
            }, function() {
                if (i._conn = null, i._deathback) {
                    var e = i._deathback;
                    i.clearErrorHandler(), e();
                }
            }, o);
        },
        relinquishConn: function() {
            this._conn && (this.clearErrorHandler(), this._account.__folderDoneWithConnection(this._conn, !0, !1), 
            this._conn = null);
        },
        withConnection: function(e, t, n, o) {
            return this._conn ? (this._deathback = t, e(this), void 0) : (this.acquireConn(function() {
                this.withConnection(e, t, n);
            }.bind(this), t, n, o), void 0);
        },
        clearErrorHandler: function() {
            this._deathback = null;
        },
        reselectBox: function(e) {
            this._conn.selectMailbox(this._storage.folderMeta.path, e);
        },
        _timelySyncSearch: function(e, t, n, o, i) {
            var r = !1;
            if (!this._conn) return this.acquireConn(this._timelySyncSearch.bind(this, e, t, n, o, i), n, "sync", !0), 
            void 0;
            if (!i) {
                var s = n;
                n = function() {
                    r ? s() : (console.warn("Broken connection for SEARCH. Retrying."), this._timelySyncSearch(e, t, s, o, !0));
                }.bind(this);
            }
            this._deathback = n, o && o(.1), this._account.isGmail && this._conn.exec("NOOP"), 
            this._conn.search(e, {
                byUid: !0
            }, function(o, i) {
                return r = !0, o ? (console.error("Search error on", e, "err:", o), n(), void 0) : (t(i), 
                void 0);
            });
        },
        syncDateRange: function() {
            var e = Array.slice(arguments), t = this;
            a([ "imap/protocol/sync" ], function(n) {
                y = n, (t.syncDateRange = t._lazySyncDateRange).apply(t, e);
            });
        },
        _lazySyncDateRange: function(e, t, n, o, r) {
            if (e && t && T(e, t)) return this._LOG.illegalSync(e, t), o("invariant"), void 0;
            console.log("syncDateRange:", e, t);
            var s = d(), a = this, c = a._storage, l = i.BISECT_DATE_AT_N_MESSAGES;
            e && (s.since = new Date(e)), t && (s.before = new Date(t));
            var h = v([ "search", "db" ], function(i) {
                var s = i.search, d = i.db, h = [], g = 0, _ = "";
                if (a.box.highestModseq && (_ = a.box.highestModseq + ""), console.log("SERVER UIDS", s.length, l), 
                s.length > l) {
                    var v = t || C(S() + b + a._account.tzOffset), T = Math.round((v - e) / b);
                    if (console.log("BISECT CASE", s.length, "curDaysDelta", T), T > 1) {
                        a._LOG.syncDateRange_end(null, null, null, e, t, null, null);
                        var w = {
                            oldStartTS: e,
                            oldEndTS: t,
                            numHeaders: s.length,
                            curDaysDelta: T,
                            newStartTS: e,
                            newEndTS: t
                        };
                        return "abort" === o("bisect", w, null) ? (a.clearErrorHandler(), o("bisect-aborted", null), 
                        null) : a.syncDateRange(w.newStartTS, w.newEndTS, n, o, r);
                    }
                }
                r && r(.25);
                for (var A = 0; A < d.length; A++) {
                    var E = d[A], I = s.indexOf(E.srvid);
                    -1 !== I ? (s[I] = null, h.push(E.srvid)) : (c.deleteMessageHeaderAndBodyUsingHeader(E), 
                    g++, d[A] = null);
                }
                var O = u(s);
                g && u(d);
                var x = new y.Sync({
                    connection: a._conn,
                    storage: a._storage,
                    newUIDs: O,
                    knownUIDs: h,
                    knownHeaders: d
                });
                x.onprogress = r, x.oncomplete = function(i, r) {
                    a._LOG.syncDateRange_end(i, r, g, e, t, null, null), a._storage.markSyncRange(e, t, _, n), 
                    m || (m = !0, a.clearErrorHandler(), o(null, null, i + r, p, f));
                };
            }), p = e - this._account.tzOffset, f = t ? t - this._account.tzOffset : null, m = !1;
            console.log("Skewed DB lookup. Start: ", p, new Date(p).toUTCString(), "End: ", f, f ? new Date(f).toUTCString() : null), 
            this._LOG.syncDateRange_begin(null, null, null, e, t, p, f), this._timelySyncSearch(s, h.search, function() {
                m || (m = !0, this._LOG.syncDateRange_end(0, 0, 0, e, t, null, null), o("aborted"));
            }.bind(this), r, !1), this._storage.getAllMessagesInImapDateRange(p, f, h.db);
        },
        downloadBodyReps: function() {
            var e = Array.slice(arguments), t = this;
            a([ "./imapchew", "./protocol/bodyfetcher", "./protocol/textparser", "./protocol/snippetparser" ], function(n, o, i, r) {
                _ = n, g = o, f = i, m = r, (t.downloadBodyReps = t._lazyDownloadBodyReps).apply(t, e);
            });
        },
        _lazyDownloadBodyReps: function(e, t, o) {
            "function" == typeof t && (o = t, t = null), t = t || {};
            var i = this, r = function(r) {
                var s = _.selectSnippetBodyRep(e, r), a = t.maximumBytesToFetch, c = f.TextParser, u = [], d = n.latch();
                if (r.bodyReps.forEach(function(t, n) {
                    if (!t.isDownloaded) {
                        var o = {
                            uid: e.srvid,
                            partInfo: t._partInfo,
                            bodyRepIndex: n,
                            createSnippet: n === s,
                            headerUpdatedCallback: d.defer(e.srvid + "-" + t._partInfo)
                        }, i = Math.min(5 * t.sizeEstimate, x);
                        if (void 0 !== a) {
                            if (c = m.SnippetParser, 0 >= a) return;
                            t.sizeEstimate > a && (i = a), a -= t.sizeEstimate;
                        }
                        0 >= i && (i = 64), (void 0 !== a || t.amountDownloaded) && (o.bytes = [ t.amountDownloaded, i ]), 
                        u.push(o);
                    }
                }), !u.length) return o(null, r), void 0;
                var l = new g.BodyFetcher(i._conn, c, u);
                i._handleBodyFetcher(l, e, r, d.defer("body")), d.then(function(e) {
                    o(n.extractErrFromCallbackArgs(e), r);
                });
            };
            this._storage.getMessageBody(e.suid, e.date, r);
        },
        _handleBodyFetcher: function(e, t, n, o) {
            var i = {
                changeDetails: {
                    bodyReps: []
                }
            };
            e.onparsed = function(e, o, r) {
                return e ? (o.headerUpdatedCallback(e), void 0) : (_.updateMessageWithFetch(t, n, o, r, this._LOG), 
                t.bytesToDownloadForBodyDisplay = _.calculateBytesToDownloadForImapBodyDisplay(n), 
                this._storage.updateMessageHeader(t.date, t.id, !1, t, n, o.headerUpdatedCallback.bind(null, null)), 
                i.changeDetails.bodyReps.push(o.bodyRepIndex), void 0);
            }.bind(this), e.onend = function() {
                this._storage.updateMessageBody(t, n, {}, i, o.bind(null, null));
            }.bind(this);
        },
        _lazyDownloadBodies: function(e, t, o) {
            for (var i = 0, r = n.latch(), s = 0; s < e.length; s++) {
                var a = e[s];
                a && null === a.snippet && (i++, this.downloadBodyReps(e[s], t, r.defer(a.suid)));
            }
            r.then(function(e) {
                o(n.extractErrFromCallbackArgs(e), i);
            });
        },
        downloadBodies: function() {
            var e = Array.slice(arguments), t = this;
            a([ "./imapchew", "./protocol/bodyfetcher", "./protocol/snippetparser" ], function(n, o, i) {
                _ = n, g = o, m = i, (t.downloadBodies = t._lazyDownloadBodies).apply(t, e);
            });
        },
        downloadMessageAttachments: function(e, t, o) {
            a([ "mimeparser" ], function(i) {
                var r = this._conn, s = n.latch(), a = null, c = [];
                t.forEach(function(t, n) {
                    var o = "body.peek[" + t.part + "]", u = s.defer(t.part);
                    r.listMessages(e, [ o ], {
                        byUid: !0
                    }, function(e, r) {
                        if (e) return a = e, console.error("attachments:download-error", {
                            error: e,
                            part: t.part,
                            type: t.type
                        }), u(), void 0;
                        var s, d = r[0];
                        for (var l in d) if (/body\[/.test(l)) {
                            s = d[l];
                            break;
                        }
                        if (!s) return console.error("attachments:download-error", {
                            error: "no body part?",
                            requestedPart: o,
                            responseKeys: Object.keys(d)
                        }), u(), void 0;
                        var h = new i();
                        h.write("Content-Type: " + t.type + "\r\n"), h.write("Content-Transfer-Encoding: " + t.encoding + "\r\n"), 
                        h.write("\r\n"), h.write(s), h.end();
                        var p = h.node;
                        c[n] = new Blob([ p.content ], {
                            type: p.contentType.value
                        }), u();
                    });
                }), s.then(function() {
                    o(a, c);
                });
            }.bind(this));
        },
        shutdown: function() {
            this._LOG.__die();
        }
    }, c.ImapFolderSyncer = h, h.prototype = {
        syncable: !0,
        get canGrowSync() {
            return !this.folderStorage.isLocalOnly;
        },
        initialSync: function(e, t, n, o, r) {
            n("sync", !1), this.folderConn.withConnection(function(n) {
                var s = !1;
                n && n.box && n.box.exists < i.SYNC_WHOLE_FOLDER_AT_N_MESSAGES && (s = !0), this._startSync(e, I, "grow", null, i.OLDEST_SYNC_DATE, null, s ? null : t, o, r);
            }.bind(this), function() {
                o("aborted");
            }, "initialSync", !0);
        },
        refreshSync: function(e, t, n, o, i, r, s) {
            this._startSync(e, t, "refresh", t === I ? o : n, t === I ? n : o, i, null, r, s);
        },
        growSync: function(e, t, n, o, r, s) {
            var a;
            a = t === I ? i.OLDEST_SYNC_DATE : null, this._startSync(e, t, "grow", n, a, null, o, r, s);
        },
        _startSync: function(e, t, n, o, i, r, s, a, c) {
            var u, d;
            this._syncSlice = e, this._curSyncAccuracyStamp = S(), this._curSyncDir = t, this._curSyncIsGrow = "grow" === n, 
            this._fallbackOriginTS = r, t === I ? (d = o, s ? this._nextSyncAnchorTS = u = d ? d - s * b : A(s, this._account.tzOffset) : (u = i, 
            this._nextSyncAnchorTS = null)) : (u = o, s ? this._nextSyncAnchorTS = d = u + s * b : (d = i, 
            this._nextSyncAnchorTS = null)), this._syncThroughTS = i, this._curSyncDayStep = s, 
            this._curSyncDoNotGrowBoundary = null, this._curSyncDoneCallback = a, this.folderConn.syncDateRange(u, d, this._curSyncAccuracyStamp, this.onSyncCompleted.bind(this), c);
        },
        _doneSync: function(e) {
            this._syncSlice.desiredHeaders = this._syncSlice.headers.length, this._account.__checkpointSyncCompleted(function() {
                this._curSyncDoneCallback && this._curSyncDoneCallback(e), this._syncSlice = null, 
                this._curSyncAccuracyStamp = null, this._curSyncDir = null, this._nextSyncAnchorTS = null, 
                this._syncThroughTS = null, this._curSyncDayStep = null, this._curSyncDoNotGrowBoundary = null, 
                this._curSyncDoneCallback = null;
            }.bind(this));
        },
        onSyncCompleted: function(e, t, n, o, r) {
            if ("bisect" === e) {
                var s = t.curDaysDelta, a = t.numHeaders;
                if (this._curSyncDir === O && this._fallbackOriginTS) {
                    this.folderStorage.clearSyncedToDawnOfTime(this._fallbackOriginTS), t.oldStartTS = this._fallbackOriginTS, 
                    this._fallbackOriginTS = null;
                    var c = t.oldEndTS || C(S() + b + this._account.tzOffset);
                    s = Math.round((c - t.oldStartTS) / b), a = 1.5 * i.BISECT_DATE_AT_N_MESSAGES;
                } else s > 1e3 && (s = 30);
                var u = i.BISECT_DATE_AT_N_MESSAGES / (2 * a), d = Math.max(1, Math.min(s - 2, Math.ceil(u * s)));
                return this._curSyncDayStep = d, this._curSyncDir === I ? (t.newEndTS = t.oldEndTS, 
                this._nextSyncAnchorTS = t.newStartTS = E(t.newEndTS, d, this._account.tzOffset), 
                this._curSyncDoNotGrowBoundary = t.oldStartTS) : (t.newStartTS = t.oldStartTS, this._nextSyncAnchorTS = t.newEndTS = E(t.newStartTS, -d, this._account.tzOffset), 
                this._curSyncDoNotGrowBoundary = t.oldEndTS), void 0;
            }
            if (e) return this._doneSync(e), void 0;
            if (console.log("Sync Completed!", this._curSyncDayStep, "days", n, "messages synced"), 
            this._syncSlice.isDead) return this._doneSync(), void 0;
            var l = this.folderConn && this.folderConn.box && this.folderConn.box.exists, h = this.folderStorage.getKnownMessageCount(), p = this._curSyncDir === I ? o : r;
            if (console.log("folder message count", l, "dbCount", h, "syncedThrough", p, "oldest known", this.folderStorage.getOldestMessageTimestamp()), 
            this._curSyncDir === I && l === h && (!l || w(this._curSyncDir, p, this.folderStorage.getOldestMessageTimestamp()))) return this.folderStorage.markSyncedToDawnOfTime(), 
            this._doneSync(), void 0;
            if (!this._nextSyncAnchorTS || w(this._curSyncDir, this._nextSyncAnchorTS, this._syncThroughTS)) return this._doneSync(), 
            void 0;
            if (this._curSyncIsGrow && this._syncSlice.headers.length >= this._syncSlice.desiredHeaders) return console.log("SYNCDONE Enough headers retrieved.", "have", this._syncSlice.headers.length, "want", this._syncSlice.desiredHeaders, "conn knows about", this.folderConn.box.exists, "sync date", this._curSyncStartTS, "[oldest defined as", i.OLDEST_SYNC_DATE, "]"), 
            this._doneSync(), void 0;
            var f, m;
            n || null !== this._curSyncDoNotGrowBoundary && !w(this._curSyncDir, this._nextSyncAnchorTS, this._curSyncDoNotGrowBoundary) ? f = this._curSyncDayStep : (this._curSyncDoNotGrowBoundary = null, 
            m = (C(S() + this._account.tzOffset) - this._nextSyncAnchorTS) / b, f = Math.ceil(this._curSyncDayStep * i.TIME_SCALE_FACTOR_ON_NO_MESSAGES), 
            180 > m ? f > 45 && (f = 45) : 365 > m ? f > 90 && (f = 90) : 730 > m ? f > 120 && (f = 120) : 1825 > m ? f > 180 && (f = 180) : 3650 > m ? f > 365 && (f = 365) : f > 730 && (f = 730), 
            this._curSyncDayStep = f);
            var g, _;
            this._curSyncDir === I ? (_ = this._nextSyncAnchorTS, this._nextSyncAnchorTS = g = E(_, f, this._account.tzOffset)) : (g = this._nextSyncAnchorTS, 
            this._nextSyncAnchorTS = _ = E(g, -f, this._account.tzOffset)), this.folderConn.syncDateRange(g, _, this._curSyncAccuracyStamp, this.onSyncCompleted.bind(this));
        },
        allConsumersDead: function() {
            this.folderConn.relinquishConn();
        },
        shutdown: function() {
            this.folderConn.shutdown(), this._LOG.__die();
        }
    }, p.prototype = {};
    var M = c.LOGFAB = e.register(s, {
        ImapFolderConn: {
            type: e.CONNECTION,
            subtype: e.CLIENT,
            events: {},
            TEST_ONLY_events: {},
            errors: {
                callbackErr: {
                    ex: e.EXCEPTION
                },
                htmlParseError: {
                    ex: e.EXCEPTION
                },
                htmlSnippetError: {
                    ex: e.EXCEPTION
                },
                textChewError: {
                    ex: e.EXCEPTION
                },
                textSnippetError: {
                    ex: e.EXCEPTION
                },
                illegalSync: {
                    startTS: !1,
                    endTS: !1
                }
            },
            asyncJobs: {
                syncDateRange: {
                    newMessages: !0,
                    existingMessages: !0,
                    deletedMessages: !0,
                    start: !1,
                    end: !1,
                    skewedStart: !1,
                    skewedEnd: !1
                }
            }
        },
        ImapFolderSyncer: {
            type: e.DATABASE,
            events: {}
        }
    });
}), function(e, t) {
    "function" == typeof define && define.amd ? define("mimeparser-tzabbr", t) : "object" == typeof exports ? module.exports = t() : e.tzabbr = t();
}(this, function() {
    return {
        ACDT: "+1030",
        ACST: "+0930",
        ACT: "+0800",
        ADT: "-0300",
        AEDT: "+1100",
        AEST: "+1000",
        AFT: "+0430",
        AKDT: "-0800",
        AKST: "-0900",
        AMST: "-0300",
        AMT: "+0400",
        ART: "-0300",
        AST: "+0300",
        AWDT: "+0900",
        AWST: "+0800",
        AZOST: "-0100",
        AZT: "+0400",
        BDT: "+0800",
        BIOT: "+0600",
        BIT: "-1200",
        BOT: "-0400",
        BRT: "-0300",
        BST: "+0600",
        BTT: "+0600",
        CAT: "+0200",
        CCT: "+0630",
        CDT: "-0500",
        CEDT: "+0200",
        CEST: "+0200",
        CET: "+0100",
        CHADT: "+1345",
        CHAST: "+1245",
        CHOT: "+0800",
        CHST: "+1000",
        CHUT: "+1000",
        CIST: "-0800",
        CIT: "+0800",
        CKT: "-1000",
        CLST: "-0300",
        CLT: "-0400",
        COST: "-0400",
        COT: "-0500",
        CST: "-0600",
        CT: "+0800",
        CVT: "-0100",
        CWST: "+0845",
        CXT: "+0700",
        DAVT: "+0700",
        DDUT: "+1000",
        DFT: "+0100",
        EASST: "-0500",
        EAST: "-0600",
        EAT: "+0300",
        ECT: "-0500",
        EDT: "-0400",
        EEDT: "+0300",
        EEST: "+0300",
        EET: "+0200",
        EGST: "+0000",
        EGT: "-0100",
        EIT: "+0900",
        EST: "-0500",
        FET: "+0300",
        FJT: "+1200",
        FKST: "-0300",
        FKT: "-0400",
        FNT: "-0200",
        GALT: "-0600",
        GAMT: "-0900",
        GET: "+0400",
        GFT: "-0300",
        GILT: "+1200",
        GIT: "-0900",
        GMT: "+0000",
        GST: "+0400",
        GYT: "-0400",
        HADT: "-0900",
        HAEC: "+0200",
        HAST: "-1000",
        HKT: "+0800",
        HMT: "+0500",
        HOVT: "+0700",
        HST: "-1000",
        ICT: "+0700",
        IDT: "+0300",
        IOT: "+0300",
        IRDT: "+0430",
        IRKT: "+0900",
        IRST: "+0330",
        IST: "+0530",
        JST: "+0900",
        KGT: "+0600",
        KOST: "+1100",
        KRAT: "+0700",
        KST: "+0900",
        LHST: "+1030",
        LINT: "+1400",
        MAGT: "+1200",
        MART: "-0930",
        MAWT: "+0500",
        MDT: "-0600",
        MET: "+0100",
        MEST: "+0200",
        MHT: "+1200",
        MIST: "+1100",
        MIT: "-0930",
        MMT: "+0630",
        MSK: "+0400",
        MST: "-0700",
        MUT: "+0400",
        MVT: "+0500",
        MYT: "+0800",
        NCT: "+1100",
        NDT: "-0230",
        NFT: "+1130",
        NPT: "+0545",
        NST: "-0330",
        NT: "-0330",
        NUT: "-1100",
        NZDT: "+1300",
        NZST: "+1200",
        OMST: "+0700",
        ORAT: "+0500",
        PDT: "-0700",
        PET: "-0500",
        PETT: "+1200",
        PGT: "+1000",
        PHOT: "+1300",
        PHT: "+0800",
        PKT: "+0500",
        PMDT: "-0200",
        PMST: "-0300",
        PONT: "+1100",
        PST: "-0800",
        PYST: "-0300",
        PYT: "-0400",
        RET: "+0400",
        ROTT: "-0300",
        SAKT: "+1100",
        SAMT: "+0400",
        SAST: "+0200",
        SBT: "+1100",
        SCT: "+0400",
        SGT: "+0800",
        SLST: "+0530",
        SRT: "-0300",
        SST: "+0800",
        SYOT: "+0300",
        TAHT: "-1000",
        THA: "+0700",
        TFT: "+0500",
        TJT: "+0500",
        TKT: "+1300",
        TLT: "+0900",
        TMT: "+0500",
        TOT: "+1300",
        TVT: "+1200",
        UCT: "+0000",
        ULAT: "+0800",
        UTC: "+0000",
        UYST: "-0200",
        UYT: "-0300",
        UZT: "+0500",
        VET: "-0430",
        VLAT: "+1000",
        VOLT: "+0400",
        VOST: "+0600",
        VUT: "+1100",
        WAKT: "+1200",
        WAST: "+0200",
        WAT: "+0100",
        WEDT: "+0100",
        WEST: "+0100",
        WET: "+0000",
        WST: "+0800",
        YAKT: "+1000",
        YEKT: "+0600",
        Z: "+0000"
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("mimeparser", [ "mimefuncs", "addressparser", "mimeparser-tzabbr" ], t) : "object" == typeof exports ? module.exports = t(require("mimefuncs"), require("wo-addressparser"), require("./mimeparser-tzabbr")) : e.MimeParser = t(e.mimefuncs, e.addressparser, e.tzabbr);
}(this, function(e, t, n) {
    function o() {
        this.running = !0, this.nodes = {}, this.node = new i(null, this), this._remainder = "";
    }
    function i(e, t) {
        this.header = [], this.headers = {}, this.path = e ? e.path.concat(e._childNodes.length + 1) : [], 
        this._parser = t, this._parentNode = e, this._state = "HEADER", this._bodyBuffer = "", 
        this._lineCount = 0, this._childNodes = !1, this._currentChild = !1, this._lineRemainder = "", 
        this._isMultipart = !1, this._multipartBoundary = !1, this._isRfc822 = !1, this.raw = "", 
        this._parser.nodes["node" + this.path.join(".")] = this;
    }
    return o.prototype.write = function(t) {
        if (!t || !t.length) return !this.running;
        var n = (this._remainder + ("object" == typeof t ? e.fromTypedArray(t) : t)).split(/\r?\n/g);
        this._remainder = n.pop();
        for (var o = 0, i = n.length; i > o; o++) this.node.writeLine(n[o]);
        return !this.running;
    }, o.prototype.end = function(e) {
        e && e.length && this.write(e), (this.node._lineCount || this._remainder) && (this.node.writeLine(this._remainder), 
        this._remainder = ""), this.node && this.node.finalize(), this.onend();
    }, o.prototype.getNode = function(e) {
        return e = e || "", this.nodes["node" + e] || null;
    }, o.prototype.onend = function() {}, o.prototype.onheader = function() {}, o.prototype.onbody = function() {}, 
    i.prototype.writeLine = function(e) {
        this.raw += (this.raw ? "\n" : "") + e, "HEADER" === this._state ? this._processHeaderLine(e) : "BODY" === this._state && this._processBodyLine(e);
    }, i.prototype.finalize = function() {
        this._isRfc822 ? this._currentChild.finalize() : this._emitBody(!0);
    }, i.prototype._processHeaderLine = function(e) {
        return e ? (e.match(/^\s/) && this.header.length ? this.header[this.header.length - 1] += "\n" + e : this.header.push(e), 
        void 0) : (this._parseHeaders(), this._parser.onheader(this), this._state = "BODY", 
        void 0);
    }, i.prototype._parseHeaders = function() {
        for (var t, n, o, i = 0, r = this.header.length; r > i; i++) n = this.header[i].split(":"), 
        t = (n.shift() || "").trim().toLowerCase(), n = (n.join(":") || "").replace(/\n/g, "").trim(), 
        n.match(/[\u0080-\uFFFF]/) && (this.charset || (o = !0), n = e.charset.decode(e.charset.convert(e.toTypedArray(n), this.charset || "iso-8859-1"))), 
        this.headers[t] ? this.headers[t].push(this._parseHeaderValue(t, n)) : this.headers[t] = [ this._parseHeaderValue(t, n) ], 
        this.charset || "content-type" !== t || (this.charset = this.headers[t][this.headers[t].length - 1].params.charset), 
        o && this.charset && (o = !1, this.headers = {}, i = -1);
        this._processContentType(), this._processContentTransferEncoding();
    }, i.prototype._parseHeaderValue = function(n, o) {
        var i, r = !1;
        switch (n) {
          case "content-type":
          case "content-transfer-encoding":
          case "content-disposition":
          case "dkim-signature":
            i = e.parseHeaderValue(o);
            break;

          case "from":
          case "sender":
          case "to":
          case "reply-to":
          case "cc":
          case "bcc":
          case "abuse-reports-to":
          case "errors-to":
          case "return-path":
          case "delivered-to":
            r = !0, i = {
                value: [].concat(t.parse(o) || [])
            };
            break;

          case "date":
            i = {
                value: this._parseDate(o)
            };
            break;

          default:
            i = {
                value: o
            };
        }
        return i.initial = o, this._decodeHeaderCharset(i, {
            isAddress: r
        }), i;
    }, i.prototype._parseDate = function(e) {
        e = (e || "").toString().trim();
        var t = new Date(e);
        return this._isValidDate(t) ? t.toUTCString().replace(/GMT/, "+0000") : (e = e.replace(/\b[a-z]+$/i, function(e) {
            return e = e.toUpperCase(), n.hasOwnProperty(e) ? n[e] : e;
        }), t = new Date(e), this._isValidDate(t) ? t.toUTCString().replace(/GMT/, "+0000") : e);
    }, i.prototype._isValidDate = function(e) {
        return "[object Date]" === Object.prototype.toString.call(e) && "Invalid Date" !== e.toString();
    }, i.prototype._decodeHeaderCharset = function(t, n) {
        return n = n || {}, "string" == typeof t.value && (t.value = e.mimeWordsDecode(t.value)), 
        Object.keys(t.params || {}).forEach(function(n) {
            "string" == typeof t.params[n] && (t.params[n] = e.mimeWordsDecode(t.params[n]));
        }), n.isAddress && Array.isArray(t.value) && t.value.forEach(function(t) {
            t.name && (t.name = e.mimeWordsDecode(t.name), Array.isArray(t.group) && this._decodeHeaderCharset({
                value: t.group
            }, {
                isAddress: !0
            }));
        }.bind(this)), t;
    }, i.prototype._processContentType = function() {
        var t;
        this.contentType = this.headers["content-type"] && this.headers["content-type"][0] || e.parseHeaderValue("text/plain"), 
        this.contentType.value = (this.contentType.value || "").toLowerCase().trim(), this.contentType.type = this.contentType.value.split("/").shift() || "text", 
        this.contentType.params && this.contentType.params.charset && !this.charset && (this.charset = this.contentType.params.charset), 
        "multipart" === this.contentType.type && this.contentType.params.boundary && (this._childNodes = [], 
        this._isMultipart = this.contentType.value.split("/").pop() || "mixed", this._multipartBoundary = this.contentType.params.boundary), 
        "message/rfc822" === this.contentType.value && (t = this.headers["content-disposition"] && this.headers["content-disposition"][0] || e.parseHeaderValue(""), 
        "attachment" !== (t.value || "").toLowerCase().trim() && (this._childNodes = [], 
        this._currentChild = new i(this, this._parser), this._childNodes.push(this._currentChild), 
        this._isRfc822 = !0));
    }, i.prototype._processContentTransferEncoding = function() {
        this.contentTransferEncoding = this.headers["content-transfer-encoding"] && this.headers["content-transfer-encoding"][0] || e.parseHeaderValue("7bit"), 
        this.contentTransferEncoding.value = (this.contentTransferEncoding.value || "").toLowerCase().trim();
    }, i.prototype._processBodyLine = function(t) {
        var n, o;
        if (this._lineCount++, this._isMultipart) t === "--" + this._multipartBoundary ? (this._currentChild && this._currentChild.finalize(), 
        this._currentChild = new i(this, this._parser), this._childNodes.push(this._currentChild)) : t === "--" + this._multipartBoundary + "--" ? (this._currentChild && this._currentChild.finalize(), 
        this._currentChild = !1) : this._currentChild && this._currentChild.writeLine(t); else if (this._isRfc822) this._currentChild.writeLine(t); else switch (this.contentTransferEncoding.value) {
          case "base64":
            n = this._lineRemainder + t.trim(), n.length % 4 ? (this._lineRemainder = n.substr(-n.length % 4), 
            n = n.substr(0, n.length - this._lineRemainder.length)) : this._lineRemainder = "", 
            n.length && (this._bodyBuffer += e.fromTypedArray(e.base64.decode(n)));
            break;

          case "quoted-printable":
            n = this._lineRemainder + (this._lineCount > 1 ? "\n" : "") + t, (o = n.match(/=[a-f0-9]{0,1}$/i)) ? (this._lineRemainder = o[0], 
            n = n.substr(0, n.length - this._lineRemainder.length)) : this._lineRemainder = "", 
            this._bodyBuffer += n.replace(/\=(\r?\n|$)/g, "").replace(/=([a-f0-9]{2})/gi, function(e, t) {
                return String.fromCharCode(parseInt(t, 16));
            });
            break;

          default:
            this._bodyBuffer += (this._lineCount > 1 ? "\n" : "") + t;
        }
    }, i.prototype._emitBody = function() {
        var t, n = this.headers["content-disposition"] && this.headers["content-disposition"][0] || e.parseHeaderValue("");
        !this._isMultipart && this._bodyBuffer && (/^text\/(plain|html)$/i.test(this.contentType.value) && this.contentType.params && /^flowed$/i.test(this.contentType.params.format) && (t = /^yes$/i.test(this.contentType.params.delsp), 
        this._bodyBuffer = this._bodyBuffer.split("\n").reduce(function(e, n) {
            var o = e;
            return t && (o = o.replace(/[ ]+$/, "")), / $/.test(e) && !/(^|\n)\-\- $/.test(e) ? o + n : o + "\n" + n;
        }).replace(/^ /gm, "")), this.content = e.toTypedArray(this._bodyBuffer), /^text\/(plain|html)$/i.test(this.contentType.value) && !/^attachment$/i.test(n.value) && (!this.charset && /^text\/html$/i.test(this.contentType.value) && (this.charset = this._detectHTMLCharset(this._bodyBuffer)), 
        /^utf[\-_]?8$/i.test(this.charset) || (this.content = e.charset.convert(e.toTypedArray(this._bodyBuffer), this.charset || "iso-8859-1")), 
        this.charset = this.contentType.params.charset = "utf-8"), this._bodyBuffer = "", 
        this._parser.onbody(this, this.content));
    }, i.prototype._detectHTMLCharset = function(e) {
        var t, n, o;
        return "string" != typeof e && (e = e.toString("ascii")), e = e.replace(/\r?\n|\r/g, " "), 
        (o = e.match(/<meta\s+http-equiv=["'\s]*content-type[^>]*?>/i)) && (n = o[0]), n && (t = n.match(/charset\s?=\s?([a-zA-Z\-_:0-9]*);?/), 
        t && (t = (t[1] || "").trim().toLowerCase())), !t && (o = e.match(/<meta\s+charset=["'\s]*([^"'<>\/\s]+)/i)) && (t = (o[1] || "").trim().toLowerCase()), 
        t;
    }, o;
}), define("imap/jobs", [ "rdcommon/log", "slog", "mix", "../jobmixins", "../drafts/jobs", "../allback", "mimeparser", "module", "exports" ], function(e, t, n, o, i, r, s, a, c) {
    function u(e, t, n) {
        this.account = e, this.resilientServerIds = !1, this._heldMutexReleasers = [], this._LOG = f.ImapJobDriver(this, n, this.account.id), 
        this._state = t, t.hasOwnProperty("suidToServerId") || (t.suidToServerId = {}, t.moveMap = {}), 
        this._stateDelta = {
            serverIdMap: null,
            moveMap: null
        };
    }
    function d() {}
    var l = "idempotent", h = "/", p = c.deriveFolderPath = function(e, t, n, o) {
        var i, r, s;
        return n ? (r = n.delim || o.delimiter || h, i = n.path || "", s = n.depth + 1) : (r = o.delimiter || h, 
        i = o.prefix || "", s = i ? 1 : 0), i && (i += r), i += e, t && (i += r), {
            path: i,
            delimiter: r,
            depth: s
        };
    };
    c.ImapJobDriver = u, u.prototype = {
        _accessFolderForMutation: function(e, t, n, o, i) {
            var r = this.account.getFolderStorageForFolderId(e), s = this;
            r.runMutexed(i, function(e) {
                var a = r.folderSyncer, c = function() {
                    s._heldMutexReleasers.push(e);
                    try {
                        n(a.folderConn, r);
                    } catch (t) {
                        s._LOG.callbackErr(t);
                    }
                };
                t && !r.isLocalOnly ? a.folderConn.withConnection(function() {
                    s._heldMutexReleasers.push(function() {
                        a.folderConn.clearErrorHandler();
                    }), c();
                }, o, i, !0) : c();
            });
        },
        _partitionAndAccessFoldersSequentially: o._partitionAndAccessFoldersSequentially,
        _acquireConnWithoutFolder: function(e, t, n) {
            this._LOG.acquireConnWithoutFolder_begin(e);
            var o = this;
            this.account.__folderDemandsConnection(null, e, function(n) {
                o._LOG.acquireConnWithoutFolder_end(e), o._heldMutexReleasers.push(function() {
                    o.account.__folderDoneWithConnection(n, !1, !1);
                });
                try {
                    t(n);
                } catch (i) {
                    o._LOG.callbackErr(i);
                }
            }, n);
        },
        postJobCleanup: o.postJobCleanup,
        allJobsDone: o.allJobsDone,
        local_do_downloadBodies: o.local_do_downloadBodies,
        do_downloadBodies: o.do_downloadBodies,
        check_downloadBodies: o.check_downloadBodies,
        local_do_downloadBodyReps: o.local_do_downloadBodyReps,
        do_downloadBodyReps: o.do_downloadBodyReps,
        check_downloadBodyReps: o.check_downloadBodyReps,
        local_do_download: o.local_do_download,
        do_download: o.do_download,
        check_download: o.check_download,
        local_undo_download: o.local_undo_download,
        undo_download: o.undo_download,
        local_do_upgradeDB: o.local_do_upgradeDB,
        local_do_modtags: o.local_do_modtags,
        do_modtags: function(e, t, n) {
            var o = n ? e.removeTags : e.addTags, i = n ? e.addTags : e.removeTags, s = null;
            this._partitionAndAccessFoldersSequentially(e.messages, !0, function(t, a, c, u, d) {
                for (var l = [], h = 0; h < c.length; h++) {
                    var p = c[h];
                    p && l.push(p);
                }
                if (!l.length) return d(), void 0;
                var f = r.latch();
                o ? t._conn.setFlags(l.join(","), {
                    add: o
                }, {
                    byUid: !0
                }, f.defer("add")) : i && t._conn.setFlags(l.join(","), {
                    remove: i
                }, {
                    byUid: !0
                }, f.defer("remove")), f.then(function(t) {
                    var o = t.add && t.add[0] || t.remove && t.remove[0];
                    o ? (console.error("failure modifying tags", o), s = "unknown") : e.progress += n ? -c.length : c.length, 
                    d();
                });
            }, function() {
                t(s);
            }, function() {
                s = "aborted-retry";
            }, n, "modtags");
        },
        check_modtags: function(e, t) {
            t(null, l);
        },
        local_undo_modtags: o.local_undo_modtags,
        undo_modtags: function(e, t) {
            return this.do_modtags(e, t, !0);
        },
        local_do_delete: o.local_do_delete,
        do_delete: function(e, t) {
            var n = this.account.getFirstFolderWithType("trash");
            this.do_move(e, t, n.id);
        },
        check_delete: function(e, t) {
            var n = this.account.getFirstFolderWithType("trash");
            this.check_move(e, t, n.id);
        },
        local_undo_delete: o.local_undo_delete,
        undo_delete: function() {},
        local_do_move: o.local_do_move,
        do_move: function(e, t, n) {
            var o = this._state, i = this._stateDelta, a = null;
            i.serverIdMap || (i.serverIdMap = {}), n || (n = e.targetFolder), this._partitionAndAccessFoldersSequentially(e.messages, !0, function(t, c, u, d, l) {
                function h(e, n) {
                    function a() {
                        e._conn.selectMailbox(n.folderMeta.path, c);
                    }
                    function c() {
                        e._conn.listMessages(d + ":*", [ "UID", "BODY.PEEK[HEADER.FIELDS (MESSAGE-ID)]" ], {
                            byUid: !0
                        }, function(e, t) {
                            if (e) l(); else {
                                var a = r.latch();
                                t.forEach(function(e) {
                                    var t = a.defer();
                                    for (var r in e) if (/header\.fields/.test(r)) {
                                        var c = new s();
                                        c.write(e[r] + "\r\n"), c.end(), e.headers = c.node.headers;
                                        break;
                                    }
                                    var u = e.headers["message-id"] && e.headers["message-id"][0] && e.headers["message-id"][0].value;
                                    if (u && "<" === u[0] && (u = u.slice(1, -1)), !m.hasOwnProperty(u)) return t(), 
                                    void 0;
                                    var l = m[u];
                                    i.serverIdMap[l.suid] = e.uid, d = e.uid + 1;
                                    var h = o.moveMap[l.suid], p = parseInt(h.substring(h.lastIndexOf("/") + 1));
                                    n.updateMessageHeader(l.date, p, !1, function(n) {
                                        return n ? n.srvid = e.uid : console.warn("did not find header for", l.suid, h, l.date, p), 
                                        t(), !0;
                                    }, null);
                                }), a.then(p);
                            }
                        });
                    }
                    var d = e.box.uidNext;
                    t._conn.copyMessages(u.join(","), n.folderMeta.path, {
                        byUid: !0
                    }, a);
                }
                function p() {
                    t._conn.deleteMessages(u.join(","), {
                        byUid: !0
                    }, f);
                }
                function f(e) {
                    e && (a = !0), l();
                }
                for (var m = {}, g = d.length - 1; g >= 0; g--) {
                    var _ = u[g];
                    if (_) {
                        var y = d[g];
                        m[y.guid] = y;
                    } else u.splice(g, 1), d.splice(g, 1);
                }
                return 0 === u.length ? (l(), void 0) : (c.isLocalOnly ? l() : c.folderId === n ? "move" === e.type ? l() : p() : this._accessFolderForMutation(n, !0, h, function() {}, "move target"), 
                void 0);
            }.bind(this), function() {
                t(a);
            }, null, !1, "server move source");
        },
        check_move: function(e, t) {
            t(null, "moot");
        },
        local_undo_move: o.local_undo_move,
        undo_move: function(e, t) {
            t("moot");
        },
        local_do_append: function(e, t) {
            t(null);
        },
        do_append: function(e, t) {
            var n, o = this.account.getFolderStorageForFolderId(e.folderId), i = o.folderMeta, r = 0, s = function(e) {
                return e ? (n = e, c(), void 0) : (d("unknown"), void 0);
            }, a = function() {
                t("aborted-retry");
            }, c = function() {
                var t = e.messages[r++], o = new FileReaderSync().readAsBinaryString(t.messageText);
                n._conn.upload(i.path, o, {
                    flags: t.flags
                }, u);
            }, u = function(t) {
                return t ? (console.error("failure appending message", t), d("unknown"), void 0) : (r < e.messages.length ? c() : d(null), 
                void 0);
            }, d = function(e) {
                n && (n = null), t(e);
            };
            this._accessFolderForMutation(e.folderId, !0, s, a, "append");
        },
        check_append: function(e, t) {
            t(null, "moot");
        },
        local_undo_append: function(e, t) {
            t(null);
        },
        undo_append: function(e, t) {
            t("moot");
        },
        local_do_syncFolderList: function(e, t) {
            t(null);
        },
        do_syncFolderList: function(e, t) {
            var n = this.account, o = !1;
            this._acquireConnWithoutFolder("syncFolderList", function(e) {
                n._syncFolderList(e, function(e) {
                    e || (n.meta.lastFolderSyncAt = Date.now()), o || t(e ? "aborted-retry" : null, null, !e), 
                    o = !0;
                });
            }, function() {
                o || t("aborted-retry"), o = !0;
            });
        },
        check_syncFolderList: function(e, t) {
            t(null, "coherent-notyet");
        },
        local_undo_syncFolderList: function(e, t) {
            t("moot");
        },
        undo_syncFolderList: function(e, t) {
            t("moot");
        },
        local_do_createFolder: function(e, t) {
            t(null);
        },
        do_createFolder: function(e, n) {
            function o(e, t) {
                n && (n(e, t), n = null);
            }
            function i() {
                o("aborted-retry", null);
            }
            var r;
            if (e.parentFolderId) {
                if (!this.account._folderInfos.hasOwnProperty(e.parentFolderId)) throw new Error("No such folder: " + e.parentFolderId);
                r = this.account._folderInfos[e.parentFolderId].$meta;
            }
            var s = this.account._namespaces && this.account._namespaces.personal || {
                prefix: "",
                delimiter: h
            }, a = p(e.folderName, e.containOtherFolders, r, s), c = a.path, u = function(e) {
                t.log("imap:creatingFolder", {
                    _path: c
                }), e.createMailbox(c, d);
            }.bind(this), d = function(n, i) {
                if (n) return t.error("imap:createFolderErr", {
                    _path: c,
                    err: n
                }), o("failure-give-up", null), void 0;
                t.log("imap:createdFolder", {
                    _path: c,
                    alreadyExists: i
                });
                var r = this.account._learnAboutFolder(e.folderName, c, e.parentFolderId, e.folderType, a.delimiter, a.depth, !1);
                o(null, r);
            }.bind(this), l = this.account.getFolderByPath(c);
            l ? o(null, l) : this._acquireConnWithoutFolder("createFolder", u, i);
        },
        check_createFolder: function(e, t) {
            t("moot");
        },
        local_undo_createFolder: function(e, t) {
            t(null);
        },
        undo_createFolder: function(e, t) {
            t("moot");
        },
        local_do_purgeExcessMessages: function(e, t) {
            this._accessFolderForMutation(e.folderId, !1, function(e, n) {
                n.purgeExcessMessages(function(e) {
                    t(null, null, e > 0);
                });
            }, null, "purgeExcessMessages");
        },
        do_purgeExcessMessages: function(e, t) {
            t(null);
        },
        check_purgeExcessMessages: function() {
            return l;
        },
        local_undo_purgeExcessMessages: function(e, t) {
            t(null);
        },
        undo_purgeExcessMessages: function(e, t) {
            t(null);
        },
        local_do_sendOutboxMessages: o.local_do_sendOutboxMessages,
        do_sendOutboxMessages: o.do_sendOutboxMessages,
        check_sendOutboxMessages: o.check_sendOutboxMessages,
        local_undo_sendOutboxMessages: o.local_undo_sendOutboxMessages,
        undo_sendOutboxMessages: o.undo_sendOutboxMessages,
        local_do_setOutboxSyncEnabled: o.local_do_setOutboxSyncEnabled
    }, d.prototype = {
        do_xmove: function() {},
        check_xmove: function() {},
        undo_xmove: function() {},
        do_xcopy: function() {},
        check_xcopy: function() {},
        undo_xcopy: function() {}
    }, n(u.prototype, i.draftsMixins);
    var f = c.LOGFAB = e.register(a, {
        ImapJobDriver: {
            type: e.DAEMON,
            events: {
                savedAttachment: {
                    storage: !0,
                    mimeType: !0,
                    size: !0
                },
                saveFailure: {
                    storage: !1,
                    mimeType: !1,
                    error: !1
                }
            },
            TEST_ONLY_events: {
                saveFailure: {
                    filename: !1
                }
            },
            asyncJobs: {
                acquireConnWithoutFolder: {
                    label: !1
                }
            },
            errors: {
                callbackErr: {
                    ex: e.EXCEPTION
                }
            }
        }
    });
}), function(e, t) {
    "function" == typeof define && define.amd ? define("imap-formal-syntax", t) : "object" == typeof exports ? module.exports = t() : e.imapFormalSyntax = t();
}(this, function() {
    function e(e, t) {
        for (var n = [], o = e; t >= o; o++) n.push(o);
        return String.fromCharCode.apply(String, n);
    }
    function t(e, t) {
        for (var n = Array.prototype.slice.call(e), o = n.length - 1; o >= 0; o--) t.indexOf(n[o]) >= 0 && n.splice(o, 1);
        return n.join("");
    }
    return {
        CHAR: function() {
            var t = e(1, 127);
            return this.CHAR = function() {
                return t;
            }, t;
        },
        CHAR8: function() {
            var t = e(1, 255);
            return this.CHAR8 = function() {
                return t;
            }, t;
        },
        SP: function() {
            return " ";
        },
        CTL: function() {
            var t = e(0, 31) + "";
            return this.CTL = function() {
                return t;
            }, t;
        },
        DQUOTE: function() {
            return '"';
        },
        ALPHA: function() {
            var t = e(65, 90) + e(97, 122);
            return this.ALPHA = function() {
                return t;
            }, t;
        },
        DIGIT: function() {
            var t = e(48, 57) + e(97, 122);
            return this.DIGIT = function() {
                return t;
            }, t;
        },
        "ATOM-CHAR": function() {
            var e = t(this.CHAR(), this["atom-specials"]());
            return this["ATOM-CHAR"] = function() {
                return e;
            }, e;
        },
        "ASTRING-CHAR": function() {
            var e = this["ATOM-CHAR"]() + this["resp-specials"]();
            return this["ASTRING-CHAR"] = function() {
                return e;
            }, e;
        },
        "TEXT-CHAR": function() {
            var e = t(this.CHAR(), "\r\n");
            return this["TEXT-CHAR"] = function() {
                return e;
            }, e;
        },
        "atom-specials": function() {
            var e = "(){" + this.SP() + this.CTL() + this["list-wildcards"]() + this["quoted-specials"]() + this["resp-specials"]();
            return this["atom-specials"] = function() {
                return e;
            }, e;
        },
        "list-wildcards": function() {
            return "%*";
        },
        "quoted-specials": function() {
            var e = this.DQUOTE() + "\\";
            return this["quoted-specials"] = function() {
                return e;
            }, e;
        },
        "resp-specials": function() {
            return "]";
        },
        tag: function() {
            var e = t(this["ASTRING-CHAR"](), "+");
            return this.tag = function() {
                return e;
            }, e;
        },
        command: function() {
            var e = this.ALPHA() + this.DIGIT();
            return this.command = function() {
                return e;
            }, e;
        },
        verify: function(e, t) {
            for (var n = 0, o = e.length; o > n; n++) if (t.indexOf(e.charAt(n)) < 0) return n;
            return -1;
        }
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("imap-handler/src/imap-parser", [ "imap-formal-syntax" ], t) : "object" == typeof exports ? module.exports = t(require("./imap-formal-syntax")) : e.imapParser = t(e.imapFormalSyntax);
}(this, function(e) {
    function t(e, t) {
        this.input = (e || "").toString(), this.options = t || {}, this.remainder = this.input, 
        this.pos = 0;
    }
    function n(e, t, n, o) {
        this.str = (n || "").toString(), this.options = o || {}, this.parent = e, this.tree = this.currentNode = this.createNode(), 
        this.pos = t || 0, this.currentNode.type = "TREE", this.state = "NORMAL", this.processString();
    }
    return t.prototype.getTag = function() {
        return this.tag || (this.tag = this.getElement(e.tag() + "*+", !0)), this.tag;
    }, t.prototype.getCommand = function() {
        var t;
        switch (this.command || (this.command = this.getElement(e.command())), (this.command || "").toString().toUpperCase()) {
          case "OK":
          case "NO":
          case "BAD":
          case "PREAUTH":
          case "BYE":
            t = this.remainder.match(/^ \[(?:[^\]]*\])+/), t ? (this.humanReadable = this.remainder.substr(t[0].length).trim(), 
            this.remainder = t[0]) : (this.humanReadable = this.remainder.trim(), this.remainder = "");
        }
        return this.command;
    }, t.prototype.getElement = function(t) {
        var n, o, i;
        if (this.remainder.match(/^\s/)) throw new Error("Unexpected whitespace at position " + this.pos);
        if (!(n = this.remainder.match(/^[^\s]+(?=\s|$)/))) throw new Error("Unexpected end of input at position " + this.pos);
        if (o = n[0], (i = e.verify(o, t)) >= 0) throw new Error("Unexpected char at position " + (this.pos + i));
        return this.pos += n[0].length, this.remainder = this.remainder.substr(n[0].length), 
        o;
    }, t.prototype.getSpace = function() {
        if (!this.remainder.length) throw new Error("Unexpected end of input at position " + this.pos);
        if (e.verify(this.remainder.charAt(0), e.SP()) >= 0) throw new Error("Unexpected char at position " + this.pos);
        this.pos++, this.remainder = this.remainder.substr(1);
    }, t.prototype.getAttributes = function() {
        if (!this.remainder.length) throw new Error("Unexpected end of input at position " + this.pos);
        if (this.remainder.match(/^\s/)) throw new Error("Unexpected whitespace at position " + this.pos);
        return new n(this, this.pos, this.remainder, this.options).getAttributes();
    }, n.prototype.getAttributes = function() {
        var e = [], t = e, n = function(e) {
            var o, i, r = t;
            if (e.closed || "SEQUENCE" !== e.type || "*" !== e.value || (e.closed = !0, e.type = "ATOM"), 
            !e.closed) throw new Error("Unexpected end of input at position " + (this.pos + this.str.length - 1));
            switch (e.type.toUpperCase()) {
              case "LITERAL":
              case "STRING":
              case "SEQUENCE":
                o = {
                    type: e.type.toUpperCase(),
                    value: e.value
                }, t.push(o);
                break;

              case "ATOM":
                if ("NIL" === e.value.toUpperCase()) {
                    t.push(null);
                    break;
                }
                o = {
                    type: e.type.toUpperCase(),
                    value: e.value
                }, t.push(o);
                break;

              case "SECTION":
                t = t[t.length - 1].section = [];
                break;

              case "LIST":
                o = [], t.push(o), t = o;
                break;

              case "PARTIAL":
                if (i = e.value.split(".").map(Number), i.slice(-1)[0] < i.slice(0, 1)[0]) throw new Error("Invalid partial value at position " + e.startPos);
                t[t.length - 1].partial = i;
            }
            e.childNodes.forEach(function(e) {
                n(e);
            }), t = r;
        }.bind(this);
        return n(this.tree), e;
    }, n.prototype.createNode = function(e, t) {
        var n = {
            childNodes: [],
            type: !1,
            value: "",
            closed: !0
        };
        return e && (n.parentNode = e), "number" == typeof t && (n.startPos = t), e && e.childNodes.push(n), 
        n;
    }, n.prototype.processString = function() {
        var t, n, o, i = function() {
            for (;" " === this.str.charAt(n + 1); ) n++;
        }.bind(this);
        for (n = 0, o = this.str.length; o > n; n++) switch (t = this.str.charAt(n), this.state) {
          case "NORMAL":
            switch (t) {
              case '"':
                this.currentNode = this.createNode(this.currentNode, this.pos + n), this.currentNode.type = "string", 
                this.state = "STRING", this.currentNode.closed = !1;
                break;

              case "(":
                this.currentNode = this.createNode(this.currentNode, this.pos + n), this.currentNode.type = "LIST", 
                this.currentNode.closed = !1;
                break;

              case ")":
                if ("LIST" !== this.currentNode.type) throw new Error("Unexpected list terminator ) at position " + (this.pos + n));
                this.currentNode.closed = !0, this.currentNode.endPos = this.pos + n, this.currentNode = this.currentNode.parentNode, 
                i();
                break;

              case "]":
                if ("SECTION" !== this.currentNode.type) throw new Error("Unexpected section terminator ] at position " + (this.pos + n));
                this.currentNode.closed = !0, this.currentNode.endPos = this.pos + n, this.currentNode = this.currentNode.parentNode, 
                i();
                break;

              case "<":
                "]" !== this.str.charAt(n - 1) ? (this.currentNode = this.createNode(this.currentNode, this.pos + n), 
                this.currentNode.type = "ATOM", this.currentNode.value = t, this.state = "ATOM") : (this.currentNode = this.createNode(this.currentNode, this.pos + n), 
                this.currentNode.type = "PARTIAL", this.state = "PARTIAL", this.currentNode.closed = !1);
                break;

              case "{":
                this.currentNode = this.createNode(this.currentNode, this.pos + n), this.currentNode.type = "LITERAL", 
                this.state = "LITERAL", this.currentNode.closed = !1;
                break;

              case "*":
                this.currentNode = this.createNode(this.currentNode, this.pos + n), this.currentNode.type = "SEQUENCE", 
                this.currentNode.value = t, this.currentNode.closed = !1, this.state = "SEQUENCE";
                break;

              case " ":
                break;

              case "[":
                if ([ "OK", "NO", "BAD", "BYE", "PREAUTH" ].indexOf(this.parent.command.toUpperCase()) >= 0 && this.currentNode === this.tree) {
                    this.currentNode.endPos = this.pos + n, this.currentNode = this.createNode(this.currentNode, this.pos + n), 
                    this.currentNode.type = "ATOM", this.currentNode = this.createNode(this.currentNode, this.pos + n), 
                    this.currentNode.type = "SECTION", this.currentNode.closed = !1, this.state = "NORMAL";
                    break;
                }

              default:
                if (e["ATOM-CHAR"]().indexOf(t) < 0 && "\\" !== t && "%" !== t) throw new Error("Unexpected char at position " + (this.pos + n));
                this.currentNode = this.createNode(this.currentNode, this.pos + n), this.currentNode.type = "ATOM", 
                this.currentNode.value = t, this.state = "ATOM";
            }
            break;

          case "ATOM":
            if (" " === t) {
                this.currentNode.endPos = this.pos + n - 1, this.currentNode = this.currentNode.parentNode, 
                this.state = "NORMAL";
                break;
            }
            if (this.currentNode.parentNode && (")" === t && "LIST" === this.currentNode.parentNode.type || "]" === t && "SECTION" === this.currentNode.parentNode.type)) {
                this.currentNode.endPos = this.pos + n - 1, this.currentNode = this.currentNode.parentNode, 
                this.currentNode.closed = !0, this.currentNode.endPos = this.pos + n, this.currentNode = this.currentNode.parentNode, 
                this.state = "NORMAL", i();
                break;
            }
            if ("," !== t && ":" !== t || !this.currentNode.value.match(/^\d+$/) || (this.currentNode.type = "SEQUENCE", 
            this.currentNode.closed = !0, this.state = "SEQUENCE"), "[" === t) {
                if ([ "BODY", "BODY.PEEK" ].indexOf(this.currentNode.value.toUpperCase()) < 0) throw new Error("Unexpected section start char [ at position " + this.pos);
                this.currentNode.endPos = this.pos + n, this.currentNode = this.createNode(this.currentNode.parentNode, this.pos + n), 
                this.currentNode.type = "SECTION", this.currentNode.closed = !1, this.state = "NORMAL";
                break;
            }
            if ("<" === t) throw new Error("Unexpected start of partial at position " + this.pos);
            if (e["ATOM-CHAR"]().indexOf(t) < 0 && "]" !== t && ("*" !== t || "\\" !== this.currentNode.value)) throw new Error("Unexpected char at position " + (this.pos + n));
            if ("\\*" === this.currentNode.value) throw new Error("Unexpected char at position " + (this.pos + n));
            this.currentNode.value += t;
            break;

          case "STRING":
            if ('"' === t) {
                this.currentNode.endPos = this.pos + n, this.currentNode.closed = !0, this.currentNode = this.currentNode.parentNode, 
                this.state = "NORMAL", i();
                break;
            }
            if ("\\" === t) {
                if (n++, n >= o) throw new Error("Unexpected end of input at position " + (this.pos + n));
                t = this.str.charAt(n);
            }
            if (e["TEXT-CHAR"]().indexOf(t) < 0) throw new Error("Unexpected char at position " + (this.pos + n));
            this.currentNode.value += t;
            break;

          case "PARTIAL":
            if (">" === t) {
                if ("." === this.currentNode.value.substr(-1)) throw new Error("Unexpected end of partial at position " + this.pos);
                this.currentNode.endPos = this.pos + n, this.currentNode.closed = !0, this.currentNode = this.currentNode.parentNode, 
                this.state = "NORMAL", i();
                break;
            }
            if ("." === t && (!this.currentNode.value.length || this.currentNode.value.match(/\./))) throw new Error("Unexpected partial separator . at position " + this.pos);
            if (e.DIGIT().indexOf(t) < 0 && "." !== t) throw new Error("Unexpected char at position " + (this.pos + n));
            if (this.currentNode.value.match(/^0$|\.0$/) && "." !== t) throw new Error("Invalid partial at position " + (this.pos + n));
            this.currentNode.value += t;
            break;

          case "LITERAL":
            if (this.currentNode.started) {
                if ("\0" === t) throw new Error("Unexpected \\x00 at position " + (this.pos + n));
                this.currentNode.value += t, this.currentNode.value.length >= this.currentNode.literalLength && (this.currentNode.endPos = this.pos + n, 
                this.currentNode.closed = !0, this.currentNode = this.currentNode.parentNode, this.state = "NORMAL", 
                i());
                break;
            }
            if ("+" === t && this.options.literalPlus) {
                this.currentNode.literalPlus = !0;
                break;
            }
            if ("}" === t) {
                if (!("literalLength" in this.currentNode)) throw new Error("Unexpected literal prefix end char } at position " + (this.pos + n));
                if ("\n" === this.str.charAt(n + 1)) n++; else {
                    if ("\r" !== this.str.charAt(n + 1) || "\n" !== this.str.charAt(n + 2)) throw new Error("Unexpected char at position " + (this.pos + n));
                    n += 2;
                }
                this.currentNode.literalLength = Number(this.currentNode.literalLength), this.currentNode.started = !0, 
                this.currentNode.literalLength || (this.currentNode.endPos = this.pos + n, this.currentNode.closed = !0, 
                this.currentNode = this.currentNode.parentNode, this.state = "NORMAL", i());
                break;
            }
            if (e.DIGIT().indexOf(t) < 0) throw new Error("Unexpected char at position " + (this.pos + n));
            if ("0" === this.currentNode.literalLength) throw new Error("Invalid literal at position " + (this.pos + n));
            this.currentNode.literalLength = (this.currentNode.literalLength || "") + t;
            break;

          case "SEQUENCE":
            if (" " === t) {
                if (!this.currentNode.value.substr(-1).match(/\d/) && "*" !== this.currentNode.value.substr(-1)) throw new Error("Unexpected whitespace at position " + (this.pos + n));
                if ("*" === this.currentNode.value.substr(-1) && ":" !== this.currentNode.value.substr(-2, 1)) throw new Error("Unexpected whitespace at position " + (this.pos + n));
                this.currentNode.closed = !0, this.currentNode.endPos = this.pos + n - 1, this.currentNode = this.currentNode.parentNode, 
                this.state = "NORMAL";
                break;
            }
            if (":" === t) {
                if (!this.currentNode.value.substr(-1).match(/\d/) && "*" !== this.currentNode.value.substr(-1)) throw new Error("Unexpected range separator : at position " + (this.pos + n));
            } else if ("*" === t) {
                if ([ ",", ":" ].indexOf(this.currentNode.value.substr(-1)) < 0) throw new Error("Unexpected range wildcard at position " + (this.pos + n));
            } else if ("," === t) {
                if (!this.currentNode.value.substr(-1).match(/\d/) && "*" !== this.currentNode.value.substr(-1)) throw new Error("Unexpected sequence separator , at position " + (this.pos + n));
                if ("*" === this.currentNode.value.substr(-1) && ":" !== this.currentNode.value.substr(-2, 1)) throw new Error("Unexpected sequence separator , at position " + (this.pos + n));
            } else if (!t.match(/\d/)) throw new Error("Unexpected char at position " + (this.pos + n));
            if (t.match(/\d/) && "*" === this.currentNode.value.substr(-1)) throw new Error("Unexpected number at position " + (this.pos + n));
            this.currentNode.value += t;
        }
    }, function(n, o) {
        var i, r = {};
        return o = o || {}, i = new t(n, o), r.tag = i.getTag(), i.getSpace(), r.command = i.getCommand(), 
        [ "UID", "AUTHENTICATE" ].indexOf((r.command || "").toUpperCase()) >= 0 && (i.getSpace(), 
        r.command += " " + i.getElement(e.command())), i.remainder.trim().length && (i.getSpace(), 
        r.attributes = i.getAttributes()), i.humanReadable && (r.attributes = (r.attributes || []).concat({
            type: "TEXT",
            value: i.humanReadable
        })), r;
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("imap-handler/src/imap-compiler", [ "imap-formal-syntax" ], t) : "object" == typeof exports ? module.exports = t(require("./imap-formal-syntax")) : e.imapCompiler = t(e.imapFormalSyntax);
}(this, function(e) {
    return function(t, n) {
        var o, i, r = [], s = (t.tag || "") + (t.command ? " " + t.command : ""), a = function(t) {
            if (("LITERAL" === i || [ "(", "<", "[" ].indexOf(s.substr(-1)) < 0 && s.length) && (s += " "), 
            Array.isArray(t)) return i = "LIST", s += "(", t.forEach(a), s += ")", void 0;
            if (!t && "string" != typeof t && "number" != typeof t) return s += "NIL", void 0;
            if ("string" == typeof t) return s += JSON.stringify(t), void 0;
            if ("number" == typeof t) return s += Math.round(t) || 0, void 0;
            switch (i = t.type, t.type.toUpperCase()) {
              case "LITERAL":
                s += t.value ? "{" + t.value.length + "}\r\n" : "{0}\r\n", r.push(s), s = t.value || "";
                break;

              case "STRING":
                s += JSON.stringify(t.value || "");
                break;

              case "TEXT":
              case "SEQUENCE":
                s += t.value || "";
                break;

              case "NUMBER":
                s += t.value || 0;
                break;

              case "ATOM":
              case "SECTION":
                o = t.value || "", e.verify("\\" === o.charAt(0) ? o.substr(1) : o, e["ATOM-CHAR"]()) >= 0 && (o = JSON.stringify(o)), 
                s += o, t.section && (s += "[", t.section.forEach(a), s += "]"), t.partial && (s += "<" + t.partial.join(".") + ">");
            }
        };
        return [].concat(t.attributes || []).forEach(a), s.length && r.push(s), n ? r : r.join("");
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("imap-handler/src/imap-handler", [ "./imap-parser", "./imap-compiler" ], t) : "object" == typeof exports ? module.exports = t(require("./imap-parser"), require("./imap-compiler")) : e.imapHandler = t(e.imapParser, e.imapCompiler);
}(this, function(e, t) {
    return {
        parser: e,
        compiler: t
    };
}), define("imap-handler", [ "./imap-handler/src/imap-handler" ], function(e) {
    return e;
}), define("axeshim-browserbox", [ "slog" ], function() {
    var e = require("slog"), t = "browserbox";
    return {
        debug: function(n, o) {
            e.debug(t, {
                msg: o
            });
        },
        log: function(n, o) {
            e.log(t, {
                msg: o
            });
        },
        warn: function(n, o) {
            e.warn(t, {
                msg: o
            });
        },
        error: function(n, o) {
            e.error(t, {
                msg: o
            });
        }
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("browserbox-imap", [ "tcp-socket", "imap-handler", "mimefuncs", "axe" ], function(e, n, o, i) {
        return t(e, n, o, i);
    }) : "object" == typeof exports ? module.exports = t(require("tcp-socket"), require("wo-imap-handler"), require("mimefuncs"), require("axe-logger")) : e.BrowserboxImapClient = t(navigator.TCPSocket, e.imapHandler, e.mimefuncs, e.axe);
}(this, function(e, t, n, o) {
    function i(t, n, o) {
        this._TCPSocket = e, this.options = o || {}, this.port = n || (this.options.useSecureTransport ? 993 : 143), 
        this.host = t || "localhost", this.options.useSecureTransport = "useSecureTransport" in this.options ? !!this.options.useSecureTransport : 993 === this.port, 
        this.options.auth = this.options.auth || !1, this.socket = !1, this.destroyed = !1, 
        this.waitDrain = !1, this.secureMode = !!this.options.useSecureTransport, this._connectionReady = !1, 
        this._remainder = "", this._command = "", this._literalRemaining = 0, this._processingServerData = !1, 
        this._serverQueue = [], this._canSend = !1, this._clientQueue = [], this._tagCounter = 0, 
        this._currentCommand = !1, this._globalAcceptUntagged = {}, this._idleTimer = !1, 
        this._socketTimeoutTimer = !1;
    }
    var r = "browserbox IMAP";
    return i.prototype.TIMEOUT_ENTER_IDLE = 1e3, i.prototype.TIMEOUT_SOCKET_LOWER_BOUND = 1e4, 
    i.prototype.TIMEOUT_SOCKET_MULTIPLIER = .1, i.prototype.onerror = function() {}, 
    i.prototype.ondrain = function() {}, i.prototype.onclose = function() {}, i.prototype.onready = function() {}, 
    i.prototype.onidle = function() {}, i.prototype.connect = function() {
        this.socket = this._TCPSocket.open(this.host, this.port, {
            binaryType: "arraybuffer",
            useSecureTransport: this.secureMode,
            ca: this.options.ca,
            tlsWorkerPath: this.options.tlsWorkerPath
        });
        try {
            this.socket.oncert = this.oncert;
        } catch (e) {}
        this.socket.onerror = this._onError.bind(this), this.socket.onopen = this._onOpen.bind(this);
    }, i.prototype.close = function() {
        this.socket && "open" === this.socket.readyState ? this.socket.close() : this._destroy();
    }, i.prototype.upgrade = function(e) {
        return this.secureMode ? e(null, !1) : (this.secureMode = !0, this.socket.upgradeToSecure(), 
        e(null, !0), void 0);
    }, i.prototype.exec = function(e, t, n, o) {
        return "string" == typeof e && (e = {
            command: e
        }), this._addToClientQueue(e, t, n, o), this;
    }, i.prototype.send = function(e) {
        var t = n.toTypedArray(e).buffer, o = this.TIMEOUT_SOCKET_LOWER_BOUND + Math.floor(t.byteLength * this.TIMEOUT_SOCKET_MULTIPLIER);
        clearTimeout(this._socketTimeoutTimer), this._socketTimeoutTimer = setTimeout(this._onTimeout.bind(this), o), 
        this.waitDrain = this.socket.send(t);
    }, i.prototype.setHandler = function(e, t) {
        this._globalAcceptUntagged[(e || "").toString().toUpperCase().trim()] = t;
    }, i.prototype._onError = function(e) {
        this.isError(e) ? this.onerror(e) : e && this.isError(e.data) ? this.onerror(e.data) : this.onerror(new Error(e && e.data && e.data.message || e.data || e || "Error")), 
        this.close();
    }, i.prototype._destroy = function() {
        this._serverQueue = [], this._clientQueue = [], this._currentCommand = !1, clearTimeout(this._idleTimer), 
        clearTimeout(this._socketTimeoutTimer), this.destroyed || (this.destroyed = !0, 
        this.onclose());
    }, i.prototype._onClose = function() {
        this._destroy();
    }, i.prototype._onTimeout = function() {
        var e = new Error("Socket timed out!");
        o.error(r, e), this._onError(e);
    }, i.prototype._onDrain = function() {
        this.waitDrain = !1, this.ondrain();
    }, i.prototype._onData = function(e) {
        if (e && e.data) {
            clearTimeout(this._socketTimeoutTimer);
            var t, o = n.fromTypedArray(e.data);
            if (this._literalRemaining) {
                if (this._literalRemaining > o.length) return this._literalRemaining -= o.length, 
                this._command += o, void 0;
                this._command += o.substr(0, this._literalRemaining), o = o.substr(this._literalRemaining), 
                this._literalRemaining = 0;
            }
            for (this._remainder = o = this._remainder + o; t = o.match(/(\{(\d+)(\+)?\})?\r?\n/); ) if (t[2]) {
                if (this._remainder = "", this._command += o.substr(0, t.index + t[0].length), this._literalRemaining = Number(t[2]), 
                o = o.substr(t.index + t[0].length), this._literalRemaining > o.length) return this._command += o, 
                this._literalRemaining -= o.length, void 0;
                this._command += o.substr(0, this._literalRemaining), this._remainder = o = o.substr(this._literalRemaining), 
                this._literalRemaining = 0;
            } else this._addToServerQueue(this._command + o.substr(0, t.index)), this._remainder = o = o.substr(t.index + t[0].length), 
            this._command = "";
        }
    }, i.prototype._onOpen = function() {
        o.debug(r, "tcp socket opened"), this.socket.ondata = this._onData.bind(this), this.socket.onclose = this._onClose.bind(this), 
        this.socket.ondrain = this._onDrain.bind(this);
    }, i.prototype._addToServerQueue = function(e) {
        this._serverQueue.push(e), this._processingServerData || (this._processingServerData = !0, 
        this._processServerQueue());
    }, i.prototype._processServerQueue = function() {
        if (!this._serverQueue.length) return this._processingServerData = !1, void 0;
        this._clearIdle();
        var e, n = this._serverQueue.shift();
        try {
            /^\+/.test(n) ? e = {
                tag: "+",
                payload: n.substr(2) || ""
            } : (e = t.parser(n), o.debug(r, "received response: " + e.tag + " " + e.command));
        } catch (i) {
            return o.error(r, "error parsing imap response: " + i + "\n" + i.stack + "\nraw:" + n), 
            this._onError(i);
        }
        if ("*" === e.tag && /^\d+$/.test(e.command) && e.attributes && e.attributes.length && "ATOM" === e.attributes[0].type && (e.nr = Number(e.command), 
        e.command = (e.attributes.shift().value || "").toString().toUpperCase().trim()), 
        "+" === e.tag) {
            if (this._currentCommand.data.length) n = this._currentCommand.data.shift(), this.send(n + (this._currentCommand.data.length ? "" : "\r\n")); else if ("function" == typeof this._currentCommand.onplustagged) return this._currentCommand.onplustagged(e, this._processServerQueue.bind(this)), 
            void 0;
            return setTimeout(this._processServerQueue.bind(this), 0), void 0;
        }
        this._processServerResponse(e, function(t) {
            return t ? this._onError(t) : (this._connectionReady ? "*" !== e.tag && (this._canSend = !0, 
            this._sendRequest()) : (this._connectionReady = !0, this.onready(), this._canSend = !0, 
            this._sendRequest()), setTimeout(this._processServerQueue.bind(this), 0), void 0);
        }.bind(this));
    }, i.prototype._processServerResponse = function(e, t) {
        var n = (e && e.command || "").toUpperCase().trim();
        return this._processResponse(e), this._currentCommand ? this._currentCommand.payload && "*" === e.tag && n in this._currentCommand.payload ? (this._currentCommand.payload[n].push(e), 
        t()) : "*" === e.tag && n in this._globalAcceptUntagged ? (this._globalAcceptUntagged[n](e, t), 
        void 0) : e.tag === this._currentCommand.tag ? "function" == typeof this._currentCommand.callback ? (this._currentCommand.payload && Object.keys(this._currentCommand.payload).length && (e.payload = this._currentCommand.payload), 
        this._currentCommand.callback(e, t)) : t() : t() : "*" === e.tag && n in this._globalAcceptUntagged ? this._globalAcceptUntagged[n](e, t) : t();
    }, i.prototype._addToClientQueue = function(e, t, n, o) {
        var i, r = "W" + ++this._tagCounter;
        o || "function" != typeof n || (o = n, n = void 0), o || "function" != typeof t || (o = t, 
        t = void 0), t = [].concat(t || []).map(function(e) {
            return (e || "").toString().toUpperCase().trim();
        }), e.tag = r, i = {
            tag: r,
            request: e,
            payload: t.length ? {} : void 0,
            callback: o
        }, Object.keys(n || {}).forEach(function(e) {
            i[e] = n[e];
        }), t.forEach(function(e) {
            i.payload[e] = [];
        }), this._clientQueue.push(i), this._canSend && this._sendRequest();
    }, i.prototype._sendRequest = function() {
        if (!this._clientQueue.length) return this._enterIdle();
        this._clearIdle(), this._canSend = !1, this._currentCommand = this._clientQueue.shift();
        try {
            this._currentCommand.data = t.compiler(this._currentCommand.request, !0);
        } catch (e) {
            return o.error(r, "error compiling imap command: " + e + "\nstack trace: " + e.stack + "\nraw:" + this._currentCommand.request), 
            this._onError(e);
        }
        o.debug(r, "sending request: " + this._currentCommand.request.tag + " " + this._currentCommand.request.command);
        var n = this._currentCommand.data.shift();
        return this.send(n + (this._currentCommand.data.length ? "" : "\r\n")), this.waitDrain;
    }, i.prototype._enterIdle = function() {
        clearTimeout(this._idleTimer), this._idleTimer = setTimeout(function() {
            this.onidle();
        }.bind(this), this.TIMEOUT_ENTER_IDLE);
    }, i.prototype._clearIdle = function() {
        clearTimeout(this._idleTimer);
    }, i.prototype._processResponse = function(e) {
        var t, n, o = (e && e.command || "").toString().toUpperCase().trim();
        [ "OK", "NO", "BAD", "BYE", "PREAUTH" ].indexOf(o) >= 0 && ((t = e && e.attributes && e.attributes.length && "ATOM" === e.attributes[0].type && e.attributes[0].section && e.attributes[0].section.map(function(e) {
            return e ? Array.isArray(e) ? e.map(function(e) {
                return (e.value || "").toString().trim();
            }) : (e.value || "").toString().toUpperCase().trim() : void 0;
        })) && (n = t && t.shift(), e.code = n, t.length && (t = [].concat(t || []), e[n.toLowerCase()] = 1 === t.length ? t[0] : t)), 
        e && e.attributes && e.attributes.length && "TEXT" === e.attributes[e.attributes.length - 1].type && (e.humanReadable = e.attributes[e.attributes.length - 1].value));
    }, i.prototype.isError = function(e) {
        return !!Object.prototype.toString.call(e).match(/Error\]$/);
    }, i;
}), function(e, t) {
    "function" == typeof define && define.amd ? define("browserbox", [ "browserbox-imap", "utf7", "imap-handler", "mimefuncs", "axe" ], function(e, n, o, i, r) {
        return t(e, n, o, i, r);
    }) : "object" == typeof exports ? module.exports = t(require("./browserbox-imap"), require("wo-utf7"), require("wo-imap-handler"), require("mimefuncs"), require("axe-logger")) : e.BrowserBox = t(e.BrowserboxImapClient, e.utf7, e.imapHandler, e.mimefuncs, e.axe);
}(this, function(e, t, n, o, i) {
    function r(t, n, o) {
        this.options = o || {}, this.capability = [], this.serverId = !1, this.state = !1, 
        this.authenticated = !1, this.selectedMailbox = !1, this.client = new e(t, n, this.options), 
        this._enteredIdle = !1, this._idleTimeout = !1, this._init();
    }
    var s = "browserbox", a = [ "\\All", "\\Archive", "\\Drafts", "\\Flagged", "\\Junk", "\\Sent", "\\Trash" ], c = {
        "\\Sent": [ "aika", "bidaliak", "bidalita", "dihantar", "e rometsweng", "e tindami", "elküldött", "elküldöttek", "enviadas", "enviadas", "enviados", "enviats", "envoyés", "ethunyelweyo", "expediate", "ezipuru", "gesendete", "gestuur", "gönderilmiş öğeler", "göndərilənlər", "iberilen", "inviati", "išsiųstieji", "kuthunyelwe", "lasa", "lähetetyt", "messages envoyés", "naipadala", "nalefa", "napadala", "nosūtītās ziņas", "odeslané", "padala", "poslane", "poslano", "poslano", "poslané", "poslato", "saadetud", "saadetud kirjad", "sendt", "sendt", "sent", "sent items", "sent messages", "sända poster", "sänt", "terkirim", "ti fi ranṣẹ", "të dërguara", "verzonden", "vilivyotumwa", "wysłane", "đã gửi", "σταλθέντα", "жиберилген", "жіберілгендер", "изпратени", "илгээсэн", "ирсол шуд", "испратено", "надіслані", "отправленные", "пасланыя", "юборилган", "ուղարկված", "נשלחו", "פריטים שנשלחו", "المرسلة", "بھیجے گئے", "سوزمژہ", "لېګل شوی", "موارد ارسال شده", "पाठविले", "पाठविलेले", "प्रेषित", "भेजा गया", "প্রেরিত", "প্রেরিত", "প্ৰেৰিত", "ਭੇਜੇ", "મોકલેલા", "ପଠାଗଲା", "அனுப்பியவை", "పంపించబడింది", "ಕಳುಹಿಸಲಾದ", "അയച്ചു", "යැවු පණිවුඩ", "ส่งแล้ว", "გაგზავნილი", "የተላኩ", "បាន​ផ្ញើ", "寄件備份", "寄件備份", "已发信息", "送信済みﾒｰﾙ", "발신 메시지", "보낸 편지함" ],
        "\\Trash": [ "articole șterse", "bin", "borttagna objekt", "deleted", "deleted items", "deleted messages", "elementi eliminati", "elementos borrados", "elementos eliminados", "gelöschte objekte", "item dipadam", "itens apagados", "itens excluídos", "mục đã xóa", "odstraněné položky", "pesan terhapus", "poistetut", "praht", "prügikast", "silinmiş öğeler", "slettede beskeder", "slettede elementer", "trash", "törölt elemek", "usunięte wiadomości", "verwijderde items", "vymazané správy", "éléments supprimés", "видалені", "жойылғандар", "удаленные", "פריטים שנמחקו", "العناصر المحذوفة", "موارد حذف شده", "รายการที่ลบ", "已删除邮件", "已刪除項目", "已刪除項目" ],
        "\\Junk": [ "bulk mail", "correo no deseado", "courrier indésirable", "istenmeyen", "istenmeyen e-posta", "junk", "levélszemét", "nevyžiadaná pošta", "nevyžádaná pošta", "no deseado", "posta indesiderata", "pourriel", "roskaposti", "skräppost", "spam", "spam", "spamowanie", "søppelpost", "thư rác", "спам", "דואר זבל", "الرسائل العشوائية", "هرزنامه", "สแปม", "‎垃圾郵件", "垃圾邮件", "垃圾電郵" ],
        "\\Drafts": [ "ba brouillon", "borrador", "borrador", "borradores", "bozze", "brouillons", "bản thảo", "ciorne", "concepten", "draf", "drafts", "drög", "entwürfe", "esborranys", "garalamalar", "ihe edeturu", "iidrafti", "izinhlaka", "juodraščiai", "kladd", "kladder", "koncepty", "koncepty", "konsep", "konsepte", "kopie robocze", "layihələr", "luonnokset", "melnraksti", "meralo", "mesazhe të padërguara", "mga draft", "mustandid", "nacrti", "nacrti", "osnutki", "piszkozatok", "rascunhos", "rasimu", "skice", "taslaklar", "tsararrun saƙonni", "utkast", "vakiraoka", "vázlatok", "zirriborroak", "àwọn àkọpamọ́", "πρόχειρα", "жобалар", "нацрти", "нооргууд", "сиёҳнавис", "хомаки хатлар", "чарнавікі", "чернетки", "чернови", "черновики", "черновиктер", "սևագրեր", "טיוטות", "مسودات", "مسودات", "موسودې", "پیش نویسها", "ڈرافٹ/", "ड्राफ़्ट", "प्रारूप", "খসড়া", "খসড়া", "ড্ৰাফ্ট", "ਡ੍ਰਾਫਟ", "ડ્રાફ્ટસ", "ଡ୍ରାଫ୍ଟ", "வரைவுகள்", "చిత్తు ప్రతులు", "ಕರಡುಗಳು", "കരടുകള്‍", "කෙටුම් පත්", "ฉบับร่าง", "მონახაზები", "ረቂቆች", "សារព្រាង", "下書き", "草稿", "草稿", "草稿", "임시 보관함" ]
    }, u = Object.keys(c);
    return r.prototype.STATE_CONNECTING = 1, r.prototype.STATE_NOT_AUTHENTICATED = 2, 
    r.prototype.STATE_AUTHENTICATED = 3, r.prototype.STATE_SELECTED = 4, r.prototype.STATE_LOGOUT = 5, 
    r.prototype.TIMEOUT_CONNECTION = 9e4, r.prototype.TIMEOUT_NOOP = 6e4, r.prototype.TIMEOUT_IDLE = 6e4, 
    r.prototype._init = function() {
        this.client.onerror = function(e) {
            this.onerror(e);
        }.bind(this), this.client.oncert = function(e) {
            this.oncert(e);
        }.bind(this), this.client.onclose = function() {
            clearTimeout(this._connectionTimeout), clearTimeout(this._idleTimeout), this.onclose();
        }.bind(this), this.client.onready = this._onReady.bind(this), this.client.onidle = this._onIdle.bind(this), 
        this.client.setHandler("capability", this._untaggedCapabilityHandler.bind(this)), 
        this.client.setHandler("ok", this._untaggedOkHandler.bind(this)), this.client.setHandler("exists", this._untaggedExistsHandler.bind(this)), 
        this.client.setHandler("expunge", this._untaggedExpungeHandler.bind(this)), this.client.setHandler("fetch", this._untaggedFetchHandler.bind(this));
    }, r.prototype.onclose = function() {}, r.prototype.onauth = function() {}, r.prototype.onupdate = function() {}, 
    r.prototype.oncert = function() {}, r.prototype.onselectmailbox = function() {}, 
    r.prototype.onclosemailbox = function() {}, r.prototype._onClose = function() {
        i.debug(s, "connection closed. goodbye."), this.onclose();
    }, r.prototype._onTimeout = function() {
        clearTimeout(this._connectionTimeout);
        var e = new Error("Timeout creating connection to the IMAP server");
        i.error(s, e), this.onerror(e), this.client._destroy();
    }, r.prototype._onReady = function() {
        clearTimeout(this._connectionTimeout), i.debug(s, "session: connection established"), 
        this._changeState(this.STATE_NOT_AUTHENTICATED), this.updateCapability(function() {
            this.upgradeConnection(function(e) {
                return e ? (this.onerror(e), this.close(), void 0) : (this.updateId(this.options.id, function() {
                    this.login(this.options.auth, function(e) {
                        return e ? (this.onerror(e), this.close(), void 0) : (this.onauth(), void 0);
                    }.bind(this));
                }.bind(this)), void 0);
            }.bind(this));
        }.bind(this));
    }, r.prototype._onIdle = function() {
        this.authenticated && !this._enteredIdle && (i.debug(s, "client: started idling"), 
        this.enterIdle());
    }, r.prototype.connect = function() {
        i.debug(s, "connecting to " + this.client.host + ":" + this.client.port), this._changeState(this.STATE_CONNECTING), 
        clearTimeout(this._connectionTimeout), this._connectionTimeout = setTimeout(this._onTimeout.bind(this), this.TIMEOUT_CONNECTION), 
        this.client.connect();
    }, r.prototype.close = function(e) {
        i.debug(s, "closing connection"), this._changeState(this.STATE_LOGOUT), this.exec("LOGOUT", function(t) {
            "function" == typeof e && e(t || null), this.client.close();
        }.bind(this));
    }, r.prototype.exec = function() {
        var e = Array.prototype.slice.call(arguments), t = e.pop();
        "function" != typeof t && (e.push(t), t = void 0), e.push(function(e, n) {
            var o = null;
            e && e.capability && (this.capability = e.capability), [ "NO", "BAD" ].indexOf((e && e.command || "").toString().toUpperCase().trim()) >= 0 && (o = new Error(e.humanReadable || "Error"), 
            e.code && (o.code = e.code)), "function" == typeof t ? t(o, e, n) : n();
        }.bind(this)), this.breakIdle(function() {
            this.client.exec.apply(this.client, e);
        }.bind(this));
    }, r.prototype.enterIdle = function() {
        this._enteredIdle || (this._enteredIdle = this.capability.indexOf("IDLE") >= 0 ? "IDLE" : "NOOP", 
        i.debug(s, "entering idle with " + this._enteredIdle), "NOOP" === this._enteredIdle ? this._idleTimeout = setTimeout(function() {
            this.exec("NOOP");
        }.bind(this), this.TIMEOUT_NOOP) : "IDLE" === this._enteredIdle && (this.client.exec({
            command: "IDLE"
        }, function(e, t) {
            t();
        }.bind(this)), this._idleTimeout = setTimeout(function() {
            i.debug(s, "sending idle DONE"), this.client.socket.send(new Uint8Array([ 68, 79, 78, 69, 13, 10 ]).buffer), 
            this._enteredIdle = !1;
        }.bind(this), this.TIMEOUT_IDLE)));
    }, r.prototype.breakIdle = function(e) {
        return this._enteredIdle ? (clearTimeout(this._idleTimeout), "IDLE" === this._enteredIdle && (i.debug(s, "sending idle DONE"), 
        this.client.socket.send(new Uint8Array([ 68, 79, 78, 69, 13, 10 ]).buffer)), this._enteredIdle = !1, 
        i.debug(s, "idle terminated"), e()) : e();
    }, r.prototype.upgradeConnection = function(e) {
        return this.client.secureMode ? e(null, !1) : (this.capability.indexOf("STARTTLS") < 0 || this.options.ignoreTLS) && !this.options.requireTLS ? e(null, !1) : (this.exec("STARTTLS", function(t, n, o) {
            t ? (e(t), o()) : (this.capability = [], this.client.upgrade(function(t, n) {
                this.updateCapability(function() {
                    e(t, n);
                }), o();
            }.bind(this)));
        }.bind(this)), void 0);
    }, r.prototype.updateCapability = function(e, t) {
        return t || "function" != typeof e || (t = e, e = void 0), !e && this.capability.length ? t(null, !1) : !this.client.secureMode && this.options.requireTLS ? t(null, !1) : (this.exec("CAPABILITY", function(e, n, o) {
            e ? t(e) : t(null, !0), o();
        }), void 0);
    }, r.prototype.listNamespaces = function(e) {
        return this.capability.indexOf("NAMESPACE") < 0 ? e(null, !1) : (this.exec("NAMESPACE", "NAMESPACE", function(t, n, o) {
            t ? e(t) : e(null, this._parseNAMESPACE(n)), o();
        }.bind(this)), void 0);
    }, r.prototype.login = function(e, t) {
        var n, r = {};
        return e ? (this.capability.indexOf("AUTH=XOAUTH2") >= 0 && e && e.xoauth2 ? (n = {
            command: "AUTHENTICATE",
            attributes: [ {
                type: "ATOM",
                value: "XOAUTH2"
            }, {
                type: "ATOM",
                value: this._buildXOAuth2Token(e.user, e.xoauth2)
            } ]
        }, r.onplustagged = function(e, t) {
            var n;
            if (e && e.payload) try {
                n = JSON.parse(o.base64Decode(e.payload));
            } catch (r) {
                i.error(s, "error parsing XOAUTH2 payload: " + r + "\nstack trace: " + r.stack);
            }
            this.client.send("\r\n"), t();
        }.bind(this)) : n = {
            command: "login",
            attributes: [ {
                type: "STRING",
                value: e.user || ""
            }, {
                type: "STRING",
                value: e.pass || ""
            } ]
        }, this.exec(n, "capability", r, function(e, n, o) {
            var r = !1;
            return e ? (t(e), o()) : (this._changeState(this.STATE_AUTHENTICATED), this.authenticated = !0, 
            n.capability && n.capability.length ? (this.capability = [].concat(n.capability || []), 
            r = !0, i.debug(s, "post-auth capabilites updated: " + this.capability), t(null, !0)) : n.payload && n.payload.CAPABILITY && n.payload.CAPABILITY.length ? (this.capability = [].concat(n.payload.CAPABILITY.pop().attributes || []).map(function(e) {
                return (e.value || "").toString().toUpperCase().trim();
            }), r = !0, i.debug(s, "post-auth capabilites updated: " + this.capability), t(null, !0)) : this.updateCapability(!0, function(e) {
                e ? t(e) : (i.debug(s, "post-auth capabilites updated: " + this.capability), t(null, !0));
            }.bind(this)), o(), void 0);
        }.bind(this)), void 0) : t(new Error("Authentication information not provided"));
    }, r.prototype.updateId = function(e, t) {
        if (this.capability.indexOf("ID") < 0) return t(null, !1);
        var n = [ [] ];
        e ? ("string" == typeof e && (e = {
            name: e
        }), Object.keys(e).forEach(function(t) {
            n[0].push(t), n[0].push(e[t]);
        })) : n[0] = null, this.exec({
            command: "ID",
            attributes: n
        }, "ID", function(e, n, o) {
            if (e) return i.error(s, "error updating server id: " + e + "\n" + e.stack), t(e), 
            o();
            if (!n.payload || !n.payload.ID || !n.payload.ID.length) return t(null, !1), o();
            this.serverId = {};
            var r;
            [].concat([].concat(n.payload.ID.shift().attributes || []).shift() || []).forEach(function(e, t) {
                0 === t % 2 ? r = (e && e.value || "").toString().toLowerCase().trim() : this.serverId[r] = (e && e.value || "").toString();
            }.bind(this)), t(null, this.serverId), o();
        }.bind(this));
    }, r.prototype.listMailboxes = function(e) {
        this.exec({
            command: "LIST",
            attributes: [ "", "*" ]
        }, "LIST", function(t, n, o) {
            if (t) return e(t), o();
            var r = {
                root: !0,
                children: []
            };
            return n.payload && n.payload.LIST && n.payload.LIST.length ? (n.payload.LIST.forEach(function(e) {
                if (e && e.attributes && !(e.attributes.length < 3)) {
                    var t = this._ensurePath(r, (e.attributes[2].value || "").toString(), (e.attributes[1] ? e.attributes[1].value : "/").toString());
                    t.flags = [].concat(e.attributes[0] || []).map(function(e) {
                        return (e.value || "").toString();
                    }), t.listed = !0, this._checkSpecialUse(t);
                }
            }.bind(this)), this.exec({
                command: "LSUB",
                attributes: [ "", "*" ]
            }, "LSUB", function(t, n, o) {
                return t ? (i.error(s, "error while listing subscribed mailboxes: " + t + "\n" + t.stack), 
                e(null, r), o()) : n.payload && n.payload.LSUB && n.payload.LSUB.length ? (n.payload.LSUB.forEach(function(e) {
                    if (e && e.attributes && !(e.attributes.length < 3)) {
                        var t = this._ensurePath(r, (e.attributes[2].value || "").toString(), (e.attributes[1] ? e.attributes[1].value : "/").toString());
                        [].concat(e.attributes[0] || []).map(function(e) {
                            e = (e.value || "").toString(), (!t.flags || t.flags.indexOf(e) < 0) && (t.flags = [].concat(t.flags || []).concat(e));
                        }), t.subscribed = !0;
                    }
                }.bind(this)), e(null, r), o(), void 0) : (e(null, r), o());
            }.bind(this)), o(), void 0) : (e(null, !1), o());
        }.bind(this));
    }, r.prototype.createMailbox = function(e, n) {
        this.exec({
            command: "CREATE",
            attributes: [ t.imap.encode(e) ]
        }, function(e, t, o) {
            e && "ALREADYEXISTS" === e.code ? n(null, !0) : n(e, !1), o();
        });
    }, r.prototype.listMessages = function(e, t, n, o) {
        o || "function" != typeof n || (o = n, n = void 0), o || "function" != typeof t || (o = t, 
        t = void 0), t = t || {
            fast: !0
        }, n = n || {};
        var i = this._buildFETCHCommand(e, t, n);
        this.exec(i, "FETCH", function(e, t, n) {
            e ? o(e) : o(null, this._parseFETCH(t)), n();
        }.bind(this));
    }, r.prototype.search = function(e, t, n) {
        n || "function" != typeof t || (n = t, t = void 0), t = t || {};
        var o = this._buildSEARCHCommand(e, t);
        this.exec(o, "SEARCH", function(e, t, o) {
            e ? n(e) : n(null, this._parseSEARCH(t)), o();
        }.bind(this));
    }, r.prototype.setFlags = function(e, t, n, o) {
        o || "function" != typeof n || (o = n, n = void 0), n = n || {};
        var i = this._buildSTORECommand(e, t, n);
        this.exec(i, "FETCH", function(e, t, n) {
            e ? o(e) : o(null, this._parseFETCH(t)), n();
        }.bind(this));
    }, r.prototype.upload = function(e, t, n, o) {
        o || "function" != typeof n || (o = n, n = void 0), n = n || {}, n.flags = n.flags || [ "\\Seen" ];
        var i = n.flags.map(function(e) {
            return {
                type: "atom",
                value: e
            };
        }), r = {
            command: "APPEND"
        };
        r.attributes = [ {
            type: "atom",
            value: e
        }, i, {
            type: "literal",
            value: t
        } ], this.exec(r, function(e, t, n) {
            o(e, e ? void 0 : !0), n();
        }.bind(this));
    }, r.prototype.deleteMessages = function(e, t, n) {
        n || "function" != typeof t || (n = t, t = void 0), t = t || {}, this.setFlags(e, {
            add: "\\Deleted"
        }, t, function(o) {
            return o ? n(o) : (this.exec(t.byUid && this.capability.indexOf("UIDPLUS") >= 0 ? {
                command: "UID EXPUNGE",
                attributes: [ {
                    type: "sequence",
                    value: e
                } ]
            } : "EXPUNGE", function(e, t, o) {
                e ? n(e) : n(null, !0), o();
            }.bind(this)), void 0);
        }.bind(this));
    }, r.prototype.copyMessages = function(e, t, n, o) {
        o || "function" != typeof n || (o = n, n = void 0), n = n || {}, this.exec({
            command: n.byUid ? "UID COPY" : "COPY",
            attributes: [ {
                type: "sequence",
                value: e
            }, {
                type: "atom",
                value: t
            } ]
        }, function(e, t, n) {
            e ? o(e) : o(null, t.humanReadable || "COPY completed"), n();
        }.bind(this));
    }, r.prototype.moveMessages = function(e, t, n, o) {
        o || "function" != typeof n || (o = n, n = void 0), n = n || {}, this.capability.indexOf("MOVE") >= 0 ? this.exec({
            command: n.byUid ? "UID MOVE" : "MOVE",
            attributes: [ {
                type: "sequence",
                value: e
            }, {
                type: "atom",
                value: t
            } ]
        }, [ "OK" ], function(e, t, n) {
            e ? o(e) : o(null, !0), n();
        }.bind(this)) : this.copyMessages(e, t, n, function(t) {
            return t ? o(t) : (this.deleteMessages(e, n, o), void 0);
        }.bind(this));
    }, r.prototype.selectMailbox = function(e, t, n) {
        n || "function" != typeof t || (n = t, t = void 0), t = t || {};
        var o = {
            command: t.readOnly ? "EXAMINE" : "SELECT",
            attributes: [ {
                type: "STRING",
                value: e
            } ]
        };
        t.condstore && this.capability.indexOf("CONDSTORE") >= 0 && o.attributes.push([ {
            type: "ATOM",
            value: "CONDSTORE"
        } ]), this.exec(o, [ "EXISTS", "FLAGS", "OK" ], function(t, o, i) {
            if (t) return n(t), i();
            this._changeState(this.STATE_SELECTED), this.selectedMailbox && this.selectedMailbox !== e && this.onclosemailbox(this.selectedMailbox), 
            this.selectedMailbox = e;
            var r = this._parseSELECT(o);
            n(null, r), this.onselectmailbox(e, r), i();
        }.bind(this));
    }, r.prototype.hasCapability = function(e) {
        return this.capability.indexOf((e || "").toString().toUpperCase().trim()) >= 0;
    }, r.prototype._untaggedOkHandler = function(e, t) {
        e && e.capability && (this.capability = e.capability), t();
    }, r.prototype._untaggedCapabilityHandler = function(e, t) {
        this.capability = [].concat(e && e.attributes || []).map(function(e) {
            return (e.value || "").toString().toUpperCase().trim();
        }), t();
    }, r.prototype._untaggedExistsHandler = function(e, t) {
        e && e.hasOwnProperty("nr") && this.onupdate("exists", e.nr), t();
    }, r.prototype._untaggedExpungeHandler = function(e, t) {
        e && e.hasOwnProperty("nr") && this.onupdate("expunge", e.nr), t();
    }, r.prototype._untaggedFetchHandler = function(e, t) {
        this.onupdate("fetch", [].concat(this._parseFETCH({
            payload: {
                FETCH: [ e ]
            }
        }) || []).shift()), t();
    }, r.prototype._parseSELECT = function(e) {
        if (e && e.payload) {
            var t = {
                readOnly: "READ-ONLY" === e.code
            }, n = e.payload.EXISTS && e.payload.EXISTS.pop(), o = e.payload.FLAGS && e.payload.FLAGS.pop(), i = e.payload.OK;
            return n && (t.exists = n.nr || 0), o && o.attributes && o.attributes.length && (t.flags = o.attributes[0].map(function(e) {
                return (e.value || "").toString().trim();
            })), [].concat(i || []).forEach(function(e) {
                switch (e && e.code) {
                  case "PERMANENTFLAGS":
                    t.permanentFlags = [].concat(e.permanentflags || []);
                    break;

                  case "UIDVALIDITY":
                    t.uidValidity = Number(e.uidvalidity) || 0;
                    break;

                  case "UIDNEXT":
                    t.uidNext = Number(e.uidnext) || 0;
                    break;

                  case "HIGHESTMODSEQ":
                    t.highestModseq = e.highestmodseq || "0";
                }
            }), t;
        }
    }, r.prototype._parseNAMESPACE = function(e) {
        var t, n = !1, o = function(e) {
            return e ? [].concat(e || []).map(function(e) {
                return e && e.length ? {
                    prefix: e[0].value,
                    delimiter: e[1] && e[1].value
                } : !1;
            }) : !1;
        };
        return e.payload && e.payload.NAMESPACE && e.payload.NAMESPACE.length && (t = [].concat(e.payload.NAMESPACE.pop().attributes || [])).length && (n = {
            personal: o(t[0]),
            users: o(t[1]),
            shared: o(t[2])
        }), n;
    }, r.prototype._buildFETCHCommand = function(e, t, o) {
        var i = {
            command: o.byUid ? "UID FETCH" : "FETCH",
            attributes: [ {
                type: "SEQUENCE",
                value: e
            } ]
        }, r = [];
        return [].concat(t || []).forEach(function(e) {
            var t;
            if (e = (e || "").toString().toUpperCase().trim(), /^\w+$/.test(e)) r.push({
                type: "ATOM",
                value: e
            }); else if (e) try {
                t = n.parser("* Z " + e), r = r.concat(t.attributes || []);
            } catch (o) {
                r.push({
                    type: "ATOM",
                    value: e
                });
            }
        }), 1 === r.length && (r = r.pop()), i.attributes.push(r), o.changedSince && i.attributes.push([ {
            type: "ATOM",
            value: "CHANGEDSINCE"
        }, {
            type: "ATOM",
            value: o.changedSince
        } ]), i;
    }, r.prototype._parseFETCH = function(e) {
        var t;
        return e && e.payload && e.payload.FETCH && e.payload.FETCH.length ? t = [].concat(e.payload.FETCH || []).map(function(e) {
            var t, o, i, r = [].concat([].concat(e.attributes || [])[0] || []), s = {
                "#": e.nr
            };
            for (t = 0, o = r.length; o > t; t++) 0 !== t % 2 ? s[i] = this._parseFetchValue(i, r[t]) : i = n.compiler({
                attributes: [ r[t] ]
            }).toLowerCase().replace(/<\d+>$/, "");
            return s;
        }.bind(this)) : [];
    }, r.prototype._parseFetchValue = function(e, t) {
        if (!t) return null;
        if (!Array.isArray(t)) {
            switch (e) {
              case "uid":
              case "rfc822.size":
                return Number(t.value) || 0;

              case "modseq":
                return t.value || "0";
            }
            return t.value;
        }
        switch (e) {
          case "flags":
            t = [].concat(t).map(function(e) {
                return e.value || "";
            });
            break;

          case "envelope":
            t = this._parseENVELOPE([].concat(t || []));
            break;

          case "bodystructure":
            t = this._parseBODYSTRUCTURE([].concat(t || []));
            break;

          case "modseq":
            t = (t.shift() || {}).value || "0";
        }
        return t;
    }, r.prototype._parseENVELOPE = function(e) {
        var t = function(e) {
            return [].concat(e || []).map(function(e) {
                return {
                    name: o.mimeWordsDecode(e[0] && e[0].value || ""),
                    address: (e[2] && e[2].value || "") + "@" + (e[3] && e[3].value || "")
                };
            });
        }, n = {};
        return e[0] && e[0].value && (n.date = e[0].value), e[1] && e[1].value && (n.subject = o.mimeWordsDecode(e[1] && e[1].value)), 
        e[2] && e[2].length && (n.from = t(e[2])), e[3] && e[3].length && (n.sender = t(e[3])), 
        e[4] && e[4].length && (n["reply-to"] = t(e[4])), e[5] && e[5].length && (n.to = t(e[5])), 
        e[6] && e[6].length && (n.cc = t(e[6])), e[7] && e[7].length && (n.bcc = t(e[7])), 
        e[8] && e[8].value && (n["in-reply-to"] = e[8].value), e[9] && e[9].value && (n["message-id"] = e[9].value), 
        n;
    }, r.prototype._parseBODYSTRUCTURE = function(e) {
        var t = this, n = function(e, i) {
            i = i || [];
            var r, s = {}, a = 0, c = 0;
            if (i.length && (s.part = i.join(".")), Array.isArray(e[0])) {
                for (s.childNodes = []; Array.isArray(e[a]); ) s.childNodes.push(n(e[a], i.concat(++c))), 
                a++;
                s.type = "multipart/" + ((e[a++] || {}).value || "").toString().toLowerCase(), a < e.length - 1 && (e[a] && (s.parameters = {}, 
                [].concat(e[a] || []).forEach(function(e, t) {
                    t % 2 ? s.parameters[r] = o.mimeWordsDecode((e && e.value || "").toString()) : r = (e && e.value || "").toString().toLowerCase();
                })), a++);
            } else s.type = [ ((e[a++] || {}).value || "").toString().toLowerCase(), ((e[a++] || {}).value || "").toString().toLowerCase() ].join("/"), 
            e[a] && (s.parameters = {}, [].concat(e[a] || []).forEach(function(e, t) {
                t % 2 ? s.parameters[r] = o.mimeWordsDecode((e && e.value || "").toString()) : r = (e && e.value || "").toString().toLowerCase();
            })), a++, e[a] && (s.id = ((e[a] || {}).value || "").toString()), a++, e[a] && (s.description = ((e[a] || {}).value || "").toString()), 
            a++, e[a] && (s.encoding = ((e[a] || {}).value || "").toString().toLowerCase()), 
            a++, e[a] && (s.size = Number((e[a] || {}).value || 0) || 0), a++, "message/rfc822" === s.type ? (e[a] && (s.envelope = t._parseENVELOPE([].concat(e[a] || []))), 
            a++, e[a] && (s.childNodes = [ n(e[a], i) ]), a++, e[a] && (s.lineCount = Number((e[a] || {}).value || 0) || 0), 
            a++) : /^text\//.test(s.type) && (e[a] && (s.lineCount = Number((e[a] || {}).value || 0) || 0), 
            a++), a < e.length - 1 && (e[a] && (s.md5 = ((e[a] || {}).value || "").toString().toLowerCase()), 
            a++);
            return a < e.length - 1 && (Array.isArray(e[a]) && e[a].length && (s.disposition = ((e[a][0] || {}).value || "").toString().toLowerCase(), 
            Array.isArray(e[a][1]) && (s.dispositionParameters = {}, [].concat(e[a][1] || []).forEach(function(e, t) {
                t % 2 ? s.dispositionParameters[r] = o.mimeWordsDecode((e && e.value || "").toString()) : r = (e && e.value || "").toString().toLowerCase();
            }))), a++), a < e.length - 1 && (e[a] && (s.language = [].concat(e[a] || []).map(function(e) {
                return (e && e.value || "").toString().toLowerCase();
            })), a++), a < e.length - 1 && (e[a] && (s.location = ((e[a] || {}).value || "").toString()), 
            a++), s;
        };
        return n(e);
    }, r.prototype._buildSEARCHCommand = function(e, t) {
        var n = {
            command: t.byUid ? "UID SEARCH" : "SEARCH"
        }, i = !0, r = function(e) {
            var t = [];
            return Object.keys(e).forEach(function(n) {
                var s = [], a = function(e) {
                    return e.toUTCString().replace(/^\w+, 0?(\d+) (\w+) (\d+).*/, "$1-$2-$3");
                }, c = function(e) {
                    return "number" == typeof e ? {
                        type: "number",
                        value: e
                    } : "string" == typeof e ? /[\u0080-\uFFFF]/.test(e) ? (i = !1, {
                        type: "literal",
                        value: o.fromTypedArray(o.charset.encode(e))
                    }) : {
                        type: "string",
                        value: e
                    } : "[object Date]" === Object.prototype.toString.call(e) ? {
                        type: "atom",
                        value: a(e)
                    } : Array.isArray(e) ? e.map(c) : "object" == typeof e ? r(e) : void 0;
                };
                s.push({
                    type: "atom",
                    value: n.toUpperCase()
                }), [].concat(e[n] || []).forEach(function(e) {
                    switch (n.toLowerCase()) {
                      case "uid":
                        e = {
                            type: "sequence",
                            value: e
                        };
                        break;

                      default:
                        e = c(e);
                    }
                    e && (s = s.concat(e || []));
                }), t = t.concat(s || []);
            }), t;
        };
        return n.attributes = [].concat(r(e || {}) || []), i || (n.attributes.unshift({
            type: "atom",
            value: "UTF-8"
        }), n.attributes.unshift({
            type: "atom",
            value: "CHARSET"
        })), n;
    }, r.prototype._parseSEARCH = function(e) {
        var t = [];
        return e && e.payload && e.payload.SEARCH && e.payload.SEARCH.length ? ([].concat(e.payload.SEARCH || []).forEach(function(e) {
            [].concat(e.attributes || []).forEach(function(e) {
                e = Number(e && e.value || e || 0) || 0, t.indexOf(e) < 0 && t.push(e);
            });
        }.bind(this)), t.sort(function(e, t) {
            return e - t;
        }), t) : [];
    }, r.prototype._buildSTORECommand = function(e, t, n) {
        var o = {
            command: n.byUid ? "UID STORE" : "STORE",
            attributes: [ {
                type: "sequence",
                value: e
            } ]
        }, i = "", r = [];
        return (Array.isArray(t) || "object" != typeof t) && (t = {
            set: t
        }), t.add ? (r = [].concat(t.add || []), i = "+") : t.set ? (i = "", r = [].concat(t.set || [])) : t.remove && (i = "-", 
        r = [].concat(t.remove || [])), o.attributes.push({
            type: "atom",
            value: i + "FLAGS" + (n.silent ? ".SILENT" : "")
        }), o.attributes.push(r.map(function(e) {
            return {
                type: "atom",
                value: e
            };
        })), o;
    }, r.prototype._changeState = function(e) {
        e !== this.state && (i.debug(s, "entering state: " + this.state), this.state === this.STATE_SELECTED && this.selectedMailbox && (this.onclosemailbox(this.selectedMailbox), 
        this.selectedMailbox = !1), this.state = e);
    }, r.prototype._ensurePath = function(e, n, o) {
        var i, r, s, a = n.split(o), c = e;
        for (i = 0; i < a.length; i++) {
            for (s = !1, r = 0; r < c.children.length; r++) if (this._compareMailboxNames(c.children[r].name, t.imap.decode(a[i]))) {
                c = c.children[r], s = !0;
                break;
            }
            s || (c.children.push({
                name: t.imap.decode(a[i]),
                delimiter: o,
                path: a.slice(0, i + 1).join(o),
                children: []
            }), c = c.children[c.children.length - 1]);
        }
        return c;
    }, r.prototype._compareMailboxNames = function(e, t) {
        return ("INBOX" === e.toUpperCase() ? "INBOX" : e) === ("INBOX" === t.toUpperCase() ? "INBOX" : t);
    }, r.prototype._checkSpecialUse = function(e) {
        var t, n;
        if (e.flags) for (t = 0; t < a.length; t++) if (n = a[t], (e.flags || []).indexOf(n) >= 0) return e.specialUse = n, 
        n;
        return this._checkSpecialUseByName(e);
    }, r.prototype._checkSpecialUseByName = function(e) {
        var t, n, o = (e.name || "").toLowerCase().trim();
        for (t = 0; t < u.length; t++) if (n = u[t], c[n].indexOf(o) >= 0) return e.flags = [].concat(e.flags || []).concat(n), 
        e.specialUse = n, n;
        return !1;
    }, r.prototype._buildXOAuth2Token = function(e, t) {
        var n = [ "user=" + (e || ""), "auth=Bearer " + t, "", "" ];
        return o.base64.encode(n.join(""));
    }, r;
}), define("oauth", [ "require", "exports", "module", "./errorutils", "./syncbase", "./slog", "./date" ], function(e, t) {
    function n(e) {
        return r.log("oauth:renewing-access-token"), new Promise(function(t, n) {
            e._transientLastRenew = s.PERFNOW();
            var a = r.interceptable("oauth:renew-xhr", function() {
                return new XMLHttpRequest({
                    mozSystem: !0
                });
            });
            a.open("POST", e.tokenEndpoint, !0), a.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), 
            a.timeout = i.CONNECT_TIMEOUT_MS, a.send([ "client_id=", encodeURIComponent(e.clientId), "&client_secret=", encodeURIComponent(e.clientSecret), "&refresh_token=", encodeURIComponent(e.refreshToken), "&grant_type=refresh_token" ].join("")), 
            a.onload = function() {
                if (a.status < 200 || a.status >= 300) {
                    try {
                        var o = JSON.parse(a.responseText);
                    } catch (i) {}
                    r.error("oauth:xhr-fail", {
                        tokenEndpoint: e.tokenEndpoint,
                        status: a.status,
                        errResp: o
                    }), n("needs-oauth-reauth");
                } else try {
                    var u = JSON.parse(a.responseText);
                    if (u && u.access_token) {
                        r.log("oauth:got-access-token", {
                            _accessToken: u.access_token
                        });
                        var d = 1e3 * u.expires_in, l = s.NOW() + Math.max(0, d - c);
                        t({
                            accessToken: u.access_token,
                            expireTimeMS: l
                        });
                    } else r.error("oauth:no-access-token", {
                        data: a.responseText
                    }), n("needs-oauth-reauth");
                } catch (h) {
                    r.error("oauth:bad-json", {
                        error: h,
                        data: a.responseText
                    }), n("needs-oauth-reauth");
                }
            }, a.onerror = function(e) {
                n(o.analyzeException(e));
            }, a.ontimeout = function() {
                n("unresponsive-server");
            };
        });
    }
    var o = e("./errorutils"), i = e("./syncbase"), r = e("./slog"), s = e("./date"), a = 18e5, c = 3e4;
    t.isRenewPossible = function(e) {
        var t = e.oauth2, n = t && (t._transientLastRenew || 0), o = s.PERFNOW();
        return t ? !t || n && a > o - n ? !1 : !0 : !1;
    }, t.ensureUpdatedCredentials = function(e, t, o) {
        o && console.log("ensureUpdatedCredentials: force renewing token");
        var i = e.oauth2;
        return i && (!i.accessToken || i.expireTimeMS < s.NOW()) || o ? n(i).then(function(n) {
            i.accessToken = n.accessToken, i.expireTimeMS = n.expireTimeMS, r.log("oauth:credentials-changed", {
                _accessToken: i.accessToken,
                expireTimeMS: i.expireTimeMS
            }), t && t(e);
        }) : (r.log("oauth:credentials-ok"), Promise.resolve(!1));
    };
}), define("imap/client", [ "require", "exports", "module", "browserbox", "browserbox-imap", "imap-handler", "slog", "../syncbase", "../errorutils", "../oauth" ], function(e, t) {
    function n() {}
    function o(e, t) {
        if (!e || !e.response) return null;
        if (e.command && e.command.request && "STARTTLS" === e.command.request.command) return "bad-security";
        var n = t && !!t.options.auth.xoauth2, o = e.response, i = (o.code || "") + (o.humanReadable || "");
        return /Your account is not enabled for IMAP use/.test(i) || /IMAP access is disabled for your domain/.test(i) ? "imap-disabled" : /UNAVAILABLE/.test(i) ? "server-maintenance" : -1 == t.capability.indexOf("LOGINDISABLED") || t.authenticated ? /AUTHENTICATIONFAILED/.test(i) || /Invalid credentials/i.test(i) || /login failed/i.test(i) || /password/.test(i) || !t.authenticated ? n ? "needs-oauth-reauth" : "bad-user-or-pass" : null : "server-maintenance";
    }
    var i = e("browserbox"), r = e("browserbox-imap"), s = e("imap-handler"), a = e("slog"), c = e("../syncbase"), u = e("../errorutils"), d = e("../oauth"), l = window.setTimeout, h = window.clearTimeout;
    t.setTimeoutFunctions = function(e, t) {
        l = e, h = t;
    }, t.createImapConnection = function(e, o, r) {
        var s;
        return d.ensureUpdatedCredentials(e, r).then(function() {
            return new Promise(function(t, r) {
                s = new i(o.hostname, o.port, {
                    auth: {
                        user: e.username,
                        pass: e.password,
                        xoauth2: e.oauth2 ? e.oauth2.accessToken : null
                    },
                    id: {
                        vendor: "Mozilla",
                        name: "GaiaMail",
                        version: "0.2",
                        "support-url": "http://mzl.la/file-gaia-email-bug"
                    },
                    useSecureTransport: "ssl" === o.crypto || o.crypto === !0,
                    requireTLS: "starttls" === o.crypto,
                    ignoreTLS: "plain" === o.crypto
                });
                var u = l(function() {
                    s.onerror("unresponsive-server"), s.close();
                }, c.CONNECT_TIMEOUT_MS);
                s.onauth = function() {
                    h(u), a.info("imap:connected", o), s.onauth = s.onerror = n, t(s);
                }, s.onerror = function(e) {
                    h(u), r(e);
                }, s.connect();
            });
        }).catch(function(n) {
            var i = f(s, n);
            if (s && s.close(), "needs-oauth-reauth" === i && d.isRenewPossible(e)) return d.ensureUpdatedCredentials(e, r, !0).then(function() {
                return t.createImapConnection(e, o, r);
            });
            throw a.error("imap:connect-error", {
                error: i
            }), i;
        });
    };
    var p = r.prototype._processResponse;
    r.prototype._processResponse = function(e) {
        p.apply(this, arguments);
        var t = (e && e.command || "").toString().toUpperCase().trim();
        -1 !== [ "NO", "BAD" ].indexOf(t) && (a.log("imap:protocol-error", {
            humanReadable: e.humanReadable,
            responseCode: e.code,
            commandData: this._currentCommand && this._currentCommand.request && s.compiler(this._currentCommand.request)
        }), this._lastImapError = {
            command: this._currentCommand,
            response: e
        });
    }, r.prototype._onError = function(e) {
        this.isError(e) ? this.onerror(e) : e && this.isError(e.data) ? this.onerror(e.data) : this.onerror(e && e.data && e.data.message || e.data || e || "Error"), 
        this.close();
    };
    var f = t.normalizeImapError = function(e, t) {
        var n = u.analyzeException(t), i = e && o(e.client._lastImapError, e), r = n || i || "unknown";
        return a.error("imap:normalized-error", {
            error: t,
            errorName: t && t.name,
            errorMessage: t && t.message,
            errorStack: t && t.stack,
            socketLevelError: n,
            protocolLevelError: i,
            reportAs: r
        }), r;
    };
}), define("imap/account", [ "rdcommon/log", "slog", "../a64", "../accountmixins", "../allback", "../errbackoff", "../mailslice", "../searchfilter", "../syncbase", "../util", "../composite/incoming", "./folder", "./jobs", "./client", "../errorutils", "../disaster-recovery", "module", "require", "exports" ], function(e, t, n, o, i, r, s, a, c, u, d, l, h, p, f, m, g, _, y) {
    function v(e, t, n, o, i, s, a, c, u) {
        this._LOG = w.ImapAccount(this, c, n), b.apply(this, [ l.ImapFolderSyncer ].concat(Array.slice(arguments))), 
        this._maxConnsAllowed = 3, this._pendingConn = null, this._ownedConns = [], this._demandedConns = [], 
        this._backoffEndpoint = r.createEndpoint("imap:" + this.id, this, this._LOG), u && this._reuseConnection(u), 
        this.tzOffset = t.accountDef.tzOffset, this._jobDriver = new h.ImapJobDriver(this, this._folderInfos.$mutationState, this._LOG), 
        this._TEST_doNotCloseFolder = !1, this.ensureEssentialOfflineFolders();
    }
    u.bsearchForInsert, i.allbackMaker;
    var b = d.CompositeIncomingAccount;
    y.Account = y.ImapAccount = v, v.prototype = Object.create(b.prototype);
    var S = {
        type: "imap",
        supportsServerFolders: !0,
        toString: function() {
            return "[ImapAccount: " + this.id + "]";
        },
        get isGmail() {
            return -1 !== this.meta.capability.indexOf("X-GM-EXT-1");
        },
        get numActiveConns() {
            return this._ownedConns.length;
        },
        __folderDemandsConnection: function(e, t, n, o, i) {
            if (i && !this.universe.online) return window.setZeroTimeout(o), void 0;
            var r = {
                folderId: e,
                label: t,
                callback: n,
                deathback: o,
                dieOnConnectFailure: Boolean(i)
            };
            this._demandedConns.push(r), this._demandedConns.length > 1 || this._allocateExistingConnection() || this._makeConnectionIfPossible();
        },
        _killDieOnConnectFailureDemands: function() {
            for (var e = 0; e < this._demandedConns.length; e++) {
                var t = this._demandedConns[e];
                t.dieOnConnectFailure && (t.deathback.call(null), this._demandedConns.splice(e--, 1));
            }
        },
        _allocateExistingConnection: function() {
            if (!this._demandedConns.length) return !1;
            for (var e = this._demandedConns[0], t = 0; t < this._ownedConns.length; t++) {
                var n = this._ownedConns[t];
                if (e.folderId && n.folderId === e.folderId && this._LOG.folderAlreadyHasConn(e.folderId), 
                !n.inUseBy) return n.inUseBy = e, this._demandedConns.shift(), this._LOG.reuseConnection(e.folderId, e.label), 
                e.callback(n.conn), !0;
            }
            return !1;
        },
        allOperationsCompleted: function() {
            this.maybeCloseUnusedConnections();
        },
        maybeCloseUnusedConnections: function() {
            !c.KILL_CONNECTIONS_WHEN_JOBLESS || this._demandedConns.length || this.universe.areServerJobsWaiting(this) || this.closeUnusedConnections();
        },
        closeUnusedConnections: function() {
            for (var e = this._ownedConns.length - 1; e >= 0; e--) {
                var t = this._ownedConns[e];
                t.inUseBy || (console.log("Killing unused IMAP connection."), this._ownedConns.splice(e, 1), 
                t.conn.client.close(), this._LOG.deadConnection("unused", null));
            }
        },
        _makeConnectionIfPossible: function() {
            if (this._ownedConns.length >= this._maxConnsAllowed) return this._LOG.maximumConnsNoNew(), 
            void 0;
            if (!this._pendingConn) {
                this._pendingConn = !0;
                var e = this._makeConnection.bind(this);
                this._backoffEndpoint.scheduleConnectAttempt(e);
            }
        },
        _makeConnection: function(e, t, n) {
            this._pendingConn = !0, _([ "./client" ], function(o) {
                this._LOG.createConnection(t, n), o.createImapConnection(this._credentials, this._connInfo, function() {
                    return new Promise(function(e) {
                        this.universe.saveAccountDef(this.compositeAccount.accountDef, null, e);
                    }.bind(this));
                }.bind(this)).then(function(t) {
                    m.associateSocketWithAccount(t.client.socket, this), this._pendingConn = null, this._bindConnectionDeathHandlers(t), 
                    this._backoffEndpoint.noteConnectSuccess(), this._ownedConns.push({
                        conn: t,
                        inUseBy: null
                    }), this._allocateExistingConnection(), this._demandedConns.length && this._makeConnectionIfPossible(), 
                    e && e(null);
                }.bind(this)).catch(function(n) {
                    this._LOG.deadConnection("connect-error", t), f.shouldReportProblem(n) && this.universe.__reportAccountProblem(this.compositeAccount, n, "incoming"), 
                    this._pendingConn = null, e && e(n), f.shouldRetry(n) ? this._backoffEndpoint.noteConnectFailureMaybeRetry(f.wasErrorFromReachableState(n)) ? this._makeConnectionIfPossible() : this._killDieOnConnectFailureDemands() : (this._backoffEndpoint.noteBrokenConnection(), 
                    this._killDieOnConnectFailureDemands());
                }.bind(this));
            }.bind(this));
        },
        _reuseConnection: function(e) {
            m.associateSocketWithAccount(e.client.socket, this), this._ownedConns.push({
                conn: e,
                inUseBy: null
            }), this._bindConnectionDeathHandlers(e);
        },
        _bindConnectionDeathHandlers: function(e) {
            e.breakIdle(function() {
                e.client.TIMEOUT_ENTER_IDLE = c.STALE_CONNECTION_TIMEOUT_MS, e.client.onidle = function() {
                    console.warn("Killing stale IMAP connection."), e.client.close();
                }, e.client._enterIdle();
            }), e.onclose = function() {
                for (var t = 0; t < this._ownedConns.length; t++) {
                    var n = this._ownedConns[t];
                    if (n.conn === e) return this._LOG.deadConnection("closed", n.inUseBy && n.inUseBy.folderId), 
                    n.inUseBy && n.inUseBy.deathback && n.inUseBy.deathback(e), n.inUseBy = null, this._ownedConns.splice(t, 1), 
                    void 0;
                }
            }.bind(this), e.onerror = function(t) {
                t = p.normalizeImapError(e, t), this._LOG.connectionError(t), console.error("imap:onerror", JSON.stringify({
                    error: t,
                    host: this._connInfo.hostname,
                    port: this._connInfo.port
                }));
            }.bind(this);
        },
        __folderDoneWithConnection: function(e, t, n) {
            for (var o = 0; o < this._ownedConns.length; o++) {
                var i = this._ownedConns[o];
                if (i.conn === e) return n && this._backoffEndpoint(i.inUseBy.folderId), this._LOG.releaseConnection(i.inUseBy.folderId, i.inUseBy.label), 
                i.inUseBy = null, this.maybeCloseUnusedConnections(), void 0;
            }
            this._LOG.connectionMismatch();
        },
        _syncFolderList: function(e, t) {
            e.listMailboxes(this._syncFolderComputeDeltas.bind(this, e, t));
        },
        _determineFolderType: function(e, t) {
            var n = (e.flags || []).map(function(e) {
                return e.substr(1).toUpperCase();
            }), o = null;
            if (-1 !== n.indexOf("NOSELECT")) o = "nomail"; else {
                for (var i = 0; i < n.length; i++) switch (n[i]) {
                  case "ALL":
                  case "ALLMAIL":
                  case "ARCHIVE":
                    o = "archive";
                    break;

                  case "DRAFTS":
                    o = "drafts";
                    break;

                  case "FLAGGED":
                    o = "starred";
                    break;

                  case "IMPORTANT":
                    o = "important";
                    break;

                  case "INBOX":
                    o = "inbox";
                    break;

                  case "JUNK":
                    o = "junk";
                    break;

                  case "SENT":
                    o = "sent";
                    break;

                  case "SPAM":
                    o = "junk";
                    break;

                  case "STARRED":
                    o = "starred";
                    break;

                  case "TRASH":
                    o = "trash";
                    break;

                  case "HASCHILDREN":
                  case "HASNOCHILDREN":
                  case "MARKED":
                  case "UNMARKED":
                  case "NOINFERIORS":                }
                if (!o) {
                    var r = this._namespaces.personal[0] && this._namespaces.personal[0].prefix, s = t === r + e.name;
                    if (s || t === e.name) switch (e.name.toUpperCase()) {
                      case "DRAFT":
                      case "DRAFTS":
                        o = "drafts";
                        break;

                      case "INBOX":
                        "INBOX" === t.toUpperCase() && (o = "inbox");
                        break;

                      case "BULK MAIL":
                      case "JUNK":
                      case "SPAM":
                        o = "junk";
                        break;

                      case "SENT":
                        o = "sent";
                        break;

                      case "TRASH":
                        o = "trash";
                        break;

                      case "UNSENT MESSAGES":
                        o = "queue";
                    }
                }
                o || (o = "normal");
            }
            return o;
        },
        _namespaces: {
            personal: {
                prefix: "",
                delimiter: "/"
            },
            provisional: !0
        },
        _syncFolderComputeDeltas: function(e, n, o, i) {
            function r(e, n, o) {
                e.forEach(function(e) {
                    var i;
                    e.name;
                    var s = e.delimiter || "/";
                    0 === e.path.indexOf(s) && (e.path = e.path.slice(s.length));
                    var c = e.path, d = a._determineFolderType(e, c);
                    "inbox" === d && (c = "INBOX"), u.hasOwnProperty(c) ? (i = u[c], i.name = e.name, 
                    i.delim = s, t.log("imap:folder-sync:existing", {
                        type: d,
                        name: e.name,
                        path: c,
                        delim: s
                    }), u[c] = !0) : (t.log("imap:folder-sync:add", {
                        type: d,
                        name: e.name,
                        path: c,
                        delim: s
                    }), i = a._learnAboutFolder(e.name, c, o, d, s, n)), e.children && r(e.children, n + 1, i.id);
                });
            }
            var a = this;
            if (o) return n(o), void 0;
            if (a._namespaces.provisional) return e.listNamespaces(function(o, r) {
                !o && r && (a._namespaces = r), a._namespaces.provisional = !1, t.log("imap:list-namespaces", {
                    namespaces: r
                }), a._syncFolderComputeDeltas(e, n, o, i);
            }), void 0;
            for (var c, u = {}, d = 0; d < this.folders.length; d++) c = this.folders[d], u[c.path] = c;
            r(i.children, "", 0, null);
            for (var l in u) c = u[l], c !== !0 && (s.FolderStorage.isTypeLocalOnly(c.type) || (t.log("imap:delete-dead-folder", {
                type: c.type,
                id: c.id
            }), this._forgetFolder(c.id)));
            this.ensureEssentialOnlineFolders(), this.normalizeFolderHierarchy(), n(null);
        },
        ensureEssentialOfflineFolders: function() {
            [ "outbox", "localdrafts" ].forEach(function(e) {
                this.getFirstFolderWithType(e) || this._learnAboutFolder(e, e, null, e, "", 0, !0);
            }, this);
        },
        ensureEssentialOnlineFolders: function(e) {
            var t = {
                trash: "Trash",
                sent: "Sent"
            }, n = i.latch();
            for (var o in t) this.getFirstFolderWithType(o) || this.universe.createFolder(this.id, null, t[o], o, !1, n.defer());
            n.then(e);
        },
        normalizeFolderHierarchy: o.normalizeFolderHierarchy,
        saveSentMessage: function(e) {
            this.isGmail || e.withMessageBlob({
                includeBcc: !0
            }, function(e) {
                var t = {
                    messageText: e,
                    flags: [ "\\Seen" ]
                }, n = this.getFirstFolderWithType("sent");
                n && this.universe.appendMessages(n.id, [ t ]);
            }.bind(this));
        },
        shutdown: function(e) {
            function t() {
                0 === --n && e();
            }
            b.prototype.shutdownFolders.call(this), this._backoffEndpoint.shutdown();
            for (var n = this._ownedConns.length, o = 0; o < this._ownedConns.length; o++) {
                var i = this._ownedConns[o];
                if (e) {
                    i.inUseBy = {
                        deathback: t
                    };
                    try {
                        i.conn.client.close();
                    } catch (r) {
                        n--;
                    }
                } else i.conn.client.close();
            }
            this._LOG.__die(), !n && e && e();
        },
        checkAccount: function(e) {
            this._LOG.checkAccount_begin(null), this._makeConnection(function(t) {
                this._LOG.checkAccount_end(t), e(t);
            }.bind(this), null, "check");
        },
        accountDeleted: function() {
            this._alive = !1, this.shutdown();
        }
    };
    for (var T in S) Object.defineProperty(v.prototype, T, Object.getOwnPropertyDescriptor(S, T));
    var w = y.LOGFAB = e.register(g, {
        ImapAccount: d.LOGFAB_DEFINITION.CompositeIncomingAccount
    });
}), define("md5", [ "require", "exports", "module" ], function(e, t, n) {
    function o(e) {
        return r(i(s(e)));
    }
    function i(e) {
        return c(u(a(e), 8 * e.length));
    }
    function r(e) {
        try {} catch (t) {
            _ = 0;
        }
        for (var n, o = _ ? "0123456789ABCDEF" : "0123456789abcdef", i = "", r = 0; r < e.length; r++) n = e.charCodeAt(r), 
        i += o.charAt(15 & n >>> 4) + o.charAt(15 & n);
        return i;
    }
    function s(e) {
        for (var t, n, o = "", i = -1; ++i < e.length; ) t = e.charCodeAt(i), n = i + 1 < e.length ? e.charCodeAt(i + 1) : 0, 
        t >= 55296 && 56319 >= t && n >= 56320 && 57343 >= n && (t = 65536 + ((1023 & t) << 10) + (1023 & n), 
        i++), 127 >= t ? o += String.fromCharCode(t) : 2047 >= t ? o += String.fromCharCode(192 | 31 & t >>> 6, 128 | 63 & t) : 65535 >= t ? o += String.fromCharCode(224 | 15 & t >>> 12, 128 | 63 & t >>> 6, 128 | 63 & t) : 2097151 >= t && (o += String.fromCharCode(240 | 7 & t >>> 18, 128 | 63 & t >>> 12, 128 | 63 & t >>> 6, 128 | 63 & t));
        return o;
    }
    function a(e) {
        for (var t = Array(e.length >> 2), n = 0; n < t.length; n++) t[n] = 0;
        for (var n = 0; n < 8 * e.length; n += 8) t[n >> 5] |= (255 & e.charCodeAt(n / 8)) << n % 32;
        return t;
    }
    function c(e) {
        for (var t = "", n = 0; n < 32 * e.length; n += 8) t += String.fromCharCode(255 & e[n >> 5] >>> n % 32);
        return t;
    }
    function u(e, t) {
        e[t >> 5] |= 128 << t % 32, e[(t + 64 >>> 9 << 4) + 14] = t;
        for (var n = 1732584193, o = -271733879, i = -1732584194, r = 271733878, s = 0; s < e.length; s += 16) {
            var a = n, c = o, u = i, d = r;
            n = l(n, o, i, r, e[s + 0], 7, -680876936), r = l(r, n, o, i, e[s + 1], 12, -389564586), 
            i = l(i, r, n, o, e[s + 2], 17, 606105819), o = l(o, i, r, n, e[s + 3], 22, -1044525330), 
            n = l(n, o, i, r, e[s + 4], 7, -176418897), r = l(r, n, o, i, e[s + 5], 12, 1200080426), 
            i = l(i, r, n, o, e[s + 6], 17, -1473231341), o = l(o, i, r, n, e[s + 7], 22, -45705983), 
            n = l(n, o, i, r, e[s + 8], 7, 1770035416), r = l(r, n, o, i, e[s + 9], 12, -1958414417), 
            i = l(i, r, n, o, e[s + 10], 17, -42063), o = l(o, i, r, n, e[s + 11], 22, -1990404162), 
            n = l(n, o, i, r, e[s + 12], 7, 1804603682), r = l(r, n, o, i, e[s + 13], 12, -40341101), 
            i = l(i, r, n, o, e[s + 14], 17, -1502002290), o = l(o, i, r, n, e[s + 15], 22, 1236535329), 
            n = h(n, o, i, r, e[s + 1], 5, -165796510), r = h(r, n, o, i, e[s + 6], 9, -1069501632), 
            i = h(i, r, n, o, e[s + 11], 14, 643717713), o = h(o, i, r, n, e[s + 0], 20, -373897302), 
            n = h(n, o, i, r, e[s + 5], 5, -701558691), r = h(r, n, o, i, e[s + 10], 9, 38016083), 
            i = h(i, r, n, o, e[s + 15], 14, -660478335), o = h(o, i, r, n, e[s + 4], 20, -405537848), 
            n = h(n, o, i, r, e[s + 9], 5, 568446438), r = h(r, n, o, i, e[s + 14], 9, -1019803690), 
            i = h(i, r, n, o, e[s + 3], 14, -187363961), o = h(o, i, r, n, e[s + 8], 20, 1163531501), 
            n = h(n, o, i, r, e[s + 13], 5, -1444681467), r = h(r, n, o, i, e[s + 2], 9, -51403784), 
            i = h(i, r, n, o, e[s + 7], 14, 1735328473), o = h(o, i, r, n, e[s + 12], 20, -1926607734), 
            n = p(n, o, i, r, e[s + 5], 4, -378558), r = p(r, n, o, i, e[s + 8], 11, -2022574463), 
            i = p(i, r, n, o, e[s + 11], 16, 1839030562), o = p(o, i, r, n, e[s + 14], 23, -35309556), 
            n = p(n, o, i, r, e[s + 1], 4, -1530992060), r = p(r, n, o, i, e[s + 4], 11, 1272893353), 
            i = p(i, r, n, o, e[s + 7], 16, -155497632), o = p(o, i, r, n, e[s + 10], 23, -1094730640), 
            n = p(n, o, i, r, e[s + 13], 4, 681279174), r = p(r, n, o, i, e[s + 0], 11, -358537222), 
            i = p(i, r, n, o, e[s + 3], 16, -722521979), o = p(o, i, r, n, e[s + 6], 23, 76029189), 
            n = p(n, o, i, r, e[s + 9], 4, -640364487), r = p(r, n, o, i, e[s + 12], 11, -421815835), 
            i = p(i, r, n, o, e[s + 15], 16, 530742520), o = p(o, i, r, n, e[s + 2], 23, -995338651), 
            n = f(n, o, i, r, e[s + 0], 6, -198630844), r = f(r, n, o, i, e[s + 7], 10, 1126891415), 
            i = f(i, r, n, o, e[s + 14], 15, -1416354905), o = f(o, i, r, n, e[s + 5], 21, -57434055), 
            n = f(n, o, i, r, e[s + 12], 6, 1700485571), r = f(r, n, o, i, e[s + 3], 10, -1894986606), 
            i = f(i, r, n, o, e[s + 10], 15, -1051523), o = f(o, i, r, n, e[s + 1], 21, -2054922799), 
            n = f(n, o, i, r, e[s + 8], 6, 1873313359), r = f(r, n, o, i, e[s + 15], 10, -30611744), 
            i = f(i, r, n, o, e[s + 6], 15, -1560198380), o = f(o, i, r, n, e[s + 13], 21, 1309151649), 
            n = f(n, o, i, r, e[s + 4], 6, -145523070), r = f(r, n, o, i, e[s + 11], 10, -1120210379), 
            i = f(i, r, n, o, e[s + 2], 15, 718787259), o = f(o, i, r, n, e[s + 9], 21, -343485551), 
            n = m(n, a), o = m(o, c), i = m(i, u), r = m(r, d);
        }
        return Array(n, o, i, r);
    }
    function d(e, t, n, o, i, r) {
        return m(g(m(m(t, e), m(o, r)), i), n);
    }
    function l(e, t, n, o, i, r, s) {
        return d(t & n | ~t & o, e, t, i, r, s);
    }
    function h(e, t, n, o, i, r, s) {
        return d(t & o | n & ~o, e, t, i, r, s);
    }
    function p(e, t, n, o, i, r, s) {
        return d(t ^ n ^ o, e, t, i, r, s);
    }
    function f(e, t, n, o, i, r, s) {
        return d(n ^ (t | ~o), e, t, i, r, s);
    }
    function m(e, t) {
        var n = (65535 & e) + (65535 & t), o = (e >> 16) + (t >> 16) + (n >> 16);
        return o << 16 | 65535 & n;
    }
    function g(e, t) {
        return e << t | e >>> 32 - t;
    }
    n.exports = function(e) {
        return o(e);
    };
    var _ = 0;
}), define("pop3/transport", [ "mimefuncs", "exports" ], function(e, t) {
    function n(e, t) {
        var n = new Uint8Array(e.length + t.length);
        return n.set(e, 0), n.set(t, e.length), n;
    }
    function o() {
        this.buffer = new Uint8Array(0), this.unprocessedLines = [];
    }
    function i(e, t) {
        this.lines = e, this.isMultiline = t, this.ok = this.lines[0][0] === d, this.err = !this.ok, 
        this.request = null;
    }
    function r(e, t, n, o) {
        this.command = e, this.args = t, this.expectMultiline = n, this.onresponse = o || null;
    }
    function s() {
        this.parser = new o(), this.onsend = function() {
            throw new Error("You must implement Pop3Protocol.onsend to send data.");
        }, this.unsentRequests = [], this.pipeline = !1, this.pendingRequests = [], this.closed = !1;
    }
    window.setTimeout.bind(window), window.clearTimeout.bind(window);
    var a = "\r".charCodeAt(0), c = "\n".charCodeAt(0), u = ".".charCodeAt(0), d = "+".charCodeAt(0);
    "-".charCodeAt(0), " ".charCodeAt(0);
    var l = new TextEncoder("utf-8", {
        fatal: !1
    });
    o.prototype.push = function(e) {
        for (var t = this.buffer = n(this.buffer, e), o = 0; o < t.length - 1; o++) if (t[o] === a && t[o + 1] === c) {
            var i = o + 1;
            this.unprocessedLines.push(t.subarray(0, i + 1)), t = this.buffer = t.subarray(i + 1), 
            o = -1;
        }
    }, o.prototype.extractResponse = function(e) {
        if (!this.unprocessedLines.length) return null;
        if (this.unprocessedLines[0][0] !== d && (e = !1), e) {
            for (var t = -1, n = 1; n < this.unprocessedLines.length; n++) {
                var o = this.unprocessedLines[n];
                if (3 === o.byteLength && o[0] === u && o[1] === a && o[2] === c) {
                    t = n;
                    break;
                }
            }
            if (-1 === t) return null;
            var r = this.unprocessedLines.splice(0, t + 1);
            r.pop();
            for (var n = 1; t > n; n++) r[n][0] === u && (r[n] = r[n].subarray(1));
            return new i(r, !0);
        }
        return new i([ this.unprocessedLines.shift() ], !1);
    }, i.prototype.getStatusLine = function() {
        return this.getLineAsString(0).replace(/^(\+OK|-ERR) /, "");
    }, i.prototype.getLineAsString = function(t) {
        return e.fromTypedArray(this.lines[t]);
    }, i.prototype.getLinesAsString = function() {
        for (var e = [], t = 0; t < this.lines.length; t++) e.push(this.getLineAsString(t));
        return e;
    }, i.prototype.getDataLines = function() {
        for (var e = [], t = 1; t < this.lines.length; t++) {
            var n = this.getLineAsString(t);
            e.push(n.slice(0, n.length - 2));
        }
        return e;
    }, i.prototype.getDataAsString = function() {
        for (var e = [], t = 1; t < this.lines.length; t++) e.push(this.getLineAsString(t));
        return e.join("");
    }, i.prototype.toString = function() {
        return this.getLinesAsString().join("\r\n");
    }, t.Request = r, r.prototype.toByteArray = function() {
        return l.encode(this.command + (this.args.length ? " " + this.args.join(" ") : "") + "\r\n");
    }, r.prototype._respondWithError = function(e) {
        var t = new i([ l.encode("-ERR " + e + "\r\n") ], !1);
        t.request = this, this.onresponse(t, null);
    }, t.Response = i, t.Pop3Protocol = s, s.prototype.sendRequest = function(e, t, n, o) {
        var i;
        return i = e instanceof r ? e : new r(e, t, n, o), this.closed ? (i._respondWithError("(request sent after connection closed)"), 
        void 0) : (this.pipeline || 0 === this.pendingRequests.length ? (this.onsend(i.toByteArray()), 
        this.pendingRequests.push(i)) : this.unsentRequests.push(i), void 0);
    }, s.prototype.onreceive = function(e) {
        this.parser.push(new Uint8Array(e.data));
        for (var t; ;) {
            var n = this.pendingRequests[0];
            if (t = this.parser.extractResponse(n && n.expectMultiline), !t) break;
            if (!n) {
                console.error("Unsolicited response from server: " + t);
                break;
            }
            t.request = n, this.pendingRequests.shift(), this.unsentRequests.length && this.sendRequest(this.unsentRequests.shift()), 
            n.onresponse && (t.err ? n.onresponse(t, null) : n.onresponse(null, t));
        }
    }, s.prototype.onclose = function() {
        this.closed = !0;
        var e = this.pendingRequests.concat(this.unsentRequests);
        this.pendingRequests = [], this.unsentRequests = [];
        for (var t = 0; t < e.length; t++) {
            var n = e[t];
            n._respondWithError("(connection closed, no response)");
        }
    };
}), define("imap/imapchew", [ "mimefuncs", "../db/mail_rep", "../mailchew", "mimeparser", "exports" ], function(e, t, n, o, i) {
    function r(t) {
        var n = /^([^']*)'([^']*)'(.+)$/.exec(t);
        return n ? e.mimeWordsDecode("=?" + (n[1] || "us-ascii") + "?Q?" + n[3].replace(/%/g, "=") + "?=") : null;
    }
    function s(e) {
        return Array.isArray(e) ? e.map(s) : e && "<" === e[0] ? e.slice(1, -1) : e;
    }
    function a(e, t) {
        return e.headers[t] && e.headers[t][0] || null;
    }
    function c(n) {
        function o(e) {
            var t = e.encoding.toLowerCase();
            return "base64" === t ? Math.floor(57 * e.size / 78) : "quoted-printable" === t ? e.size : e.size;
        }
        function i(n, h) {
            var p, f, m, g = n.type.split("/")[0], _ = n.type.split("/")[1];
            if ("multipart" !== g) {
                if (f = n.parameters && n.parameters.name ? e.mimeWordsDecode(n.parameters.name) : n.parameters && n.parameters["name*"] ? r(n.parameters["name*"]) : n.dispositionParameters && n.dispositionParameters.filename ? e.mimeWordsDecode(n.dispositionParameters.filename) : n.dispositionParameters && n.dispositionParameters["filename*"] ? r(n.dispositionParameters["filename*"]) : null, 
                m = n.disposition ? "inline" == n.disposition.toLowerCase() ? "text" === g || n.id ? "inline" : "attachment" : "attachment" == n.disposition.toLowerCase() ? "attachment" : "inline" : "related" === h && n.id && "image" === g ? "inline" : f || "text" !== g ? "attachment" : "inline", 
                "text" !== g && "image" !== g && (m = "attachment"), "application" === g && ("pgp-signature" === _ || "pkcs7-signature" === _)) return !0;
                var y = function(e, n) {
                    return t.makeAttachmentPart({
                        name: n || "unnamed-" + ++d,
                        contentId: e.id ? s(e.id) : null,
                        type: e.type.toLowerCase(),
                        part: e.part,
                        encoding: e.encoding && e.encoding.toLowerCase(),
                        sizeEstimate: o(e),
                        file: null
                    });
                }, v = function(e) {
                    return t.makeBodyPart({
                        type: _,
                        part: e.part || "1",
                        sizeEstimate: e.size,
                        amountDownloaded: 0,
                        isDownloaded: 0 === e.size,
                        _partInfo: e.size ? {
                            partID: e.part,
                            type: g,
                            subtype: _,
                            params: u(e.parameters),
                            encoding: e.encoding && e.encoding.toLowerCase()
                        } : null,
                        content: ""
                    });
                };
                if ("attachment" === m) return a.push(y(n, f)), !0;
                switch (g) {
                  case "image":
                    return l.push(y(n, f)), !0;

                  case "text":
                    if ("plain" === _ || "html" === _) return c.push(v(n)), !0;
                }
                return !1;
            }
            switch (_) {
              case "alternative":
                for (p = n.childNodes.length - 1; p >= 0; p--) {
                    var b = n.childNodes[p], S = b.type.split("/")[0], T = b.type.split("/")[1];
                    switch (S) {
                      case "text":
                        break;

                      case "multipart":
                        if (i(b)) return !0;
                        break;

                      default:
                        continue;
                    }
                    switch (T) {
                      case "html":
                      case "plain":
                        if (i(b), _) return !0;
                    }
                }
                return !1;

              case "mixed":
              case "signed":
              case "related":
                for (p = 0; p < n.childNodes.length; p++) i(n.childNodes[p], _);
                return !0;

              default:
                return console.warn("Ignoring multipart type:", _), !1;
            }
        }
        var a = [], c = [], d = 0, l = [];
        return i(n.bodystructure), {
            bodyReps: c,
            attachments: a,
            relatedParts: l
        };
    }
    function u(e) {
        if (Array.isArray(e)) return e.map(u);
        if (e && "object" == typeof e) {
            if ("value" in e) return e.value;
            var t = {};
            for (var n in e) t[n] = u(e[n]);
            return t;
        }
        return e && "object" == typeof e ? e : void 0 !== e ? e : null;
    }
    i.chewHeaderAndBodyStructure = function(e, n, i) {
        var r = c(e);
        e.date = e.internaldate && f(e.internaldate), e.headers = {};
        for (var d in e) if (/header\.fields/.test(d)) {
            var l = new o();
            l.write(e[d] + "\r\n"), l.end(), e.headers = l.node.headers;
            break;
        }
        var h = u(a(e, "from")), p = u(a(e, "references"));
        return {
            header: t.makeHeaderInfo({
                id: i,
                srvid: e.uid,
                suid: n + "/" + i,
                guid: s(u(a(e, "message-id"))),
                author: h && h[0] || {
                    address: "missing-address@example.com"
                },
                to: u(a(e, "to")),
                cc: u(a(e, "cc")),
                bcc: u(a(e, "bcc")),
                replyTo: u(a(e, "reply-to")),
                date: e.date,
                flags: e.flags || [],
                hasAttachments: r.attachments.length > 0,
                subject: u(a(e, "subject")),
                snippet: null
            }),
            bodyInfo: t.makeBodyInfo({
                date: e.date,
                size: 0,
                attachments: r.attachments,
                relatedParts: r.relatedParts,
                references: p ? s(p.split(/\s+/)) : null,
                bodyReps: r.bodyReps
            })
        };
    }, i.updateMessageWithFetch = function(e, t, o, i, r) {
        var s = t.bodyReps[o.bodyRepIndex];
        (!o.bytes || i.bytesFetched < o.bytes[1]) && (s.isDownloaded = !0, s._partInfo = null), 
        !s.isDownloaded && i.buffer && (s._partInfo.pendingBuffer = i.buffer), s.amountDownloaded += i.bytesFetched;
        var a = n.processMessageContent(i.text, s.type, s.isDownloaded, o.createSnippet, r);
        o.createSnippet && (e.snippet = a.snippet), s.isDownloaded && (s.content = a.content);
    }, i.selectSnippetBodyRep = function(e, t) {
        if (e.snippet) return -1;
        for (var n = t.bodyReps, o = n.length, r = 0; o > r; r++) if (i.canBodyRepFillSnippet(n[r])) return r;
        return -1;
    }, i.canBodyRepFillSnippet = function(e) {
        return e && "plain" === e.type || "html" === e.type;
    }, i.calculateBytesToDownloadForImapBodyDisplay = function(e) {
        var t = 0;
        return e.bodyReps.forEach(function(e) {
            e.isDownloaded || (t += e.sizeEstimate - e.amountDownloaded);
        }), e.relatedParts.forEach(function(e) {
            e.file || (t += e.sizeEstimate);
        }), t;
    };
    var d = /^( ?\d|\d{2})-(.{3})-(\d{4}) (\d{2}):(\d{2}):(\d{2})(?: ([+-]\d{4}))?$/, l = 36e5, h = 6e4, p = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ], f = i.parseImapDateTime = function(e) {
        var t = d.exec(e);
        if (!t) throw new Error("Not a good IMAP date-time: " + e);
        var n = parseInt(t[1], 10), o = p.indexOf(t[2]), i = parseInt(t[3], 10), r = parseInt(t[4], 10), s = parseInt(t[5], 10), a = parseInt(t[6], 10), c = Date.UTC(i, o, n, r, s, a), u = t[7] ? parseInt(t[7], 10) : 0, f = Math.floor(u / 100), m = u % 100;
        return c -= f * l + m * h;
    };
    i.formatImapDateTime = function(e) {
        var t;
        return t = (e.getDate() < 10 ? " " : "") + e.getDate() + "-" + p[e.getMonth()] + "-" + e.getFullYear() + " " + ("0" + e.getHours()).slice(-2) + ":" + ("0" + e.getMinutes()).slice(-2) + ":" + ("0" + e.getSeconds()).slice(-2) + (e.getTimezoneOffset() > 0 ? " -" : " +") + ("0" + Math.abs(e.getTimezoneOffset()) / 60).slice(-2) + ("0" + Math.abs(e.getTimezoneOffset()) % 60).slice(-2);
    };
}), define("pop3/mime_mapper", [], function() {
    return {
        _typeToExtensionMap: {
            "image/jpeg": "jpg",
            "image/png": "png",
            "image/gif": "gif",
            "image/bmp": "bmp",
            "audio/mpeg": "mp3",
            "audio/mp4": "m4a",
            "audio/ogg": "ogg",
            "audio/webm": "webm",
            "audio/3gpp": "3gp",
            "audio/amr": "amr",
            "video/mp4": "mp4",
            "video/mpeg": "mpg",
            "video/ogg": "ogg",
            "video/webm": "webm",
            "video/3gpp": "3gp",
            "application/vcard": "vcf",
            "text/vcard": "vcf",
            "text/x-vcard": "vcf"
        },
        _extensionToTypeMap: {
            jpg: "image/jpeg",
            jpeg: "image/jpeg",
            jpe: "image/jpeg",
            png: "image/png",
            gif: "image/gif",
            bmp: "image/bmp",
            mp3: "audio/mpeg",
            m4a: "audio/mp4",
            m4b: "audio/mp4",
            m4p: "audio/mp4",
            m4r: "audio/mp4",
            aac: "audio/aac",
            opus: "audio/ogg",
            amr: "audio/amr",
            mp4: "video/mp4",
            mpeg: "video/mpeg",
            mpg: "video/mpeg",
            ogv: "video/ogg",
            ogx: "video/ogg",
            webm: "video/webm",
            "3gp": "video/3gpp",
            ogg: "video/ogg",
            vcf: "text/vcard"
        },
        _parseExtension: function(e) {
            var t = e.split(".");
            return t.length > 1 ? t.pop() : "";
        },
        isSupportedType: function(e) {
            return e in this._typeToExtensionMap;
        },
        isSupportedExtension: function(e) {
            return e in this._extensionToTypeMap;
        },
        isFilenameMatchesType: function(e, t) {
            var n = this._parseExtension(e), o = this.guessTypeFromExtension(n);
            return o == t;
        },
        guessExtensionFromType: function(e) {
            return this._typeToExtensionMap[e];
        },
        guessTypeFromExtension: function(e) {
            return this._extensionToTypeMap[e];
        },
        guessTypeFromFileProperties: function(e, t) {
            var n = this._parseExtension(e), o = this.isSupportedType(t) ? t : this.guessTypeFromExtension(n);
            return o || "";
        },
        ensureFilenameMatchesType: function(e, t) {
            if (!this.isFilenameMatchesType(e, t)) {
                var n = this.guessExtensionFromType(t);
                n && (e += "." + n);
            }
            return e;
        }
    };
}), define("pop3/pop3", [ "module", "exports", "rdcommon/log", "tcp-socket", "md5", "./transport", "mimeparser", "imap/imapchew", "syncbase", "date", "mimefuncs", "./mime_mapper", "allback" ], function(e, t, n, o, i, r, s, a, c, u, d, l, h) {
    function p(e, t, n) {
        var o = e.headers[t];
        return o && o[0] ? o[0].value : n || null;
    }
    function f(e, t) {
        var n = e.headers[t];
        return n && n[0] ? n[0].params || {} : {};
    }
    function m(e, t, n, o) {
        var i = {};
        i.part = t || "1", i.type = e.contentType.value, i.parameters = f(e, "content-type");
        var r = p(e, "content-disposition");
        if (r && (i.disposition = r, i.dispositionParameters = f(e, "content-disposition")), 
        i.id = p(e, "content-id"), i.encoding = "binary", i.size = e.content && e.content.length || 0, 
        i.description = null, i.lines = null, i.md5 = null, i.childNodes = [], null != e.content || /^multipart\//.test(i.type) || (e.content = new Uint8Array()), 
        null != e.content && (n[i.part] = e.content, o === e && (n.partial = i.part)), e._childNodes.length) for (var s = 0; s < e._childNodes.length; s++) {
            var a = e._childNodes[s];
            i.childNodes.push(m(a, i.part + "." + (s + 1), n, o));
        }
        return i;
    }
    var g = window.setTimeout.bind(window), _ = window.clearTimeout.bind(window);
    t.setTimeoutFunctions = function(e, t) {
        g = e, _ = t;
    };
    var y = t.Pop3Client = function(e, t) {
        if (this.options = e = e || {}, e.host = e.host || null, e.username = e.username || null, 
        e.password = e.password || null, e.port = e.port || null, e.crypto = e.crypto || !1, 
        e.connTimeout = e.connTimeout || 3e4, e.debug = e.debug || !1, e.authMethods = [ "apop", "sasl", "user-pass" ], 
        this._LOG = e._logParent ? v.Pop3Client(this, e._logParent, Date.now() % 1e3) : null, 
        e.preferredAuthMethod) {
            var n = e.authMethods.indexOf(e.preferredAuthMethod);
            -1 !== n && e.authMethods.splice(n, 1), e.authMethods.unshift(e.preferredAuthMethod);
        }
        if (e.crypto === !0 ? e.crypto = "ssl" : e.crypto || (e.crypto = "plain"), !e.port && (e.port = {
            plain: 110,
            starttls: 110,
            ssl: 995
        }[e.crypto], !e.port)) throw new Error("Invalid crypto option for Pop3Client: " + e.crypto);
        this.state = "disconnected", this.authMethod = null, this.idToUidl = {}, this.uidlToId = {}, 
        this.idToSize = {}, this._messageList = null, this._greetingLine = null, this.protocol = new r.Pop3Protocol(), 
        this.socket = o.open(e.host, e.port, {
            useSecureTransport: "ssl" === e.crypto || e.crypto === !0
        });
        var i = g(function() {
            this.state = "disconnected", i && (_(i), i = null), t && t({
                scope: "connection",
                request: null,
                name: "unresponsive-server",
                message: "Could not connect to " + e.host + ":" + e.port + " with " + e.crypto + " encryption."
            });
        }.bind(this), e.connTimeout);
        this.socket.ondata = this.protocol.onreceive.bind(this.protocol), this.protocol.onsend = this.socket.send.bind(this.socket), 
        this.socket.onopen = function() {
            console.log("pop3:onopen"), i && (_(i), i = null), this.state = "greeting";
        }.bind(this), this.socket.onerror = function(e) {
            var n = e && e.data || e;
            console.log("pop3:onerror", n), i && (_(i), i = null), t && t({
                scope: "connection",
                request: null,
                name: "unresponsive-server",
                message: "Socket exception: " + JSON.stringify(n),
                exception: n
            });
        }.bind(this), this.onclose = null, this.socket.onclose = function() {
            console.log("pop3:onclose"), this.protocol.onclose(), this.close(), this.onclose && this.onclose();
        }.bind(this), this.protocol.pendingRequests.push(new r.Request(null, [], !1, function(e, n) {
            return e ? (t && t({
                scope: "connection",
                request: null,
                name: "unresponsive-server",
                message: e.getStatusLine(),
                response: e
            }), void 0) : (this._greetingLine = n.getLineAsString(0), this._maybeUpgradeConnection(function(e) {
                return e ? (t && t(e), void 0) : (this._thenAuthorize(function(e) {
                    e || (this.state = "ready"), t && t(e);
                }), void 0);
            }.bind(this)), void 0);
        }.bind(this)));
    };
    y.prototype.close = y.prototype.die = function() {
        "disconnected" !== this.state && (this.state = "disconnected", this.socket.close());
    }, y.prototype._getCapabilities = function() {
        this.protocol.sendRequest("CAPA", [], !0, function(e, t) {
            if (e) this.capabilities = {}; else for (var n = t.getDataLines(), o = 0; o < n.length; o++) {
                var i = n[o].split(" ");
                this.capabilities[i[0]] = i.slice(1);
            }
        }.bind(this));
    }, y.prototype._maybeUpgradeConnection = function(e) {
        "starttls" === this.options.crypto ? (this.state = "starttls", this.protocol.sendRequest("STLS", [], !1, function(t) {
            return t ? (e && e({
                scope: "connection",
                request: t.request,
                name: "bad-security",
                message: t.getStatusLine(),
                response: t
            }), void 0) : (this.socket.upgradeToSecure(), e(), void 0);
        }.bind(this))) : e();
    }, y.prototype._thenAuthorize = function(e) {
        this.state = "authorization", this.authMethod = this.options.authMethods.shift();
        var t, n = this.options.username, o = this.options.password;
        switch (this.authMethod) {
          case "apop":
            var r = /<.*?>/.exec(this._greetingLine || ""), s = r && r[0];
            s ? (t = i(s + o).toLowerCase(), this.protocol.sendRequest("APOP", [ n, t ], !1, function(t) {
                t ? (this._greetingLine = null, this._thenAuthorize(e)) : e();
            }.bind(this))) : this._thenAuthorize(e);
            break;

          case "sasl":
            t = btoa(n + "\0" + n + "\0" + o), this.protocol.sendRequest("AUTH", [ "PLAIN", t ], !1, function(t) {
                t ? this._thenAuthorize(e) : e();
            }.bind(this));
            break;

          case "user-pass":
          default:
            this.protocol.sendRequest("USER", [ n ], !1, function(t) {
                return t ? (e && e({
                    scope: "authentication",
                    request: t.request,
                    name: "bad-user-or-pass",
                    message: t.getStatusLine(),
                    response: t
                }), void 0) : (this.protocol.sendRequest("PASS", [ o ], !1, function(t) {
                    return t ? (e && e({
                        scope: "authentication",
                        request: null,
                        name: "bad-user-or-pass",
                        message: t.getStatusLine(),
                        response: t
                    }), void 0) : (e(), void 0);
                }.bind(this)), void 0);
            }.bind(this));
        }
    }, y.prototype.quit = function(e) {
        this.state = "disconnected", this.protocol.sendRequest("QUIT", [], !1, function(t) {
            this.close(), t ? e && e({
                scope: "mailbox",
                request: t.request,
                name: "server-problem",
                message: t.getStatusLine(),
                response: t
            }) : e && e();
        }.bind(this));
    }, y.prototype._loadMessageList = function(e) {
        return this._messageList ? (e(null, this._messageList), void 0) : (this.protocol.sendRequest("UIDL", [], !0, function(t, n) {
            if (t) return e && e({
                scope: "mailbox",
                request: t.request,
                name: "server-problem",
                message: t.getStatusLine(),
                response: t
            }), void 0;
            for (var o = n.getDataLines(), i = 0; i < o.length; i++) {
                var r = o[i].split(" "), s = r[0], a = r[1];
                this.idToUidl[s] = a, this.uidlToId[a] = s;
            }
        }.bind(this)), this.protocol.sendRequest("LIST", [], !0, function(t, n) {
            if (t) return e && e({
                scope: "mailbox",
                request: t.request,
                name: "server-problem",
                message: t.getStatusLine(),
                response: t
            }), void 0;
            for (var o = n.getDataLines(), i = [], r = 0; r < o.length; r++) {
                var s = o[r].split(" "), a = s[0], c = parseInt(s[1], 10);
                this.idToSize[a] = c, i.unshift({
                    uidl: this.idToUidl[a],
                    size: c,
                    number: a
                });
            }
            this._messageList = i, e && e(null, i);
        }.bind(this)), void 0);
    }, y.prototype.listMessages = function(e, t) {
        var n = e.filter, o = e.progress, i = e.checkpointInterval || null, r = e.maxMessages || 1/0, s = e.checkpoint, a = [];
        this._loadMessageList(function(e, c) {
            if (e) return t && t(e), void 0;
            for (var u = 0, d = 0, l = [], p = 0, f = 0; f < c.length; f++) {
                var m = c[f];
                !n || n(m.uidl) ? l.length < r ? (u += m.size, l.push(m)) : a.push(m) : p++;
            }
            console.log("POP3: listMessages found " + l.length + " new, " + a.length + " overflow, and " + p + " seen messages. New UIDLs:"), 
            l.forEach(function(e) {
                console.log("POP3: " + e.size + " bytes: " + e.uidl);
            });
            var g = l.length;
            i || (i = g);
            var _ = null, y = function() {
                if (console.log("POP3: Next batch. Messages left: " + l.length), !l.length || this.protocol.closed) return console.log("POP3: Sync complete. " + g + " messages synced, " + a.length + " overflow messages."), 
                t && t(_, g, a), void 0;
                var e = l.splice(0, i), n = h.latch();
                e.forEach(function(e) {
                    var t = n.defer(e.number);
                    this.downloadPartialMessageByNumber(e.number, function(n, i) {
                        d += e.size, n ? _ || (_ = n) : o && o({
                            totalBytes: u,
                            bytesFetched: d,
                            size: e.size,
                            message: i
                        }), t(n);
                    });
                }.bind(this)), n.then(function(e) {
                    var t = !1;
                    for (var n in e) if (console.log("result", n, e[n]), !e[n][0]) {
                        t = !0;
                        break;
                    }
                    s && t ? (console.log("POP3: Checkpoint."), s(y)) : y();
                });
            }.bind(this);
            y();
        }.bind(this));
    }, y.prototype.downloadMessageByUidl = function(e, t) {
        this._loadMessageList(function(n) {
            n ? t && t(n) : this.downloadMessageByNumber(this.uidlToId[e], t);
        }.bind(this));
    }, y.prototype.downloadPartialMessageByNumber = function(e, t) {
        var n = Math.floor(c.POP3_SNIPPET_SIZE_GOAL / 80);
        this.protocol.sendRequest("TOP", [ e, n ], !0, function(n, o) {
            if (n) return t && t({
                scope: "message",
                request: n.request,
                name: "server-problem",
                message: n.getStatusLine(),
                response: n
            }), void 0;
            var i = this.idToSize[e], r = o.getDataAsString(), s = !i || r.length < i;
            t(null, this.parseMime(r, s, e));
        }.bind(this));
    }, y.prototype.downloadMessageByNumber = function(e, t) {
        this.protocol.sendRequest("RETR", [ e ], !0, function(n, o) {
            return n ? (t && t({
                scope: "message",
                request: n.request,
                name: "server-problem",
                message: n.getStatusLine(),
                response: n
            }), void 0) : (t(null, this.parseMime(o.getDataAsString(), !1, e)), void 0);
        }.bind(this));
    }, y.parseMime = function(e) {
        return y.prototype.parseMime.call(this, e);
    }, y.prototype.parseMime = function(e, t, n) {
        var o, i = new s();
        for (i.write(d.charset.encode(e, "utf-8")), i.end(), o = i.node; o._currentChild && o !== o._currentChild; ) o = o._currentChild;
        var r, h, f = i.node, g = t ? o : null, _ = n && this.idToSize[n] || e.length, y = p(f, "date"), v = u.NOW();
        y ? (h = Date.parse(y), (isNaN(h) || h > v) && (h = v)) : h = v;
        var b = [];
        for (var S in f.headers) b.push(S + ": " + f.headers[S][0].initial + "\r\n");
        var T = {}, w = {
            uid: n && this.idToUidl[n],
            "header.fields[]": b.join(""),
            internaldate: h && a.formatImapDateTime(new Date(h)),
            flags: [],
            bodystructure: m(f, "1", T, g)
        }, A = a.chewHeaderAndBodyStructure(w, null, null), E = a.selectSnippetBodyRep(A.header, A.bodyInfo), C = {}, I = 0, O = T.partial;
        for (var x in T) "partial" !== x && x !== O && (I += T[x].length, C[x] = T[x].length);
        O && (C[O] = _ - I);
        for (var M = 0; M < A.bodyInfo.bodyReps.length; M++) {
            var D = A.bodyInfo.bodyReps[M];
            r = d.charset.decode(T[D.part], "utf-8");
            var k = {
                bytes: O === D.part ? [ -1, -1 ] : null,
                bodyRepIndex: M,
                createSnippet: M === E
            };
            if (null != r) {
                D.size = C[D.part];
                var N = {
                    bytesFetched: r.length,
                    text: r
                };
                a.updateMessageWithFetch(A.header, A.bodyInfo, k, N, this._LOG);
            }
        }
        for (var M = 0; M < A.bodyInfo.relatedParts.length; M++) {
            var R = A.bodyInfo.relatedParts[M];
            R.sizeEstimate = C[R.part], r = T[R.part], null != r && O !== R.part && (R.file = new Blob([ r ], {
                type: R.type
            }));
        }
        for (var M = 0; M < A.bodyInfo.attachments.length; M++) {
            var P = A.bodyInfo.attachments[M];
            r = T[P.part], P.sizeEstimate = C[P.part], null != r && O !== P.part && l.isSupportedType(P.type) && (P.file = new Blob([ r ], {
                type: P.type
            }));
        }
        return t && !A.header.hasAttachments && (p(f, "x-ms-has-attach") || /multipart\/mixed/.test(f.contentType.value) || _ > c.POP3_INFER_ATTACHMENTS_SIZE) && (A.header.hasAttachments = !0), 
        A.bodyInfo.bodyReps.push({
            type: "fake",
            part: "fake",
            sizeEstimate: 0,
            amountDownloaded: 0,
            isDownloaded: !t,
            content: null,
            size: 0
        }), A.header.bytesToDownloadForBodyDisplay = t ? _ : 0, A;
    };
    var v = t.LOGFAB = n.register(e, {
        Pop3Client: {
            type: n.CONNECTION,
            subtype: n.CLIENT,
            events: {},
            TEST_ONLY_events: {},
            errors: {
                htmlParseError: {
                    ex: n.EXCEPTION
                },
                htmlSnippetError: {
                    ex: n.EXCEPTION
                },
                textChewError: {
                    ex: n.EXCEPTION
                },
                textSnippetError: {
                    ex: n.EXCEPTION
                }
            },
            asyncJobs: {}
        }
    });
    y._LOG = v.Pop3Client();
}), define("pop3/sync", [ "rdcommon/log", "slog", "../util", "module", "require", "exports", "../mailchew", "../syncbase", "../date", "../jobmixins", "../allback", "./pop3" ], function(e, t, n, o, i, r, s, a, c, u, d) {
    function l(e, t, n) {
        this._LOG = m.Pop3FolderSyncer(this, n, t.folderId), this.account = e, this.storage = t, 
        this.isInbox = "inbox" === t.folderMeta.type;
    }
    function h(e, t, n, o) {
        return function() {
            var r = Array.slice(arguments);
            i([], function() {
                var i = function() {
                    return this.isInbox ? (this.account.withConnection(function(e, n, i) {
                        var s = r[t];
                        e ? s && s(e) : (r[t] = function(e) {
                            i(), s && s(e);
                        }, o.apply(this, [ n ].concat(r)));
                    }.bind(this), n), void 0) : (o.apply(this, [ null ].concat(r)), void 0);
                }.bind(this);
                e && this.account._conn && "disconnected" !== this.account._conn.state ? this.account._conn.quit(i) : i();
            }.bind(this));
        };
    }
    function p(e) {
        for (var t = [], n = 0; e > n; n++) t.push(n);
        return t;
    }
    var f = 1;
    r.Pop3FolderSyncer = l, l.prototype = {
        syncable: !0,
        get canGrowSync() {
            return this.isInbox;
        },
        downloadBodies: h(!1, 2, "downloadBodies", function(e, t, n, o) {
            var i = d.latch();
            this.storage;
            for (var r = 0; r < t.length; r++) t[r] && null == t[r].snippet && this.downloadBodyReps(t[r], n, i.defer(r));
            i.then(function(e) {
                var n = null;
                for (var i in e) n = e[i][0];
                o(n, t.length);
            });
        }),
        downloadBodyReps: h(!1, 2, "downloadBodyReps", function(e, t, n, o) {
            n instanceof Function && (o = n, n = {}), console.log("POP3: Downloading bodyReps for UIDL " + t.srvid), 
            e.downloadMessageByUidl(t.srvid, function(e, n) {
                if (e) return o(e), void 0;
                t.bytesToDownloadForBodyDisplay = n.header.bytesToDownloadForBodyDisplay, console.log("POP3: Storing message " + t.srvid + " with " + t.bytesToDownloadForBodyDisplay + " bytesToDownload.");
                var i = n.bodyInfo.attachments.length > 0;
                this.storeMessage(t, n.bodyInfo, {
                    flush: i
                }, function() {
                    o && o(null, n.bodyInfo, i);
                });
            }.bind(this));
        }),
        downloadMessageAttachments: function(e, t, n) {
            console.log("POP3: ERROR: downloadMessageAttachments called and POP3 shouldn't do that."), 
            n(null, null);
        },
        storeMessage: function(e, t, n, o) {
            o = o || function() {};
            var i = {
                changeDetails: {}
            }, r = this.getMessageIdForUidl(e.srvid);
            null == e.id && (e.id = null == r ? this.storage._issueNewHeaderId() : r, e.suid = this.storage.folderId + "/" + e.id, 
            e.guid = e.guid || e.srvid);
            for (var s = d.latch(), a = this, c = 0; c < t.attachments.length; c++) {
                var l = t.attachments[c];
                l.file instanceof Blob && (console.log("Saving attachment", l.file), u.saveToDeviceStorage(this._LOG, l.file, "sdcard", l.name, l, s.defer()));
            }
            s.then(function() {
                if (s = d.latch(), null == r) a.storeMessageUidlForMessageId(e.srvid, e.id), a.storage.addMessageHeader(e, t, s.defer()), 
                a.storage.addMessageBody(e, t, s.defer()); else {
                    a.storage.updateMessageHeader(e.date, e.id, !0, e, t, s.defer()), i.changeDetails.attachments = p(t.attachments.length), 
                    i.changeDetails.bodyReps = p(t.bodyReps.length);
                    var c = {};
                    n.flush && (c.flushBecause = "blobs"), a.storage.updateMessageBody(e, t, c, i, s.defer());
                }
                s.then(function() {
                    o(null, t);
                });
            });
        },
        get inboxMeta() {
            return this.inboxMeta = this.account.getFolderMetaForFolderId(this.account.getFirstFolderWithType("inbox").id);
        },
        getMessageIdForUidl: function(e) {
            return null == e ? null : (this.inboxMeta.uidlMap = this.inboxMeta.uidlMap || {}, 
            this.inboxMeta.uidlMap[e]);
        },
        storeMessageUidlForMessageId: function(e, t) {
            this.inboxMeta.uidlMap = this.inboxMeta.uidlMap || {}, this.inboxMeta.uidlMap[e] = t, 
            this.inboxMeta.overflowMap && delete this.inboxMeta.overflowMap[e];
        },
        storeOverflowMessageUidl: function(e, t) {
            this.inboxMeta.overflowMap = this.inboxMeta.overflowMap || {}, this.inboxMeta.overflowMap[e] = {
                size: t
            };
        },
        hasOverflowMessages: function() {
            if (!this.inboxMeta.overflowMap) return !1;
            for (var e in this.inboxMeta.overflowMap) return !0;
            return !1;
        },
        isUidlInOverflowMap: function(e) {
            return this.inboxMeta.overflowMap ? !!this.inboxMeta.overflowMap[e] : !1;
        },
        initialSync: function(e, t, n, o, i) {
            n("sync", !0), this.sync("initial", e, o, i);
        },
        refreshSync: function(e, t, n, o, i, r, s) {
            this.sync("refresh", e, r, s);
        },
        _performTestAdditionsAndDeletions: function(e) {
            var t = this.storage.folderMeta, n = d.latch(), o = !1;
            return t._TEST_pendingHeaderDeletes && (t._TEST_pendingHeaderDeletes.forEach(function(e) {
                o = !0, this.storage.deleteMessageHeaderAndBody(e.suid, e.date, n.defer());
            }, this), t._TEST_pendingHeaderDeletes = null), t._TEST_pendingAdds && (t._TEST_pendingAdds.forEach(function(e) {
                o = !0, this.storeMessage(e.header, e.bodyInfo, {}, n.defer());
            }, this), t._TEST_pendingAdds = null), n.then(function() {
                e();
            }), o;
        },
        growSync: function(e, t, n, o, i, r) {
            return t === f && this.hasOverflowMessages() ? (this.sync("grow", e, i, r), !0) : !1;
        },
        allConsumersDead: function() {},
        shutdown: function() {
            this._LOG.__die();
        },
        sync: h(!0, 2, "sync", function(e, n, o, i, r) {
            var s = this;
            t.log("pop3.sync:begin", {
                syncType: n
            });
            var u, l = !1, h = function(e) {
                return l ? (t.log("pop3.sync:duplicateDone", {
                    syncType: n,
                    err: e
                }), void 0) : (t.log("pop3.sync:end", {
                    syncType: n,
                    err: e
                }), l = !0, i(e ? "unknown" : null), void 0);
            };
            u = "grow" !== n ? function(e) {
                return null == s.getMessageIdForUidl(e) && !s.isUidlInOverflowMap(e);
            } : this.isUidlInOverflowMap.bind(this);
            var p, f = 0, m = 0, g = d.latch();
            if (this.isInbox) {
                p = !0, this._LOG.sync_begin();
                var _ = g.defer(), y = !1;
                e.onclose = function() {
                    y || (y = !0, window.setTimeout(function() {
                        window.setTimeout(function() {
                            h("closed");
                        }, 0);
                    }, 0));
                }, e.listMessages({
                    filter: u,
                    checkpointInterval: a.POP3_SAVE_STATE_EVERY_N_MESSAGES,
                    maxMessages: a.POP3_MAX_MESSAGES_PER_SYNC,
                    checkpoint: function(e) {
                        this.account.__checkpointSyncCompleted(e, "syncBatch");
                    }.bind(this),
                    progress: function(e) {
                        var t = e.totalBytes, n = e.message, o = g.defer();
                        this.storeMessage(n.header, n.bodyInfo, {}, function() {
                            f += e.size, m++, r(.1 + .7 * f / t), o();
                        });
                    }.bind(this)
                }, function(t, n, o) {
                    return y = !0, e.quit(), t ? (h(t), void 0) : (o.length && (o.forEach(function(e) {
                        this.storeOverflowMessageUidl(e.uidl, e.size);
                    }, this), this._LOG.overflowMessages(o.length)), _(), void 0);
                }.bind(this));
            } else o.desiredHeaders = this._TEST_pendingAdds && this._TEST_pendingAdds.length, 
            p = this._performTestAdditionsAndDeletions(g.defer());
            g.then(function() {
                this.storage.markSyncRange(a.OLDEST_SYNC_DATE + c.DAY_MILLIS + 1, c.NOW(), "XXX", c.NOW()), 
                this.hasOverflowMessages() || this.storage.markSyncedToDawnOfTime(), this.isInbox && this._LOG.sync_end(), 
                p ? this.account.__checkpointSyncCompleted(v, "syncComplete") : v();
            }.bind(this));
            var v = function() {
                "initial" === n ? (this.storage._curSyncSlice.ignoreHeaders = !1, this.storage._curSyncSlice.waitingOnData = "db", 
                this.storage.getMessagesInImapDateRange(a.OLDEST_SYNC_DATE, null, a.INITIAL_FILL_SIZE, a.INITIAL_FILL_SIZE, this.storage.onFetchDBHeaders.bind(this.storage, this.storage._curSyncSlice, !1, h, null))) : h(null);
            }.bind(this);
        })
    };
    var m = r.LOGFAB = e.register(o, {
        Pop3FolderSyncer: {
            type: e.CONNECTION,
            subtype: e.CLIENT,
            events: {
                savedAttachment: {
                    storage: !0,
                    mimeType: !0,
                    size: !0
                },
                saveFailure: {
                    storage: !1,
                    mimeType: !1,
                    error: !1
                },
                overflowMessages: {
                    count: !0
                }
            },
            TEST_ONLY_events: {},
            errors: {
                callbackErr: {
                    ex: e.EXCEPTION
                },
                htmlParseError: {
                    ex: e.EXCEPTION
                },
                htmlSnippetError: {
                    ex: e.EXCEPTION
                },
                textChewError: {
                    ex: e.EXCEPTION
                },
                textSnippetError: {
                    ex: e.EXCEPTION
                },
                illegalSync: {
                    startTS: !1,
                    endTS: !1
                }
            },
            asyncJobs: {
                sync: {},
                syncDateRange: {
                    newMessages: !0,
                    existingMessages: !0,
                    deletedMessages: !0,
                    start: !1,
                    end: !1,
                    skewedStart: !1,
                    skewedEnd: !1
                }
            }
        }
    });
}), define("pop3/jobs", [ "module", "exports", "rdcommon/log", "../allback", "mix", "../jobmixins", "../drafts/jobs", "./pop3" ], function(e, t, n, o, i, r, s) {
    function a(e, t, n) {
        this._LOG = c.Pop3JobDriver(this, n, e.id), this.account = e, this.resilientServerIds = !0, 
        this._heldMutexReleasers = [], this._stateDelta = {}, this._state = t, t.hasOwnProperty("suidToServerId") || (t.suidToServerId = {}, 
        t.moveMap = {});
    }
    t.Pop3JobDriver = a, a.prototype = {
        _accessFolderForMutation: function(e, t, n, o, i) {
            var r = this.account.getFolderStorageForFolderId(e);
            r.runMutexed(i, function(e) {
                this._heldMutexReleasers.push(e);
                try {
                    n(r.folderSyncer, r);
                } catch (t) {
                    this._LOG.callbackErr(t);
                }
            }.bind(this));
        },
        local_do_createFolder: function(e, t) {
            var n, o, i = null, r = 0;
            if (e.parentFolderId) {
                if (!this.account._folderInfos.hasOwnProperty(e.parentFolderId)) throw new Error("No such folder: " + e.parentFolderId);
                var s = this.account._folderInfos[e.parentFolderId];
                o = s.$meta.delim, n = s.$meta.path + o, i = s.$meta.id, r = s.depth + 1;
            } else n = "", o = "/";
            if (n += "string" == typeof e.folderName ? e.folderName : e.folderName.join(o), 
            e.containOnlyOtherFolders && (n += o), this.account.getFolderByPath(n)) t(null); else {
                var a = self.account._learnAboutFolder(e.folderName, n, i, "normal", o, r);
                t(null, a);
            }
        },
        local_do_purgeExcessMessages: function(e, t) {
            this._accessFolderForMutation(e.folderId, !1, function(e, n) {
                n.purgeExcessMessages(function(e) {
                    t(null, null, e > 0);
                });
            }, null, "purgeExcessMessages");
        },
        local_do_saveSentDraft: function(e, t) {
            this._accessFolderForMutation(e.folderId, !1, function(n, i) {
                var r = o.latch();
                i.addMessageHeader(e.headerInfo, e.bodyInfo, r.defer()), i.addMessageBody(e.headerInfo, e.bodyInfo, r.defer()), 
                r.then(function() {
                    t(null, null, !0);
                });
            }, null, "saveSentDraft");
        },
        do_syncFolderList: function(e, t) {
            this.account.meta.lastFolderSyncAt = Date.now(), t(null);
        },
        do_modtags: function(e, t) {
            t(null);
        },
        undo_modtags: function(e, t) {
            t(null);
        },
        local_do_modtags: r.local_do_modtags,
        local_undo_modtags: r.local_undo_modtags,
        local_do_move: r.local_do_move,
        local_undo_move: r.local_undo_move,
        local_do_delete: r.local_do_delete,
        local_undo_delete: r.local_undo_delete,
        local_do_downloadBodies: r.local_do_downloadBodies,
        do_downloadBodies: r.do_downloadBodies,
        check_downloadBodies: r.check_downloadBodies,
        check_downloadBodyReps: r.check_downloadBodyReps,
        do_downloadBodyReps: r.do_downloadBodyReps,
        local_do_downloadBodyReps: r.local_do_downloadBodyReps,
        local_do_sendOutboxMessages: r.local_do_sendOutboxMessages,
        do_sendOutboxMessages: r.do_sendOutboxMessages,
        check_sendOutboxMessages: r.check_sendOutboxMessages,
        local_undo_sendOutboxMessages: r.local_undo_sendOutboxMessages,
        undo_sendOutboxMessages: r.undo_sendOutboxMessages,
        local_do_setOutboxSyncEnabled: r.local_do_setOutboxSyncEnabled,
        local_do_upgradeDB: r.local_do_upgradeDB,
        postJobCleanup: r.postJobCleanup,
        allJobsDone: r.allJobsDone,
        _partitionAndAccessFoldersSequentially: r._partitionAndAccessFoldersSequentially
    }, i(a.prototype, s.draftsMixins);
    var c = t.LOGFAB = n.register(e, {
        Pop3JobDriver: {
            type: n.DAEMON,
            events: {
                savedAttachment: {
                    storage: !0,
                    mimeType: !0,
                    size: !0
                },
                saveFailure: {
                    storage: !1,
                    mimeType: !1,
                    error: !1
                }
            },
            TEST_ONLY_events: {
                saveFailure: {
                    filename: !1
                }
            },
            asyncJobs: {
                acquireConnWithoutFolder: {
                    label: !1
                }
            },
            errors: {
                callbackErr: {
                    ex: n.EXCEPTION
                }
            }
        }
    });
}), define("pop3/account", [ "rdcommon/log", "../errbackoff", "../composite/incoming", "./sync", "../errorutils", "./jobs", "../drafts/draft_rep", "../disaster-recovery", "module", "require", "exports" ], function(e, t, n, o, i, r, s, a, c, u, d) {
    function l(e, n, i, s, c, u, d, l, p) {
        this._LOG = m.Pop3Account(this, l, i), h.apply(this, [ o.Pop3FolderSyncer ].concat(Array.slice(arguments))), 
        this._conn = null, this._pendingConnectionRequests = [], this._backoffEndpoint = t.createEndpoint("pop3:" + this.id, this, this._LOG), 
        this.tzOffset = 0, p && (a.associateSocketWithAccount(p.socket, this), this._conn = p), 
        this.ensureEssentialOfflineFolders(), this._jobDriver = new r.Pop3JobDriver(this, this._folderInfos.$mutationState, this._LOG);
    }
    var h = n.CompositeIncomingAccount;
    d.Account = d.Pop3Account = l, l.prototype = Object.create(h.prototype);
    var p = {
        type: "pop3",
        supportsServerFolders: !1,
        toString: function() {
            return "[Pop3Account: " + this.id + "]";
        },
        withConnection: function(e, t) {
            this._pendingConnectionRequests.push(e);
            var n = function() {
                var e = this._pendingConnectionRequests.shift();
                if (e) {
                    var o = function(t) {
                        t ? (e(t), n()) : e(null, this._conn, n);
                    }.bind(this);
                    this._conn && "disconnected" !== this._conn.state ? o() : this._makeConnection(o, t);
                }
            }.bind(this);
            1 === this._pendingConnectionRequests.length && n();
        },
        __folderDoneWithConnection: function() {},
        _makeConnection: function(e, t) {
            this._conn = !0, u([ "./pop3", "./probe" ], function(n, o) {
                this._LOG.createConnection(t);
                var r = {
                    host: this._connInfo.hostname,
                    port: this._connInfo.port,
                    crypto: this._connInfo.crypto,
                    preferredAuthMethod: this._connInfo.preferredAuthMethod,
                    username: this._credentials.username,
                    password: this._credentials.password
                };
                this._LOG && (r._logParent = this._LOG);
                var s = this._conn = new n.Pop3Client(r, function(t) {
                    t ? (console.error("Connect error:", t.name, "formal:", t, "on", this._connInfo.hostname, this._connInfo.port), 
                    t = o.normalizePop3Error(t), i.shouldReportProblem(t) && this.universe.__reportAccountProblem(this.compositeAccount, t, "incoming"), 
                    e && e(t, null), s.close(), i.shouldRetry(t) ? this._backoffEndpoint.noteConnectFailureMaybeRetry(i.wasErrorFromReachableState(t)) ? this._backoffEndpoint.scheduleConnectAttempt(this._makeConnection.bind(this)) : this._backoffEndpoint.noteBrokenConnection() : this._backoffEndpoint.noteBrokenConnection()) : (this._backoffEndpoint.noteConnectSuccess(), 
                    e && e(null, s));
                }.bind(this));
                a.associateSocketWithAccount(s.socket, this);
            }.bind(this));
        },
        saveSentMessage: function(e) {
            var t = this.getFirstFolderWithType("sent");
            if (t) {
                var n = this.getFolderStorageForFolderId(t.id), o = n._issueNewHeaderId(), i = n.folderId + "/" + o, r = s.cloneDraftMessageForSentFolderWithoutAttachments(e.header, e.body, {
                    id: o,
                    suid: i
                });
                this.universe.saveSentDraft(t.id, r.header, r.body);
            }
        },
        deleteFolder: function(e, t) {
            if (!this._folderInfos.hasOwnProperty(e)) throw new Error("No such folder: " + e);
            var n = this._folderInfos[e].$meta;
            self._LOG.deleteFolder(n.path), self._forgetFolder(e), t && t(null, n);
        },
        shutdown: function(e) {
            h.prototype.shutdownFolders.call(this), this._backoffEndpoint.shutdown(), this._conn && this._conn.close && this._conn.close(), 
            this._LOG.__die(), e && e();
        },
        checkAccount: function(e) {
            null !== this._conn && ("disconnected" !== this._conn.state && this._conn.close(), 
            this._conn = null), this._LOG.checkAccount_begin(null), this.withConnection(function(t) {
                this._LOG.checkAccount_end(t), e(t);
            }.bind(this), "checkAccount");
        },
        ensureEssentialOfflineFolders: function() {
            [ "sent", "localdrafts", "trash", "outbox" ].forEach(function(e) {
                this.getFirstFolderWithType(e) || this._learnAboutFolder(e, e, null, e, "", 0, !0);
            }, this);
        },
        ensureEssentialOnlineFolders: function(e) {
            e && e();
        },
        accountDeleted: function() {
            this._alive = !1, this.shutdown();
        }
    };
    for (var f in p) Object.defineProperty(l.prototype, f, Object.getOwnPropertyDescriptor(p, f));
    var m = d.LOGFAB = e.register(c, {
        Pop3Account: n.LOGFAB_DEFINITION.CompositeIncomingAccount
    });
}), define("axeshim-smtpclient", [ "slog" ], function() {
    var e = require("slog"), t = "smtpclient";
    return {
        debug: function(n, o) {
            e.debug(t, {
                msg: o
            });
        },
        log: function(n, o) {
            e.log(t, {
                msg: o
            });
        },
        warn: function(n, o) {
            e.warn(t, {
                msg: o
            });
        },
        error: function(n, o) {
            e.error(t, {
                msg: o
            });
        }
    };
}), function(e, t) {
    "function" == typeof define && define.amd ? define("ext/smtpclient/src/smtpclient-response-parser", t) : "object" == typeof exports ? module.exports = t() : e.SmtpClientResponseParser = t();
}(this, function() {
    var e = function() {
        this._remainder = "", this._block = {
            data: [],
            lines: [],
            statusCode: null
        }, this.destroyed = !1;
    };
    return e.prototype.onerror = function() {}, e.prototype.ondata = function() {}, 
    e.prototype.onend = function() {}, e.prototype.send = function(e) {
        if (this.destroyed) return this.onerror(new Error('This parser has already been closed, "write" is prohibited'));
        var t = (this._remainder + (e || "")).split(/\r?\n/);
        this._remainder = t.pop();
        for (var n = 0, o = t.length; o > n; n++) this._processLine(t[n]);
    }, e.prototype.end = function(e) {
        return this.destroyed ? this.onerror(new Error('This parser has already been closed, "end" is prohibited')) : (e && this.send(e), 
        this._remainder && this._processLine(this._remainder), this.destroyed = !0, this.onend(), 
        void 0);
    }, e.prototype._processLine = function(e) {
        var t, n;
        if (e.trim()) if (this._block.lines.push(e), t = e.match(/^(\d{3})([\- ])(?:(\d+\.\d+\.\d+)(?: ))?(.*)/)) {
            if (this._block.data.push(t[4]), "-" === t[2]) return this._block.statusCode && this._block.statusCode !== Number(t[1]) ? this.onerror("Invalid status code " + t[1] + " for multi line response (" + this._block.statusCode + " expected)") : this._block.statusCode || (this._block.statusCode = Number(t[1])), 
            void 0;
            n = {
                statusCode: Number(t[1]) || 0,
                enhancedStatus: t[3] || null,
                data: this._block.data.join("\n"),
                line: this._block.lines.join("\n")
            }, n.success = n.statusCode >= 200 && n.statusCode < 300, this.ondata(n), this._block = {
                data: [],
                lines: [],
                statusCode: null
            }, this._block.statusCode = null;
        } else this.onerror(new Error('Invalid SMTP response "' + e + '"')), this.ondata({
            success: !1,
            statusCode: this._block.statusCode || null,
            enhancedStatus: null,
            data: [ e ].join("\n"),
            line: this._block.lines.join("\n")
        }), this._block = {
            data: [],
            lines: [],
            statusCode: null
        };
    }, e;
}), function(e, t) {
    var n;
    "function" == typeof define && define.amd ? define("ext/smtpclient/src/smtpclient", [ "tcp-socket", "stringencoding", "axe", "./smtpclient-response-parser" ], function(e, n, o, i) {
        return t(e, n.TextEncoder, n.TextDecoder, o, i, window.btoa);
    }) : "object" == typeof exports && "undefined" != typeof navigator ? (n = require("wo-stringencoding"), 
    module.exports = t(require("tcp-socket"), n.TextEncoder, n.TextDecoder, require("axe-logger"), require("./smtpclient-response-parser"), btoa)) : "object" == typeof exports ? (n = require("wo-stringencoding"), 
    module.exports = t(require("tcp-socket"), n.TextEncoder, n.TextDecoder, require("axe-logger"), require("./smtpclient-response-parser"), function(e) {
        var t = require("buffer").Buffer;
        return new t(e, "binary").toString("base64");
    })) : (navigator.TCPSocket = navigator.TCPSocket || navigator.mozTCPSocket, e.SmtpClient = t(navigator.TCPSocket, e.TextEncoder, e.TextDecoder, e.axe, e.SmtpClientResponseParser, window.btoa));
}(this, function(e, t, n, o, i, r) {
    function s(t, n, o) {
        this._TCPSocket = e, this.options = o || {}, this.port = n || (this.options.useSecureTransport ? 465 : 25), 
        this.host = t || "localhost", this.options.useSecureTransport = "useSecureTransport" in this.options ? !!this.options.useSecureTransport : 465 === this.port, 
        this.options.auth = this.options.auth || !1, this.options.name = this.options.name || !1, 
        this.socket = !1, this.destroyed = !1, this.maxAllowedSize = 0, this.waitDrain = !1, 
        this._parser = new i(), this._authenticatedAs = null, this._supportedAuth = [], 
        this._dataMode = !1, this._lastDataBytes = "", this._envelope = null, this._currentAction = null, 
        this._secureMode = !!this.options.useSecureTransport;
    }
    var a = "SMTP Client";
    return s.prototype.onerror = function() {}, s.prototype.ondrain = function() {}, 
    s.prototype.onclose = function() {}, s.prototype.onidle = function() {}, s.prototype.onready = function() {}, 
    s.prototype.ondone = function() {}, s.prototype.connect = function() {
        if (!this.options.name && "getHostname" in this._TCPSocket && "function" == typeof this._TCPSocket.getHostname) return this._TCPSocket.getHostname(function(e, t) {
            this.options.name = t || "localhost", this.connect();
        }.bind(this)), void 0;
        this.options.name || (this.options.name = "localhost"), this.socket = this._TCPSocket.open(this.host, this.port, {
            binaryType: "arraybuffer",
            useSecureTransport: this._secureMode,
            ca: this.options.ca,
            tlsWorkerPath: this.options.tlsWorkerPath
        });
        try {
            this.socket.oncert = this.oncert;
        } catch (e) {}
        this.socket.onerror = this._onError.bind(this), this.socket.onopen = this._onOpen.bind(this);
    }, s.prototype.suspend = function() {
        this.socket && "open" === this.socket.readyState && this.socket.suspend();
    }, s.prototype.resume = function() {
        this.socket && "open" === this.socket.readyState && this.socket.resume();
    }, s.prototype.quit = function() {
        o.debug(a, "Sending QUIT..."), this._sendCommand("QUIT"), this._currentAction = this.close;
    }, s.prototype.reset = function(e) {
        this.options.auth = e || this.options.auth, o.debug(a, "Sending RSET..."), this._sendCommand("RSET"), 
        this._currentAction = this._actionRSET;
    }, s.prototype.close = function() {
        o.debug(a, "Closing connection..."), this.socket && "open" === this.socket.readyState ? this.socket.close() : this._destroy();
    }, s.prototype.useEnvelope = function(e) {
        this._envelope = e || {}, this._envelope.from = [].concat(this._envelope.from || "anonymous@" + this.options.name)[0], 
        this._envelope.to = [].concat(this._envelope.to || []), this._envelope.rcptQueue = [].concat(this._envelope.to), 
        this._envelope.rcptFailed = [], this._envelope.responseQueue = [], this._currentAction = this._actionMAIL, 
        o.debug(a, "Sending MAIL FROM..."), this._sendCommand("MAIL FROM:<" + this._envelope.from + ">");
    }, s.prototype.send = function(e) {
        return this._dataMode ? this._sendString(e) : !0;
    }, s.prototype.end = function(e) {
        return this._dataMode ? (e && e.length && this.send(e), this._currentAction = this._actionStream, 
        this.waitDrain = "\r\n" === this._lastDataBytes ? this.socket.send(new Uint8Array([ 46, 13, 10 ]).buffer) : "\r" === this._lastDataBytes.substr(-1) ? this.socket.send(new Uint8Array([ 10, 46, 13, 10 ]).buffer) : this.socket.send(new Uint8Array([ 13, 10, 46, 13, 10 ]).buffer), 
        this._dataMode = !1, this.waitDrain) : !0;
    }, s.prototype._onOpen = function() {
        this.socket.ondata = this._onData.bind(this), this.socket.onclose = this._onClose.bind(this), 
        this.socket.ondrain = this._onDrain.bind(this), this._parser.ondata = this._onCommand.bind(this), 
        this._currentAction = this._actionGreeting;
    }, s.prototype._onData = function(e) {
        var t = new n("UTF-8").decode(new Uint8Array(e.data));
        o.debug(a, "SERVER: " + t), this._parser.send(t);
    }, s.prototype._onDrain = function() {
        this.waitDrain = !1, this.ondrain();
    }, s.prototype._onError = function(e) {
        e instanceof Error && e.message ? (o.error(a, e), this.onerror(e)) : e && e.data instanceof Error ? (o.error(a, e.data), 
        this.onerror(e.data)) : (o.error(a, new Error(e && e.data && e.data.message || e.data || e || "Error")), 
        this.onerror(new Error(e && e.data && e.data.message || e.data || e || "Error"))), 
        this.close();
    }, s.prototype._onClose = function() {
        o.debug(a, "Socket closed."), this._destroy();
    }, s.prototype._onCommand = function(e) {
        "function" == typeof this._currentAction && this._currentAction.call(this, e);
    }, s.prototype._destroy = function() {
        this.destroyed || (this.destroyed = !0, this.onclose());
    }, s.prototype._sendString = function(e) {
        return this.options.disableEscaping || (e = e.replace(/\n\./g, "\n.."), "\n" !== this._lastDataBytes.substr(-1) && this._lastDataBytes || "." !== e.charAt(0) || (e = "." + e)), 
        e.length > 2 ? this._lastDataBytes = e.substr(-2) : 1 === e.length && (this._lastDataBytes = this._lastDataBytes.substr(-1) + e), 
        o.debug(a, "Sending " + e.length + " bytes of payload"), this.waitDrain = this.socket.send(new t("UTF-8").encode(e).buffer), 
        this.waitDrain;
    }, s.prototype._sendCommand = function(e) {
        this.waitDrain = this.socket.send(new t("UTF-8").encode(e + ("\r\n" !== e.substr(-2) ? "\r\n" : "")).buffer);
    }, s.prototype._authenticateUser = function() {
        if (!this.options.auth) return this._currentAction = this._actionIdle, this.onidle(), 
        void 0;
        var e;
        switch (!this.options.authMethod && this.options.auth.xoauth2 && (this.options.authMethod = "XOAUTH2"), 
        e = this.options.authMethod ? this.options.authMethod.toUpperCase().trim() : (this._supportedAuth[0] || "PLAIN").toUpperCase().trim()) {
          case "LOGIN":
            return o.debug(a, "Authentication via AUTH LOGIN"), this._currentAction = this._actionAUTH_LOGIN_USER, 
            this._sendCommand("AUTH LOGIN"), void 0;

          case "PLAIN":
            return o.debug(a, "Authentication via AUTH PLAIN"), this._currentAction = this._actionAUTHComplete, 
            this._sendCommand("AUTH PLAIN " + r(unescape(encodeURIComponent("\0" + this.options.auth.user + "\0" + this.options.auth.pass)))), 
            void 0;

          case "XOAUTH2":
            return o.debug(a, "Authentication via AUTH XOAUTH2"), this._currentAction = this._actionAUTH_XOAUTH2, 
            this._sendCommand("AUTH XOAUTH2 " + this._buildXOAuth2Token(this.options.auth.user, this.options.auth.xoauth2)), 
            void 0;
        }
        this._onError(new Error("Unknown authentication method " + e));
    }, s.prototype._actionGreeting = function(e) {
        return 220 !== e.statusCode ? (this._onError(new Error("Invalid greeting: " + e.data)), 
        void 0) : (this.options.lmtp ? (o.debug(a, "Sending LHLO " + this.options.name), 
        this._currentAction = this._actionLHLO, this._sendCommand("LHLO " + this.options.name)) : (o.debug(a, "Sending EHLO " + this.options.name), 
        this._currentAction = this._actionEHLO, this._sendCommand("EHLO " + this.options.name)), 
        void 0);
    }, s.prototype._actionLHLO = function(e) {
        return e.success ? (this._actionEHLO(e), void 0) : (o.error(a, "LHLO not successful"), 
        this._onError(new Error(e.data)), void 0);
    }, s.prototype._actionEHLO = function(e) {
        var t;
        if (!e.success) {
            if (!this._secureMode && this.options.requireTLS) {
                var n = "STARTTLS not supported without EHLO";
                return o.error(a, n), this._onError(new Error(n)), void 0;
            }
            return o.warn(a, "EHLO not successful, trying HELO " + this.options.name), this._currentAction = this._actionHELO, 
            this._sendCommand("HELO " + this.options.name), void 0;
        }
        return e.line.match(/AUTH(?:\s+[^\n]*\s+|\s+)PLAIN/i) && (o.debug(a, "Server supports AUTH PLAIN"), 
        this._supportedAuth.push("PLAIN")), e.line.match(/AUTH(?:\s+[^\n]*\s+|\s+)LOGIN/i) && (o.debug(a, "Server supports AUTH LOGIN"), 
        this._supportedAuth.push("LOGIN")), e.line.match(/AUTH(?:\s+[^\n]*\s+|\s+)XOAUTH2/i) && (o.debug(a, "Server supports AUTH XOAUTH2"), 
        this._supportedAuth.push("XOAUTH2")), (t = e.line.match(/SIZE (\d+)/i)) && Number(t[1]) && (this._maxAllowedSize = Number(t[1]), 
        o.debug(a, "Maximum allowd message size: " + this._maxAllowedSize)), !this._secureMode && (e.line.match(/[ \-]STARTTLS\s?$/im) && !this.options.ignoreTLS || this.options.requireTLS) ? (this._currentAction = this._actionSTARTTLS, 
        this._sendCommand("STARTTLS"), void 0) : (this._authenticateUser.call(this), void 0);
    }, s.prototype._actionSTARTTLS = function(e) {
        return e.success ? (this._secureMode = !0, this.socket.upgradeToSecure(), this._currentAction = this._actionEHLO, 
        this._sendCommand("EHLO " + this.options.name), void 0) : (o.error(a, "STARTTLS not successful"), 
        this._onError(new Error(e.data)), void 0);
    }, s.prototype._actionHELO = function(e) {
        return e.success ? (this._authenticateUser.call(this), void 0) : (o.error(a, "HELO not successful"), 
        this._onError(new Error(e.data)), void 0);
    }, s.prototype._actionAUTH_LOGIN_USER = function(e) {
        return 334 !== e.statusCode || "VXNlcm5hbWU6" !== e.data ? (o.error(a, "AUTH LOGIN USER not successful: " + e.data), 
        this._onError(new Error('Invalid login sequence while waiting for "334 VXNlcm5hbWU6 ": ' + e.data)), 
        void 0) : (o.debug(a, "AUTH LOGIN USER successful"), this._currentAction = this._actionAUTH_LOGIN_PASS, 
        this._sendCommand(r(unescape(encodeURIComponent(this.options.auth.user)))), void 0);
    }, s.prototype._actionAUTH_LOGIN_PASS = function(e) {
        return 334 !== e.statusCode || "UGFzc3dvcmQ6" !== e.data ? (o.error(a, "AUTH LOGIN PASS not successful: " + e.data), 
        this._onError(new Error('Invalid login sequence while waiting for "334 UGFzc3dvcmQ6 ": ' + e.data)), 
        void 0) : (o.debug(a, "AUTH LOGIN PASS successful"), this._currentAction = this._actionAUTHComplete, 
        this._sendCommand(r(unescape(encodeURIComponent(this.options.auth.pass)))), void 0);
    }, s.prototype._actionAUTH_XOAUTH2 = function(e) {
        e.success ? this._actionAUTHComplete(e) : (o.warn(a, "Error during AUTH XOAUTH2, sending empty response"), 
        this._sendCommand(""), this._currentAction = this._actionAUTHComplete);
    }, s.prototype._actionAUTHComplete = function(e) {
        return e.success ? (o.debug(a, "Authentication successful."), this._authenticatedAs = this.options.auth.user, 
        this._currentAction = this._actionIdle, this.onidle(), void 0) : (o.debug(a, "Authentication failed: " + e.data), 
        this._onError(new Error(e.data)), void 0);
    }, s.prototype._actionIdle = function(e) {
        return e.statusCode > 300 ? (this._onError(new Error(e.line)), void 0) : (this._onError(new Error(e.data)), 
        void 0);
    }, s.prototype._actionMAIL = function(e) {
        return e.success ? (this._envelope.rcptQueue.length ? (o.debug(a, "MAIL FROM successful, proceeding with " + this._envelope.rcptQueue.length + " recipients"), 
        o.debug(a, "Adding recipient..."), this._envelope.curRecipient = this._envelope.rcptQueue.shift(), 
        this._currentAction = this._actionRCPT, this._sendCommand("RCPT TO:<" + this._envelope.curRecipient + ">")) : this._onError(new Error("Can't send mail - no recipients defined")), 
        void 0) : (o.debug(a, "MAIL FROM unsuccessful: " + e.data), this._onError(new Error(e.data)), 
        void 0);
    }, s.prototype._actionRCPT = function(e) {
        if (e.success ? this._envelope.responseQueue.push(this._envelope.curRecipient) : (o.warn(a, "RCPT TO failed for: " + this._envelope.curRecipient), 
        this._envelope.rcptFailed.push(this._envelope.curRecipient)), this._envelope.rcptQueue.length) o.debug(a, "Adding recipient..."), 
        this._envelope.curRecipient = this._envelope.rcptQueue.shift(), this._currentAction = this._actionRCPT, 
        this._sendCommand("RCPT TO:<" + this._envelope.curRecipient + ">"); else {
            if (!(this._envelope.rcptFailed.length < this._envelope.to.length)) return this._onError(new Error("Can't send mail - all recipients were rejected")), 
            this._currentAction = this._actionIdle, void 0;
            this._currentAction = this._actionDATA, o.debug(a, "RCPT TO done, proceeding with payload"), 
            this._sendCommand("DATA");
        }
    }, s.prototype._actionRSET = function(e) {
        return e.success ? (this._authenticatedAs = null, this._authenticateUser.call(this), 
        void 0) : (o.error(a, "RSET unsuccessful " + e.data), this._onError(new Error(e.data)), 
        void 0);
    }, s.prototype._actionDATA = function(e) {
        return [ 250, 354 ].indexOf(e.statusCode) < 0 ? (o.error(a, "DATA unsuccessful " + e.data), 
        this._onError(new Error(e.data)), void 0) : (this._dataMode = !0, this._currentAction = this._actionIdle, 
        this.onready(this._envelope.rcptFailed), void 0);
    }, s.prototype._actionStream = function(e) {
        var t;
        if (this.options.lmtp) {
            if (t = this._envelope.responseQueue.shift(), e.success ? o.error(a, "Local delivery to " + t + " succeeded.") : (o.error(a, "Local delivery to " + t + " failed."), 
            this._envelope.rcptFailed.push(t)), this._envelope.responseQueue.length) return this._currentAction = this._actionStream, 
            void 0;
            this._currentAction = this._actionIdle, this.ondone(!0);
        } else e.success ? o.debug(a, "Message sent successfully.") : o.error(a, "Message sending failed."), 
        this._currentAction = this._actionIdle, this.ondone(!!e.success);
        this._currentAction === this._actionIdle && (o.debug(a, "Idling while waiting for new connections..."), 
        this.onidle());
    }, s.prototype._buildXOAuth2Token = function(e, t) {
        var n = [ "user=" + (e || ""), "auth=Bearer " + t, "", "" ];
        return r(unescape(encodeURIComponent(n.join(""))));
    }, s;
}), define("smtpclient", [ "ext/smtpclient/src/smtpclient" ], function(e) {
    return e;
}), define("smtp/client", [ "require", "exports", "module", "slog", "smtpclient", "../syncbase", "../oauth" ], function(e, t) {
    var n = e("slog"), o = e("smtpclient"), i = e("../syncbase"), r = e("../oauth"), s = window.setTimeout, a = window.clearTimeout;
    t.setTimeoutFunctions = function(e, t) {
        s = e, a = t;
    }, t.createSmtpConnection = function(e, c, d) {
        var l;
        return r.ensureUpdatedCredentials(e, d).then(function() {
            return new Promise(function(t, r) {
                function u() {
                    h && (a(h), h = null);
                }
                var d = {
                    user: void 0 !== e.outgoingUsername ? e.outgoingUsername : e.username,
                    pass: void 0 !== e.outgoingPassword ? e.outgoingPassword : e.password,
                    xoauth2: e.oauth2 ? e.oauth2.accessToken : null
                };
                n.log("smtp:connect", {
                    _auth: d,
                    usingOauth2: !!e.oauth2,
                    connInfo: c
                }), l = new o(c.hostname, c.port, {
                    auth: d,
                    useSecureTransport: "ssl" === c.crypto || c.crypto === !0,
                    requireTLS: "starttls" === c.crypto,
                    ignoreTLS: "plain" === c.crypto
                });
                var h = s(function() {
                    l.onerror("unresponsive-server"), l.close();
                }, i.CONNECT_TIMEOUT_MS);
                l.onidle = function() {
                    u(), n.info("smtp:connected", c), l.onidle = l.onclose = l.onerror = function() {}, 
                    t(l);
                }, l.onerror = function(e) {
                    u(), r(e);
                }, l.onclose = function() {
                    u(), r("server-maybe-offline");
                }, l.connect();
            });
        }).catch(function(o) {
            var i = u(l, o, !1);
            if (l && l.close(), "needs-oauth-reauth" === i && r.isRenewPossible(e)) return r.ensureUpdatedCredentials(e, d, !0).then(function() {
                return t.createImapConnection(e, c, d);
            });
            throw n.error("smtp:connect-error", {
                error: i,
                connInfo: c
            }), i;
        });
    };
    var c = o.prototype._onCommand;
    o.prototype._onCommand = function(e) {
        e.statusCode && !e.success && (this._lastSmtpError = e), c.apply(this, arguments);
    }, o.prototype._onError = function(e) {
        e instanceof Error && e.message ? this.onerror(e) : e && e.data instanceof Error ? this.onerror(e.data) : this.onerror(e && e.data && e.data.message || e.data || e || "Error"), 
        this.close();
    };
    var u = t.analyzeSmtpError = function(e, t, o) {
        var i = t;
        (i && !i.statusCode && "Error" === i.name || !i) && (i = e && e._lastSmtpError || null), 
        i || (i = "null-error");
        var r = e && !!e.options.auth.xoauth2, s = "unknown";
        if (i.statusCode) if (e._currentAction === e._actionSTARTTLS || e._currentAction === e._actionEHLO) s = "bad-security"; else switch (i.statusCode) {
          case 535:
            s = r ? "needs-oauth-reauth" : "bad-user-or-pass";
            break;

          case 534:
            s = "bad-user-or-pass";
            break;

          case 501:
            s = o ? "bad-message" : "server-maybe-offline";
            break;

          case 550:
          case 551:
          case 553:
          case 554:
            s = "bad-address";
            break;

          case 500:
            s = "server-problem";
            break;

          default:
            s = o ? "bad-message" : "unknown";
        } else "ConnectionRefusedError" === i.name ? s = "unresponsive-server" : /^Security/.test(i.name) ? s = "bad-security" : "string" == typeof i && (s = i);
        return n.log("smtp:analyzed-error", {
            statusCode: i.statusCode,
            enhancedStatus: i.enhancedStatus,
            rawError: t,
            rawErrorName: t && t.name,
            rawErrorMessage: t && t.message,
            rawErrorStack: t && t.stack,
            normalizedError: s,
            errorName: i.name,
            errorMessage: i.message,
            errorData: i.data,
            wasSending: o
        }), s;
    };
}), define("smtp/account", [ "require", "slog", "./client", "../disaster-recovery" ], function(e) {
    function t(e, t, n, o, i) {
        this.universe = e, this.compositeAccount = t, this.accountId = n, this.credentials = o, 
        this.connInfo = i, this._activeConnections = [];
    }
    var n = e("slog"), o = e("./client"), i = e("../disaster-recovery");
    return t.prototype = {
        type: "smtp",
        toString: function() {
            return "[SmtpAccount: " + this.id + "]";
        },
        get numActiveConns() {
            return this._activeConnections.length;
        },
        shutdown: function() {},
        accountDeleted: function() {
            this.shutdown();
        },
        sendMessage: function(e, t) {
            this.establishConnection({
                sendEnvelope: function(t) {
                    var o = e.getEnvelope();
                    n.log("smtp:sendEnvelope", {
                        _envelope: o
                    }), t.useEnvelope(o);
                },
                onProgress: function() {
                    e.renewSmartWakeLock("SMTP XHR Progress");
                },
                sendMessage: function(t) {
                    n.log("smtp:building-blob"), e.withMessageBlob({
                        includeBcc: !1
                    }, function(e) {
                        n.log("smtp:sending-blob", {
                            size: e.size
                        }), t.socket.send(e), t._lastDataBytes = "\r\n", t.end();
                    });
                },
                onSendComplete: function() {
                    n.log("smtp:sent"), t(null);
                },
                onError: function(e, o) {
                    n.error("smtp:error", {
                        error: e,
                        badAddresses: o
                    }), t(e, o);
                }
            });
        },
        checkAccount: function(e) {
            var t = !1;
            this.establishConnection({
                sendEnvelope: function(n, o) {
                    t = !0, o(), e();
                },
                sendMessage: function() {},
                onSendComplete: function() {},
                onError: function(t) {
                    "bad-user-or-pass" === t && this.universe.__reportAccountProblem(this.compositeAccount, t, "outgoing"), 
                    e(t);
                }.bind(this)
            });
        },
        establishConnection: function(e) {
            var t, r = !1;
            o.createSmtpConnection(this.credentials, this.connInfo, function() {
                return new Promise(function(e) {
                    this.universe.saveAccountDef(this.compositeAccount.accountDef, null, e);
                }.bind(this));
            }.bind(this)).then(function(s) {
                t = s, i.associateSocketWithAccount(t.socket, this), this._activeConnections.push(t);
                var a = t.socket.ondrain;
                t.socket.ondrain = function() {
                    a && a.call(t.socket), e.onProgress && e.onProgress();
                }, e.sendEnvelope(t, t.close.bind(t)), t.onready = function(o) {
                    n.log("smtp:onready"), o.length ? (t.close(), n.warn("smtp:bad-recipients", {
                        badRecipients: o
                    }), e.onError("bad-recipient", o)) : (r = !0, e.sendMessage(t));
                }, t.ondone = function(i) {
                    if (t.close(), i) n.log("smtp:sent"), e.onSendComplete(t); else {
                        n.error("smtp:send-failed");
                        var s = o.analyzeSmtpError(t, null, r);
                        e.onError(s, null);
                    }
                }, t.onerror = function(n) {
                    t.close(), n = o.analyzeSmtpError(t, n, r), e.onError(n, null);
                }, t.onclose = function() {
                    n.log("smtp:onclose");
                    var e = this._activeConnections.indexOf(t);
                    -1 !== e ? this._activeConnections.splice(e, 1) : n.error("smtp:dead-unknown-connection");
                }.bind(this);
            }.bind(this)).catch(function(n) {
                n = o.analyzeSmtpError(t, n, r), e.onError(n);
            });
        }
    }, {
        Account: t,
        SmtpAccount: t
    };
}), define("composite/account", [ "rdcommon/log", "../accountcommon", "../a64", "../accountmixins", "../imap/account", "../pop3/account", "../smtp/account", "../allback", "exports" ], function(e, t, n, o, i, r, s, a, c) {
    function u(e, t, n, i, r, s) {
        this.universe = e, this.id = t.id, this.accountDef = t, this._enabled = !0, this.problems = [], 
        t.credentials && t.credentials.oauth2 && (t.credentials.oauth2._transientLastRenew = 0), 
        this.identities = t.identities, d.hasOwnProperty(t.receiveType) || s.badAccountType(t.receiveType), 
        d.hasOwnProperty(t.sendType) || s.badAccountType(t.sendType), this._receivePiece = new d[t.receiveType](e, this, t.id, t.credentials, t.receiveConnInfo, n, i, s, r), 
        this._sendPiece = new d[t.sendType](e, this, t.id, t.credentials, t.sendConnInfo, i, s), 
        this._LOG = this._receivePiece._LOG, this.folders = this._receivePiece.folders, 
        this.meta = this._receivePiece.meta, this.mutations = this._receivePiece.mutations, 
        this.tzOffset = t.tzOffset, o.accountConstructorMixin.call(this, this._receivePiece, this._sendPiece);
    }
    var d = {
        imap: i.ImapAccount,
        pop3: r.Pop3Account,
        smtp: s.SmtpAccount
    };
    c.Account = c.CompositeAccount = u, u.prototype = {
        toString: function() {
            return "[CompositeAccount: " + this.id + "]";
        },
        get supportsServerFolders() {
            return this._receivePiece.supportsServerFolders;
        },
        toBridgeWire: function() {
            return {
                id: this.accountDef.id,
                name: this.accountDef.name,
                type: this.accountDef.type,
                defaultPriority: this.accountDef.defaultPriority,
                enabled: this.enabled,
                problems: this.problems,
                syncRange: this.accountDef.syncRange,
                syncInterval: this.accountDef.syncInterval,
                notifyOnNew: this.accountDef.notifyOnNew,
                playSoundOnSend: this.accountDef.playSoundOnSend,
                identities: this.identities,
                credentials: {
                    username: this.accountDef.credentials.username,
                    outgoingUsername: this.accountDef.credentials.outgoingUsername,
                    oauth2: this.accountDef.credentials.oauth2
                },
                servers: [ {
                    type: this.accountDef.receiveType,
                    connInfo: this.accountDef.receiveConnInfo,
                    activeConns: this._receivePiece.numActiveConns || 0
                }, {
                    type: this.accountDef.sendType,
                    connInfo: this.accountDef.sendConnInfo,
                    activeConns: this._sendPiece.numActiveConns || 0
                } ]
            };
        },
        toBridgeFolder: function() {
            return {
                id: this.accountDef.id,
                name: this.accountDef.name,
                path: this.accountDef.name,
                type: "account"
            };
        },
        get enabled() {
            return this._enabled;
        },
        set enabled(e) {
            this._enabled = this._receivePiece.enabled = e;
        },
        saveAccountState: function(e, t, n) {
            return this._receivePiece.saveAccountState(e, t, n);
        },
        get _saveAccountIsImminent() {
            return this.__saveAccountIsImminent;
        },
        set _saveAccountIsImminent(e) {
            this.___saveAccountIsImminent = this._receivePiece._saveAccountIsImminent = e;
        },
        runAfterSaves: function(e) {
            return this._receivePiece.runAfterSaves(e);
        },
        allOperationsCompleted: function() {
            this._receivePiece.allOperationsCompleted && this._receivePiece.allOperationsCompleted();
        },
        checkAccount: function(e) {
            var t = a.latch();
            this._receivePiece.checkAccount(t.defer("incoming")), this._sendPiece.checkAccount(t.defer("outgoing")), 
            t.then(function(t) {
                e(t.incoming[0], t.outgoing[0]);
            });
        },
        shutdown: function(e) {
            this._sendPiece.shutdown(), this._receivePiece.shutdown(e);
        },
        accountDeleted: function() {
            this._sendPiece.accountDeleted(), this._receivePiece.accountDeleted();
        },
        deleteFolder: function(e, t) {
            return this._receivePiece.deleteFolder(e, t);
        },
        sliceFolderMessages: function(e, t) {
            return this._receivePiece.sliceFolderMessages(e, t);
        },
        searchFolderMessages: function(e, t, n, o) {
            return this._receivePiece.searchFolderMessages(e, t, n, o);
        },
        syncFolderList: function(e) {
            return this._receivePiece.syncFolderList(e);
        },
        sendMessage: function(e, t) {
            return this._sendPiece.sendMessage(e, function(n, o) {
                n || this._receivePiece.saveSentMessage(e), t(n, o, null);
            }.bind(this));
        },
        getFolderStorageForFolderId: function(e) {
            return this._receivePiece.getFolderStorageForFolderId(e);
        },
        getFolderMetaForFolderId: function(e) {
            return this._receivePiece.getFolderMetaForFolderId(e);
        },
        runOp: function(e, t, n) {
            return this._receivePiece.runOp(e, t, n);
        },
        ensureEssentialOnlineFolders: function(e) {
            return this._receivePiece.ensureEssentialOnlineFolders(e);
        },
        getFirstFolderWithType: o.getFirstFolderWithType,
        upgradeFolderStoragesIfNeeded: function() {
            for (var e in this._receivePiece._folderStorages) {
                var t = this._receivePiece._folderStorages[e];
                t.upgradeIfNeeded();
            }
        }
    };
}), define("composite/configurator", [ "rdcommon/log", "../accountcommon", "../a64", "../allback", "./account", "../date", "require", "exports" ], function(e, t, n, o, i, r, s, a) {
    o.allbackMaker, a.account = i, a.configurator = {
        tryToCreateAccount: function(e, t, n, o) {
            var i, a, c, u;
            if (n) {
                u = "imap+smtp" === n.type ? "imap" : "pop3";
                var d = null;
                d = void 0 !== t.outgoingPassword ? t.outgoingPassword : t.password, i = {
                    username: n.incoming.username,
                    password: t.password,
                    outgoingUsername: n.outgoing.username,
                    outgoingPassword: d
                }, n.oauth2Tokens && (i.oauth2 = {
                    authEndpoint: n.oauth2Settings.authEndpoint,
                    tokenEndpoint: n.oauth2Settings.tokenEndpoint,
                    scope: n.oauth2Settings.scope,
                    clientId: n.oauth2Secrets.clientId,
                    clientSecret: n.oauth2Secrets.clientSecret,
                    refreshToken: n.oauth2Tokens.refreshToken,
                    accessToken: n.oauth2Tokens.accessToken,
                    expireTimeMS: n.oauth2Tokens.expireTimeMS,
                    _transientLastRenew: r.PERFNOW()
                }), a = {
                    hostname: n.incoming.hostname,
                    port: n.incoming.port,
                    crypto: "string" == typeof n.incoming.socketType ? n.incoming.socketType.toLowerCase() : n.incoming.socketType
                }, "pop3" === u && (a.preferredAuthMethod = null), c = {
                    emailAddress: t.emailAddress,
                    hostname: n.outgoing.hostname,
                    port: n.outgoing.port,
                    crypto: "string" == typeof n.outgoing.socketType ? n.outgoing.socketType.toLowerCase() : n.outgoing.socketType
                };
            }
            var l = new Promise(function(e, t) {
                "imap" === u ? s([ "../imap/probe" ], function(n) {
                    n.probeAccount(i, a).then(e, t);
                }) : s([ "../pop3/probe" ], function(n) {
                    n.probeAccount(i, a).then(e, t);
                });
            }), h = new Promise(function(e, t) {
                s([ "../smtp/probe" ], function(n) {
                    n.probeAccount(i, c).then(e, t);
                });
            });
            Promise.all([ l, h ]).then(function(n) {
                var r, s = n[0].conn, d = null;
                "imap" === u ? (d = n[0].timezoneOffset, r = this._defineImapAccount) : "pop3" === u && (a.preferredAuthMethod = s.authMethod, 
                r = this._definePop3Account), r.call(this, e, t, i, a, c, s, d, o);
            }.bind(this)).catch(function(e) {
                l.then(function(t) {
                    t.conn.close(), o(e, null, {
                        server: c.hostname
                    });
                }).catch(function(e) {
                    o(e, null, {
                        server: a.hostname
                    });
                });
            });
        },
        recreateAccount: function(e, o, i, r) {
            var s = i.def, a = {
                username: s.credentials.username,
                password: s.credentials.password,
                outgoingUsername: s.credentials.outgoingUsername,
                outgoingPassword: s.credentials.outgoingPassword,
                authMechanism: s.credentials.authMechanism,
                oauth2: s.credentials.oauth2
            }, c = n.encodeInt(e.config.nextAccountNum++), u = s.type || "imap+smtp", d = {
                id: c,
                name: s.name,
                type: u,
                receiveType: u.split("+")[0],
                sendType: "smtp",
                syncRange: s.syncRange,
                syncInterval: s.syncInterval || 0,
                notifyOnNew: s.hasOwnProperty("notifyOnNew") ? s.notifyOnNew : !0,
                playSoundOnSend: s.hasOwnProperty("playSoundOnSend") ? s.playSoundOnSend : !0,
                credentials: a,
                receiveConnInfo: {
                    hostname: s.receiveConnInfo.hostname,
                    port: s.receiveConnInfo.port,
                    crypto: s.receiveConnInfo.crypto,
                    preferredAuthMethod: s.receiveConnInfo.preferredAuthMethod || null
                },
                sendConnInfo: {
                    hostname: s.sendConnInfo.hostname,
                    port: s.sendConnInfo.port,
                    crypto: s.sendConnInfo.crypto
                },
                identities: t.recreateIdentities(e, c, s.identities),
                tzOffset: void 0 !== i.tzOffset ? i.tzOffset : -252e5
            };
            this._loadAccount(e, d, i.folderInfo, null, function(e) {
                r(null, e, null);
            });
        },
        _defineImapAccount: function(e, t, o, i, s, a, c, u) {
            var d = n.encodeInt(e.config.nextAccountNum++), l = {
                id: d,
                name: t.accountName || t.emailAddress,
                defaultPriority: r.NOW(),
                type: "imap+smtp",
                receiveType: "imap",
                sendType: "smtp",
                syncRange: "auto",
                syncInterval: t.syncInterval || 0,
                notifyOnNew: t.hasOwnProperty("notifyOnNew") ? t.notifyOnNew : !0,
                playSoundOnSend: t.hasOwnProperty("playSoundOnSend") ? t.playSoundOnSend : !0,
                credentials: o,
                receiveConnInfo: i,
                sendConnInfo: s,
                identities: [ {
                    id: d + "/" + n.encodeInt(e.config.nextIdentityNum++),
                    name: t.displayName,
                    address: t.emailAddress,
                    replyTo: null,
                    signature: null,
                    signatureEnabled: !1
                } ],
                tzOffset: c
            };
            this._loadAccount(e, l, null, a, function(e) {
                u(null, e, null);
            });
        },
        _definePop3Account: function(e, t, o, i, s, a, c, u) {
            var d = n.encodeInt(e.config.nextAccountNum++), l = {
                id: d,
                name: t.accountName || t.emailAddress,
                defaultPriority: r.NOW(),
                type: "pop3+smtp",
                receiveType: "pop3",
                sendType: "smtp",
                syncRange: "auto",
                syncInterval: t.syncInterval || 0,
                notifyOnNew: t.hasOwnProperty("notifyOnNew") ? t.notifyOnNew : !0,
                playSoundOnSend: t.hasOwnProperty("playSoundOnSend") ? t.playSoundOnSend : !0,
                credentials: o,
                receiveConnInfo: i,
                sendConnInfo: s,
                identities: [ {
                    id: d + "/" + n.encodeInt(e.config.nextIdentityNum++),
                    name: t.displayName,
                    address: t.emailAddress,
                    replyTo: null,
                    signature: null,
                    signatureEnabled: !1
                } ]
            };
            this._loadAccount(e, l, null, a, function(e) {
                u(null, e, null);
            });
        },
        _loadAccount: function(e, t, n, o, i) {
            var r;
            r = "imap" === t.receiveType ? {
                $meta: {
                    nextFolderNum: 0,
                    nextMutationNum: 0,
                    lastFolderSyncAt: 0,
                    capability: n && n.$meta.capability || o.capability
                },
                $mutations: [],
                $mutationState: {}
            } : {
                $meta: {
                    nextFolderNum: 0,
                    nextMutationNum: 0,
                    lastFolderSyncAt: 0
                },
                $mutations: [],
                $mutationState: {}
            }, e.saveAccountDef(t, r), e._loadAccount(t, r, o, i);
        }
    };
});