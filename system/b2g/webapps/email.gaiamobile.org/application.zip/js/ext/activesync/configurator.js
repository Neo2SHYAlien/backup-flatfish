define("activesync/folder", [ "rdcommon/log", "../date", "../syncbase", "../allback", "../db/mail_rep", "activesync/codepages/AirSync", "activesync/codepages/AirSyncBase", "activesync/codepages/ItemEstimate", "activesync/codepages/Email", "activesync/codepages/ItemOperations", "safe-base64", "mimetypes", "module", "require", "exports" ], function(e, t, n, i, o, r, s, a, c, l, d, u, p, h, f) {
    function m() {
        y = r.Enums.FilterType, b = {
            auto: null,
            "1d": y.OneDayBack,
            "3d": y.ThreeDaysBack,
            "1w": y.OneWeekBack,
            "2w": y.TwoWeeksBack,
            "1m": y.OneMonthBack,
            all: y.NoFilter
        }, x = {
            0: "all messages",
            1: "one day",
            2: "three days",
            3: "one week",
            4: "two weeks",
            5: "one month"
        };
    }
    function g(e, t, n) {
        return function() {
            var i = Array.slice(arguments), o = i[e], r = this;
            h([ "wbxml", "addressparser", "../mailchew" ], function(e, s, a) {
                S || (S = e, w = s.parse.bind(s), T = a, m()), r._account.withConnection(o, function() {
                    t.apply(r, i);
                }, n);
            });
        };
    }
    function v(e, t, n) {
        this._account = e, this._storage = t, this._LOG = I.ActiveSyncFolderConn(this, n, t.folderId), 
        this.folderMeta = t.folderMeta, this.syncKey || (this.syncKey = "0");
    }
    function _(e, t, n) {
        this._account = e, this.folderStorage = t, this._LOG = I.ActiveSyncFolderSyncer(this, n, t.folderId), 
        this.folderConn = new v(e, t, this._LOG);
    }
    var y, b, x, S, w, T, A = 512, E = 50;
    v.prototype = {
        get syncKey() {
            return this.folderMeta.syncKey;
        },
        set syncKey(e) {
            return this.folderMeta.syncKey = e;
        },
        get serverId() {
            return this.folderMeta.serverId;
        },
        get filterType() {
            var e = this._account.accountDef.syncRange;
            if (b.hasOwnProperty(e)) {
                var t = b[e];
                return t ? t : this.folderMeta.filterType;
            }
            return console.warn("Got an invalid syncRange (" + e + ") using three days back instead"), 
            r.Enums.FilterType.ThreeDaysBack;
        },
        _getSyncKey: g(1, function(e, t) {
            var n = this, i = this._account, o = r.Tags, s = new S.Writer("1.3", 1, "UTF-8");
            s.stag(o.Sync).stag(o.Collections).stag(o.Collection), i.conn.currentVersion.lt("12.1") && s.tag(o.Class, "Email"), 
            s.tag(o.SyncKey, "0").tag(o.CollectionId, this.serverId).stag(o.Options).tag(o.FilterType, e).etag().etag().etag().etag(), 
            i.conn.postCommand(s, function(e, r) {
                if (e) return console.error(e), i._reportErrorIfNecessary(e), t("unknown"), void 0;
                n.syncKey = "0";
                var s = new S.EventParser();
                s.addEventListener([ o.Sync, o.Collections, o.Collection, o.SyncKey ], function(e) {
                    n.syncKey = e.children[0].textContent;
                }), s.onerror = function() {}, s.run(r), "0" === n.syncKey ? (console.error("Unable to get sync key for folder"), 
                t("unknown")) : t();
            });
        }),
        _getItemEstimate: g(1, function(e, t) {
            var n = a.Tags, i = r.Tags, o = this._account, s = new S.Writer("1.3", 1, "UTF-8");
            s.stag(n.GetItemEstimate).stag(n.Collections).stag(n.Collection), this._account.conn.currentVersion.gte("14.0") ? s.tag(i.SyncKey, this.syncKey).tag(n.CollectionId, this.serverId).stag(i.Options).tag(i.FilterType, e).etag() : this._account.conn.currentVersion.gte("12.0") ? s.tag(n.CollectionId, this.serverId).tag(i.FilterType, e).tag(i.SyncKey, this.syncKey) : s.tag(n.Class, "Email").tag(i.SyncKey, this.syncKey).tag(n.CollectionId, this.serverId).tag(i.FilterType, e), 
            s.etag(n.Collection).etag(n.Collections).etag(n.GetItemEstimate), o.conn.postCommand(s, function(e, i) {
                if (e) return console.error(e), o._reportErrorIfNecessary(e), t("unknown"), void 0;
                var r, s, c = new S.EventParser(), l = [ n.GetItemEstimate, n.Response ];
                c.addEventListener(l.concat(n.Status), function(e) {
                    r = e.children[0].textContent;
                }), c.addEventListener(l.concat(n.Collection, n.Estimate), function(e) {
                    s = parseInt(e.children[0].textContent, 10);
                });
                try {
                    c.run(i);
                } catch (d) {
                    return console.error("Error parsing GetItemEstimate response", d, "\n", d.stack), 
                    t("unknown"), void 0;
                }
                r !== a.Enums.Status.Success ? (console.error("Error getting item estimate:", r), 
                t("unknown")) : t(null, s);
            });
        }),
        _inferFilterType: g(0, function(e) {
            var t = this, n = r.Enums.FilterType, i = function(i, o) {
                t._getSyncKey(i, function(r) {
                    return r ? (e("unknown"), void 0) : (t._getItemEstimate(i, function(t, i) {
                        return t ? (e(null, n.ThreeDaysBack), void 0) : (o(i), void 0);
                    }), void 0);
                });
            };
            i(n.TwoWeeksBack, function(o) {
                var r, s = o / 14;
                if (0 > o) r = n.ThreeDaysBack; else if (s >= E) r = n.OneDayBack; else if (3 * s >= E) r = n.ThreeDaysBack; else if (7 * s >= E) r = n.OneWeekBack; else if (14 * s >= E) r = n.TwoWeeksBack; else {
                    if (!(30 * s >= E)) return i(n.NoFilter, function(i) {
                        var o;
                        i > E ? (o = n.OneMonthBack, t.syncKey = "0") : o = n.NoFilter, t._LOG.inferFilterType(o), 
                        e(null, o);
                    }), void 0;
                    r = n.OneMonthBack;
                }
                r !== n.TwoWeeksBack && (t.syncKey = "0"), t._LOG.inferFilterType(r), e(null, r);
            });
        }),
        _enumerateFolderChanges: g(0, function(e, t) {
            var n = this, i = this._storage;
            if (!this.filterType) return this._inferFilterType(function(i, o) {
                return i ? (e("unknown"), void 0) : (console.log("We want a filter of", x[o]), n.folderMeta.filterType = o, 
                n._enumerateFolderChanges(e, t), void 0);
            }), void 0;
            if ("0" === this.syncKey) return this._getSyncKey(this.filterType, function(i) {
                return i ? (e("aborted"), void 0) : (n._enumerateFolderChanges(e, t), void 0);
            }), void 0;
            var o = r.Tags, a = r.Enums;
            s.Tags, s.Enums;
            var c;
            0 === this._account._syncsInProgress++ && this._account._lastSyncKey === this.syncKey && this._account._lastSyncFilterType === this.filterType && this._account._lastSyncResponseWasEmpty ? c = o.Sync : (c = new S.Writer("1.3", 1, "UTF-8"), 
            c.stag(o.Sync).stag(o.Collections).stag(o.Collection), this._account.conn.currentVersion.lt("12.1") && c.tag(o.Class, "Email"), 
            c.tag(o.SyncKey, this.syncKey).tag(o.CollectionId, this.serverId).tag(o.GetChanges).stag(o.Options).tag(o.FilterType, this.filterType), 
            this._account.conn.currentVersion.lte("12.0") && c.tag(o.MIMESupport, a.MIMESupport.Never).tag(o.Truncation, a.MIMETruncation.TruncateAll), 
            c.etag().etag().etag().etag()), this._account.conn.postCommand(c, function(r, s) {
                var c, l = [], d = [], u = [], p = !1;
                if (n._account._syncsInProgress--, r) return console.error("Error syncing folder:", r), 
                n._account._reportErrorIfNecessary(r), e("aborted"), void 0;
                if (n._account._lastSyncKey = n.syncKey, n._account._lastSyncFilterType = n.filterType, 
                !s) return console.log("Sync completed with empty response"), n._account._lastSyncResponseWasEmpty = !0, 
                e(null, l, d, u), void 0;
                n._account._lastSyncResponseWasEmpty = !1;
                var h = new S.EventParser(), f = [ o.Sync, o.Collections, o.Collection ];
                h.addEventListener(f.concat(o.SyncKey), function(e) {
                    n.syncKey = e.children[0].textContent;
                }), h.addEventListener(f.concat(o.Status), function(e) {
                    c = e.children[0].textContent;
                }), h.addEventListener(f.concat(o.MoreAvailable), function() {
                    p = !0;
                }), h.addEventListener(f.concat(o.Commands, [ [ o.Add, o.Change ] ]), function(e) {
                    var t, r;
                    for (var s in Iterator(e.children)) {
                        var a = s[1];
                        switch (a.tag) {
                          case o.ServerId:
                            t = a.children[0].textContent;
                            break;

                          case o.ApplicationData:
                            try {
                                r = n._parseMessage(a, e.tag === o.Add, i);
                            } catch (c) {
                                return console.error("Failed to parse a message:", c, "\n", c.stack), void 0;
                            }
                        }
                    }
                    r.header.srvid = t;
                    var u = e.tag === o.Add ? l : d;
                    u.push(r);
                }), h.addEventListener(f.concat(o.Commands, [ [ o.Delete, o.SoftDelete ] ]), function(e) {
                    var t;
                    for (var n in Iterator(e.children)) {
                        var i = n[1];
                        switch (i.tag) {
                          case o.ServerId:
                            t = i.children[0].textContent;
                        }
                    }
                    u.push(t);
                });
                try {
                    h.run(s);
                } catch (m) {
                    return console.error("Error parsing Sync response:", m, "\n", m.stack), e("unknown"), 
                    void 0;
                }
                c === a.Status.Success ? (console.log("Sync completed: added " + l.length + ", changed " + d.length + ", deleted " + u.length), 
                e(null, l, d, u, p), p && n._enumerateFolderChanges(e, t)) : c === a.Status.InvalidSyncKey ? (console.warn("ActiveSync had a bad sync key"), 
                e("badkey")) : (console.error("Something went wrong during ActiveSync syncing and we got a status of " + c), 
                e("unknown"));
            }, null, null, function(e, n) {
                n || (n = Math.max(1e6, e)), t(.1 + .7 * e / n);
            });
        }, "aborted"),
        _parseMessage: function(e, t, n) {
            var i, r, a, l = c.Tags, d = s.Tags, p = s.Enums;
            if (t) {
                var h = n._issueNewHeaderId();
                i = {
                    id: h,
                    srvid: null,
                    suid: n.folderId + "/" + h,
                    guid: "",
                    author: null,
                    to: null,
                    cc: null,
                    bcc: null,
                    replyTo: null,
                    date: null,
                    flags: [],
                    hasAttachments: !1,
                    subject: null,
                    snippet: null
                }, r = {
                    date: null,
                    size: 0,
                    attachments: [],
                    relatedParts: [],
                    references: null,
                    bodyReps: null
                }, a = function(e, t) {
                    t && i.flags.push(e);
                };
            } else i = {
                flags: [],
                mergeInto: function(e) {
                    for (var t in Iterator(this.flags)) {
                        var n = t[1];
                        if (n[1]) e.flags.push(n[0]); else {
                            var i = e.flags.indexOf(n[0]);
                            -1 !== i && e.flags.splice(i, 1);
                        }
                    }
                    var o = [ "mergeInto", "suid", "srvid", "guid", "id", "flags" ];
                    for (var t in Iterator(this)) {
                        var r = t[0], s = t[1];
                        -1 === o.indexOf(r) && (e[r] = s);
                    }
                }
            }, r = {
                mergeInto: function(e) {
                    for (var t in Iterator(this)) {
                        var n = t[0], i = t[1];
                        "mergeInto" !== n && (e[n] = i);
                    }
                }
            }, a = function(e, t) {
                i.flags.push([ e, t ]);
            };
            var f, m;
            for (var g in Iterator(e.children)) {
                var v = g[1], _ = v.children.length ? v.children[0].textContent : null;
                switch (v.tag) {
                  case l.Subject:
                    i.subject = _;
                    break;

                  case l.From:
                    i.author = w(_)[0] || null;
                    break;

                  case l.To:
                    i.to = w(_);
                    break;

                  case l.Cc:
                    i.cc = w(_);
                    break;

                  case l.ReplyTo:
                    i.replyTo = w(_);
                    break;

                  case l.DateReceived:
                    r.date = i.date = new Date(_).valueOf();
                    break;

                  case l.Read:
                    a("\\Seen", "1" === _);
                    break;

                  case l.Flag:
                    for (var y in Iterator(v.children)) {
                        var b = y[1];
                        b.tag === l.Status && a("\\Flagged", "0" !== b.children[0].textContent);
                    }
                    break;

                  case d.Body:
                    for (var y in Iterator(v.children)) {
                        var b = y[1];
                        switch (b.tag) {
                          case d.Type:
                            var x = b.children[0].textContent;
                            x === p.Type.HTML ? f = "html" : (x !== p.Type.PlainText && console.warn("A message had a strange body type:", x), 
                            f = "plain");
                            break;

                          case d.EstimatedDataSize:
                            m = b.children[0].textContent;
                        }
                    }
                    break;

                  case l.BodySize:
                    f = "plain", m = _;
                    break;

                  case d.Attachments:
                  case l.Attachments:
                    for (var y in Iterator(v.children)) {
                        var S = y[1];
                        if (S.tag === d.Attachment || S.tag === l.Attachment) {
                            var T = {
                                name: null,
                                contentId: null,
                                type: null,
                                part: null,
                                encoding: null,
                                sizeEstimate: null,
                                file: null
                            }, A = !1;
                            for (var E in Iterator(S.children)) {
                                var I, k, C = E[1], O = C.children.length ? C.children[0].textContent : null;
                                switch (C.tag) {
                                  case d.DisplayName:
                                  case l.DisplayName:
                                    T.name = O, I = T.name.lastIndexOf("."), k = I > 0 ? T.name.substring(I + 1).toLowerCase() : "", 
                                    T.type = u.detectMimeType(k);
                                    break;

                                  case d.FileReference:
                                  case l.AttName:
                                    T.part = O;
                                    break;

                                  case d.EstimatedDataSize:
                                  case l.AttSize:
                                    T.sizeEstimate = parseInt(O, 10);
                                    break;

                                  case d.ContentId:
                                    T.contentId = O;
                                    break;

                                  case d.IsInline:
                                    A = "1" === O;
                                    break;

                                  case d.FileReference:
                                  case l.Att0Id:
                                    T.part = C.children[0].textContent;
                                }
                            }
                            A ? r.relatedParts.push(o.makeAttachmentPart(T)) : r.attachments.push(o.makeAttachmentPart(T));
                        }
                    }
                    i.hasAttachments = r.attachments.length > 0;
                }
            }
            return t ? (r.bodyReps = [ o.makeBodyPart({
                type: f,
                sizeEstimate: m,
                amountDownloaded: 0,
                isDownloaded: !1
            }) ], {
                header: o.makeHeaderInfo(i),
                body: o.makeBodyInfo(r)
            }) : {
                header: i,
                body: r
            };
        },
        downloadBodies: function(e, t, n) {
            if (this._account.conn.currentVersion.lt("12.0")) return this._syncBodies(e, n);
            for (var o = 0, r = i.latch(), s = 0; s < e.length; s++) {
                var a = e[s];
                a && null === a.snippet && (o++, this.downloadBodyReps(a, t, r.defer(a.suid)));
            }
            r.then(function(e) {
                n(i.extractErrFromCallbackArgs(e), o);
            });
        },
        downloadBodyReps: g(1, function(e, t, n) {
            var i = this, o = this._account;
            if (o.conn.currentVersion.lt("12.0")) return this._syncBodies([ e ], n);
            "function" == typeof t && (n = t, t = null), t = t || {};
            var a = l.Tags, c = l.Enums, d = r.Tags;
            r.Enums;
            var u = s.Tags, p = s.Enums.Type, h = function(r) {
                if (!r) return n("unknown");
                var s, l = r.bodyReps[0], h = "html" === l.type ? p.HTML : p.PlainText;
                t.maximumBytesToFetch < l.sizeEstimate && (h = p.PlainText, s = A);
                var f = new S.Writer("1.3", 1, "UTF-8");
                f.stag(a.ItemOperations).stag(a.Fetch).tag(a.Store, "Mailbox").tag(d.CollectionId, i.serverId).tag(d.ServerId, e.srvid).stag(a.Options).stag(a.Schema).tag(u.Body).etag().stag(u.BodyPreference).tag(u.Type, h), 
                s && f.tag(u.TruncationSize, s), f.etag().etag().etag().etag(), o.conn.postCommand(f, function(t, l) {
                    if (t) return console.error(t), o._reportErrorIfNecessary(t), n("unknown"), void 0;
                    var d, p, h = new S.EventParser();
                    h.addEventListener([ a.ItemOperations, a.Status ], function(e) {
                        d = e.children[0].textContent;
                    }), h.addEventListener([ a.ItemOperations, a.Response, a.Fetch, a.Properties, u.Body, u.Data ], function(e) {
                        p = e.children[0].textContent;
                    });
                    try {
                        h.run(l);
                    } catch (f) {
                        return n("unknown");
                    }
                    return d !== c.Status.Success ? n("unknown") : (i._updateBody(e, r, p, !!s, n), 
                    void 0);
                });
            };
            this._storage.getMessageBody(e.suid, e.date, h);
        }),
        _syncBodies: function(e, t) {
            var n = r.Tags, o = r.Enums, s = c.Tags, a = this, l = this._account, d = new S.Writer("1.3", 1, "UTF-8");
            d.stag(n.Sync).stag(n.Collections).stag(n.Collection).tag(n.Class, "Email").tag(n.SyncKey, this.syncKey).tag(n.CollectionId, this.serverId).stag(n.Options).tag(n.MIMESupport, o.MIMESupport.Never).etag().stag(n.Commands);
            for (var u = 0; u < e.length; u++) d.stag(n.Fetch).tag(n.ServerId, e[u].srvid).etag();
            d.etag().etag().etag().etag(), l.conn.postCommand(d, function(r, c) {
                if (r) return console.error(r), l._reportErrorIfNecessary(r), t("unknown"), void 0;
                var d = i.latch(), u = 0, p = new S.EventParser(), h = [ n.Sync, n.Collections, n.Collection ];
                p.addEventListener(h.concat(n.SyncKey), function(e) {
                    a.syncKey = e.children[0].textContent;
                }), p.addEventListener(h.concat(n.Status), function(e) {
                    var t = e.children[0].textContent;
                    t !== o.Status.Success && d.defer("status")("unknown");
                }), p.addEventListener(h.concat(n.Responses, n.Fetch, n.ApplicationData, s.Body), function(t) {
                    var n = e[u++], i = t.children[0].textContent, o = d.defer(n.suid);
                    a._storage.getMessageBody(n.suid, n.date, function(e) {
                        a._updateBody(n, e, i, !1, o);
                    });
                }), p.run(c), d.then(function(e) {
                    t(i.extractErrFromCallbackArgs(e));
                });
            });
        },
        _activeSyncHeaderIsSeen: function(e) {
            for (var t = 0; t < e.flags.length; t++) if ("\\Seen" === e.flags[t][0] && e.flags[t][1]) return !0;
            return !1;
        },
        _updateBody: function(e, t, n, o, r) {
            var s = t.bodyReps[0];
            n = n.replace(/\r/g, "");
            var a = o ? "plain" : s.type, c = T.processMessageContent(n, a, !o, !0, this._LOG);
            e.snippet = c.snippet, s.isDownloaded = !o, s.amountDownloaded = n.length, o || (s.content = c.content);
            var l = {
                changeDetails: {
                    bodyReps: [ 0 ]
                }
            }, d = i.latch();
            this._storage.updateMessageHeader(e.date, e.id, !1, e, t, d.defer("header")), this._storage.updateMessageBody(e, t, {}, l, d.defer("body")), 
            d.then(r.bind(null, null, t, !1));
        },
        sync: g(1, function(e, t, o) {
            var r = this, s = 0, a = 0, c = 0;
            this._LOG.sync_begin(null, null, null);
            var l = this;
            this._enumerateFolderChanges(function(o, d, u, p, h) {
                var f = r._storage;
                if ("badkey" === o) return r._account._recreateFolder(f.folderId, function() {
                    r._storage = null, r._LOG.sync_end(null, null, null);
                }), void 0;
                if (o) return r._LOG.sync_end(null, null, null), t(o), void 0;
                var m = i.latch();
                for (var g in Iterator(d)) {
                    var v = g[1];
                    f.hasMessageWithServerId(v.header.srvid) || (f.addMessageHeader(v.header, v.body, m.defer()), 
                    f.addMessageBody(v.header, v.body, m.defer()), s++);
                }
                for (var g in Iterator(u)) {
                    var v = g[1];
                    f.hasMessageWithServerId(v.header.srvid) && (f.updateMessageHeaderByServerId(v.header.srvid, !0, function(e, t) {
                        return !l._activeSyncHeaderIsSeen(t) && l._activeSyncHeaderIsSeen(e.header) ? f.folderMeta.unreadCount-- : l._activeSyncHeaderIsSeen(t) && !l._activeSyncHeaderIsSeen(e.header) && f.folderMeta.unreadCount++, 
                        e.header.mergeInto(t), !0;
                    }.bind(null, v), null, m.defer()), a++);
                }
                for (var g in Iterator(p)) {
                    var _ = g[1];
                    f.hasMessageWithServerId(_) && (f.deleteMessageByServerId(_, m.defer()), c++);
                }
                if (!h) {
                    var y = s + a + c;
                    m.then(function() {
                        r._LOG.sync_end(s, a, c), f.markSyncRange(n.OLDEST_SYNC_DATE, e, "XXX", e), t(null, null, y);
                    });
                }
            }, o);
        }),
        performMutation: g(1, function(e, t) {
            var n = this, i = r.Tags, o = this._account, s = new S.Writer("1.3", 1, "UTF-8");
            s.stag(i.Sync).stag(i.Collections).stag(i.Collection), o.conn.currentVersion.lt("12.1") && s.tag(i.Class, "Email"), 
            s.tag(i.SyncKey, this.syncKey).tag(i.CollectionId, this.serverId).tag(i.DeletesAsMoves, "trash" === this.folderMeta.type ? "0" : "1").tag(i.GetChanges, "0").stag(i.Commands);
            try {
                e(s);
            } catch (a) {
                return console.error("Exception in performMutation callee:", a, "\n", a.stack), 
                t("unknown"), void 0;
            }
            s.etag(i.Commands).etag(i.Collection).etag(i.Collections).etag(i.Sync), o.conn.postCommand(s, function(e, s) {
                if (e) return console.error("postCommand error:", e), o._reportErrorIfNecessary(e), 
                t("unknown"), void 0;
                var a, c, l = new S.EventParser(), d = [ i.Sync, i.Collections, i.Collection ];
                l.addEventListener(d.concat(i.SyncKey), function(e) {
                    a = e.children[0].textContent;
                }), l.addEventListener(d.concat(i.Status), function(e) {
                    c = e.children[0].textContent;
                });
                try {
                    l.run(s);
                } catch (u) {
                    return console.error("Error parsing Sync response:", u, "\n", u.stack), t("unknown"), 
                    void 0;
                }
                c === r.Enums.Status.Success ? (n.syncKey = a, t && t(null)) : (console.error("Something went wrong during ActiveSync syncing and we got a status of " + c), 
                t("status:" + c));
            });
        }),
        downloadMessageAttachments: g(2, function(e, t, n) {
            var i = this, o = l.Tags, r = l.Enums.Status, a = s.Tags, c = new S.Writer("1.3", 1, "UTF-8");
            c.stag(o.ItemOperations);
            for (var u in Iterator(t)) {
                var p = u[1];
                c.stag(o.Fetch).tag(o.Store, "Mailbox").tag(a.FileReference, p.part).etag();
            }
            c.etag(), this._account.conn.postCommand(c, function(e, s) {
                if (e) return console.error("postCommand error:", e), i._account._reportErrorIfNecessary(e), 
                n("unknown"), void 0;
                var c, l = {}, u = new S.EventParser();
                u.addEventListener([ o.ItemOperations, o.Status ], function(e) {
                    c = e.children[0].textContent;
                }), u.addEventListener([ o.ItemOperations, o.Response, o.Fetch ], function(e) {
                    var t = null, n = {};
                    for (var i in Iterator(e.children)) {
                        var r = i[1];
                        switch (r.tag) {
                          case o.Status:
                            n.status = r.children[0].textContent;
                            break;

                          case a.FileReference:
                            t = r.children[0].textContent;
                            break;

                          case o.Properties:
                            var s = null, c = null;
                            for (var u in Iterator(r.children)) {
                                var p = u[1], h = p.children[0].textContent;
                                switch (p.tag) {
                                  case a.ContentType:
                                    s = h;
                                    break;

                                  case o.Data:
                                    c = d.decode(h);
                                }
                            }
                            s && c && (n.data = new Blob([ c ], {
                                type: s
                            }));
                        }
                        t && (l[t] = n);
                    }
                }), u.run(s);
                var p = c !== r.Success ? "unknown" : null, h = [];
                for (var f in Iterator(t)) {
                    var m = f[1];
                    l.hasOwnProperty(m.part) && l[m.part].status === r.Success ? h.push(l[m.part].data) : (p = "unknown", 
                    h.push(null));
                }
                n(p, h);
            });
        })
    }, f.ActiveSyncFolderSyncer = _, _.prototype = {
        get syncable() {
            return null !== this.folderConn.serverId;
        },
        get canGrowSync() {
            return !1;
        },
        initialSync: function(e, n, i, o, r) {
            i("sync", !0), this.folderConn.sync(t.NOW(), this.onSyncCompleted.bind(this, o, !0), r);
        },
        refreshSync: function(e, n, i, o, r, s, a) {
            this.folderConn.sync(t.NOW(), this.onSyncCompleted.bind(this, s, !1), a);
        },
        growSync: function() {
            return !1;
        },
        onSyncCompleted: function(e, t, i, o, r) {
            var s = this.folderStorage;
            console.log("Sync Completed!", r, "messages synced"), i || s.markSyncedToDawnOfTime(), 
            this._account.__checkpointSyncCompleted(function() {
                i ? e(i) : t ? (s._curSyncSlice.ignoreHeaders = !1, s._curSyncSlice.waitingOnData = "db", 
                s.getMessagesInImapDateRange(0, null, n.INITIAL_FILL_SIZE, n.INITIAL_FILL_SIZE, s.onFetchDBHeaders.bind(s, s._curSyncSlice, !1, e, null))) : e(i);
            });
        },
        allConsumersDead: function() {},
        shutdown: function() {
            this.folderConn.shutdown(), this._LOG.__die();
        }
    };
    var I = f.LOGFAB = e.register(p, {
        ActiveSyncFolderConn: {
            type: e.CONNECTION,
            subtype: e.CLIENT,
            events: {
                inferFilterType: {
                    filterType: !1
                }
            },
            asyncJobs: {
                sync: {
                    newMessages: !0,
                    changedMessages: !0,
                    deletedMessages: !0
                }
            },
            errors: {
                htmlParseError: {
                    ex: e.EXCEPTION
                },
                htmlSnippetError: {
                    ex: e.EXCEPTION
                },
                textChewError: {
                    ex: e.EXCEPTION
                },
                textSnippetError: {
                    ex: e.EXCEPTION
                }
            }
        },
        ActiveSyncFolderSyncer: {
            type: e.DATABASE,
            events: {}
        }
    });
}), define("activesync/jobs", [ "rdcommon/log", "mix", "../jobmixins", "../drafts/jobs", "activesync/codepages/AirSync", "activesync/codepages/Email", "activesync/codepages/Move", "module", "require", "exports" ], function(e, t, n, i, o, r, s, a, c, l) {
    function d(e, t, n) {
        return function() {
            var i = Array.slice(arguments), o = i[e], r = this;
            c([ "wbxml" ], function(e) {
                p || (p = e), r.account.withConnection(o, function() {
                    t.apply(r, i);
                }, n);
            });
        };
    }
    function u(e, t, n) {
        this.account = e, this.resilientServerIds = !0, this._heldMutexReleasers = [], this._LOG = h.ActiveSyncJobDriver(this, n, this.account.id), 
        this._state = t, t.hasOwnProperty("suidToServerId") || (t.suidToServerId = {}, t.moveMap = {}), 
        this._stateDelta = {
            serverIdMap: null,
            moveMap: null
        };
    }
    var p;
    l.ActiveSyncJobDriver = u, u.prototype = {
        postJobCleanup: n.postJobCleanup,
        allJobsDone: n.allJobsDone,
        _accessFolderForMutation: function(e, t, n, i, o) {
            var r = this.account.getFolderStorageForFolderId(e), s = this;
            r.runMutexed(o, function(e) {
                s._heldMutexReleasers.push(e);
                var i = r.folderSyncer;
                if (t) s.account.withConnection(n, function() {
                    try {
                        n(i.folderConn, r);
                    } catch (e) {
                        s._LOG.callbackErr(e);
                    }
                }); else try {
                    n(i.folderConn, r);
                } catch (o) {
                    s._LOG.callbackErr(o);
                }
            });
        },
        _partitionAndAccessFoldersSequentially: n._partitionAndAccessFoldersSequentially,
        local_do_modtags: n.local_do_modtags,
        do_modtags: d(1, function(e, t, n) {
            function i(e) {
                return s && -1 !== s.indexOf(e) ? !0 : a && -1 !== a.indexOf(e) ? !1 : void 0;
            }
            var s = n ? e.removeTags : e.addTags, a = n ? e.addTags : e.removeTags, c = i("\\Seen"), l = i("\\Flagged"), d = o.Tags, u = r.Tags, p = null;
            this._partitionAndAccessFoldersSequentially(e.messages, !0, function(e, t, n, i, o) {
                return n = n.filter(function(e) {
                    return !!e;
                }), n.length ? (e.performMutation(function(e) {
                    for (var t = 0; t < n.length; t++) e.stag(d.Change).tag(d.ServerId, n[t]).stag(d.ApplicationData), 
                    void 0 !== c && e.tag(u.Read, c ? "1" : "0"), void 0 !== l && e.stag(u.Flag).tag(u.Status, l ? "2" : "0").etag(), 
                    e.etag(d.ApplicationData).etag(d.Change);
                }, function(e) {
                    e && (p = e), o();
                }), void 0) : (o(), void 0);
            }, function() {
                t(p);
            }, function() {
                p = "aborted-retry";
            }, n, "modtags");
        }),
        check_modtags: function(e, t) {
            t(null, "idempotent");
        },
        local_undo_modtags: n.local_undo_modtags,
        undo_modtags: function(e, t) {
            this.do_modtags(e, t, !0);
        },
        local_do_move: n.local_do_move,
        do_move: d(1, function(e, t) {
            var n = null, i = this.account, o = this.account.getFolderStorageForFolderId(e.targetFolder), r = s.Tags;
            this._partitionAndAccessFoldersSequentially(e.messages, !0, function(e, t, s, a, c) {
                if (s = s.filter(function(e) {
                    return !!e;
                }), !s.length) return c(), void 0;
                if (s = s.filter(function(e) {
                    return !!e;
                }), !s.length) return c(), void 0;
                var l = new p.Writer("1.3", 1, "UTF-8");
                l.stag(r.MoveItems);
                for (var d = 0; d < s.length; d++) l.stag(r.Move).tag(r.SrcMsgId, s[d]).tag(r.SrcFldId, t.folderMeta.serverId).tag(r.DstFldId, o.folderMeta.serverId).etag(r.Move);
                l.etag(r.MoveItems), i.conn.postCommand(l, function(e) {
                    e && (n = e, console.error("failure moving messages:", e)), c();
                });
            }, function() {
                t(n, null, !0);
            }, function() {
                n = "aborted-retry";
            }, !1, "move");
        }),
        check_move: function() {},
        local_undo_move: n.local_undo_move,
        undo_move: function() {},
        local_do_delete: n.local_do_delete,
        do_delete: d(1, function(e, t) {
            var n = null, i = o.Tags;
            r.Tags, this._partitionAndAccessFoldersSequentially(e.messages, !0, function(e, t, o, r, s) {
                return o = o.filter(function(e) {
                    return !!e;
                }), o.length ? (e.performMutation(function(e) {
                    for (var t = 0; t < o.length; t++) e.stag(i.Delete).tag(i.ServerId, o[t]).etag(i.Delete);
                }, function(e) {
                    e && (n = e, console.error("failure deleting messages:", e)), s();
                }), void 0) : (s(), void 0);
            }, function() {
                t(n, null, !0);
            }, function() {
                n = "aborted-retry";
            }, !1, "delete");
        }),
        check_delete: function(e, t) {
            t(null, "idempotent");
        },
        local_undo_delete: n.local_undo_delete,
        undo_delete: function(e, t) {
            t("moot");
        },
        local_do_syncFolderList: function(e, t) {
            t(null);
        },
        do_syncFolderList: d(1, function(e, t) {
            var n, i = this.account, o = i.getFirstFolderWithType("inbox");
            o && null === o.serverId && (n = i.getFolderStorageForFolderId(o.id)), i.syncFolderList(function(e) {
                e || (i.meta.lastFolderSyncAt = Date.now()), t(e ? "aborted-retry" : null, null, !e), 
                n && n.hasActiveSlices && (e || (console.log("Refreshing fake inbox"), n.resetAndRefreshActiveSlices()));
            });
        }, "aborted-retry"),
        check_syncFolderList: function(e, t) {
            t(null, "coherent-notyet");
        },
        local_undo_syncFolderList: function(e, t) {
            t("moot");
        },
        undo_syncFolderList: function(e, t) {
            t("moot");
        },
        local_do_downloadBodies: n.local_do_downloadBodies,
        do_downloadBodies: n.do_downloadBodies,
        check_downloadBodies: n.check_downloadBodies,
        local_do_downloadBodyReps: n.local_do_downloadBodyReps,
        do_downloadBodyReps: n.do_downloadBodyReps,
        check_downloadBodyReps: n.check_downloadBodyReps,
        local_do_download: n.local_do_download,
        do_download: n.do_download,
        check_download: n.check_download,
        local_undo_download: n.local_undo_download,
        undo_download: n.undo_download,
        local_do_sendOutboxMessages: n.local_do_sendOutboxMessages,
        do_sendOutboxMessages: n.do_sendOutboxMessages,
        check_sendOutboxMessages: n.check_sendOutboxMessages,
        local_undo_sendOutboxMessages: n.local_undo_sendOutboxMessages,
        undo_sendOutboxMessages: n.undo_sendOutboxMessages,
        local_do_setOutboxSyncEnabled: n.local_do_setOutboxSyncEnabled,
        local_do_upgradeDB: n.local_do_upgradeDB,
        local_do_purgeExcessMessages: function(e, t) {
            t(null);
        },
        do_purgeExcessMessages: function(e, t) {
            t(null);
        },
        check_purgeExcessMessages: function() {
            return "idempotent";
        },
        local_undo_purgeExcessMessages: function(e, t) {
            t(null);
        },
        undo_purgeExcessMessages: function(e, t) {
            t(null);
        }
    }, t(u.prototype, i.draftsMixins);
    var h = l.LOGFAB = e.register(a, {
        ActiveSyncJobDriver: {
            type: e.DAEMON,
            events: {
                savedAttachment: {
                    storage: !0,
                    mimeType: !0,
                    size: !0
                },
                saveFailure: {
                    storage: !1,
                    mimeType: !1,
                    error: !1
                }
            },
            TEST_ONLY_events: {
                saveFailure: {
                    filename: !1
                }
            },
            errors: {
                callbackErr: {
                    ex: e.EXCEPTION
                }
            }
        }
    });
}), define("activesync/account", [ "rdcommon/log", "../a64", "../accountmixins", "../mailslice", "../searchfilter", "activesync/codepages/FolderHierarchy", "./folder", "./jobs", "../util", "../db/folder_info_rep", "module", "require", "exports" ], function(e, t, n, i, o, r, s, a, c, l, d, u, p) {
    function h(e, t, n) {
        return function() {
            var i = Array.slice(arguments), o = i[e], r = this;
            this.withConnection(o, function() {
                t.apply(r, i);
            }, n);
        };
    }
    function f(e, t, o, r, c, l) {
        this.universe = e, this.id = t.id, this.accountDef = t, t.connInfo.deviceId || (t.connInfo.deviceId = p.makeUniqueDeviceId()), 
        this._db = r, this._LOG = x.ActiveSyncAccount(this, l, this.id), c ? (this.conn = c, 
        this._attachLoggerToConnection(this.conn)) : this.conn = null, this.enabled = !0, 
        this.problems = [], this._alive = !0, this.identities = t.identities, this.folders = [], 
        this._folderStorages = {}, this._folderInfos = o, this._serverIdToFolderId = {}, 
        this._deadFolderIds = null, this._syncsInProgress = 0, this._lastSyncKey = null, 
        this._lastSyncResponseWasEmpty = !1, this.meta = o.$meta, this.mutations = o.$mutations, 
        this.tzOffset = 0;
        for (var d in o) if ("$" !== d[0]) {
            var u = o[d];
            this._folderStorages[d] = new i.FolderStorage(this, d, u, this._db, s.ActiveSyncFolderSyncer, this._LOG), 
            this._serverIdToFolderId[u.$meta.serverId] = d, this.folders.push(u.$meta);
        }
        this.folders.sort(function(e, t) {
            return e.path.localeCompare(t.path);
        }), this._jobDriver = new a.ActiveSyncJobDriver(this, this._folderInfos.$mutationState), 
        this.ensureEssentialOfflineFolders(), n.accountConstructorMixin.call(this, this, this);
    }
    var m, g, v, _ = c.bsearchForInsert, y = r.Enums.Type, b = p.DEFAULT_TIMEOUT_MS = 3e4;
    p.makeUniqueDeviceId = function() {
        return Math.random().toString(36).substr(2);
    }, p.Account = p.ActiveSyncAccount = f, f.prototype = {
        type: "activesync",
        supportsServerFolders: !0,
        toString: function() {
            return "[ActiveSyncAccount: " + this.id + "]";
        },
        withConnection: function(e, t, n) {
            if (!m) return u([ "wbxml", "activesync/protocol", "activesync/codepages" ], function(i, o, r) {
                m = i, g = o, v = r, this.withConnection(e, t, n);
            }.bind(this)), void 0;
            if (!this.conn) {
                var i = this.accountDef;
                this.conn = new g.Connection(i.connInfo.deviceId), this._attachLoggerToConnection(this.conn), 
                this.conn.open(i.connInfo.server, i.credentials.username, i.credentials.password), 
                this.conn.timeout = b;
            }
            this.conn.connected ? t() : this.conn.connect(function(i) {
                return i ? (this._reportErrorIfNecessary(i), this._isBadUserOrPassError(i) && !n && (n = "bad-user-or-pass"), 
                e(n || "unknown"), void 0) : (t(), void 0);
            }.bind(this));
        },
        _isBadUserOrPassError: function(e) {
            return e && e instanceof g.HttpError && 401 === e.status;
        },
        _reportErrorIfNecessary: function(e) {
            e && this._isBadUserOrPassError(e) && this.universe.__reportAccountProblem(this, "bad-user-or-pass", "incoming");
        },
        _attachLoggerToConnection: function(e) {
            var t = x.ActiveSyncConnection(e, this._LOG, Date.now() % 1e3);
            "safe" === t.logLevel ? e.onmessage = this._onmessage_safe.bind(this, t) : "dangerous" === t.logLevel && (e.onmessage = this._onmessage_dangerous.bind(this, t));
        },
        _onmessage_safe: function(e, t, n, i, o, r, s, a) {
            "options" === t ? e.options(n, i.status, a) : e.command(t, n, i.status);
        },
        _onmessage_dangerous: function(e, t, n, i, o, r, s, a) {
            if ("options" === t) e.options(n, i.status, a); else {
                var c, l;
                if (s) try {
                    var d = new m.Reader(new Uint8Array(s), v);
                    c = d.dump();
                } catch (u) {
                    c = "parse problem";
                }
                if (a) try {
                    l = a.dump(), a.rewind();
                } catch (u) {
                    l = "parse problem";
                }
                e.command(t, n, i.status, o, r, c, l);
            }
        },
        toBridgeWire: function() {
            return {
                id: this.accountDef.id,
                name: this.accountDef.name,
                path: this.accountDef.name,
                type: this.accountDef.type,
                defaultPriority: this.accountDef.defaultPriority,
                enabled: this.enabled,
                problems: this.problems,
                syncRange: this.accountDef.syncRange,
                syncInterval: this.accountDef.syncInterval,
                notifyOnNew: this.accountDef.notifyOnNew,
                playSoundOnSend: this.accountDef.playSoundOnSend,
                identities: this.identities,
                credentials: {
                    username: this.accountDef.credentials.username
                },
                servers: [ {
                    type: this.accountDef.type,
                    connInfo: this.accountDef.connInfo
                } ]
            };
        },
        toBridgeFolder: function() {
            return {
                id: this.accountDef.id,
                name: this.accountDef.name,
                path: this.accountDef.name,
                type: "account"
            };
        },
        get numActiveConns() {
            return 0;
        },
        checkAccount: function(e) {
            null != this.conn && (this.conn.connected && this.conn.disconnect(), this.conn = null), 
            this.withConnection(function(t) {
                e(t);
            }, function() {
                e();
            });
        },
        __checkpointSyncCompleted: function(e, t) {
            this.saveAccountState(null, e, t || "checkpointSync");
        },
        shutdown: function(e) {
            this._LOG.__die(), e && e();
        },
        accountDeleted: function() {
            this._alive = !1, this.shutdown();
        },
        sliceFolderMessages: function(e, t) {
            var n = this._folderStorages[e], o = new i.MailSlice(t, n, this._LOG);
            n.sliceOpenMostRecent(o);
        },
        searchFolderMessages: function(e, t, n, i) {
            var r = this._folderStorages[e], s = new o.SearchSlice(t, r, n, i, this._LOG);
            return r.sliceOpenSearch(s), s;
        },
        syncFolderList: h(0, function(e) {
            var t = this, n = v.FolderHierarchy.Tags, i = new m.Writer("1.3", 1, "UTF-8");
            i.stag(n.FolderSync).tag(n.SyncKey, this.meta.syncKey).etag(), this.conn.postCommand(i, function(i, o) {
                if (i) return t._reportErrorIfNecessary(i), e(i), void 0;
                var r = new m.EventParser(), s = [];
                r.addEventListener([ n.FolderSync, n.SyncKey ], function(e) {
                    t.meta.syncKey = e.children[0].textContent;
                }), r.addEventListener([ n.FolderSync, n.Changes, [ n.Add, n.Delete ] ], function(e) {
                    var i = {};
                    for (var o in Iterator(e.children)) {
                        var r = o[1];
                        i[r.localTagName] = r.children[0].textContent;
                    }
                    e.tag === n.Add ? t._addedFolder(i.ServerId, i.ParentId, i.DisplayName, i.Type) || s.push(i) : t._deletedFolder(i.ServerId);
                });
                try {
                    r.run(o);
                } catch (a) {
                    return console.error("Error parsing FolderSync response:", a, "\n", a.stack), e("unknown"), 
                    void 0;
                }
                for (;s.length; ) {
                    var c = [];
                    for (var l in Iterator(s)) {
                        var d = l[1];
                        t._addedFolder(d.ServerId, d.ParentId, d.DisplayName, d.Type) || c.push(d);
                    }
                    if (c.length === s.length) throw new Error("got some orphaned folders");
                    s = c;
                }
                t.ensureEssentialOnlineFolders(), t.normalizeFolderHierarchy(), console.log("Synced folder list"), 
                e && e(null);
            });
        }),
        _folderTypes: {
            1: "normal",
            2: "inbox",
            3: "drafts",
            4: "trash",
            5: "sent",
            6: "normal",
            12: "normal"
        },
        _addedFolder: function(e, n, o, r, a, c) {
            if (!(a || r in this._folderTypes)) return !0;
            var d = o, u = null, p = 0;
            if ("0" !== n) {
                if (u = this._serverIdToFolderId[n], void 0 === u) return null;
                var h = this._folderInfos[u];
                d = h.$meta.path + "/" + d, p = h.$meta.depth + 1;
            }
            if (r === y.DefaultInbox) {
                var f = this.getFirstFolderWithType("inbox");
                if (f) return delete this._serverIdToFolderId[f.serverId], this._serverIdToFolderId[e] = f.id, 
                f.serverId = e, f.name = o, f.path = d, f.depth = p, f;
            }
            var m = this.id + "/" + t.encodeInt(this.meta.nextFolderNum++), g = this._folderInfos[m] = {
                $meta: l.makeFolderMeta({
                    id: m,
                    serverId: e,
                    name: o,
                    type: a || this._folderTypes[r],
                    path: d,
                    parentId: u,
                    depth: p,
                    lastSyncedAt: 0,
                    syncKey: "0",
                    version: i.FOLDER_DB_VERSION
                }),
                $impl: {
                    nextId: 0,
                    nextHeaderBlock: 0,
                    nextBodyBlock: 0
                },
                accuracy: [],
                headerBlocks: [],
                bodyBlocks: [],
                serverIdHeaderBlockMapping: {}
            };
            console.log("Added folder " + o + " (" + m + ")"), this._folderStorages[m] = new i.FolderStorage(this, m, g, this._db, s.ActiveSyncFolderSyncer, this._LOG), 
            this._serverIdToFolderId[e] = m;
            var v = g.$meta, b = _(this.folders, v, function(e, t) {
                return e.path.localeCompare(t.path);
            });
            return this.folders.splice(b, 0, v), c || this.universe.__notifyAddedFolder(this, v), 
            v;
        },
        _deletedFolder: function(e, t) {
            var n = this._serverIdToFolderId[e], i = this._folderInfos[n], o = i.$meta;
            console.log("Deleted folder " + o.name + " (" + n + ")"), delete this._serverIdToFolderId[e], 
            delete this._folderInfos[n], delete this._folderStorages[n];
            var r = this.folders.indexOf(o);
            this.folders.splice(r, 1), null === this._deadFolderIds && (this._deadFolderIds = []), 
            this._deadFolderIds.push(n), t || this.universe.__notifyRemovedFolder(this, o);
        },
        _recreateFolder: function(e, t) {
            this._LOG.recreateFolder(e);
            var n = this._folderInfos[e];
            n.$impl = {
                nextId: 0,
                nextHeaderBlock: 0,
                nextBodyBlock: 0
            }, n.accuracy = [], n.headerBlocks = [], n.bodyBlocks = [], n.serverIdHeaderBlockMapping = {}, 
            null === this._deadFolderIds && (this._deadFolderIds = []), this._deadFolderIds.push(e);
            var o = this;
            this.saveAccountState(null, function() {
                var r = new i.FolderStorage(o, e, n, o._db, s.ActiveSyncFolderSyncer, o._LOG);
                for (var a in Iterator(o._folderStorages[e]._slices)) {
                    var c = a[1];
                    c._storage = r, c.reset(), r.sliceOpenMostRecent(c);
                }
                o._folderStorages[e]._slices = [], o._folderStorages[e] = r, t(r);
            }, "recreateFolder");
        },
        createFolder: h(3, function(e, t, n, i) {
            var o = this, r = e ? this._folderInfos[e] : "0", s = v.FolderHierarchy.Tags, a = v.FolderHierarchy.Enums.Status, c = v.FolderHierarchy.Enums.Type.Mail, l = new m.Writer("1.3", 1, "UTF-8");
            l.stag(s.FolderCreate).tag(s.SyncKey, this.meta.syncKey).tag(s.ParentId, r).tag(s.DisplayName, t).tag(s.Type, c).etag(), 
            this.conn.postCommand(l, function(e, n) {
                o._reportErrorIfNecessary(e);
                var l, d, u = new m.EventParser();
                u.addEventListener([ s.FolderCreate, s.Status ], function(e) {
                    l = e.children[0].textContent;
                }), u.addEventListener([ s.FolderCreate, s.SyncKey ], function(e) {
                    o.meta.syncKey = e.children[0].textContent;
                }), u.addEventListener([ s.FolderCreate, s.ServerId ], function(e) {
                    d = e.children[0].textContent;
                });
                try {
                    u.run(n);
                } catch (p) {
                    return console.error("Error parsing FolderCreate response:", p, "\n", p.stack), 
                    i("unknown"), void 0;
                }
                if (l === a.Success) {
                    var h = o._addedFolder(d, r, t, c);
                    i(null, h);
                } else l === a.FolderExists ? i("already-exists") : i("unknown");
            });
        }),
        deleteFolder: h(1, function(e, t) {
            var n = this, i = this._folderInfos[e].$meta, o = v.FolderHierarchy.Tags, r = v.FolderHierarchy.Enums.Status;
            v.FolderHierarchy.Enums.Type.Mail;
            var s = new m.Writer("1.3", 1, "UTF-8");
            s.stag(o.FolderDelete).tag(o.SyncKey, this.meta.syncKey).tag(o.ServerId, i.serverId).etag(), 
            this.conn.postCommand(s, function(e, s) {
                n._reportErrorIfNecessary(e);
                var a, c = new m.EventParser();
                c.addEventListener([ o.FolderDelete, o.Status ], function(e) {
                    a = e.children[0].textContent;
                }), c.addEventListener([ o.FolderDelete, o.SyncKey ], function(e) {
                    n.meta.syncKey = e.children[0].textContent;
                });
                try {
                    c.run(s);
                } catch (l) {
                    return console.error("Error parsing FolderDelete response:", l, "\n", l.stack), 
                    t("unknown"), void 0;
                }
                a === r.Success ? (n._deletedFolder(i.serverId), t(null, i)) : t("unknown");
            });
        }),
        sendMessage: h(1, function(e, t) {
            var n = this;
            e.withMessageBlob({
                includeBcc: !0
            }, function(i) {
                if (this.conn.currentVersion.gte("14.0")) {
                    var o = v.ComposeMail.Tags, r = new m.Writer("1.3", 1, "UTF-8", null, "blob");
                    r.stag(o.SendMail).tag(o.ClientId, Date.now().toString() + "@mozgaia").tag(o.SaveInSentItems).stag(o.Mime).opaque(i).etag().etag(), 
                    this.conn.postCommand(r, function(e, i) {
                        return e ? (n._reportErrorIfNecessary(e), console.error(e), t("unknown"), void 0) : (null === i ? (console.log("Sent message successfully!"), 
                        t(null)) : (console.error("Error sending message. XML dump follows:\n" + i.dump()), 
                        t("unknown")), void 0);
                    }, null, null, function() {
                        e.renewSmartWakeLock("ActiveSync XHR Progress");
                    });
                } else this.conn.postData("SendMail", "message/rfc822", i, function(e) {
                    return e ? (n._reportErrorIfNecessary(e), console.error(e), t("unknown"), void 0) : (console.log("Sent message successfully!"), 
                    t(null), void 0);
                }, {
                    SaveInSent: "T"
                }, null, function() {
                    e.renewSmartWakeLock("ActiveSync XHR Progress");
                });
            }.bind(this));
        }),
        getFolderStorageForFolderId: function(e) {
            return this._folderStorages[e];
        },
        getFolderStorageForServerId: function(e) {
            return this._folderStorages[this._serverIdToFolderId[e]];
        },
        getFolderMetaForFolderId: function(e) {
            return this._folderInfos.hasOwnProperty(e) ? this._folderInfos[e].$meta : null;
        },
        ensureEssentialOfflineFolders: function() {
            [ {
                type: "inbox",
                displayName: "Inbox",
                typeNum: y.DefaultInbox
            }, {
                type: "outbox",
                displayName: "outbox",
                typeNum: y.Unknown
            }, {
                type: "localdrafts",
                displayName: "localdrafts",
                typeNum: y.Unknown
            } ].forEach(function(e) {
                this.getFirstFolderWithType(e.type) || this._addedFolder(null, "0", e.displayName, e.typeNum, e.type, !0);
            }, this);
        },
        ensureEssentialOnlineFolders: function(e) {
            e && e();
        },
        normalizeFolderHierarchy: n.normalizeFolderHierarchy,
        scheduleMessagePurge: function(e, t) {
            t && t();
        },
        upgradeFolderStoragesIfNeeded: n.upgradeFolderStoragesIfNeeded,
        runOp: n.runOp,
        getFirstFolderWithType: n.getFirstFolderWithType,
        getFolderByPath: n.getFolderByPath,
        saveAccountState: n.saveAccountState,
        runAfterSaves: n.runAfterSaves,
        allOperationsCompleted: function() {}
    };
    var x = p.LOGFAB = e.register(d, {
        ActiveSyncAccount: {
            type: e.ACCOUNT,
            events: {
                createFolder: {},
                deleteFolder: {},
                recreateFolder: {
                    id: !1
                },
                accountDeleted: {
                    where: !1
                }
            },
            asyncJobs: {
                runOp: {
                    mode: !0,
                    type: !0,
                    error: !0,
                    op: !1
                },
                saveAccountState: {
                    reason: !0,
                    folderSaveCount: !0
                }
            },
            errors: {
                opError: {
                    mode: !1,
                    type: !1,
                    ex: e.EXCEPTION
                }
            }
        },
        ActiveSyncConnection: {
            type: e.CONNECTION,
            events: {
                options: {
                    special: !1,
                    status: !1,
                    result: !1
                },
                command: {
                    name: !1,
                    special: !1,
                    status: !1
                }
            },
            TEST_ONLY_events: {
                options: {},
                command: {
                    params: !1,
                    extraHeaders: !1,
                    sent: !1,
                    response: !1
                }
            }
        }
    });
}), define("activesync/configurator", [ "rdcommon/log", "slog", "../accountcommon", "../a64", "./account", "../date", "tcp-socket", "require", "exports" ], function(e, t, n, i, o, r, s, a, c) {
    function l(e, t) {
        function n(e) {
            if (a) {
                var n = a;
                a = null;
                try {
                    n.close();
                } catch (i) {}
                t(e);
            }
        }
        var i = /^https:\/\/([^:\/]+)(?::(\d+))?/.exec(e);
        if (!i) return t(null), void 0;
        var o = i[2] ? parseInt(i[2], 10) : 443, r = i[1];
        console.log("checking", r, o, "for security problem");
        var a = s.open(r, o);
        a.onopen = function() {
            a.send(new TextEncoder("utf-8").encode("GET /images/logo.png HTTP/1.1\n\n"));
        }, a.onerror = function(e) {
            var t = null;
            e && "object" == typeof e && /^Security/.test(e.name) && (t = "bad-security"), n(t);
        }, a.ondata = function() {
            n(null);
        };
    }
    c.account = o, c.configurator = {
        timeout: 3e4,
        _getFullDetailsFromAutodiscover: function(e, n, i, o) {
            t.log("activesync.configurator.autodiscover:begin", {
                url: i
            }), e.raw_autodiscover(i, n.emailAddress, n.password, self.timeout, !1, function(n, r) {
                if (n) {
                    var s = "no-config-info", a = {};
                    return n instanceof e.HttpError ? 401 === n.status ? s = "bad-user-or-pass" : 403 === n.status ? s = "not-authorized" : a.status = n.status : n instanceof e.AutodiscoverDomainError && t.log("activesync.configurator.autodiscover.error", {
                        message: n.message
                    }), t.log("activesync.configurator.autodiscover:end", {
                        url: i,
                        err: s
                    }), o(s, null, a), void 0;
                }
                t.log("activesync.configurator.autodiscover:end", {
                    url: i,
                    server: r.mobileSyncServer.url
                });
                var c = {
                    type: "activesync",
                    displayName: r.user.name,
                    incoming: {
                        server: r.mobileSyncServer.url,
                        username: r.user.email
                    }
                };
                o(null, c, null);
            });
        },
        tryToCreateAccount: function(e, t, n, i, o) {
            a([ "activesync/protocol" ], function(r) {
                return n.incoming.autodiscoverEndpoint ? (this._getFullDetailsFromAutodiscover(r, t, n.incoming.autodiscoverEndpoint, function(n, s, a) {
                    return n ? (i(n, s, a), void 0) : (this._createAccountUsingFullInfo(e, t, s, i, r, o), 
                    void 0);
                }.bind(this)), void 0) : (this._createAccountUsingFullInfo(e, t, n, i, r, o), void 0);
            }.bind(this));
        },
        _createAccountUsingFullInfo: function(e, n, s, a, c) {
            t.log("activesync.configurator.create:begin", {
                server: s.incoming.server
            });
            var d = {
                username: s.incoming.username,
                password: n.password
            }, u = o.makeUniqueDeviceId(), p = this, h = new c.Connection(u);
            h.open(s.incoming.server, d.username, d.password), h.timeout = o.DEFAULT_TIMEOUT_MS, 
            h.connect(function(o) {
                if (o) {
                    var f, m = {
                        server: s.incoming.server
                    };
                    return o instanceof c.HttpError ? (401 === o.status ? f = "bad-user-or-pass" : 403 === o.status ? f = "not-authorized" : (f = "server-problem", 
                    m.status = o.status), t.log("activesync.configurator.create:end", {
                        server: s.incoming.server,
                        err: f
                    }), a(f, null, m), void 0) : (l(s.incoming.server, function(e) {
                        var t;
                        t = e ? "bad-security" : "unresponsive-server", a(t, null, m);
                    }), void 0);
                }
                var g = i.encodeInt(e.config.nextAccountNum++), v = {
                    id: g,
                    name: n.accountName || n.emailAddress,
                    defaultPriority: r.NOW(),
                    type: "activesync",
                    syncRange: "auto",
                    syncInterval: n.syncInterval || 0,
                    notifyOnNew: n.hasOwnProperty("notifyOnNew") ? n.notifyOnNew : !0,
                    playSoundOnSend: n.hasOwnProperty("playSoundOnSend") ? n.playSoundOnSend : !0,
                    credentials: d,
                    connInfo: {
                        server: s.incoming.server,
                        deviceId: u
                    },
                    identities: [ {
                        id: g + "/" + i.encodeInt(e.config.nextIdentityNum++),
                        name: n.displayName || s.displayName,
                        address: n.emailAddress,
                        replyTo: null,
                        signature: null
                    } ]
                };
                t.log("activesync.configurator.create:end", {
                    server: s.incoming.server,
                    id: g
                }), p._loadAccount(e, v, h, function(e) {
                    a(null, e, null);
                });
            });
        },
        recreateAccount: function(e, t, r, s) {
            var a = r.def, c = {
                username: a.credentials.username,
                password: a.credentials.password
            }, l = i.encodeInt(e.config.nextAccountNum++), d = {
                id: l,
                name: a.name,
                type: "activesync",
                syncRange: a.syncRange,
                syncInterval: a.syncInterval || 0,
                notifyOnNew: a.hasOwnProperty("notifyOnNew") ? a.notifyOnNew : !0,
                playSoundOnSend: a.hasOwnProperty("playSoundOnSend") ? a.playSoundOnSend : !0,
                credentials: c,
                connInfo: {
                    server: a.connInfo.server,
                    deviceId: a.connInfo.deviceId || o.makeUniqueDeviceId()
                },
                identities: n.recreateIdentities(e, l, a.identities)
            };
            this._loadAccount(e, d, null, function(e) {
                s(null, e, null);
            });
        },
        _loadAccount: function(e, t, n, i) {
            var o = {
                $meta: {
                    nextFolderNum: 0,
                    nextMutationNum: 0,
                    lastFolderSyncAt: 0,
                    syncKey: "0"
                },
                $mutations: [],
                $mutationState: {}
            };
            e.saveAccountDef(t, o), e._loadAccount(t, o, n, i);
        }
    };
});