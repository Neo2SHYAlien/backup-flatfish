define([ "slog", "./client", "exports" ], function(e, t, n) {
    function i(t, n) {
        return e.log("probe:smtp:checking-address-validity"), new Promise(function(e, i) {
            t.useEnvelope({
                from: n,
                to: [ n ]
            }), t.onready = function() {
                e();
            }, t.onerror = function(e) {
                i(e);
            };
        });
    }
    n.probeAccount = function(n, o) {
        e.info("probe:smtp:connecting", {
            _credentials: n,
            connInfo: o
        });
        var r;
        return t.createSmtpConnection(n, o, function() {
            e.warn("probe:smtp:credentials-updated");
        }).then(function(e) {
            return r = e, i(r, o.emailAddress);
        }).then(function() {
            return e.info("probe:smtp:success"), r.close(), r;
        }).catch(function(n) {
            var i = t.analyzeSmtpError(r, n, !1);
            throw r && r.close(), e.error("probe:smtp:error", {
                error: i,
                connInfo: o
            }), i;
        });
    };
});