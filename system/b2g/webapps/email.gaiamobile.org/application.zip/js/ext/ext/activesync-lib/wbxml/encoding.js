(function(e) {
    function t(e, t, n) {
        return e >= t && n >= e;
    }
    function n(e, t) {
        return Math.floor(e / t);
    }
    function i(e) {
        var t = 0;
        this.get = function() {
            return t >= e.length ? U : Number(e[t]);
        }, this.offset = function(n) {
            if (t += n, 0 > t) throw new Error("Seeking past start of the buffer");
            if (t > e.length) throw new Error("Seeking past EOF");
        }, this.match = function(n) {
            if (n.length > t + e.length) return !1;
            var i;
            for (i = 0; i < n.length; i += 1) if (Number(e[t + i]) !== n[i]) return !1;
            return !0;
        };
    }
    function s(e) {
        var t = 0;
        this.emit = function() {
            var n, i = U;
            for (n = 0; n < arguments.length; ++n) i = Number(arguments[n]), e[t++] = i;
            return i;
        };
    }
    function r(e) {
        var n = 0, i = function() {
            for (var n = [], i = 0, s = e.length; i < e.length; ) {
                var r = e.charCodeAt(i);
                if (t(r, 55296, 57343)) if (t(r, 56320, 57343)) n.push(65533); else if (i === s - 1) n.push(65533); else {
                    var o = e.charCodeAt(i + 1);
                    if (t(o, 56320, 57343)) {
                        var a = 1023 & r, u = 1023 & o;
                        i += 1, n.push(65536 + (a << 10) + u);
                    } else n.push(65533);
                } else n.push(r);
                i += 1;
            }
            return n;
        }();
        this.offset = function(e) {
            if (n += e, 0 > n) throw new Error("Seeking past start of the buffer");
            if (n > i.length) throw new Error("Seeking past EOF");
        }, this.get = function() {
            return n >= i.length ? j : i[n];
        };
    }
    function o() {
        var e = "";
        this.string = function() {
            return e;
        }, this.emit = function(t) {
            65535 >= t ? e += String.fromCharCode(t) : (t -= 65536, e += String.fromCharCode(55296 + (1023 & t >> 10)), 
            e += String.fromCharCode(56320 + (1023 & t)));
        };
    }
    function a(e, t) {
        if (e) throw new Error("EncodingError");
        return t || 65533;
    }
    function u() {
        throw new Error("EncodingError");
    }
    function c(e) {
        if (e = String(e).trim().toLowerCase(), Object.prototype.hasOwnProperty.call(z, e)) return z[e];
        throw new Error("EncodingError: Unknown encoding: " + e);
    }
    function l(e, t) {
        return (t || [])[e] || null;
    }
    function d(e, t) {
        var n = t.indexOf(e);
        return -1 === n ? null : n;
    }
    function h(e) {
        if (e > 39419 && 189e3 > e || e > 1237575) return null;
        var t, n = 0, i = 0, s = V.gb18030;
        for (t = 0; t < s.length; ++t) {
            var r = s[t];
            if (!(r[0] <= e)) break;
            n = r[0], i = r[1];
        }
        return i + e - n;
    }
    function f(e) {
        var t, n = 0, i = 0, s = V.gb18030;
        for (t = 0; t < s.length; ++t) {
            var r = s[t];
            if (!(r[1] <= e)) break;
            n = r[1], i = r[0];
        }
        return i + e - n;
    }
    function p(e) {
        var n = e.fatal, i = 0, s = 0, r = 0, o = 0;
        this.decode = function(e) {
            var u = e.get();
            if (u === U) return 0 !== s ? (s = 0, a(n)) : j;
            if (e.offset(1), 0 === s) {
                if (t(u, 0, 127)) return u;
                if (t(u, 194, 223)) s = 1, o = 128, i = u - 192; else if (t(u, 224, 239)) s = 2, 
                o = 2048, i = u - 224; else {
                    if (!t(u, 240, 244)) return a(n);
                    s = 3, o = 65536, i = u - 240;
                }
                return i *= Math.pow(64, s), null;
            }
            if (!t(u, 128, 191)) return i = 0, s = 0, r = 0, o = 0, e.offset(-1), a(n);
            if (r += 1, i += (u - 128) * Math.pow(64, s - r), r !== s) return null;
            var c = i, l = o;
            return i = 0, s = 0, r = 0, o = 0, t(c, l, 1114111) && !t(c, 55296, 57343) ? c : a(n);
        };
    }
    function g(e) {
        e.fatal, this.encode = function(e, i) {
            var s = i.get();
            if (s === j) return U;
            if (i.offset(1), t(s, 55296, 57343)) return u(s);
            if (t(s, 0, 127)) return e.emit(s);
            var r, o;
            t(s, 128, 2047) ? (r = 1, o = 192) : t(s, 2048, 65535) ? (r = 2, o = 224) : t(s, 65536, 1114111) && (r = 3, 
            o = 240);
            for (var a = e.emit(n(s, Math.pow(64, r)) + o); r > 0; ) {
                var c = n(s, Math.pow(64, r - 1));
                a = e.emit(128 + c % 64), r -= 1;
            }
            return a;
        };
    }
    function _(e, n) {
        var i = n.fatal;
        this.decode = function(n) {
            var s = n.get();
            if (s === U) return j;
            if (n.offset(1), t(s, 0, 127)) return s;
            var r = e[s - 128];
            return null === r ? a(i) : r;
        };
    }
    function m(e, n) {
        n.fatal, this.encode = function(n, i) {
            var s = i.get();
            if (s === j) return U;
            if (i.offset(1), t(s, 0, 127)) return n.emit(s);
            var r = d(s, e);
            return null === r && u(s), n.emit(r + 128);
        };
    }
    function b(e, n) {
        var i = n.fatal, s = 0, r = 0, o = 0;
        this.decode = function(n) {
            var u = n.get();
            if (u === U && 0 === s && 0 === r && 0 === o) return j;
            u !== U || 0 === s && 0 === r && 0 === o || (s = 0, r = 0, o = 0, a(i)), n.offset(1);
            var c;
            if (0 !== o) return c = null, t(u, 48, 57) && (c = h(10 * (126 * (10 * (s - 129) + (r - 48)) + (o - 129)) + u - 48)), 
            s = 0, r = 0, o = 0, null === c ? (n.offset(-3), a(i)) : c;
            if (0 !== r) return t(u, 129, 254) ? (o = u, null) : (n.offset(-2), s = 0, r = 0, 
            a(i));
            if (0 !== s) {
                if (t(u, 48, 57) && e) return r = u, null;
                var d = s, f = null;
                s = 0;
                var p = 127 > u ? 64 : 65;
                return (t(u, 64, 126) || t(u, 128, 254)) && (f = 190 * (d - 129) + (u - p)), c = null === f ? null : l(f, V.gbk), 
                null === f && n.offset(-1), null === c ? a(i) : c;
            }
            return t(u, 0, 127) ? u : 128 === u ? 8364 : t(u, 129, 254) ? (s = u, null) : a(i);
        };
    }
    function v(e, i) {
        i.fatal, this.encode = function(i, s) {
            var r = s.get();
            if (r === j) return U;
            if (s.offset(1), t(r, 0, 127)) return i.emit(r);
            var o = d(r, V.gbk);
            if (null !== o) {
                var a = n(o, 190) + 129, c = o % 190, l = 63 > c ? 64 : 65;
                return i.emit(a, c + l);
            }
            if (null === o && !e) return u(r);
            o = f(r);
            var h = n(n(n(o, 10), 126), 10);
            o -= 10 * 126 * 10 * h;
            var p = n(n(o, 10), 126);
            o -= 126 * 10 * p;
            var g = n(o, 10), _ = o - 10 * g;
            return i.emit(h + 129, p + 48, g + 129, _ + 48);
        };
    }
    function y(e) {
        var n = e.fatal, i = !1, s = 0;
        this.decode = function(e) {
            var r = e.get();
            if (r === U && 0 === s) return j;
            if (r === U && 0 !== s) return s = 0, a(n);
            if (e.offset(1), 126 === s) return s = 0, 123 === r ? (i = !0, null) : 125 === r ? (i = !1, 
            null) : 126 === r ? 126 : 10 === r ? null : (e.offset(-1), a(n));
            if (0 !== s) {
                var o = s;
                s = 0;
                var u = null;
                return t(r, 33, 126) && (u = l(190 * (o - 1) + (r + 63), V.gbk)), 10 === r && (i = !1), 
                null === u ? a(n) : u;
            }
            return 126 === r ? (s = 126, null) : i ? t(r, 32, 127) ? (s = r, null) : (10 === r && (i = !1), 
            a(n)) : t(r, 0, 127) ? r : a(n);
        };
    }
    function w(e) {
        e.fatal;
        var i = !1;
        this.encode = function(e, s) {
            var r = s.get();
            if (r === j) return U;
            if (s.offset(1), t(r, 0, 127) && i) return s.offset(-1), i = !1, e.emit(126, 125);
            if (126 === r) return e.emit(126, 126);
            if (t(r, 0, 127)) return e.emit(r);
            if (!i) return s.offset(-1), i = !0, e.emit(126, 123);
            var o = d(r, V.gbk);
            if (null === o) return u(r);
            var a = n(o, 190) + 1, c = o % 190 - 63;
            return t(a, 33, 126) && t(c, 33, 126) ? e.emit(a, c) : u(r);
        };
    }
    function S(e) {
        var n = e.fatal, i = 0, s = null;
        this.decode = function(e) {
            if (null !== s) {
                var r = s;
                return s = null, r;
            }
            var o = e.get();
            if (o === U && 0 === i) return j;
            if (o === U && 0 !== i) return i = 0, a(n);
            if (e.offset(1), 0 !== i) {
                var u = i, c = null;
                i = 0;
                var d = 127 > o ? 64 : 98;
                if ((t(o, 64, 126) || t(o, 161, 254)) && (c = 157 * (u - 129) + (o - d)), 1133 === c) return s = 772, 
                202;
                if (1135 === c) return s = 780, 202;
                if (1164 === c) return s = 772, 234;
                if (1166 === c) return s = 780, 234;
                var h = null === c ? null : l(c, V.big5);
                return null === c && e.offset(-1), null === h ? a(n) : h;
            }
            return t(o, 0, 127) ? o : t(o, 129, 254) ? (i = o, null) : a(n);
        };
    }
    function A(e) {
        e.fatal, this.encode = function(e, i) {
            var s = i.get();
            if (s === j) return U;
            if (i.offset(1), t(s, 0, 127)) return e.emit(s);
            var r = d(s, V.big5);
            if (null === r) return u(s);
            var o = n(r, 157) + 129, a = r % 157, c = 63 > a ? 64 : 98;
            return e.emit(o, a + c);
        };
    }
    function E(e) {
        var n = e.fatal, i = 0, s = 0;
        this.decode = function(e) {
            var r = e.get();
            if (r === U) return 0 === i && 0 === s ? j : (i = 0, s = 0, a(n));
            e.offset(1);
            var o, u;
            return 0 !== s ? (o = s, s = 0, u = null, t(o, 161, 254) && t(r, 161, 254) && (u = l(94 * (o - 161) + r - 161, V.jis0212)), 
            t(r, 161, 254) || e.offset(-1), null === u ? a(n) : u) : 142 === i && t(r, 161, 223) ? (i = 0, 
            65377 + r - 161) : 143 === i && t(r, 161, 254) ? (i = 0, s = r, null) : 0 !== i ? (o = i, 
            i = 0, u = null, t(o, 161, 254) && t(r, 161, 254) && (u = l(94 * (o - 161) + r - 161, V.jis0208)), 
            t(r, 161, 254) || e.offset(-1), null === u ? a(n) : u) : t(r, 0, 127) ? r : 142 === r || 143 === r || t(r, 161, 254) ? (i = r, 
            null) : a(n);
        };
    }
    function I(e) {
        e.fatal, this.encode = function(e, i) {
            var s = i.get();
            if (s === j) return U;
            if (i.offset(1), t(s, 0, 127)) return e.emit(s);
            if (165 === s) return e.emit(92);
            if (8254 === s) return e.emit(126);
            if (t(s, 65377, 65439)) return e.emit(142, s - 65377 + 161);
            var r = d(s, V.jis0208);
            if (null === r) return u(s);
            var o = n(r, 94) + 161, a = r % 94 + 161;
            return e.emit(o, a);
        };
    }
    function T(e) {
        var n = e.fatal, i = {
            ASCII: 0,
            escape_start: 1,
            escape_middle: 2,
            escape_final: 3,
            lead: 4,
            trail: 5,
            Katakana: 6
        }, s = i.ASCII, r = !1, o = 0;
        this.decode = function(e) {
            var u = e.get();
            switch (u !== U && e.offset(1), s) {
              default:
              case i.ASCII:
                return 27 === u ? (s = i.escape_start, null) : t(u, 0, 127) ? u : u === U ? j : a(n);

              case i.escape_start:
                return 36 === u || 40 === u ? (o = u, s = i.escape_middle, null) : (u !== U && e.offset(-1), 
                s = i.ASCII, a(n));

              case i.escape_middle:
                var c = o;
                return o = 0, 36 !== c || 64 !== u && 66 !== u ? 36 === c && 40 === u ? (s = i.escape_final, 
                null) : 40 !== c || 66 !== u && 74 !== u ? 40 === c && 73 === u ? (s = i.Katakana, 
                null) : (u === U ? e.offset(-1) : e.offset(-2), s = i.ASCII, a(n)) : (s = i.ASCII, 
                null) : (r = !1, s = i.lead, null);

              case i.escape_final:
                return 68 === u ? (r = !0, s = i.lead, null) : (u === U ? e.offset(-2) : e.offset(-3), 
                s = i.ASCII, a(n));

              case i.lead:
                return 10 === u ? (s = i.ASCII, a(n, 10)) : 27 === u ? (s = i.escape_start, null) : u === U ? j : (o = u, 
                s = i.trail, null);

              case i.trail:
                if (s = i.lead, u === U) return a(n);
                var d = null, h = 94 * (o - 33) + u - 33;
                return t(o, 33, 126) && t(u, 33, 126) && (d = r === !1 ? l(h, V.jis0208) : l(h, V.jis0212)), 
                null === d ? a(n) : d;

              case i.Katakana:
                return 27 === u ? (s = i.escape_start, null) : t(u, 33, 95) ? 65377 + u - 33 : u === U ? j : a(n);
            }
        };
    }
    function x(e) {
        e.fatal;
        var i = {
            ASCII: 0,
            lead: 1,
            Katakana: 2
        }, s = i.ASCII;
        this.encode = function(e, r) {
            var o = r.get();
            if (o === j) return U;
            if (r.offset(1), (t(o, 0, 127) || 165 === o || 8254 === o) && s !== i.ASCII) return r.offset(-1), 
            s = i.ASCII, e.emit(27, 40, 66);
            if (t(o, 0, 127)) return e.emit(o);
            if (165 === o) return e.emit(92);
            if (8254 === o) return e.emit(126);
            if (t(o, 65377, 65439) && s !== i.Katakana) return r.offset(-1), s = i.Katakana, 
            e.emit(27, 40, 73);
            if (t(o, 65377, 65439)) return e.emit(o - 65377 - 33);
            if (s !== i.lead) return r.offset(-1), s = i.lead, e.emit(27, 36, 66);
            var a = d(o, V.jis0208);
            if (null === a) return u(o);
            var c = n(a, 94) + 33, l = a % 94 + 33;
            return e.emit(c, l);
        };
    }
    function k(e) {
        var n = e.fatal, i = 0;
        this.decode = function(e) {
            var s = e.get();
            if (s === U && 0 === i) return j;
            if (s === U && 0 !== i) return i = 0, a(n);
            if (e.offset(1), 0 !== i) {
                var r = i;
                if (i = 0, t(s, 64, 126) || t(s, 128, 252)) {
                    var o = 127 > s ? 64 : 65, u = 160 > r ? 129 : 193, c = l(188 * (r - u) + s - o, V.jis0208);
                    return null === c ? a(n) : c;
                }
                return e.offset(-1), a(n);
            }
            return t(s, 0, 128) ? s : t(s, 161, 223) ? 65377 + s - 161 : t(s, 129, 159) || t(s, 224, 252) ? (i = s, 
            null) : a(n);
        };
    }
    function C(e) {
        e.fatal, this.encode = function(e, i) {
            var s = i.get();
            if (s === j) return U;
            if (i.offset(1), t(s, 0, 128)) return e.emit(s);
            if (165 === s) return e.emit(92);
            if (8254 === s) return e.emit(126);
            if (t(s, 65377, 65439)) return e.emit(s - 65377 + 161);
            var r = d(s, V.jis0208);
            if (null === r) return u(s);
            var o = n(r, 188), a = 31 > o ? 129 : 193, c = r % 188, l = 63 > c ? 64 : 65;
            return e.emit(o + a, c + l);
        };
    }
    function R(e) {
        var n = e.fatal, i = 0;
        this.decode = function(e) {
            var s = e.get();
            if (s === U && 0 === i) return j;
            if (s === U && 0 !== i) return i = 0, a(n);
            if (e.offset(1), 0 !== i) {
                var r = i, o = null;
                if (i = 0, t(r, 129, 198)) {
                    var u = 178 * (r - 129);
                    t(s, 65, 90) ? o = u + s - 65 : t(s, 97, 122) ? o = u + 26 + s - 97 : t(s, 129, 254) && (o = u + 26 + 26 + s - 129);
                }
                t(r, 199, 253) && t(s, 161, 254) && (o = 12460 + 94 * (r - 199) + (s - 161));
                var c = null === o ? null : l(o, V["euc-kr"]);
                return null === o && e.offset(-1), null === c ? a(n) : c;
            }
            return t(s, 0, 127) ? s : t(s, 129, 253) ? (i = s, null) : a(n);
        };
    }
    function O(e) {
        e.fatal, this.encode = function(e, i) {
            var s = i.get();
            if (s === j) return U;
            if (i.offset(1), t(s, 0, 127)) return e.emit(s);
            var r = d(s, V["euc-kr"]);
            if (null === r) return u(s);
            var o, a;
            if (12460 > r) {
                o = n(r, 178) + 129, a = r % 178;
                var c = 26 > a ? 65 : 52 > a ? 71 : 77;
                return e.emit(o, a + c);
            }
            return r -= 12460, o = n(r, 94) + 199, a = r % 94 + 161, e.emit(o, a);
        };
    }
    function D(e) {
        var n = e.fatal, i = {
            ASCII: 0,
            escape_start: 1,
            escape_middle: 2,
            escape_end: 3,
            lead: 4,
            trail: 5
        }, s = i.ASCII, r = 0;
        this.decode = function(e) {
            var o = e.get();
            switch (o !== U && e.offset(1), s) {
              default:
              case i.ASCII:
                return 14 === o ? (s = i.lead, null) : 15 === o ? null : 27 === o ? (s = i.escape_start, 
                null) : t(o, 0, 127) ? o : o === U ? j : a(n);

              case i.escape_start:
                return 36 === o ? (s = i.escape_middle, null) : (o !== U && e.offset(-1), s = i.ASCII, 
                a(n));

              case i.escape_middle:
                return 41 === o ? (s = i.escape_end, null) : (o === U ? e.offset(-1) : e.offset(-2), 
                s = i.ASCII, a(n));

              case i.escape_end:
                return 67 === o ? (s = i.ASCII, null) : (o === U ? e.offset(-2) : e.offset(-3), 
                s = i.ASCII, a(n));

              case i.lead:
                return 10 === o ? (s = i.ASCII, a(n, 10)) : 14 === o ? null : 15 === o ? (s = i.ASCII, 
                null) : o === U ? j : (r = o, s = i.trail, null);

              case i.trail:
                if (s = i.lead, o === U) return a(n);
                var u = null;
                return t(r, 33, 70) && t(o, 33, 126) ? u = l(178 * (r - 1) + 26 + 26 + o - 1, V["euc-kr"]) : t(r, 71, 126) && t(o, 33, 126) && (u = l(12460 + 94 * (r - 71) + (o - 33), V["euc-kr"])), 
                null !== u ? u : a(n);
            }
        };
    }
    function M(e) {
        e.fatal;
        var i = {
            ASCII: 0,
            lead: 1
        }, s = !1, r = i.ASCII;
        this.encode = function(e, o) {
            var a = o.get();
            if (a === j) return U;
            if (s || (s = !0, e.emit(27, 36, 41, 67)), o.offset(1), t(a, 0, 127) && r !== i.ASCII) return o.offset(-1), 
            r = i.ASCII, e.emit(15);
            if (t(a, 0, 127)) return e.emit(a);
            if (r !== i.lead) return o.offset(-1), r = i.lead, e.emit(14);
            var c = d(a, V["euc-kr"]);
            if (null === c) return u(a);
            var l, h;
            return 12460 > c ? (l = n(c, 178) + 1, h = c % 178 - 26 - 26 + 1, t(l, 33, 70) && t(h, 33, 126) ? e.emit(l, h) : u(a)) : (c -= 12460, 
            l = n(c, 94) + 71, h = c % 94 + 33, t(l, 71, 126) && t(h, 33, 126) ? e.emit(l, h) : u(a));
        };
    }
    function B(e, n) {
        var i = n.fatal, s = null, r = null;
        this.decode = function(n) {
            var o = n.get();
            if (o === U && null === s && null === r) return j;
            if (o === U && (null !== s || null !== r)) return a(i);
            if (n.offset(1), null === s) return s = o, null;
            var u;
            if (u = e ? (s << 8) + o : (o << 8) + s, s = null, null !== r) {
                var c = r;
                return r = null, t(u, 56320, 57343) ? 65536 + 1024 * (c - 55296) + (u - 56320) : (n.offset(-2), 
                a(i));
            }
            return t(u, 55296, 56319) ? (r = u, null) : t(u, 56320, 57343) ? a(i) : u;
        };
    }
    function P(e, i) {
        i.fatal, this.encode = function(i, s) {
            function r(t) {
                var n = t >> 8, s = 255 & t;
                return e ? i.emit(n, s) : i.emit(s, n);
            }
            var o = s.get();
            if (o === j) return U;
            if (s.offset(1), t(o, 55296, 57343) && u(o), 65535 >= o) return r(o);
            var a = n(o - 65536, 1024) + 55296, c = (o - 65536) % 1024 + 56320;
            return r(a), r(c);
        };
    }
    function q(e, t) {
        return t.match([ 255, 254 ]) ? (t.offset(2), "utf-16") : t.match([ 254, 255 ]) ? (t.offset(2), 
        "utf-16be") : t.match([ 239, 187, 191 ]) ? (t.offset(3), "utf-8") : e;
    }
    function N(t, n) {
        return this && this !== e ? (t = t ? String(t) : X, n = Object(n), this._encoding = c(t), 
        this._streaming = !1, this._encoder = null, this._options = {
            fatal: Boolean(n.fatal)
        }, Object.defineProperty ? Object.defineProperty(this, "encoding", {
            get: function() {
                return this._encoding.name;
            }
        }) : this.encoding = this._encoding.name, this) : new N(t, n);
    }
    function H(t, n) {
        return this && this !== e ? (t = t ? String(t) : X, n = Object(n), this._encoding = c(t), 
        this._streaming = !1, this._decoder = null, this._options = {
            fatal: Boolean(n.fatal)
        }, Object.defineProperty ? Object.defineProperty(this, "encoding", {
            get: function() {
                return this._encoding.name;
            }
        }) : this.encoding = this._encoding.name, this) : new H(t, n);
    }
    var U = -1, j = -1, L = [ {
        encodings: [ {
            labels: [ "unicode-1-1-utf-8", "utf-8", "utf8" ],
            name: "utf-8"
        } ],
        heading: "The Encoding"
    }, {
        encodings: [ {
            labels: [ "cp864", "ibm864" ],
            name: "ibm864"
        }, {
            labels: [ "cp866", "ibm866" ],
            name: "ibm866"
        }, {
            labels: [ "csisolatin2", "iso-8859-2", "iso-ir-101", "iso8859-2", "iso_8859-2", "l2", "latin2" ],
            name: "iso-8859-2"
        }, {
            labels: [ "csisolatin3", "iso-8859-3", "iso_8859-3", "iso-ir-109", "l3", "latin3" ],
            name: "iso-8859-3"
        }, {
            labels: [ "csisolatin4", "iso-8859-4", "iso_8859-4", "iso-ir-110", "l4", "latin4" ],
            name: "iso-8859-4"
        }, {
            labels: [ "csisolatincyrillic", "cyrillic", "iso-8859-5", "iso_8859-5", "iso-ir-144" ],
            name: "iso-8859-5"
        }, {
            labels: [ "arabic", "csisolatinarabic", "ecma-114", "iso-8859-6", "iso_8859-6", "iso-ir-127" ],
            name: "iso-8859-6"
        }, {
            labels: [ "csisolatingreek", "ecma-118", "elot_928", "greek", "greek8", "iso-8859-7", "iso_8859-7", "iso-ir-126" ],
            name: "iso-8859-7"
        }, {
            labels: [ "csisolatinhebrew", "hebrew", "iso-8859-8", "iso-8859-8-i", "iso-ir-138", "iso_8859-8", "visual" ],
            name: "iso-8859-8"
        }, {
            labels: [ "csisolatin6", "iso-8859-10", "iso-ir-157", "iso8859-10", "l6", "latin6" ],
            name: "iso-8859-10"
        }, {
            labels: [ "iso-8859-13" ],
            name: "iso-8859-13"
        }, {
            labels: [ "iso-8859-14", "iso8859-14" ],
            name: "iso-8859-14"
        }, {
            labels: [ "iso-8859-15", "iso_8859-15" ],
            name: "iso-8859-15"
        }, {
            labels: [ "iso-8859-16" ],
            name: "iso-8859-16"
        }, {
            labels: [ "koi8-r", "koi8_r" ],
            name: "koi8-r"
        }, {
            labels: [ "koi8-u" ],
            name: "koi8-u"
        }, {
            labels: [ "csmacintosh", "mac", "macintosh", "x-mac-roman" ],
            name: "macintosh"
        }, {
            labels: [ "iso-8859-11", "tis-620", "windows-874" ],
            name: "windows-874"
        }, {
            labels: [ "windows-1250", "x-cp1250" ],
            name: "windows-1250"
        }, {
            labels: [ "windows-1251", "x-cp1251" ],
            name: "windows-1251"
        }, {
            labels: [ "ascii", "ansi_x3.4-1968", "csisolatin1", "iso-8859-1", "iso8859-1", "iso_8859-1", "l1", "latin1", "us-ascii", "windows-1252" ],
            name: "windows-1252"
        }, {
            labels: [ "cp1253", "windows-1253" ],
            name: "windows-1253"
        }, {
            labels: [ "csisolatin5", "iso-8859-9", "iso-ir-148", "l5", "latin5", "windows-1254" ],
            name: "windows-1254"
        }, {
            labels: [ "cp1255", "windows-1255" ],
            name: "windows-1255"
        }, {
            labels: [ "cp1256", "windows-1256" ],
            name: "windows-1256"
        }, {
            labels: [ "windows-1257" ],
            name: "windows-1257"
        }, {
            labels: [ "cp1258", "windows-1258" ],
            name: "windows-1258"
        }, {
            labels: [ "x-mac-cyrillic", "x-mac-ukrainian" ],
            name: "x-mac-cyrillic"
        } ],
        heading: "Legacy single-byte encodings"
    }, {
        encodings: [ {
            labels: [ "chinese", "csgb2312", "csiso58gb231280", "gb2312", "gbk", "gb_2312", "gb_2312-80", "iso-ir-58", "x-gbk" ],
            name: "gbk"
        }, {
            labels: [ "gb18030" ],
            name: "gb18030"
        }, {
            labels: [ "hz-gb-2312" ],
            name: "hz-gb-2312"
        } ],
        heading: "Legacy multi-byte Chinese (simplified) encodings"
    }, {
        encodings: [ {
            labels: [ "big5", "big5-hkscs", "cn-big5", "csbig5", "x-x-big5" ],
            name: "big5"
        } ],
        heading: "Legacy multi-byte Chinese (traditional) encodings"
    }, {
        encodings: [ {
            labels: [ "cseucpkdfmtjapanese", "euc-jp", "x-euc-jp" ],
            name: "euc-jp"
        }, {
            labels: [ "csiso2022jp", "iso-2022-jp" ],
            name: "iso-2022-jp"
        }, {
            labels: [ "csshiftjis", "ms_kanji", "shift-jis", "shift_jis", "sjis", "windows-31j", "x-sjis" ],
            name: "shift_jis"
        } ],
        heading: "Legacy multi-byte Japanese encodings"
    }, {
        encodings: [ {
            labels: [ "cseuckr", "csksc56011987", "euc-kr", "iso-ir-149", "korean", "ks_c_5601-1987", "ks_c_5601-1989", "ksc5601", "ksc_5601", "windows-949" ],
            name: "euc-kr"
        }, {
            labels: [ "csiso2022kr", "iso-2022-kr" ],
            name: "iso-2022-kr"
        } ],
        heading: "Legacy multi-byte Korean encodings"
    }, {
        encodings: [ {
            labels: [ "utf-16", "utf-16le" ],
            name: "utf-16"
        }, {
            labels: [ "utf-16be" ],
            name: "utf-16be"
        } ],
        heading: "Legacy utf-16 encodings"
    } ], F = {}, z = {};
    L.forEach(function(e) {
        e.encodings.forEach(function(e) {
            F[e.name] = e, e.labels.forEach(function(t) {
                z[t] = e;
            });
        });
    });
    var V = e["encoding-indexes"] || {};
    F["utf-8"].getEncoder = function(e) {
        return new g(e);
    }, F["utf-8"].getDecoder = function(e) {
        return new p(e);
    }, function() {
        [ "ibm864", "ibm866", "iso-8859-2", "iso-8859-3", "iso-8859-4", "iso-8859-5", "iso-8859-6", "iso-8859-7", "iso-8859-8", "iso-8859-10", "iso-8859-13", "iso-8859-14", "iso-8859-15", "iso-8859-16", "koi8-r", "koi8-u", "macintosh", "windows-874", "windows-1250", "windows-1251", "windows-1252", "windows-1253", "windows-1254", "windows-1255", "windows-1256", "windows-1257", "windows-1258", "x-mac-cyrillic" ].forEach(function(e) {
            var t = F[e], n = V[e];
            t.getDecoder = function(e) {
                return new _(n, e);
            }, t.getEncoder = function(e) {
                return new m(n, e);
            };
        });
    }(), F.gbk.getEncoder = function(e) {
        return new v(!1, e);
    }, F.gbk.getDecoder = function(e) {
        return new b(!1, e);
    }, F.gb18030.getEncoder = function(e) {
        return new v(!0, e);
    }, F.gb18030.getDecoder = function(e) {
        return new b(!0, e);
    }, F["hz-gb-2312"].getEncoder = function(e) {
        return new w(e);
    }, F["hz-gb-2312"].getDecoder = function(e) {
        return new y(e);
    }, F.big5.getEncoder = function(e) {
        return new A(e);
    }, F.big5.getDecoder = function(e) {
        return new S(e);
    }, F["euc-jp"].getEncoder = function(e) {
        return new I(e);
    }, F["euc-jp"].getDecoder = function(e) {
        return new E(e);
    }, F["iso-2022-jp"].getEncoder = function(e) {
        return new x(e);
    }, F["iso-2022-jp"].getDecoder = function(e) {
        return new T(e);
    }, F.shift_jis.getEncoder = function(e) {
        return new C(e);
    }, F.shift_jis.getDecoder = function(e) {
        return new k(e);
    }, F["euc-kr"].getEncoder = function(e) {
        return new O(e);
    }, F["euc-kr"].getDecoder = function(e) {
        return new R(e);
    }, F["iso-2022-kr"].getEncoder = function(e) {
        return new M(e);
    }, F["iso-2022-kr"].getDecoder = function(e) {
        return new D(e);
    }, F["utf-16"].getEncoder = function(e) {
        return new P(!1, e);
    }, F["utf-16"].getDecoder = function(e) {
        return new B(!1, e);
    }, F["utf-16be"].getEncoder = function(e) {
        return new P(!0, e);
    }, F["utf-16be"].getDecoder = function(e) {
        return new B(!0, e);
    };
    var X = "utf-8";
    N.prototype = {
        encode: function(e, t) {
            e = e ? String(e) : "", t = Object(t), this._streaming || (this._encoder = this._encoding.getEncoder(this._options)), 
            this._streaming = Boolean(t.stream);
            for (var n = [], i = new s(n), o = new r(e); o.get() !== j; ) this._encoder.encode(i, o);
            if (!this._streaming) {
                var a;
                do a = this._encoder.encode(i, o); while (a !== U);
                this._encoder = null;
            }
            return new Uint8Array(n);
        }
    }, H.prototype = {
        decode: function(e, t) {
            if (e && !("buffer" in e && "byteOffset" in e && "byteLength" in e)) throw new TypeError("Expected ArrayBufferView");
            e || (e = new Uint8Array(0)), t = Object(t), this._streaming || (this._decoder = this._encoding.getDecoder(this._options)), 
            this._streaming = Boolean(t.stream);
            var n = new Uint8Array(e.buffer, e.byteOffset, e.byteLength), s = new i(n), r = q(this._encoding.name, s);
            if (c(r) !== this._encoding) throw new Error("BOM mismatch");
            for (var a, u = new o(); s.get() !== U; ) a = this._decoder.decode(s), null !== a && a !== j && u.emit(a);
            if (!this._streaming) {
                do a = this._decoder.decode(s), null !== a && a !== j && u.emit(a); while (a !== j);
                this._decoder = null;
            }
            return u.string();
        }
    }, e.TextEncoder = e.TextEncoder || N, e.TextDecoder = e.TextDecoder || H;
})(this);