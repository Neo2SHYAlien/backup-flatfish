(function(e, t) {
    "object" == typeof exports ? module.exports = t(require("wbxml"), require("activesync/codepages")) : "function" == typeof define && define.amd ? define([ "wbxml", "activesync/codepages" ], t) : e.ActiveSyncProtocol = t(WBXML, ActiveSyncCodepages);
})(this, function(e, t) {
    function n() {}
    function s(e, t, n) {
        function s() {
            var e = this instanceof s ? this : Object.create(s.prototype), t = Error(), i = 1;
            if (e.stack = t.stack.substring(t.stack.indexOf("\n") + 1), e.message = arguments[0] || t.message, 
            n) {
                i += n.length;
                for (var r = 0; r < n.length; r++) e[n[r]] = arguments[r + 1];
            }
            var o = /@(.+):(.+)/.exec(e.stack);
            return e.fileName = arguments[i] || o && o[1] || "", e.lineNumber = arguments[i + 1] || o && o[2] || 0, 
            e;
        }
        return s.prototype = Object.create((t || Error).prototype), s.prototype.name = e, 
        s.prototype.constructor = s, s;
    }
    function i(e) {
        var t = "http://schemas.microsoft.com/exchange/autodiscover/", n = {
            rq: t + "mobilesync/requestschema/2006",
            ad: t + "responseschema/2006",
            ms: t + "mobilesync/responseschema/2006"
        };
        return n[e] || null;
    }
    function r(e) {
        var t = e.split(".").map(function(e) {
            return parseInt(e);
        });
        this.major = t[0], this.minor = t[1];
    }
    function o(e, t, n) {
        var s = "Basic " + btoa(t + ":" + n);
        e.setRequestHeader("Authorization", s);
    }
    function a(e, t, s, i, r) {
        i || (i = n);
        var o = e.substring(e.indexOf("@") + 1);
        d(o, e, t, s, r, function(n, a) {
            n instanceof f || n instanceof m ? d("autodiscover." + o, e, t, s, r, i) : i(n, a);
        });
    }
    function d(e, t, n, s, i, r) {
        var o = "https://" + e + "/autodiscover/autodiscover.xml";
        return c(o, t, n, s, i, r);
    }
    function c(e, t, n, s, r, d) {
        var c = new XMLHttpRequest({
            mozSystem: !0,
            mozAnon: !0
        });
        c.open("POST", e, !0), o(c, t, n), c.setRequestHeader("Content-Type", "text/xml"), 
        c.setRequestHeader("User-Agent", u), c.timeout = s, c.upload.onprogress = c.upload.onload = function() {
            c.timeout = 0;
        }, c.onload = function() {
            if (c.status < 200 || c.status >= 300) return d(new m(c.statusText, c.status));
            var e = Math.random();
            self.postMessage({
                uid: e,
                type: "configparser",
                cmd: "accountactivesync",
                args: [ c.responseText, r ]
            }), self.addEventListener("message", function t(i) {
                var r = i.data;
                if ("configparser" == r.type && "accountactivesync" == r.cmd && r.uid == e) {
                    self.removeEventListener(i.type, t);
                    var o = r.args, c = o[0], l = o[1], h = o[2];
                    l ? d(new f(l), c) : h ? a(h, n, s, d, !0) : d(null, c);
                }
            });
        }, c.ontimeout = c.onerror = function() {
            d(new m("Error getting Autodiscover URL", null));
        };
        var l = '<?xml version="1.0" encoding="utf-8"?>\n<Autodiscover xmlns="' + i("rq") + '">\n' + "  <Request>\n" + "    <EMailAddress>" + t + "</EMailAddress>\n" + "    <AcceptableResponseSchema>" + i("ms") + "</AcceptableResponseSchema>\n" + "  </Request>\n" + "</Autodiscover>";
        c.send(l);
    }
    function l(e, t) {
        this._deviceId = e || "v140Device", this._deviceType = t || "SmartPhone", this.timeout = 0, 
        this._connected = !1, this._waitingForConnection = !1, this._connectionError = null, 
        this._connectionCallbacks = [], this.baseUrl = null, this._username = null, this._password = null, 
        this.versions = [], this.supportedCommands = [], this.currentVersion = null, this.onmessage = null;
    }
    var h = {}, u = "JavaScript ActiveSync (jsas) Client", p = s("ActiveSync.AutodiscoverError");
    h.AutodiscoverError = p;
    var f = s("ActiveSync.AutodiscoverDomainError", p);
    h.AutodiscoverDomainError = f;
    var m = s("ActiveSync.HttpError", null, [ "status" ]);
    return h.HttpError = m, h.Version = r, r.prototype = {
        eq: function(e) {
            return e instanceof r || (e = new r(e)), this.major === e.major && this.minor === e.minor;
        },
        ne: function(e) {
            return !this.eq(e);
        },
        gt: function(e) {
            return e instanceof r || (e = new r(e)), this.major > e.major || this.major === e.major && this.minor > e.minor;
        },
        gte: function(e) {
            return e instanceof r || (e = new r(e)), this.major >= e.major || this.major === e.major && this.minor >= e.minor;
        },
        lt: function(e) {
            return !this.gte(e);
        },
        lte: function(e) {
            return !this.gt(e);
        },
        toString: function() {
            return this.major + "." + this.minor;
        }
    }, h.autodiscover = a, h.raw_autodiscover = c, h.Connection = l, l.prototype = {
        _notifyConnected: function(e) {
            e && this.disconnect();
            for (var t in Iterator(this._connectionCallbacks)) {
                var n = t[1];
                n.apply(n, arguments);
            }
            this._connectionCallbacks = [];
        },
        get connected() {
            return this._connected;
        },
        open: function(e, t, n) {
            var s = "/Microsoft-Server-ActiveSync";
            this.baseUrl = e, this.baseUrl.endsWith(s) || (this.baseUrl += s), this._username = t, 
            this._password = n;
        },
        connect: function(e) {
            return this.connected ? (e && e(null), void 0) : (e && this._connectionCallbacks.push(e), 
            this._waitingForConnection || (this._waitingForConnection = !0, this._connectionError = null, 
            this.getOptions(function(e, t) {
                return this._waitingForConnection = !1, this._connectionError = e, e ? (console.error("Error connecting to ActiveSync:", e), 
                this._notifyConnected(e, t)) : (this._connected = !0, this.versions = t.versions, 
                this.supportedCommands = t.commands, this.currentVersion = new r(t.versions.slice(-1)[0]), 
                this._notifyConnected(null, t));
            }.bind(this))), void 0);
        },
        disconnect: function() {
            if (this._waitingForConnection) throw new Error("Can't disconnect while waiting for server response");
            this._connected = !1, this.versions = [], this.supportedCommands = [], this.currentVersion = null;
        },
        provision: function(n) {
            var s = t.Provision.Tags, i = new e.Writer("1.3", 1, "UTF-8");
            i.stag(s.Provision).etag(), this.postCommand(i, n);
        },
        getOptions: function(e) {
            e || (e = n);
            var t = this, s = new XMLHttpRequest({
                mozSystem: !0,
                mozAnon: !0
            });
            s.open("OPTIONS", this.baseUrl, !0), o(s, this._username, this._password), s.setRequestHeader("User-Agent", u), 
            s.timeout = this.timeout, s.upload.onprogress = s.upload.onload = function() {
                s.timeout = 0;
            }, s.onload = function() {
                if (s.status < 200 || s.status >= 300) return console.error("ActiveSync options request failed with response " + s.status), 
                t.onmessage && t.onmessage("options", "error", s, null, null, null, null), e(new m(s.statusText, s.status)), 
                void 0;
                var n = {
                    versions: s.getResponseHeader("MS-ASProtocolVersions").split(/\s*,\s*/),
                    commands: s.getResponseHeader("MS-ASProtocolCommands").split(/\s*,\s*/)
                };
                t.onmessage && t.onmessage("options", "ok", s, null, null, null, n), e(null, n);
            }, s.ontimeout = s.onerror = function() {
                var n = new Error("Error getting OPTIONS URL");
                console.error(n), t.onmessage && t.onmessage("options", "timeout", s, null, null, null, null), 
                e(n);
            }, s.responseType = "text", s.send();
        },
        supportsCommand: function(e) {
            if (!this.connected) throw new Error("Connection required to get command");
            return "number" == typeof e && (e = t.__tagnames__[e]), -1 !== this.supportedCommands.indexOf(e);
        },
        doCommand: function() {
            console.warn("doCommand is deprecated. Use postCommand instead."), this.postCommand.apply(this, arguments);
        },
        postCommand: function(e, n, s, i, r) {
            var o = "application/vnd.ms-sync.wbxml";
            if ("string" == typeof e || "number" == typeof e) this.postData(e, o, null, n, s, i); else {
                var a = t.__tagnames__[e.rootTag];
                this.postData(a, o, "blob" === e.dataType ? e.blob : e.buffer, n, s, i, r);
            }
        },
        postData: function(n, s, i, r, a, d, c) {
            if ("number" == typeof n && (n = t.__tagnames__[n]), !this.supportsCommand(n)) {
                var l = new Error("This server doesn't support the command " + n);
                return console.error(l), r(l), void 0;
            }
            var h = [ [ "Cmd", n ], [ "User", this._username ], [ "DeviceId", this._deviceId ], [ "DeviceType", this._deviceType ] ];
            if (a) {
                for (var p in Iterator(h)) {
                    var f = p[1];
                    if (f[0] in a) throw new TypeError("reserved URL parameter found");
                }
                for (var g in Iterator(a)) h.push(g);
            }
            var _ = h.map(function(e) {
                return encodeURIComponent(e[0]) + "=" + encodeURIComponent(e[1]);
            }).join("&"), y = new XMLHttpRequest({
                mozSystem: !0,
                mozAnon: !0
            });
            if (y.open("POST", this.baseUrl + "?" + _, !0), o(y, this._username, this._password), 
            y.setRequestHeader("MS-ASProtocolVersion", this.currentVersion), y.setRequestHeader("Content-Type", s), 
            y.setRequestHeader("User-Agent", u), d) for (var p in Iterator(d)) {
                var v = p[0], v = p[1];
                y.setRequestHeader(v, value);
            }
            y.timeout = this.timeout, y.upload.onprogress = y.upload.onload = function() {
                y.timeout = 0;
            }, y.onprogress = function(e) {
                c && c(e.loaded, e.total);
            };
            var b = this, w = arguments;
            y.onload = function() {
                if (451 === y.status) return b.baseUrl = y.getResponseHeader("X-MS-Location"), b.onmessage && b.onmessage(n, "redirect", y, h, d, i, null), 
                b.postData.apply(b, w), void 0;
                if (y.status < 200 || y.status >= 300) return console.error("ActiveSync command " + n + " failed with " + "response " + y.status), 
                b.onmessage && b.onmessage(n, "error", y, h, d, i, null), r(new m(y.statusText, y.status)), 
                void 0;
                var s = null;
                y.response.byteLength > 0 && (s = new e.Reader(new Uint8Array(y.response), t)), 
                b.onmessage && b.onmessage(n, "ok", y, h, d, i, s), r(null, s);
            }, y.ontimeout = y.onerror = function(e) {
                var t = new Error("Command URL " + e.type + " for command " + n + " at baseUrl " + this.baseUrl);
                console.error(t), b.onmessage && b.onmessage(n, e.type, y, h, d, i, null), r(t);
            }.bind(this), y.responseType = "arraybuffer", y.send(i);
        }
    }, h;
});