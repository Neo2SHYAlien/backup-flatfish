define([ "./log", "exports" ], function(e, t) {
    function n(e, t, n, i, r, s, u) {
        this.kind = t, this.descBits = n, this.actors = i, this.testFunc = r, this.timeoutMS = o, 
        this.log = a.testStep(this, e, n), this.log.boring(s), u && this.log.group(u);
    }
    function i(e, t) {
        this.__testCase = e, this._permIdx = t, this._permutations = 1, this.__steps = [], 
        this._deferredSteps = null, this._log = a.testCasePermutation(this, e.log, t), this._log._named = {}, 
        this._definingGroup = null, this._actors = [];
    }
    function r(e, t, n, i) {
        this.definer = e, this.kind = t, this.desc = n, this.setupFunc = i, this.log = a.testCase(this, e._log, n), 
        this.context = null;
    }
    function s(e, t, n, i) {
        this.__logfabs = t, this.__testHelperDefs = n, this.__tags = i, this._log = a.testDefiner(this, null, e), 
        this._runtimeContext = null, this.__testCases = [];
    }
    const o = t.UNSPECIFIED_STEP_TIMEOUT_MS = null;
    t.STEP_TIMEOUT_MS = 1e3, n.prototype = {
        toString: function() {
            return "[TestStep]";
        },
        toJSON: function() {
            return {
                type: "TestStep"
            };
        }
    }, i.prototype = {
        toString: function() {
            return "[TestContext]";
        },
        toJSON: function() {
            return {
                type: "TestContext"
            };
        },
        setPermutationVariant: function(e) {
            this._log.variant(e);
        },
        _mixinFromHelperDefs: function(e, t, n, i, r) {
            var s = t + "Mixins", o = this.__testCase.definer.__testHelperDefs;
            if (o) {
                for (var a = 0; a < o.length; a++) {
                    var u = o[a];
                    if (s in u && u[s].hasOwnProperty(n)) {
                        var c = u[s][n];
                        for (var l in c) e[l] = c[l];
                    }
                }
                i && "__constructor" in e && e.__constructor.apply(e, r);
            }
        },
        actor: function l(e, t, n, i) {
            for (var r = this.__testCase.definer.__logfabs, s = 0; s < r.length; s++) {
                var o = r[s]._actorCons;
                if (o.hasOwnProperty(e)) {
                    var l = new o[e](t, i ? i._uniqueName : null);
                    return l.T = this, l.RT = this.__testCase.definer._runtimeContext, this._mixinFromHelperDefs(l, "actor", e, !1), 
                    this._log._named[l._uniqueName] = l, "__constructor" in l && this._log.actorConstructor(e, t, l, l.__constructor, l, n), 
                    l;
                }
            }
            throw new Error("Unknown actor type '" + e + "'");
        },
        lazyLogger: function(e) {
            var t = new u._actorCons.lazyLogger(e);
            t.T = this, t.RT = this.__testCase.definer._runtimeContext, this._log._named[t._uniqueName] = t, 
            c = t;
            var n = this.__testCase.definer._runtimeContext.peekLogger(), i = u.lazyLogger(null, n, e);
            return t.event = i.event.bind(i), t.eventD = i.eventD.bind(i), t.value = i.value.bind(i), 
            t.namedValue = i.namedValue.bind(i), t.namedValueD = i.namedValueD.bind(i), t.error = i.error.bind(i), 
            t;
        },
        thing: function(t, n, i) {
            var r = e.__makeThing(t, n, i);
            return this._mixinFromHelperDefs(r, "thing", t, !0, []), this._log._named[r._uniqueName] = r, 
            r;
        },
        ownedThing: function(t, n, i, r) {
            var s = e.__makeThing(n, i, r);
            return this._mixinFromHelperDefs(s, "thing", n, !0, []), t._logger._named || (t._logger._named = {}), 
            t._logger._named[s._uniqueName] = s, s;
        },
        _newStep: function(t, i, r) {
            var s, o = [], a = [];
            for (s = 0; s < i.length - 1; s++) {
                var u = i[s];
                if (Array.isArray(u)) for (var c = 0; c < u.length; c++) {
                    var l = u[c];
                    e.TestActorProtoBase.isPrototypeOf(l) && o.push(l), a.push(l);
                } else e.TestActorProtoBase.isPrototypeOf(u) && o.push(u), a.push(u);
            }
            var d = i[s], h = new n(this._log, t, a, o, d, r, this._definingGroup);
            return this.__steps.push(h), h;
        },
        _newDeferredStep: function(e, t, n) {
            return this._deferredSteps || (this._deferredSteps = []), this._deferredSteps.push([ e, t, n ]), 
            null;
        },
        __postSetupFunc: function() {
            if (this._deferredSteps) {
                for (var e = 0; e < this._deferredSteps.length; e++) {
                    var t = this._deferredSteps[e];
                    this._newStep(t[0], t[1], t[2]);
                }
                this._deferredSteps = null;
            }
        },
        group: function(e) {
            this._definingGroup = e;
        },
        action: function() {
            return this._newStep("action", arguments, !1);
        },
        check: function() {
            return this._newStep("check", arguments, !1);
        },
        permutation: function(e, t) {
            var n = t.length;
            this._permutations *= n;
            for (var i = this.__steps.length - n, r = 0; r < n.length; r++) if (t[r] !== this.__steps[i]) throw new Error("Step sequence invariant violation");
            var s = this.__steps.splice(i, n);
            this.__steps.push(s);
        },
        setup: function() {
            return this._newStep("setup", arguments, !0);
        },
        convenienceSetup: function() {
            return this._newStep("setup", arguments, !0);
        },
        cleanup: function() {
            return this._newStep("cleanup", arguments, !0);
        },
        convenienceCleanup: function() {
            return this._newStep("cleanup", arguments, !0);
        },
        convenienceDeferredCleanup: function() {
            return this._newDeferredStep("cleanup", arguments, !0);
        }
    }, t.TestContext = i, r.prototype = {
        toString: function() {
            return "[TestCase]";
        },
        toJSON: function() {
            return {
                type: "TestCase"
            };
        }
    }, s.prototype = {
        toString: function() {
            return "[TestDefine]";
        },
        toJSON: function() {
            return {
                type: "TestDefiner"
            };
        },
        _newCase: function(e, t, n) {
            var i = new r(this, e, t, n);
            this.__testCases.push(i);
        },
        _newSimpleCase: function(e, t, n) {
            var i = new r(this, e, t, function(e) {
                if (0 === n.length) e.action(t, n); else {
                    var i = e.lazyLogger("lazy");
                    e.action(t, i, function() {
                        n(i);
                    });
                }
            });
            this.__testCases.push(i);
        },
        artificialCase: function(e, t) {
            this._newCase("artificial", e, t);
        },
        commonCase: function(e, t) {
            this._newCase("common", e, t);
        },
        edgeCase: function(e, t) {
            this._newCase("edge", e, t);
        },
        commonSimple: function(e, t) {
            this._newSimpleCase("common", e, t);
        },
        DISABLED_artificialCase: function() {},
        DISABLED_commonCase: function() {},
        DISABLED_edgeCase: function() {},
        DISABLED_commonSimple: function() {}
    }, t.defineTestsFor = function(e, t, n, i) {
        t = null == t ? [] : Array.isArray(t) ? t.concat() : [ t ], null == n ? n = [] : Array.isArray(n) || (n = [ n ]);
        for (var r = 0; r < n.length; r++) {
            var o = n[r];
            if ("LOGFAB_DEPS" in o) for (var a = 0; a < o.LOGFAB_DEPS.length; a++) {
                var u = o.LOGFAB_DEPS[a];
                -1 === t.indexOf(u) && t.push(u);
            }
            if ("TESTHELPER_DEPS" in o) for (var c = 0; c < o.TESTHELPER_DEPS.length; c++) {
                var l = o.TESTHELPER_DEPS[c];
                -1 === n.indexOf(l) && n.push(l);
            }
        }
        return console.log("defining tests for", e.id), new s(e.id, t, n, i);
    };
    var a = t.LOGFAB = e.register(null, {
        testDefiner: {
            type: e.TEST_DRIVER,
            subtype: e.TEST_GROUP,
            asyncJobs: {
                run: {}
            },
            latchState: {
                result: !1
            }
        },
        testCase: {
            type: e.TEST_DRIVER,
            subtype: e.TEST_CASE,
            asyncJobs: {
                run: {}
            },
            latchState: {
                result: !1,
                variant: !1
            }
        },
        testCasePermutation: {
            type: e.TEST_DRIVER,
            subtype: e.TEST_PERMUTATION,
            asyncJobs: {
                run: {}
            },
            calls: {
                setupFunc: {},
                actorConstructor: {
                    actorType: !1,
                    actorName: !1
                }
            },
            latchState: {
                result: !1,
                variant: !1
            }
        },
        testStep: {
            type: e.TEST_DRIVER,
            subtype: e.TEST_STEP,
            asyncJobs: {
                run: {}
            },
            calls: {
                stepFunc: {}
            },
            latchState: {
                boring: !1,
                result: !1,
                group: !1
            },
            errors: {
                timeout: {},
                actorNeverGotLogger: {
                    type: !1,
                    name: !1
                },
                uncaughtException: {
                    ex: e.EXCEPTION
                },
                unresolvedPromise: {
                    annotation: !1
                }
            }
        }
    });
    a._generalLog = !0;
    var u = t.__LAZYLOGFAB = e.register(null, {
        lazyLogger: {
            type: e.TEST_LAZY,
            subtype: e.TEST_LAZY,
            events: {
                event: {
                    name: !0
                },
                eventD: {
                    name: !0,
                    detail: !1
                },
                value: {
                    value: !0
                },
                namedValue: {
                    name: !0,
                    value: !0
                },
                namedValueD: {
                    name: !0,
                    value: !0,
                    detail: !1
                }
            },
            errors: {
                error: {
                    what: e.EXCEPTION
                }
            }
        }
    }), c = null;
    u.lazyLogger._underTest = {
        reportNewLogger: function(e, t) {
            return c && (c._logger = e, e._actor = c, !t && c.RT._loggerStack.length && (t = c.RT._loggerStack[c.RT._loggerStack.length - 1]), 
            c = null), t;
        }
    };
});