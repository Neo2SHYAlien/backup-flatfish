(function(e) {
    function t(e) {
        throw RangeError(O[e]);
    }
    function n(e, t) {
        for (var n = e.length; n--; ) e[n] = t(e[n]);
        return e;
    }
    function s(e, t) {
        return n(e.split(M), t).join(".");
    }
    function i(e) {
        for (var t, n, s = [], i = 0, r = e.length; r > i; ) t = e.charCodeAt(i++), t >= 55296 && 56319 >= t && r > i ? (n = e.charCodeAt(i++), 
        56320 == (64512 & n) ? s.push(((1023 & t) << 10) + (1023 & n) + 65536) : (s.push(t), 
        i--)) : s.push(t);
        return s;
    }
    function r(e) {
        return n(e, function(e) {
            var t = "";
            return e > 65535 && (e -= 65536, t += P(55296 | 1023 & e >>> 10), e = 56320 | 1023 & e), 
            t += P(e);
        }).join("");
    }
    function a(e) {
        return 10 > e - 48 ? e - 22 : 26 > e - 65 ? e - 65 : 26 > e - 97 ? e - 97 : b;
    }
    function o(e, t) {
        return e + 22 + 75 * (26 > e) - ((0 != t) << 5);
    }
    function d(e, t, n) {
        var s = 0;
        for (e = n ? D(e / I) : e >> 1, e += D(e / t); e > E * w >> 1; s += b) e = D(e / E);
        return D(s + (E + 1) * e / (e + S));
    }
    function l(e) {
        var n, s, i, o, l, c, h, u, p, f, g = [], _ = e.length, m = 0, S = k, I = R;
        for (s = e.lastIndexOf(x), 0 > s && (s = 0), i = 0; s > i; ++i) e.charCodeAt(i) >= 128 && t("not-basic"), 
        g.push(e.charCodeAt(i));
        for (o = s > 0 ? s + 1 : 0; _ > o; ) {
            for (l = m, c = 1, h = b; o >= _ && t("invalid-input"), u = a(e.charCodeAt(o++)), 
            (u >= b || u > D((y - m) / c)) && t("overflow"), m += u * c, p = I >= h ? v : h >= I + w ? w : h - I, 
            !(p > u); h += b) f = b - p, c > D(y / f) && t("overflow"), c *= f;
            n = g.length + 1, I = d(m - l, n, 0 == l), D(m / n) > y - S && t("overflow"), S += D(m / n), 
            m %= n, g.splice(m++, 0, S);
        }
        return r(g);
    }
    function c(e) {
        var n, s, r, a, l, c, h, u, p, f, g, _, m, S, I, A = [];
        for (e = i(e), _ = e.length, n = k, s = 0, l = R, c = 0; _ > c; ++c) g = e[c], 128 > g && A.push(P(g));
        for (r = a = A.length, a && A.push(x); _ > r; ) {
            for (h = y, c = 0; _ > c; ++c) g = e[c], g >= n && h > g && (h = g);
            for (m = r + 1, h - n > D((y - s) / m) && t("overflow"), s += (h - n) * m, n = h, 
            c = 0; _ > c; ++c) if (g = e[c], n > g && ++s > y && t("overflow"), g == n) {
                for (u = s, p = b; f = l >= p ? v : p >= l + w ? w : p - l, !(f > u); p += b) I = u - f, 
                S = b - f, A.push(P(o(f + I % S, 0))), u = D(I / S);
                A.push(P(o(u, 0))), l = d(s, m, r == a), s = 0, ++r;
            }
            ++s, ++n;
        }
        return A.join("");
    }
    function h(e) {
        return s(e, function(e) {
            return A.test(e) ? l(e.slice(4).toLowerCase()) : e;
        });
    }
    function u(e) {
        return s(e, function(e) {
            return C.test(e) ? "xn--" + c(e) : e;
        });
    }
    var p = "object" == typeof exports && exports, f = "object" == typeof module && module && module.exports == p && module, g = "object" == typeof global && global;
    (g.global === g || g.window === g) && (e = g);
    var _, m, y = 2147483647, b = 36, v = 1, w = 26, S = 38, I = 700, R = 72, k = 128, x = "-", A = /^xn--/, C = /[^ -~]/, M = /\x2E|\u3002|\uFF0E|\uFF61/g, O = {
        overflow: "Overflow: input needs wider integers to process",
        "not-basic": "Illegal input >= 0x80 (not a basic code point)",
        "invalid-input": "Invalid input"
    }, E = b - v, D = Math.floor, P = String.fromCharCode;
    if (_ = {
        version: "1.2.4",
        ucs2: {
            decode: i,
            encode: r
        },
        decode: l,
        encode: c,
        toASCII: u,
        toUnicode: h
    }, "function" == typeof define && "object" == typeof define.amd && define.amd) define("punycode", [], function() {
        return _;
    }); else if (p && !p.nodeType) if (f) f.exports = _; else for (m in _) _.hasOwnProperty(m) && (p[m] = _[m]); else e.punycode = _;
})(this);