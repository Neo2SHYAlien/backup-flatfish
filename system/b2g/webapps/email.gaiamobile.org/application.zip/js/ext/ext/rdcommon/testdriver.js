define([ "./deferred", "./testcontext", "./extransform", "require", "exports" ], function(e, t, n, i, r) {
    function s(e, t) {
        this._loggerStack = [], this._pendingActorsByLoggerType = {}, this._captureAllLoggersByType = {}, 
        this.envOptions = e || {}, this.caseBlackboard = {}, this.fileBlackboard = t, this.testDomainSeq = 0, 
        this._liveActors = null;
    }
    function o(e, t, n, i) {
        if (!e) throw new Error("No test definer provided!");
        this._testDefiner = e, this._exposeToTestOptions = n, this._fileBlackboard = {}, 
        this._resultsReporter = i, this._runtimeContext = null, this._superDebug = t, this._logBadThingsToLogger = null;
    }
    function a(e) {
        function t(e) {
            if (null != e && "object" == typeof e) {
                if (-1 !== n.indexOf(e)) return console.error("CYCLE with traversal", i), void 0;
                n.push(e), i.push(".");
                var r, s = i.length - 1;
                r = "toJSON" in e ? e.toJSON() : e;
                for (var o in r) if (r.hasOwnProperty(o)) {
                    var a = r[o];
                    i[s] = o, t(a);
                }
                n.pop(), i.pop();
            }
        }
        var n = [], i = [];
        t(e);
    }
    function u(e, i, r, s, o) {
        var a = {
            schema: t.LOGFAB._rawDefs,
            fileFailure: {
                fileName: e,
                moduleName: i,
                variant: r,
                exceptions: s.map(n.transformException)
            }
        };
        o(a);
    }
    function c(e) {
        return function(t) {
            e("##### LOGGEST-TEST-RUN-BEGIN #####");
            try {
                e(JSON.stringify(t));
            } catch (n) {
                console.error("JSON problem:", n.message, n.stack, n);
                try {
                    a(t.log);
                } catch (i) {
                    console.error("exx y", i);
                }
            }
            e("##### LOGGEST-TEST-RUN-END #####");
        };
    }
    var l = t.STEP_TIMEOUT_MS;
    s.prototype = {
        toString: function() {
            return "[TestRuntimeContext]";
        },
        toJSON: function() {
            return {
                type: "TestRuntimeContext"
            };
        },
        pushLogger: function(e) {
            this._loggerStack.push(e);
        },
        popLogger: function(e) {
            var t = this._loggerStack.lastIndexOf(e);
            -1 !== t && this._loggerStack.splice(t, 1);
        },
        reportPendingActor: function(e) {
            var t = e.__defName;
            this._pendingActorsByLoggerType.hasOwnProperty(t) ? this._pendingActorsByLoggerType[t].push(e) : this._pendingActorsByLoggerType[t] = [ e ];
        },
        captureAllLoggersByType: function(e, t) {
            t ? this._captureAllLoggersByType[e] = t : delete this._captureAllLoggersByType[e];
        },
        reportNewLogger: function(e, t) {
            var n = e.__defName;
            if (this._pendingActorsByLoggerType.hasOwnProperty(n) && this._pendingActorsByLoggerType[n].length) {
                var i = this._pendingActorsByLoggerType[n].shift();
                i.__attachToLogger(e);
            } else this._captureAllLoggersByType.hasOwnProperty(n) && "object" != typeof e._ident && (this._captureAllLoggersByType[n][e._ident] = e);
            return !t && this._loggerStack.length ? this._loggerStack[this._loggerStack.length - 1] : t;
        },
        reportActiveActorThisStep: function(e) {
            if (!e) throw new Error("You are passing in a null actor!");
            if (null === this._liveActors) throw new Error("We are not in a step!");
            e._activeForTestStep || (this._liveActors.push(e), e.__prepForTestStep(this));
        },
        peekLogger: function() {
            return this._loggerStack.length ? this._loggerStack[this._loggerStack.length - 1] : null;
        }
    }, r.TestDefinerRunner = o, o.prototype = {
        toString: function() {
            return "[TestDefinerRunner]";
        },
        toJSON: function() {
            return {
                type: "TestDefinerRunner"
            };
        },
        runTestStep: function(t) {
            function n() {
                for (var n = 0; n < o.length; n++) s = o[n], s._logger ? s.__failUnmetExpectations() : t.log.actorNeverGotLogger(s.__defName, s.__name), 
                s.__resetExpectations();
                p._runtimeContext._liveActors = null, e.getAllActiveDeferreds().forEach(function(e) {
                    t.log.unresolvedPromise(e);
                }), i && i(" :( timeout, fail"), t.log.timeout(), t.log.result("fail"), f.resolve(!1), 
                f = null;
            }
            const i = this._superDebug;
            i && i("====== Running Step: " + t.log._ident);
            var r, s;
            this._logBadThingsToLogger = t.log;
            var o = this._runtimeContext._liveActors = t.actors.concat();
            for (r = 0; r < t.actors.length; r++) s = t.actors[r], s.__prepForTestStep(this._runtimeContext);
            t.log.run_begin();
            var a = t.log.stepFunc(null, t.testFunc);
            if (a instanceof Error) return i && i(" :( encountered an error in the step func:", a), 
            t.log.run_end(), t.log.result("fail"), Promise.resolve(!1);
            i && i(" there are", o.length, "live actors this step", "up from", t.actors.length, "step-defined actors");
            var u = [], c = !0;
            for (r = 0; r < o.length; r++) {
                s = o[r];
                var d = s.__waitForExpectations();
                if (d.then) u.push(d), i && i(" actor", s.__defName, s.__name, "generated a promise"); else if (!d) {
                    if (i) {
                        var h;
                        h = s._expectNothing && (s._expectations.length || s._iExpectation) ? "expected nothing, got something" : s._expectationsMetSoFar ? "unsure" : "expectations not met after " + s._iExpectation, 
                        i(" :( waitVal synchronously resolved to false on " + s + " because: " + h);
                    }
                    c = !1;
                }
            }
            if (u.length) {
                var f = new e(), p = this, g = setTimeout(function() {
                    p._superDebug && p._superDebug("!! timeout fired, deferred?", null !== f), f && n();
                }, t.timeoutMS || l);
                return this._superDebug && this._superDebug("waiting on", u.length, "promises"), 
                Promise.all(u).then(function m() {
                    if (p._superDebug && p._superDebug("!! all resolved, deferred?", null !== f), f) {
                        clearTimeout(g);
                        for (var m = !0, e = 0; e < o.length; e++) s = o[e], s.__resetExpectations() || (m = !1, 
                        i && i(" :( weird actor error on: " + s));
                        p._runtimeContext._liveActors = null, t.log.run_end(), t.log.result(m ? "pass" : "fail"), 
                        f.resolve(c), f = null;
                    }
                }, function() {
                    p._superDebug && p._superDebug("!! failed, deferred?", null !== f), f && (clearTimeout(g), 
                    n());
                }), f.promise;
            }
            for (t.log.run_end(), t.log.result(c ? "pass" : "fail"), r = 0; r < o.length; r++) s = o[r], 
            s.__resetExpectations();
            return this._runtimeContext._liveActors = null, Promise.resolve(c);
        },
        skipTestStep: function(e) {
            return e.log.result("skip"), Promise.resolve(!0);
        },
        runTestCasePermutation: function(e) {
            var n = this;
            return new Promise(function(i, r) {
                function s(t) {
                    if (t || (u = !1), c >= o.__steps.length) return n._runtimeContext.popLogger(o._log), 
                    n._superDebug && n._superDebug("========= Done Case: " + e.desc + "\n"), o._log.result(u ? "pass" : "fail"), 
                    o._log.run_end(), e.log.result(u ? "pass" : "fail"), e.log.run_end(), i(u), void 0;
                    var r = o.__steps[c++], a = u || "cleanup" === r.kind;
                    a ? n.runTestStep(r).then(s) : n.skipTestStep(r).then(s);
                }
                n._superDebug && n._superDebug("========= Begin Case: " + e.desc + "\n"), e.log.run_begin();
                var o = new t.TestContext(e, 0);
                this._exposeToTestOptions && this._exposeToTestOptions.variant && (e.log.variant(this._exposeToTestOptions.variant), 
                o.setPermutationVariant(this._exposeToTestOptions.variant)), o._log.run_begin(), 
                n._runtimeContext.pushLogger(o._log);
                var a = o._log.setupFunc({}, e.setupFunc, o, n._runtimeContext);
                a instanceof Error && (n._superDebug && n._superDebug(" :( setup func error thrown!"), 
                o._log.result("fail"), e.log.result("fail"), r(!1)), o.__postSetupFunc();
                var u = !0, c = 0;
                s(!0);
            }.bind(this));
        },
        runTestCase: function(e) {
            return this._runtimeContext = new s(this._exposeToTestOptions, this._fileBlackboard), 
            this._markDefinerUnderTest(this._testDefiner), this.runTestCasePermutation(e, 0);
        },
        _markDefinerUnderTest: function(e) {
            e._runtimeContext = this._runtimeContext;
            for (var t = 0; t < e.__logfabs.length; t++) e.__logfabs[t]._underTest = this._runtimeContext;
        },
        _clearDefinerUnderTest: function(e) {
            e._runtimeContext = null;
            for (var t = 0; t < e.__logfabs.length; t++) e.__logfabs[t]._underTest = null;
        },
        runAll: function(t, n) {
            function i() {
                if (a >= u.__testCases.length) return t.removeListener("exit", r), t.removeListener("uncaughtException", s), 
                u._log.run_end(), c._clearDefinerUnderTest(u), e.clearActiveDeferreds(), o.resolve(c), 
                void 0;
                var n = u.__testCases[a++];
                c.runTestCase(n).then(i);
            }
            function r() {
                console.error("IMMINENT EVENT LOOP TERMINATION IMPLYING BAD TEST, DUMPING LOG."), 
                c.reportResults();
            }
            function s(e) {
                c._logBadThingsToLogger && c._logBadThingsToLogger.uncaughtException(e);
            }
            n && (l = n);
            var o = new e("TestDefinerRunner.runAll"), a = 0, u = this._testDefiner, c = this;
            return u._log.run_begin(), t.once("exit", r), t.on("uncaughtException", s), e.setUnhandledRejectionHandler(s), 
            i(), o.promise;
        },
        reportResults: function() {
            var e, n, i = this._testDefiner, r = {};
            n = t.LOGFAB._rawDefs;
            for (e in n) r[e] = n[e];
            n = t.__LAZYLOGFAB._rawDefs;
            for (e in n) r[e] = n[e];
            for (var s = 0; s < i.__logfabs.length; s++) {
                n = i.__logfabs[s]._rawDefs;
                for (e in n) r[e] = n[e];
            }
            var o = {
                schema: r,
                log: i._log
            };
            this._resultsReporter(o);
        }
    }, r.runTestsFromModule = function(t, n, r, s) {
        function a() {
            s && s('All tests in "' + t + '" run, ' + "generating results."), d.reportResults(), 
            h.resolve(!0);
        }
        var d, h = new e("runTestsFromModule:" + t), f = n.resultsReporter || c(r.reliableOutput), p = null;
        n && n.variant && (p = n.variant);
        var g = !1;
        return r.callbackOnError(function(e, n) {
            g || (u(t, n, p, [ e ], f), h.resolve(!0), g = !0);
        }), i([ t ], function(e) {
            var i = r.gobbleAndStopTrappingErrors();
            if (!g) {
                if (i.length) return u(t, "", p, i, f), h.resolve(!0), void 0;
                if (!e.TD) {
                    var c = new Error("Test module: '" + t + "' does not export a 'TD' symbol!");
                    return u(t, t, p, [ c ], f), h.resolve(!0), void 0;
                }
                n.hasOwnProperty("defaultStepDuration") && (l = n.defaultStepDuration), d = new o(e.TD, s, n.exposeToTest, f), 
                d.runAll(r).then(a, a);
            }
        }), h.promise;
    };
});