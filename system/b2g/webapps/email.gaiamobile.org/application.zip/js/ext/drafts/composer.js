define([ "mailbuild", "../mailchew", "../util" ], function(e, t, n) {
    function i(e) {
        return e.replace(/\r?\n|\r/g, "\r\n");
    }
    function o(n, o, r) {
        var a = this.header = n.header, c = this.body = n.body;
        this.account = o, this.identity = r, this.sentDate = new Date(this.header.date), 
        this._smartWakeLock = null, this.messageId = "<" + Date.now() + Math.random().toString(16).substr(1) + "@mozgaia>";
        var l, d = c.bodyReps[0].content[1];
        if (2 === c.bodyReps.length) {
            var u = c.bodyReps[1].content;
            l = new e("text/html"), l.setContent(i(t.mergeUserTextWithHTML(d, u)));
        } else l = new e("text/plain"), l.setContent(i(d));
        var p;
        c.attachments.length ? (p = this._rootNode = new e("multipart/mixed"), p.appendChild(l)) : p = this._rootNode = l, 
        p.setHeader("From", s([ this.identity ])), p.setHeader("Subject", a.subject), this.identity.replyTo && p.setHeader("Reply-To", this.identity.replyTo), 
        a.to && a.to.length && p.setHeader("To", s(a.to)), a.cc && a.cc.length && p.setHeader("Cc", s(a.cc)), 
        a.bcc && a.bcc.length && p.setHeader("Bcc", s(a.bcc)), p.setHeader("User-Agent", "GaiaMail/0.2"), 
        p.setHeader("Date", this.sentDate.toUTCString()), p.setHeader("Message-Id", this.messageId), 
        c.references && p.setHeader("References", c.references), p.setHeader("Content-Transfer-Encoding", "quoted-printable"), 
        this._blobReplacements = [], this._uniqueBlobBoundary = "{{blob!" + Math.random() + Date.now() + "}}", 
        c.attachments.forEach(function(t) {
            try {
                var n = new e(t.type, {
                    filename: t.name
                });
                n.setContent(this._uniqueBlobBoundary), p.appendChild(n), this._blobReplacements.push(new Blob(t.file));
            } catch (i) {
                console.error("Problem attaching attachment:", i, "\n", i.stack);
            }
        }.bind(this));
    }
    var s = n.formatAddresses;
    return e.prototype.removeHeader = function(e) {
        for (var t = 0, n = this._headers.length; n > t; t++) if (this._headers[t].key === e) {
            this._headers.splice(t, 1);
            break;
        }
    }, o.prototype = {
        getEnvelope: function() {
            return this._rootNode.getEnvelope();
        },
        withMessageBlob: function(e, t) {
            var n = "Bcc-Temp", i = /^Bcc-Temp: /m, o = e.includeBcc && this.header.bcc && this.header.bcc.length;
            o ? this._rootNode.setHeader(n, s(this.header.bcc)) : this._rootNode.removeHeader(n);
            var r = this._rootNode.build();
            o && (r = r.replace(i, "Bcc: ")), "\r\n" !== r.slice(-2) && (r += "\r\n");
            var a = r.split(btoa(this._uniqueBlobBoundary) + "\r\n");
            this._blobReplacements.forEach(function(e, t) {
                a.splice(2 * t + 1, 0, e);
            }), t(new Blob(a, {
                type: this._rootNode.getHeader("content-type")
            }));
        },
        setSmartWakeLock: function(e) {
            this._smartWakeLock = e;
        },
        renewSmartWakeLock: function(e) {
            this._smartWakeLock && this._smartWakeLock.renew(e);
        }
    }, {
        Composer: o
    };
});