function plog(e) {
    console.log(e + " " + (performance.now() - _xstart));
}

var _xstart = performance.timing.fetchStart - performance.timing.navigationStart, startupCacheEventsSent = !1, HTML_COOKIE_CACHE_VERSION = '65ff316b40d272bdc9de8a1b8a1c8e7dd44c7bb5';

window.htmlCacheRestorePendingMessage = [], function() {
    var e = window.performance, t = window.console;
    if ("function" != typeof e.mark) {
        var n = function(e) {
            setTimeout(function() {
                var n = "Performance Entry: " + e.entryType + "|" + e.name + "|" + e.startTime + "|" + e.duration + "|" + (e.time || 0);
                t.log(n);
            }, 0);
        }, i = {};
        e.mark = function(t) {
            var o = e.now(), s = Date.now();
            if ("undefined" == typeof t) throw new SyntaxError("Mark name must be specified");
            if (e.timing && t in e.timing) throw new SyntaxError("Mark name is not allowed");
            i[t] || (i[t] = []), i[t].push(o), n({
                entryType: "mark",
                name: t,
                startTime: o,
                duration: 0,
                time: s
            });
        }, e.measure = function(t, o, s) {
            var r = e.now(), a = Date.now();
            if (!t) throw new Error("Measure must be specified");
            if (!o) return n({
                entryType: "measure",
                name: t,
                startTime: 0,
                duration: r,
                time: a
            }), void 0;
            var c = 0;
            if (e.timing && o in e.timing) {
                if ("navigationStart" !== o && 0 === e.timing[o]) throw new Error(o + " has a timing of 0");
                c = e.timing[o] - e.timing.navigationStart;
            } else {
                if (!(o in i)) throw new Error(o + " mark not found");
                c = i[o][i[o].length - 1];
            }
            var l = r;
            if (s) if (l = 0, e.timing && s in e.timing) {
                if ("navigationStart" !== s && 0 === e.timing[s]) throw new Error(s + " has a timing of 0");
                l = e.timing[s] - e.timing.navigationStart;
            } else {
                if (!(s in i)) throw new Error(s + " mark not found");
                l = i[s][i[s].length - 1];
            }
            var d = l - c;
            n({
                entryType: "measure",
                name: t,
                startTime: c,
                duration: d,
                time: a
            });
        };
    }
}(), function() {
    function e() {
        for (var e, t, n, i, o = document.cookie, s = /htmlc(\d+)=([^;]+)/g, r = []; e = s.exec(o); ) r[parseInt(e[1], 10)] = e[2] || "";
        if (o = decodeURIComponent(r.join("")), t = o.indexOf(":"), -1 === t) o = ""; else {
            n = o.substring(0, t), o = o.substring(t + 1);
            var a = n.split(",");
            n = a[0], i = a[1];
        }
        return n !== HTML_COOKIE_CACHE_VERSION && (console.log("Skipping cookie cache, out of date. Expected " + HTML_COOKIE_CACHE_VERSION + " but found " + n), 
        o = ""), {
            langDir: i,
            contents: o
        };
    }
    function t() {
        var e = document.createElement("script");
        o ? (e.setAttribute("data-main", s), e.src = o) : e.src = s, document.head.appendChild(e);
    }
    function n(e) {
        if (window.mozPerfHasListener) {
            var t = window.performance.now(), n = Date.now();
            setTimeout(function() {
                var i = {
                    name: e,
                    timestamp: t,
                    epoch: n
                }, o = new CustomEvent("x-moz-perf", {
                    detail: i
                });
                window.dispatchEvent(o);
            });
        }
    }
    var i = document.querySelector("[data-loadsrc]"), o = i.dataset.loader, s = i.dataset.loadsrc, r = document.getElementById(i.dataset.targetid);
    if (navigator.mozHasPendingMessage && (navigator.mozHasPendingMessage("activity") && window.htmlCacheRestorePendingMessage.push("activity"), 
    navigator.mozHasPendingMessage("alarm") && window.htmlCacheRestorePendingMessage.push("alarm"), 
    navigator.mozHasPendingMessage("notification") && window.htmlCacheRestorePendingMessage.push("notification")), 
    window.htmlCacheRestorePendingMessage.length) t(); else {
        var a = e();
        a.langDir && document.querySelector("html").setAttribute("dir", a.langDir);
        var c = a.contents;
        r.innerHTML = c, startupCacheEventsSent = !!c, window.addEventListener("load", t, !1);
    }
    [ "moz-chrome-dom-loaded", "moz-chrome-interactive", "moz-app-visually-complete", "moz-content-interactive", "moz-app-loaded" ].forEach(function(e) {
        window.addEventListener(e, function() {
            n(e);
        }, !1);
    }), window.PerformanceTestingHelper = {
        dispatch: n
    }, startupCacheEventsSent && (window.performance.mark("navigationLoaded"), window.dispatchEvent(new CustomEvent("moz-chrome-dom-loaded")), 
    window.performance.mark("visuallyLoaded"), window.dispatchEvent(new CustomEvent("moz-app-visually-complete")));
}();