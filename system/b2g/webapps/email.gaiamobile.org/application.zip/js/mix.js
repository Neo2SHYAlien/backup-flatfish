define([], function() {
    return function(e, t, n) {
        return Object.keys(t).forEach(function(i) {
            (!e.hasOwnProperty(i) || n) && (e[i] = t[i]);
        }), e;
    };
});