define([ "require", "l10n!", "shared/js/mime_mapper" ], function(e) {
    var t = e("l10n!"), n = e("shared/js/mime_mapper"), i = {
        ensureName: function(e, i, s) {
            if (!i) {
                s = s || 1;
                var o = n.guessExtensionFromType(e.type);
                i = t.get("default-attachment-filename", {
                    n: s
                }) + (o ? "." + o : "");
            }
            return i;
        },
        ensureNameList: function(e, t) {
            for (var n = 0; n < e.length; n++) t[n] = i.ensureName(e[n], t[n], n + 1);
        }
    };
    return i;
});