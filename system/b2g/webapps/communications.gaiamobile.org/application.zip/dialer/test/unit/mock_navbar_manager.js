/* exported MockNavbarManager */

(function(exports) {
  'use strict';

  var MockNavbarManager = {
    init: function() {}
  };

  exports.MockNavbarManager = MockNavbarManager;
})(this);
