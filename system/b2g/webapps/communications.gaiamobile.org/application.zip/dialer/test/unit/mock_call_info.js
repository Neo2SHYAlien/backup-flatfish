'use strict';

/* exported MockCallInfo */

var MockCallInfo = {
  show: function(number, day, type) {}
};
