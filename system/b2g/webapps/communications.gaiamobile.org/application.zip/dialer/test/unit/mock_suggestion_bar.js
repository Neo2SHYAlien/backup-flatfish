/* exported MockSuggestionBar */

'use strict';

var MockSuggestionBar = {
  handleEvent: function msb_handleEvent(event) {},
  update: function msb_update(number) {},
  clear: function msb_clear(isHardClear) {},
  showOverlay: function msb_showOverlay() {},
  hideOverlay: function msb_hideOverlay() {}
};
