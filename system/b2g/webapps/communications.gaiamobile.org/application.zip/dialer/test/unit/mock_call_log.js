'use strict';

/* exported MockCallLog */

var MockCallLog = {
  init: function() {},
  appendGroup: function(group) {
  }
};

