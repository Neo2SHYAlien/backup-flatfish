'use strict';
/* exported MockContactsNfc */

var MockContactsNfc = {
  startListening: function() {},
  stopListening: function() {}
};
