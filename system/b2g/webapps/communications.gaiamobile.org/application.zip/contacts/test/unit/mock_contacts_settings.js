'use strict';
/* exported MockContactsSettings */

var MockContactsSettings = {
  init: function() {},
  close: function() {},
  refresh: function() {},
  cardStateChanged: function() {},
  updateTimestamps: function() {},
  navigation: {
    go: function() {}
  }
};
