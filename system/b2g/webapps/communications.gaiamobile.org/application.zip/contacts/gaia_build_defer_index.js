;(function(window,undefined){'use strict';function L10nError(message,id,loc){this.name='L10nError';this.message=message;this.id=id;this.loc=loc;}
L10nError.prototype=Object.create(Error.prototype);L10nError.prototype.constructor=L10nError;var io={load:function load(url,callback,sync){var xhr=new XMLHttpRequest();if(xhr.overrideMimeType){xhr.overrideMimeType('text/plain');}
xhr.open('GET',url,!sync);xhr.addEventListener('load',function io_load(e){if(e.target.status===200||e.target.status===0){callback(null,e.target.responseText);}else{callback(new L10nError('Not found: '+url));}});xhr.addEventListener('error',callback);xhr.addEventListener('timeout',callback);try{xhr.send(null);}catch(e){callback(new L10nError('Not found: '+url));}},loadJSON:function loadJSON(url,callback){var xhr=new XMLHttpRequest();if(xhr.overrideMimeType){xhr.overrideMimeType('application/json');}
xhr.open('GET',url);xhr.responseType='json';xhr.addEventListener('load',function io_loadjson(e){if(e.target.status===200||e.target.status===0){callback(null,e.target.response);}else{callback(new L10nError('Not found: '+url));}});xhr.addEventListener('error',callback);xhr.addEventListener('timeout',callback);try{xhr.send(null);}catch(e){callback(new L10nError('Not found: '+url));}}};function EventEmitter(){}
EventEmitter.prototype.emit=function ee_emit(){if(!this._listeners){return;}
var args=Array.prototype.slice.call(arguments);var type=args.shift();if(!this._listeners[type]){return;}
var typeListeners=this._listeners[type].slice();for(var i=0;i<typeListeners.length;i++){typeListeners[i].apply(this,args);}};EventEmitter.prototype.addEventListener=function ee_add(type,listener){if(!this._listeners){this._listeners={};}
if(!(type in this._listeners)){this._listeners[type]=[];}
this._listeners[type].push(listener);};EventEmitter.prototype.removeEventListener=function ee_rm(type,listener){if(!this._listeners){return;}
var typeListeners=this._listeners[type];var pos=typeListeners.indexOf(listener);if(pos===-1){return;}
typeListeners.splice(pos,1);};function getPluralRule(lang){var locales2rules={'af':3,'ak':4,'am':4,'ar':1,'asa':3,'az':0,'be':11,'bem':3,'bez':3,'bg':3,'bh':4,'bm':0,'bn':3,'bo':0,'br':20,'brx':3,'bs':11,'ca':3,'cgg':3,'chr':3,'cs':12,'cy':17,'da':3,'de':3,'dv':3,'dz':0,'ee':3,'el':3,'en':3,'eo':3,'es':3,'et':3,'eu':3,'fa':0,'ff':5,'fi':3,'fil':4,'fo':3,'fr':5,'fur':3,'fy':3,'ga':8,'gd':24,'gl':3,'gsw':3,'gu':3,'guw':4,'gv':23,'ha':3,'haw':3,'he':2,'hi':4,'hr':11,'hu':0,'id':0,'ig':0,'ii':0,'is':3,'it':3,'iu':7,'ja':0,'jmc':3,'jv':0,'ka':0,'kab':5,'kaj':3,'kcg':3,'kde':0,'kea':0,'kk':3,'kl':3,'km':0,'kn':0,'ko':0,'ksb':3,'ksh':21,'ku':3,'kw':7,'lag':18,'lb':3,'lg':3,'ln':4,'lo':0,'lt':10,'lv':6,'mas':3,'mg':4,'mk':16,'ml':3,'mn':3,'mo':9,'mr':3,'ms':0,'mt':15,'my':0,'nah':3,'naq':7,'nb':3,'nd':3,'ne':3,'nl':3,'nn':3,'no':3,'nr':3,'nso':4,'ny':3,'nyn':3,'om':3,'or':3,'pa':3,'pap':3,'pl':13,'ps':3,'pt':3,'rm':3,'ro':9,'rof':3,'ru':11,'rwk':3,'sah':0,'saq':3,'se':7,'seh':3,'ses':0,'sg':0,'sh':11,'shi':19,'sk':12,'sl':14,'sma':7,'smi':7,'smj':7,'smn':7,'sms':7,'sn':3,'so':3,'sq':3,'sr':11,'ss':3,'ssy':3,'st':3,'sv':3,'sw':3,'syr':3,'ta':3,'te':3,'teo':3,'th':0,'ti':4,'tig':3,'tk':3,'tl':4,'tn':3,'to':0,'tr':0,'ts':3,'tzm':22,'uk':11,'ur':3,'ve':3,'vi':0,'vun':3,'wa':4,'wae':3,'wo':0,'xh':3,'xog':3,'yo':0,'zh':0,'zu':3};function isIn(n,list){return list.indexOf(n)!==-1;}
function isBetween(n,start,end){return typeof n===typeof start&&start<=n&&n<=end;}
var pluralRules={'0':function(){return'other';},'1':function(n){if((isBetween((n%100),3,10))){return'few';}
if(n===0){return'zero';}
if((isBetween((n%100),11,99))){return'many';}
if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'2':function(n){if(n!==0&&(n%10)===0){return'many';}
if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'3':function(n){if(n===1){return'one';}
return'other';},'4':function(n){if((isBetween(n,0,1))){return'one';}
return'other';},'5':function(n){if((isBetween(n,0,2))&&n!==2){return'one';}
return'other';},'6':function(n){if(n===0){return'zero';}
if((n%10)===1&&(n%100)!==11){return'one';}
return'other';},'7':function(n){if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'8':function(n){if((isBetween(n,3,6))){return'few';}
if((isBetween(n,7,10))){return'many';}
if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'9':function(n){if(n===0||n!==1&&(isBetween((n%100),1,19))){return'few';}
if(n===1){return'one';}
return'other';},'10':function(n){if((isBetween((n%10),2,9))&&!(isBetween((n%100),11,19))){return'few';}
if((n%10)===1&&!(isBetween((n%100),11,19))){return'one';}
return'other';},'11':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14))){return'few';}
if((n%10)===0||(isBetween((n%10),5,9))||(isBetween((n%100),11,14))){return'many';}
if((n%10)===1&&(n%100)!==11){return'one';}
return'other';},'12':function(n){if((isBetween(n,2,4))){return'few';}
if(n===1){return'one';}
return'other';},'13':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14))){return'few';}
if(n!==1&&(isBetween((n%10),0,1))||(isBetween((n%10),5,9))||(isBetween((n%100),12,14))){return'many';}
if(n===1){return'one';}
return'other';},'14':function(n){if((isBetween((n%100),3,4))){return'few';}
if((n%100)===2){return'two';}
if((n%100)===1){return'one';}
return'other';},'15':function(n){if(n===0||(isBetween((n%100),2,10))){return'few';}
if((isBetween((n%100),11,19))){return'many';}
if(n===1){return'one';}
return'other';},'16':function(n){if((n%10)===1&&n!==11){return'one';}
return'other';},'17':function(n){if(n===3){return'few';}
if(n===0){return'zero';}
if(n===6){return'many';}
if(n===2){return'two';}
if(n===1){return'one';}
return'other';},'18':function(n){if(n===0){return'zero';}
if((isBetween(n,0,2))&&n!==0&&n!==2){return'one';}
return'other';},'19':function(n){if((isBetween(n,2,10))){return'few';}
if((isBetween(n,0,1))){return'one';}
return'other';},'20':function(n){if((isBetween((n%10),3,4)||((n%10)===9))&&!(isBetween((n%100),10,19)||isBetween((n%100),70,79)||isBetween((n%100),90,99))){return'few';}
if((n%1000000)===0&&n!==0){return'many';}
if((n%10)===2&&!isIn((n%100),[12,72,92])){return'two';}
if((n%10)===1&&!isIn((n%100),[11,71,91])){return'one';}
return'other';},'21':function(n){if(n===0){return'zero';}
if(n===1){return'one';}
return'other';},'22':function(n){if((isBetween(n,0,1))||(isBetween(n,11,99))){return'one';}
return'other';},'23':function(n){if((isBetween((n%10),1,2))||(n%20)===0){return'one';}
return'other';},'24':function(n){if((isBetween(n,3,10)||isBetween(n,13,19))){return'few';}
if(isIn(n,[2,12])){return'two';}
if(isIn(n,[1,11])){return'one';}
return'other';}};var index=locales2rules[lang.replace(/-.*$/,'')];if(!(index in pluralRules)){return function(){return'other';};}
return pluralRules[index];}
var MAX_PLACEABLES=100;var PropertiesParser={patterns:null,entryIds:null,init:function(){this.patterns={comment:/^\s*#|^\s*$/,entity:/^([^=\s]+)\s*=\s*(.+)$/,multiline:/[^\\]\\$/,index:/\{\[\s*(\w+)(?:\(([^\)]*)\))?\s*\]\}/i,unicode:/\\u([0-9a-fA-F]{1,4})/g,entries:/[^\r\n]+/g,controlChars:/\\([\\\n\r\t\b\f\{\}\"\'])/g,placeables:/\{\{\s*([^\s]*?)\s*\}\}/,};},parse:function(ctx,source){if(!this.patterns){this.init();}
var ast=[];this.entryIds=Object.create(null);var entries=source.match(this.patterns.entries);if(!entries){return ast;}
for(var i=0;i<entries.length;i++){var line=entries[i];if(this.patterns.comment.test(line)){continue;}
while(this.patterns.multiline.test(line)&&i<entries.length){line=line.slice(0,-1)+entries[++i].trim();}
var entityMatch=line.match(this.patterns.entity);if(entityMatch){try{this.parseEntity(entityMatch[1],entityMatch[2],ast);}catch(e){if(ctx){ctx._emitter.emit('parseerror',e);}else{throw e;}}}}
return ast;},parseEntity:function(id,value,ast){var name,key;var pos=id.indexOf('[');if(pos!==-1){name=id.substr(0,pos);key=id.substring(pos+1,id.length-1);}else{name=id;key=null;}
var nameElements=name.split('.');if(nameElements.length>2){throw new L10nError('Error in ID: "'+name+'".'+' Nested attributes are not supported.');}
var attr;if(nameElements.length>1){name=nameElements[0];attr=nameElements[1];if(attr[0]==='$'){throw new L10nError('Attribute can\'t start with "$"',id);}}else{attr=null;}
this.setEntityValue(name,attr,key,this.unescapeString(value),ast);},setEntityValue:function(id,attr,key,value,ast){var pos,v;if(value.indexOf('{{')!==-1){value=this.parseString(value);}
if(attr){pos=this.entryIds[id];if(pos===undefined){v={$i:id};if(key){v[attr]={};v[attr][key]=value;}else{v[attr]=value;}
ast.push(v);this.entryIds[id]=ast.length-1;return;}
if(key){if(typeof(ast[pos][attr])==='string'){ast[pos][attr]={$x:this.parseIndex(ast[pos][attr]),$v:{}};}
ast[pos][attr].$v[key]=value;return;}
ast[pos][attr]=value;return;}
if(key){pos=this.entryIds[id];if(pos===undefined){v={};v[key]=value;ast.push({$i:id,$v:v});this.entryIds[id]=ast.length-1;return;}
if(typeof(ast[pos].$v)==='string'){ast[pos].$x=this.parseIndex(ast[pos].$v);ast[pos].$v={};}
ast[pos].$v[key]=value;return;}
ast.push({$i:id,$v:value});this.entryIds[id]=ast.length-1;},parseString:function(str){var chunks=str.split(this.patterns.placeables);var complexStr=[];var len=chunks.length;var placeablesCount=(len-1)/2;if(placeablesCount>=MAX_PLACEABLES){throw new L10nError('Too many placeables ('+placeablesCount+', max allowed is '+MAX_PLACEABLES+')');}
for(var i=0;i<chunks.length;i++){if(chunks[i].length===0){continue;}
if(i%2===1){complexStr.push({t:'idOrVar',v:chunks[i]});}else{complexStr.push(chunks[i]);}}
return complexStr;},unescapeString:function(str){if(str.lastIndexOf('\\')!==-1){str=str.replace(this.patterns.controlChars,'$1');}
return str.replace(this.patterns.unicode,function(match,token){return unescape('%u'+'0000'.slice(token.length)+token);});},parseIndex:function(str){var match=str.match(this.patterns.index);if(!match){throw new L10nError('Malformed index');}
if(match[2]){return[{t:'idOrVar',v:match[1]},match[2]];}else{return[{t:'idOrVar',v:match[1]}];}}};var KNOWN_MACROS=['plural'];var MAX_PLACEABLE_LENGTH=2500;var rePlaceables=/\{\{\s*(.+?)\s*\}\}/g;function createEntry(node,env){var keys=Object.keys(node);if(typeof node.$v==='string'&&keys.length===2){return node.$v;}
var attrs;for(var i=0,key;key=keys[i];i++){if(key[0]==='$'){continue;}
if(!attrs){attrs=Object.create(null);}
attrs[key]=createAttribute(node[key],env,node.$i+'.'+key);}
return{id:node.$i,value:node.$v===undefined?null:node.$v,index:node.$x||null,attrs:attrs||null,env:env,dirty:false};}
function createAttribute(node,env,id){if(typeof node==='string'){return node;}
var value;if(Array.isArray(node)){value=node;}
return{id:id,value:value||node.$v||null,index:node.$x||null,env:env,dirty:false};}
function format(args,entity){if(typeof entity==='string'){return entity;}
if(entity.dirty){throw new L10nError('Cyclic reference detected: '+entity.id);}
entity.dirty=true;var val;try{val=resolveValue(args,entity.env,entity.value,entity.index);}finally{entity.dirty=false;}
return val;}
function resolveIdentifier(args,env,id){if(KNOWN_MACROS.indexOf(id)>-1){return env['__'+id];}
if(args&&args.hasOwnProperty(id)){if(typeof args[id]==='string'||(typeof args[id]==='number'&&!isNaN(args[id]))){return args[id];}else{throw new L10nError('Arg must be a string or a number: '+id);}}
if(id in env&&id!=='__proto__'){return format(args,env[id]);}
throw new L10nError('Unknown reference: '+id);}
function subPlaceable(args,env,id){var value;try{value=resolveIdentifier(args,env,id);}catch(err){return'{{ '+id+' }}';}
if(typeof value==='number'){return value;}
if(typeof value==='string'){if(value.length>=MAX_PLACEABLE_LENGTH){throw new L10nError('Too many characters in placeable ('+
value.length+', max allowed is '+
MAX_PLACEABLE_LENGTH+')');}
return value;}
return'{{ '+id+' }}';}
function interpolate(args,env,arr){return arr.reduce(function(prev,cur){if(typeof cur==='string'){return prev+cur;}else if(cur.t==='idOrVar'){return prev+subPlaceable(args,env,cur.v);}},'');}
function resolveSelector(args,env,expr,index){var selectorName=index[0].v;var selector=resolveIdentifier(args,env,selectorName);if(typeof selector!=='function'){return selector;}
var argValue=index[1]?resolveIdentifier(args,env,index[1]):undefined;if(selector===env.__plural){if(argValue===0&&'zero'in expr){return'zero';}
if(argValue===1&&'one'in expr){return'one';}
if(argValue===2&&'two'in expr){return'two';}}
return selector(argValue);}
function resolveValue(args,env,expr,index){if(typeof expr==='string'||typeof expr==='boolean'||typeof expr==='number'||!expr){return expr;}
if(Array.isArray(expr)){return interpolate(args,env,expr);}
if(index){var selector=resolveSelector(args,env,expr,index);if(expr.hasOwnProperty(selector)){return resolveValue(args,env,expr[selector]);}}
if('other'in expr){return resolveValue(args,env,expr.other);}
throw new L10nError('Unresolvable value');}
var Resolver={createEntry:createEntry,format:format,rePlaceables:rePlaceables};function walkContent(node,fn){if(typeof node==='string'){return fn(node);}
if(node.t==='idOrVar'){return node;}
var rv=Array.isArray(node)?[]:{};var keys=Object.keys(node);for(var i=0,key;key=keys[i];i++){if(key==='$i'||key==='$x'){rv[key]=node[key];}else{rv[key]=walkContent(node[key],fn);}}
return rv;}
var reAlphas=/[a-zA-Z]/g;var reVowels=/[aeiouAEIOU]/g;var ACCENTED_MAP='\u0226\u0181\u0187\u1E12\u1E16\u0191\u0193\u0126\u012A'+'\u0134\u0136\u013F\u1E3E\u0220\u01FE\u01A4\u024A\u0158'+'\u015E\u0166\u016C\u1E7C\u1E86\u1E8A\u1E8E\u1E90'+'[\\]^_`'+'\u0227\u0180\u0188\u1E13\u1E17\u0192\u0260\u0127\u012B'+'\u0135\u0137\u0140\u1E3F\u019E\u01FF\u01A5\u024B\u0159'+'\u015F\u0167\u016D\u1E7D\u1E87\u1E8B\u1E8F\u1E91';var FLIPPED_MAP='\u2200\u0510\u2183p\u018E\u025F\u05E4HI\u017F'+'\u04FC\u02E5WNO\u0500\xD2\u1D1AS\u22A5\u2229\u0245'+'\uFF2DX\u028EZ'+'[\\]\u1D65_,'+'\u0250q\u0254p\u01DD\u025F\u0183\u0265\u0131\u027E'+'\u029E\u0285\u026Fuodb\u0279s\u0287n\u028C\u028Dx\u028Ez';function makeLonger(val){return val.replace(reVowels,function(match){return match+match.toLowerCase();});}
function makeAccented(map,val){return val.replace(reAlphas,function(match){return map.charAt(match.charCodeAt(0)-65);});}
var reWords=/[^\W0-9_]+/g;function makeRTL(val){return val.replace(reWords,function(match){return'\u202e'+match+'\u202c';});}
var reExcluded=/(%[EO]?\w|\{\s*.+?\s*\})/;function mapContent(fn,val){if(!val){return val;}
var parts=val.split(reExcluded);var modified=parts.map(function(part){if(reExcluded.test(part)){return part;}
return fn(part);});return modified.join('');}
function Pseudo(id,name,charMap,modFn){this.id=id;this.translate=mapContent.bind(null,function(val){return makeAccented(charMap,modFn(val));});this.name=this.translate(name);}
var PSEUDO_STRATEGIES={'qps-ploc':new Pseudo('qps-ploc','Accented English',ACCENTED_MAP,makeLonger),'qps-plocm':new Pseudo('qps-plocm','Mirrored English',FLIPPED_MAP,makeRTL)};function Locale(id,ctx){this.id=id;this.ctx=ctx;this.isReady=false;this.isPseudo=PSEUDO_STRATEGIES.hasOwnProperty(id);this.entries=Object.create(null);this.entries.__plural=getPluralRule(this.isPseudo?this.ctx.defaultLocale:id);}
Locale.prototype.build=function L_build(callback){var sync=!callback;var ctx=this.ctx;var self=this;var l10nLoads=ctx.resLinks.length;function onL10nLoaded(err){if(err){ctx._emitter.emit('fetcherror',err);}
if(--l10nLoads<=0){self.isReady=true;if(callback){callback();}}}
if(l10nLoads===0){onL10nLoaded();return;}
function onJSONLoaded(err,json){if(!err&&json){self.addAST(json);}
onL10nLoaded(err);}
function onPropLoaded(err,source){if(!err&&source){var ast=PropertiesParser.parse(ctx,source);self.addAST(ast);}
onL10nLoaded(err);}
var idToFetch=this.isPseudo?ctx.defaultLocale:this.id;for(var i=0;i<ctx.resLinks.length;i++){var resLink=decodeURI(ctx.resLinks[i]);var path=resLink.replace('{locale}',idToFetch);var type=path.substr(path.lastIndexOf('.')+1);switch(type){case'json':io.loadJSON(path,onJSONLoaded,sync);break;case'properties':io.load(path,onPropLoaded,sync);break;}}};function createPseudoEntry(node,entries){return Resolver.createEntry(walkContent(node,PSEUDO_STRATEGIES[this.id].translate),entries);}
Locale.prototype.addAST=function(ast){var createEntry=this.isPseudo?createPseudoEntry.bind(this):Resolver.createEntry;for(var i=0,node;node=ast[i];i++){this.entries[node.$i]=createEntry(node,this.entries);}};function Context(id){this.id=id;this.isReady=false;this.isLoading=false;this.defaultLocale='en-US';this.availableLocales=[];this.supportedLocales=[];this.resLinks=[];this.locales={};this._emitter=new EventEmitter();this._ready=new Promise(this.once.bind(this));}
function reportMissing(id,err){this._emitter.emit('notfounderror',err);return id;}
function getWithFallback(id){var cur=0;var loc;var locale;while(loc=this.supportedLocales[cur]){locale=this.getLocale(loc);if(!locale.isReady){locale.build(null);}
var entry=locale.entries[id];if(entry===undefined){cur++;reportMissing.call(this,id,new L10nError('"'+id+'"'+' not found in '+loc+' in '+this.id,id,loc));continue;}
return entry;}
throw new L10nError('"'+id+'"'+' missing from all supported locales in '+this.id,id);}
function formatValue(args,entity){if(typeof entity==='string'){return entity;}
try{return Resolver.format(args,entity);}catch(err){this._emitter.emit('resolveerror',err);return entity.id;}}
function formatEntity(args,entity){if(!entity.attrs){return{value:formatValue.call(this,args,entity),attrs:null};}
var formatted={value:formatValue.call(this,args,entity),attrs:Object.create(null)};for(var key in entity.attrs){formatted.attrs[key]=formatValue.call(this,args,entity.attrs[key]);}
return formatted;}
function formatAsync(fn,id,args){return this._ready.then(getWithFallback.bind(this,id)).then(fn.bind(this,args),reportMissing.bind(this,id));}
Context.prototype.formatValue=function(id,args){return formatAsync.call(this,formatValue,id,args);};Context.prototype.formatEntity=function(id,args){return formatAsync.call(this,formatEntity,id,args);};function legacyGet(fn,id,args){if(!this.isReady){throw new L10nError('Context not ready');}
var entry;try{entry=getWithFallback.call(this,id);}catch(err){if(err.loc){throw err;}
reportMissing.call(this,id,err);return'';}
return fn.call(this,args,entry);}
Context.prototype.get=function(id,args){return legacyGet.call(this,formatValue,id,args);};Context.prototype.getEntity=function(id,args){return legacyGet.call(this,formatEntity,id,args);};Context.prototype.getLocale=function getLocale(code){var locales=this.locales;if(locales[code]){return locales[code];}
return locales[code]=new Locale(code,this);};function negotiate(available,requested,defaultLocale){if(available.indexOf(requested[0])===-1||requested[0]===defaultLocale){return[defaultLocale];}else{return[requested[0],defaultLocale];}}
function freeze(supported){var locale=this.getLocale(supported[0]);if(locale.isReady){setReady.call(this,supported);}else{locale.build(setReady.bind(this,supported));}}
function setReady(supported){this.supportedLocales=supported;this.isReady=true;this._emitter.emit('ready');}
Context.prototype.registerLocales=function(defLocale,available){this.availableLocales=[this.defaultLocale=defLocale];if(available){for(var i=0,loc;loc=available[i];i++){if(this.availableLocales.indexOf(loc)===-1){this.availableLocales.push(loc);}}}};Context.prototype.requestLocales=function requestLocales(){if(this.isLoading&&!this.isReady){throw new L10nError('Context not ready');}
this.isLoading=true;var requested=Array.prototype.slice.call(arguments);if(requested.length===0){throw new L10nError('No locales requested');}
var reqPseudo=requested.filter(function(loc){return loc in PSEUDO_STRATEGIES;});var supported=negotiate(this.availableLocales.concat(reqPseudo),requested,this.defaultLocale);freeze.call(this,supported);};Context.prototype.addEventListener=function(type,listener){this._emitter.addEventListener(type,listener);};Context.prototype.removeEventListener=function(type,listener){this._emitter.removeEventListener(type,listener);};Context.prototype.ready=function(callback){if(this.isReady){setTimeout(callback);}
this.addEventListener('ready',callback);};Context.prototype.once=function(callback){if(this.isReady){setTimeout(callback);return;}
var callAndRemove=(function(){this.removeEventListener('ready',callAndRemove);callback();}).bind(this);this.addEventListener('ready',callAndRemove);};var DEBUG=false;var isPretranslated=false;var rtlList=['ar','he','fa','ps','qps-plocm','ur'];var nodeObserver=null;var pendingElements=null;var meta={};var moConfig={attributes:true,characterData:false,childList:true,subtree:true,attributeFilter:['data-l10n-id','data-l10n-args']};navigator.mozL10n={ctx:new Context(window.document?document.URL:null),get:function get(id,ctxdata){return navigator.mozL10n.ctx.get(id,ctxdata);},formatValue:function(id,ctxdata){return navigator.mozL10n.ctx.formatValue(id,ctxdata);},formatEntity:function(id,ctxdata){return navigator.mozL10n.ctx.formatEntity(id,ctxdata);},translateFragment:function(fragment){return translateFragment.call(navigator.mozL10n,fragment);},setAttributes:setL10nAttributes,getAttributes:getL10nAttributes,ready:function ready(callback){return navigator.mozL10n.ctx.ready(callback);},once:function once(callback){return navigator.mozL10n.ctx.once(callback);},get readyState(){return navigator.mozL10n.ctx.isReady?'complete':'loading';},language:{set code(lang){navigator.mozL10n.ctx.requestLocales(lang);},get code(){return navigator.mozL10n.ctx.supportedLocales[0];},get direction(){return getDirection(navigator.mozL10n.ctx.supportedLocales[0]);}},qps:PSEUDO_STRATEGIES,_getInternalAPI:function(){return{Error:L10nError,Context:Context,Locale:Locale,Resolver:Resolver,getPluralRule:getPluralRule,rePlaceables:rePlaceables,translateDocument:translateDocument,onMetaInjected:onMetaInjected,PropertiesParser:PropertiesParser,walkContent:walkContent};}};navigator.mozL10n.ctx.ready(onReady.bind(navigator.mozL10n));navigator.mozL10n.ctx.addEventListener('notfounderror',function reportMissingEntity(e){if(DEBUG||e.loc==='en-US'){console.warn(e.toString());}});if(DEBUG){navigator.mozL10n.ctx.addEventListener('manifesterror',console.error.bind(console));navigator.mozL10n.ctx.addEventListener('fetcherror',console.error.bind(console));navigator.mozL10n.ctx.addEventListener('parseerror',console.error.bind(console));navigator.mozL10n.ctx.addEventListener('resolveerror',console.error.bind(console));}
function getDirection(lang){return(rtlList.indexOf(lang)>=0)?'rtl':'ltr';}
var readyStates={'loading':0,'interactive':1,'complete':2};function waitFor(state,callback){state=readyStates[state];if(readyStates[document.readyState]>=state){callback();return;}
document.addEventListener('readystatechange',function l10n_onrsc(){if(readyStates[document.readyState]>=state){document.removeEventListener('readystatechange',l10n_onrsc);callback();}});}
if(window.document){isPretranslated=!PSEUDO_STRATEGIES.hasOwnProperty(navigator.language)&&(document.documentElement.lang===navigator.language);var pretranslate=document.documentElement.dataset.noCompleteBug?true:!isPretranslated;waitFor('interactive',init.bind(navigator.mozL10n,pretranslate));}
function initObserver(){nodeObserver=new MutationObserver(onMutations.bind(navigator.mozL10n));nodeObserver.observe(document,moConfig);}
function init(pretranslate){if(pretranslate){initResources.call(navigator.mozL10n);}else{initObserver();window.setTimeout(initResources.bind(navigator.mozL10n));}}
function initResources(){var nodes=document.head.querySelectorAll('link[rel="localization"],'+'meta[name="availableLanguages"],'+'meta[name="defaultLanguage"],'+'script[type="application/l10n"]');for(var i=0,node;node=nodes[i];i++){var type=node.getAttribute('rel')||node.nodeName.toLowerCase();switch(type){case'localization':this.ctx.resLinks.push(node.getAttribute('href'));break;case'meta':onMetaInjected.call(this,node);break;case'script':onScriptInjected.call(this,node);break;}}
if(!this.ctx.availableLocales.length){this.ctx.registerLocales(this.ctx.defaultLocale);}
return initLocale.call(this);}
function splitAvailableLanguagesString(str){return str.split(',').map(function(lang){lang=lang.trim().split(':');return lang[0];});}
function onMetaInjected(node){if(this.ctx.availableLocales.length){return;}
switch(node.getAttribute('name')){case'availableLanguages':meta.availableLanguages=splitAvailableLanguagesString(node.getAttribute('content'));break;case'defaultLanguage':meta.defaultLanguage=node.getAttribute('content');break;}
if(Object.keys(meta).length===2){this.ctx.registerLocales(meta.defaultLanguage,meta.availableLanguages);meta={};}}
function onScriptInjected(node){var lang=node.getAttribute('lang');var locale=this.ctx.getLocale(lang);locale.addAST(JSON.parse(node.textContent));}
function initLocale(){this.ctx.requestLocales.apply(this.ctx,navigator.languages||[navigator.language]);window.addEventListener('languagechange',function l10n_langchange(){this.ctx.requestLocales.apply(this.ctx,navigator.languages||[navigator.language]);}.bind(this));}
function localizeMutations(mutations){var mutation;var targets=new Set();for(var i=0;i<mutations.length;i++){mutation=mutations[i];if(mutation.type==='childList'){var addedNode;for(var j=0;j<mutation.addedNodes.length;j++){addedNode=mutation.addedNodes[j];if(addedNode.nodeType!==Node.ELEMENT_NODE){continue;}
targets.add(addedNode);}}
if(mutation.type==='attributes'){targets.add(mutation.target);}}
targets.forEach(function(target){if(target.childElementCount){translateFragment.call(this,target);}else if(target.hasAttribute('data-l10n-id')){translateElement.call(this,target);}},this);}
function onMutations(mutations,self){self.disconnect();localizeMutations.call(this,mutations);self.observe(document,moConfig);}
function onReady(){if(!isPretranslated){translateDocument.call(this);}
isPretranslated=false;if(pendingElements){for(var i=0,element;element=pendingElements[i];i++){translateElement.call(this,element);}
pendingElements=null;}
if(!nodeObserver){initObserver();}
fireLocalizedEvent.call(this);}
function fireLocalizedEvent(){var event=new CustomEvent('localized',{'bubbles':false,'cancelable':false,'detail':{'language':this.ctx.supportedLocales[0]}});window.dispatchEvent(event);}
function translateDocument(){document.documentElement.lang=this.language.code;document.documentElement.dir=this.language.direction;translateFragment.call(this,document.documentElement);}
function translateFragment(element){if(element.hasAttribute('data-l10n-id')){translateElement.call(this,element);}
var nodes=getTranslatableChildren(element);for(var i=0;i<nodes.length;i++){translateElement.call(this,nodes[i]);}}
function setL10nAttributes(element,id,args){element.setAttribute('data-l10n-id',id);if(args){element.setAttribute('data-l10n-args',JSON.stringify(args));}}
function getL10nAttributes(element){return{id:element.getAttribute('data-l10n-id'),args:JSON.parse(element.getAttribute('data-l10n-args'))};}
function getTranslatableChildren(element){return element?element.querySelectorAll('*[data-l10n-id]'):[];}
var allowedHtmlAttrs={'ariaLabel':'aria-label','ariaValueText':'aria-valuetext','ariaMozHint':'aria-moz-hint'};function translateElement(element){if(!this.ctx.isReady){if(!pendingElements){pendingElements=[];}
pendingElements.push(element);return;}
var l10n=getL10nAttributes(element);if(!l10n.id){return false;}
var entity=this.ctx.getEntity(l10n.id,l10n.args);if(!entity){return false;}
if(typeof entity.value==='string'){setTextContent.call(this,l10n.id,element,entity.value);}
for(var key in entity.attrs){var attr=entity.attrs[key];if(allowedHtmlAttrs.hasOwnProperty(key)){element.setAttribute(allowedHtmlAttrs[key],attr);}else if(key==='innerHTML'){element.innerHTML=attr;}else{element.setAttribute(key,attr);}}
return true;}
function setTextContent(id,element,text){if(element.firstElementChild){throw new L10nError('setTextContent is deprecated (https://bugzil.la/1053629). '+'Setting text content of elements with child elements is no longer '+'supported by l10n.js. Offending data-l10n-id: "'+id+'" on element '+element.outerHTML+' in '+this.ctx.id);}
element.textContent=text;}})(this);;'use strict';navigator.mozL10n.DateTimeFormat=function(locales,options){var _=navigator.mozL10n.get;function localeFormat(d,format){var tokens=format.match(/(%E.|%O.|%.)/g);for(var i=0;tokens&&i<tokens.length;i++){var value='';switch(tokens[i]){case'%a':value=_('weekday-'+d.getDay()+'-short');break;case'%A':value=_('weekday-'+d.getDay()+'-long');break;case'%b':case'%h':value=_('month-'+d.getMonth()+'-short');break;case'%B':value=_('month-'+d.getMonth()+'-long');break;case'%Eb':value=_('month-'+d.getMonth()+'-genitive');break;case'%I':value=d.getHours()%12||12;break;case'%e':value=d.getDate();break;case'%p':value=d.getHours()<12?_('time_am'):_('time_pm');break;case'%c':case'%x':case'%X':var tmp=_('dateTimeFormat_'+tokens[i]);if(tmp&&!(/(%c|%x|%X)/).test(tmp)){value=localeFormat(d,tmp);}
break;}
format=format.replace(tokens[i],value||d.toLocaleFormat(tokens[i]));}
return format;}
function relativeParts(seconds){seconds=Math.abs(seconds);var descriptors={};var units=['years',86400*365,'months',86400*30,'weeks',86400*7,'days',86400,'hours',3600,'minutes',60];if(seconds<60){return{minutes:Math.round(seconds/60)};}
for(var i=0,uLen=units.length;i<uLen;i+=2){var value=units[i+1];if(seconds>=value){descriptors[units[i]]=Math.floor(seconds/value);seconds-=descriptors[units[i]]*value;}}
return descriptors;}
function prettyDate(time,useCompactFormat,maxDiff){maxDiff=maxDiff||86400*10;switch(time.constructor){case String:time=parseInt(time);break;case Date:time=time.getTime();break;}
var secDiff=(Date.now()-time)/1000;if(isNaN(secDiff)){return _('incorrectDate');}
if(Math.abs(secDiff)>60){secDiff=secDiff>0?Math.ceil(secDiff):Math.floor(secDiff);}
if(secDiff>maxDiff){return localeFormat(new Date(time),'%x');}
var f=useCompactFormat?'-short':'-long';var parts=relativeParts(secDiff);var affix=secDiff>=0?'-ago':'-until';for(var i in parts){return _(i+affix+f,{value:parts[i]});}}
return{localeDateString:function localeDateString(d){return localeFormat(d,'%x');},localeTimeString:function localeTimeString(d){return localeFormat(d,'%X');},localeString:function localeString(d){return localeFormat(d,'%c');},localeFormat:localeFormat,fromNow:prettyDate,relativeParts:relativeParts};};;'use strict';var ActivityHandler={_currentActivity:null,_launchedAsInlineActivity:(window.location.search=='?pick'),mozContactParam:null,get currentlyHandling(){return!!this._currentActivity;},get activityName(){if(!this._currentActivity){return null;}
return this._currentActivity.source.name;},get activityDataType(){if(!this._currentActivity){return null;}
return this._currentActivity.source.data.type;},get activityData(){if(!this._currentActivity){return null;}
return this._currentActivity.source.data;},get activityContactProperties(){if(!this._currentActivity){return null;}
return this._currentActivity.source.data.contactProperties;},currentActivityIs:function(list){return this.currentlyHandling&&list.indexOf(this.activityName)!==-1;},currentActivityIsNot:function(list){return this.currentlyHandling&&list.indexOf(this.activityName)===-1;},launch_activity:function ah_launch(activity,action){if(this._launchedAsInlineActivity){return;}
this._currentActivity=activity;Contacts.checkCancelableActivity();var hash=action;var param,params=[];if(activity.source&&activity.source.data&&activity.source.data.params){var originalParams=activity.source.data.params;for(var i in originalParams){param=originalParams[i];params.push(i+'='+param);}
hash+='?'+params.join('&');}
document.location.hash=hash;},handle:function ah_handle(activity){switch(activity.source.name){case'new':this.launch_activity(activity,'view-contact-form');break;case'open':if(this.isvCardActivity(activity)){var self=this;var dependency='/shared/js/contacts/import/utilities/vcard_reader.js';LazyLoader.load(dependency,function(){self.getvCardReader(activity.source.data.blob,self.readvCard.bind(self,activity));});}else{this.launch_activity(activity,'view-contact-details');}
break;case'update':this.launch_activity(activity,'add-parameters');break;case'pick':if(!this._launchedAsInlineActivity){return;}
this._currentActivity=activity;Contacts.checkCancelableActivity();Contacts.navigation.home();break;case'import':this.importContactsFromFile(activity);break;}},renderOneContact:function(contact,activity){this.mozContactParam=contact;activity.source.data.params={'mozContactParam':true};this.launch_activity(activity,'view-contact-form');},renderingMultipleContacts:false,renderContact:function(contact,activity){if(!this.renderingMultipleContacts){alert(navigator.mozL10n.get('notEnabledYet'));this.launch_activity(activity,'view-contact-list');this.renderingMultipleContacts=true;}},getvCardReader:function ah_getvCardReader(blob,callback){var fileReader=new FileReader();fileReader.readAsBinaryString(blob);fileReader.onloadend=function(){var reader=new VCardReader(fileReader.result);if(typeof callback==='function'){callback(reader);}};},readvCard:function ah_readvCard(activity,vCardReader){var firstContact;var firstContactRendered=false;var self=this;var cursor=vCardReader.getAll();cursor.onsuccess=function(event){var contact=event.target.result;if(contact){if(!firstContact&&!firstContactRendered){firstContact=contact;}else if(!firstContactRendered){self.renderContact(firstContact,activity);self.renderContact(contact,activity);firstContactRendered=true;firstContact=null;}else{self.renderContact(contact,activity);}
cursor.continue();}else if(firstContact){self.renderOneContact(firstContact,activity);}};},isvCardActivity:function ah_isvCardActivity(activity){return!!(activity.source&&activity.source.data&&!activity.source.data.params&&activity.source.data.type==='text/vcard'&&activity.source.data.blob);},importContactsFromFile:function ah_importContactFromVcard(activity){var self=this;if(activity.source&&activity.source.data&&activity.source.data.blob){LazyLoader.load([document.querySelector('#loading-overlay'),'/shared/js/contacts/import/utilities/import_from_vcard.js','/shared/js/contacts/import/utilities/overlay.js'],function loaded(){Contacts.loadFacebook(function(){utils.importFromVcard(activity.source.data.blob,function imported(numberOfContacts,id){if(numberOfContacts===1){activity.source.data.params={id:id};self.launch_activity(activity,'view-contact-details');}else{self.launch_activity(activity,'view-contact-list');}});});});}else{this._currentActivity.postError('wrong parameters');this._currentActivity=null;}},dataPickHandler:function ah_dataPickHandler(theContact){var type,dataSet,noDataStr;var result={};if(this.activityDataType==='webcontacts/contact'&&this.activityData.fullContact===true){result=utils.misc.toMozContact(theContact);this.postPickSuccess(result);return;}
switch(this.activityDataType){case'webcontacts/tel':type='contact';dataSet=theContact.tel;noDataStr='no_contact_phones';break;case'webcontacts/contact':type='number';dataSet=theContact.tel;noDataStr='no_contact_phones';break;case'webcontacts/email':type='email';dataSet=theContact.email;noDataStr='no_contact_email';break;case'webcontacts/select':type='select';var data=[];if(this.activityContactProperties.indexOf('tel')!==-1){if(theContact.tel&&theContact.tel.length){data=data.concat(theContact.tel);}}
if(this.activityContactProperties.indexOf('email')!==-1){if(theContact.email&&theContact.email.length){data=data.concat(theContact.email);}}
dataSet=data;noDataStr='no_contact_data';break;}
var hasData=dataSet&&dataSet.length;var numOfData=hasData?dataSet.length:0;result.name=theContact.name;switch(numOfData){case 0:var dismiss={title:'ok',callback:function(){ConfirmDialog.hide();}};Contacts.confirmDialog(null,noDataStr,dismiss);break;case 1:if(this.activityDataType=='webcontacts/tel'||this.activityDataType=='webcontacts/select'){result=this.pickContactsResult(theContact);}else{result[type]=dataSet[0].value;}
this.postPickSuccess(result);break;default:var self=this;LazyLoader.load('/contacts/js/action_menu.js',function(){var prompt1=new ActionMenu();var itemData;var capture=function(itemData){return function(){if(self.activityDataType=='webcontacts/tel'||self.activityDataType=='webcontacts/select'){result=self.pickContactsResult(theContact,itemData);}else{result[type]=itemData;}
prompt1.hide();self.postPickSuccess(result);};};for(var i=0,l=dataSet.length;i<l;i++){itemData=dataSet[i].value;var carrier=dataSet[i].carrier||'';prompt1.addToList({id:'pick_destination',args:{destination:itemData,carrier:carrier}},capture(itemData));}
prompt1.show();});}},pickContactsResult:function ah_pickContactsResult(theContact,itemData){var pickResult={};var contact=utils.misc.toMozContact(theContact);if(this.activityDataType=='webcontacts/tel'){pickResult=contact;if(itemData){pickResult.tel=this.filterDestinationForActivity(itemData,pickResult.tel);}}else if(this.activityDataType=='webcontacts/select'){pickResult.contact=contact;if(!itemData){pickResult.select=pickResult.contact.tel;if(!pickResult.select||!pickResult.select.length){pickResult.select=pickResult.contact.email;}}else{pickResult.select=this.filterDestinationForActivity(itemData,pickResult.contact.tel);if(!pickResult.select||!pickResult.select.length){pickResult.select=this.filterDestinationForActivity(itemData,pickResult.contact.email);}}}
return pickResult;},filterDestinationForActivity:function ah_filterDestinationForActivity(itemData,dataSet){return dataSet.filter(function isSamePhone(item){return item.value==itemData;});},postNewSuccess:function ah_postNewSuccess(contact){this._currentActivity.postResult({contact:contact});this._currentActivity=null;},postPickSuccess:function ah_postPickSuccess(result){this._currentActivity.postResult(result);this._currentActivity=null;},postCancel:function ah_postCancel(){this._currentActivity.postError('canceled');this._currentActivity=null;}};;'use strict';var LazyLoader=(function(){function LazyLoader(){this._loaded={};this._isLoading={};}
LazyLoader.prototype={_js:function(file,callback){var script=document.createElement('script');script.src=file;script.async=false;script.addEventListener('load',callback);document.head.appendChild(script);this._isLoading[file]=script;},_css:function(file,callback){var style=document.createElement('link');style.type='text/css';style.rel='stylesheet';style.href=file;document.head.appendChild(style);callback();},_html:function(domNode,callback){if(domNode.getAttribute('is')){this.load(['/shared/js/html_imports.js'],function(){HtmlImports.populate(callback);}.bind(this));return;}
for(var i=0;i<domNode.childNodes.length;i++){if(domNode.childNodes[i].nodeType==document.COMMENT_NODE){domNode.innerHTML=domNode.childNodes[i].nodeValue;break;}}
window.dispatchEvent(new CustomEvent('lazyload',{detail:domNode}));callback();},getJSON:function(file){return new Promise(function(resolve,reject){var xhr=new XMLHttpRequest();xhr.open('GET',file,true);xhr.responseType='json';xhr.onerror=function(error){reject(error);};xhr.onload=function(){if(xhr.response!==null){resolve(xhr.response);}else{reject(new Error('No valid JSON object was found ('+
xhr.status+' '+xhr.statusText+')'));}};xhr.send();});},load:function(files,callback){var deferred={};deferred.promise=new Promise(resolve=>{deferred.resolve=resolve;});if(!Array.isArray(files)){files=[files];}
var loadsRemaining=files.length,self=this;function perFileCallback(file){if(self._isLoading[file]){delete self._isLoading[file];}
self._loaded[file]=true;if(--loadsRemaining===0){deferred.resolve();if(callback){callback();}}}
for(var i=0;i<files.length;i++){var file=files[i];if(this._loaded[file.id||file]){perFileCallback(file);}else if(this._isLoading[file]){this._isLoading[file].addEventListener('load',perFileCallback.bind(null,file));}else{var method,idx;if(typeof file==='string'){method=file.match(/\.([^.]+)$/)[1];idx=file;}else{method='html';idx=file.id;}
this['_'+method](file,perFileCallback.bind(null,idx));}}
return deferred.promise;}};return new LazyLoader();}());;(function(window){'use strict';var performance=window.performance;var console=window.console;if(typeof performance.mark==='function'){return;}
var logEntry=function(entry){setTimeout(function(){var message='Performance Entry: '+
entry.entryType+'|'+
entry.name+'|'+
entry.startTime+'|'+
entry.duration+'|'+
(entry.time||0);console.log(message);},0);};var marks={};performance.mark=function(markName){var now=performance.now();var epoch=Date.now();if(typeof markName==='undefined'){throw new SyntaxError('Mark name must be specified');}
if(performance.timing&&markName in performance.timing){throw new SyntaxError('Mark name is not allowed');}
if(!marks[markName]){marks[markName]=[];}
marks[markName].push(now);logEntry({entryType:'mark',name:markName,startTime:now,duration:0,time:epoch});};performance.measure=function(measureName,startMark,endMark){var now=performance.now();var epoch=Date.now();if(!measureName){throw new Error('Measure must be specified');}
if(!startMark){logEntry({entryType:'measure',name:measureName,startTime:0,duration:now,time:epoch});return;}
var startMarkTime=0;if(performance.timing&&startMark in performance.timing){if(startMark!=='navigationStart'&&performance.timing[startMark]===0){throw new Error(startMark+' has a timing of 0');}
startMarkTime=performance.timing[startMark]-
performance.timing.navigationStart;}else{if(startMark in marks){startMarkTime=marks[startMark][marks[startMark].length-1];}else{throw new Error(startMark+' mark not found');}}
var endMarkTime=now;if(endMark){endMarkTime=0;if(performance.timing&&endMark in performance.timing){if(endMark!=='navigationStart'&&performance.timing[endMark]===0){throw new Error(endMark+' has a timing of 0');}
endMarkTime=performance.timing[endMark]-
performance.timing.navigationStart;}else{if(endMark in marks){endMarkTime=marks[endMark][marks[endMark].length-1];}else{throw new Error(endMark+' mark not found');}}}
var duration=endMarkTime-startMarkTime;logEntry({entryType:'measure',name:measureName,startTime:startMarkTime,duration:duration,time:epoch});};if(typeof define!=='undefined'&&define.amd){define([],function(){return performance;});}else if(typeof module!=='undefined'&&typeof module.exports!=='undefined'){module.exports=performance;}}(typeof window!=='undefined'?window:undefined));;(function(exports){'use strict';function getThumbnail(contact){return getOnePhoto(contact,'begin');}
function getFullResolution(contact){return getOnePhoto(contact,'end');}
function getOnePhoto(contact,position){if(!contact||!contact.photo||!contact.photo.length){return null;}
if(contact.photo.length===1){return contact.photo[0];}
var photos=contact.photo;var category=contact.category;if(Array.isArray(category)&&category.indexOf('fb_linked')!==-1){if(photos.length>=4){return photos[(position=='begin')?1:0];}
return photos[0];}
photos=photosBySize(contact);var index=(position=='begin')?0:photos.length-1;return photos[index];}
function photosBySize(contact){var photos=contact.photo.slice(0);photos.sort(function(p1,p2){if(size(p1)<size(p2)){return-1;}
if(size(p1)>size(p2)){return 1;}
return 0;});return photos;}
function size(photo){if(typeof photo=='string'){return photo.length;}
return photo.size;}
exports.ContactPhotoHelper={getThumbnail:getThumbnail,getFullResolution:getFullResolution};})(window);;this.asyncStorage=(function(){'use strict';var DBNAME='asyncStorage';var DBVERSION=1;var STORENAME='keyvaluepairs';var db=null;function withDatabase(f){if(db){f();}else{var openreq=indexedDB.open(DBNAME,DBVERSION);openreq.onerror=function withStoreOnError(){console.error('asyncStorage: can\'t open database:',openreq.error.name);};openreq.onupgradeneeded=function withStoreOnUpgradeNeeded(){openreq.result.createObjectStore(STORENAME);};openreq.onsuccess=function withStoreOnSuccess(){db=openreq.result;f();};}}
function withStore(type,callback,oncomplete){withDatabase(function(){var transaction=db.transaction(STORENAME,type);if(oncomplete){transaction.oncomplete=oncomplete;}
callback(transaction.objectStore(STORENAME));});}
function getItem(key,callback){var req;withStore('readonly',function getItemBody(store){req=store.get(key);req.onerror=function getItemOnError(){console.error('Error in asyncStorage.getItem(): ',req.error.name);};},function onComplete(){var value=req.result;if(value===undefined){value=null;}
callback(value);});}
function setItem(key,value,callback){withStore('readwrite',function setItemBody(store){var req=store.put(value,key);req.onerror=function setItemOnError(){console.error('Error in asyncStorage.setItem(): ',req.error.name);};},callback);}
function removeItem(key,callback){withStore('readwrite',function removeItemBody(store){var req=store.delete(key);req.onerror=function removeItemOnError(){console.error('Error in asyncStorage.removeItem(): ',req.error.name);};},callback);}
function clear(callback){withStore('readwrite',function clearBody(store){var req=store.clear();req.onerror=function clearOnError(){console.error('Error in asyncStorage.clear(): ',req.error.name);};},callback);}
function length(callback){var req;withStore('readonly',function lengthBody(store){req=store.count();req.onerror=function lengthOnError(){console.error('Error in asyncStorage.length(): ',req.error.name);};},function onComplete(){callback(req.result);});}
function key(n,callback){if(n<0){callback(null);return;}
var req;withStore('readonly',function keyBody(store){var advanced=false;req=store.openCursor();req.onsuccess=function keyOnSuccess(){var cursor=req.result;if(!cursor){return;}
if(n===0||advanced){return;}
advanced=true;cursor.advance(n);};req.onerror=function keyOnError(){console.error('Error in asyncStorage.key(): ',req.error.name);};},function onComplete(){var cursor=req.result;callback(cursor?cursor.key:null);});}
return{getItem:getItem,setItem:setItem,removeItem:removeItem,clear:clear,length:length,key:key};}());;'use strict';var utils=window.utils||{};if(typeof utils.config==='undefined'){(function(){var configs={};var initializing={};var initialized={};var EVENT_INITIALIZED='config_initialized';utils.config=utils.config||{};utils.config.reset=function(){configs={};initializing={};initialized={};};function onLoad(xhr,file,resolveCb){configs[file]=xhr.response;delete initializing[file];initialized[file]=true;document.dispatchEvent(new CustomEvent(EVENT_INITIALIZED,{detail:{file:file,success:true}}));resolveCb(configs[file]);}
utils.config.load=function(file){return new Promise(function(resolve,reject){var isInitialized=initialized[file];if(isInitialized===true){resolve(configs[file]);return;}
var isInitializing=initializing[file];if(isInitializing){var handler=function(expectedFile,e){document.removeEventListener(EVENT_INITIALIZED,handler);var file=e.detail.file;if(expectedFile!==file){return;}
if(e.detail.success){resolve(configs[file]);}
else{reject();}}.bind(null,file);document.addEventListener(EVENT_INITIALIZED,handler);return;}
initializing[file]=true;var xhr=new XMLHttpRequest();xhr.open('GET',file,true);xhr.responseType='json';xhr.onload=function(){var resolvedCb=resolve;if(xhr.status!==200){resolvedCb=reject;}
onLoad(xhr,file,resolvedCb);};xhr.onerror=function(){document.dispatchEvent(new CustomEvent(EVENT_INITIALIZED,{detail:{file:file,success:false}}));delete initializing[file];reject(xhr.error);};try{xhr.send(null);}
catch(e){console.error('Error while loading config file: ',e.message);onLoad({status:404},file,reject);}});};})();};'use strict';(function(){var utils=window.utils=window.utils||{};utils.cookie={};var COOKIE_VERSION=6;var COOKIE_DEFAULTS={order:false,viewHeight:-1,rowsPerPage:-1,fbMigrated:false,fbScheduleDone:false,defaultImage:true,accessTokenMigrated:false,fbCleaningInProgress:0};var COOKIE_PROPS=Object.keys(COOKIE_DEFAULTS);var EXPIRATION_DATE='Fri, 31 Dec 9999 23:59:59 GMT';var COOKIE_NAME='preferences';var COOKIE_NAME_EQ=COOKIE_NAME+'=';var COOKIE_NAME_LENGHT=COOKIE_NAME_EQ.length;function _parseCookie(cookie){var index=cookie.indexOf(COOKIE_NAME_EQ);if(index===-1){return null;}
var cookieVal=cookie.substring(index+COOKIE_NAME_LENGHT);if(!cookieVal){return null;}
return JSON.parse(decodeURIComponent(cookieVal));}
utils.cookie.load=function(){if(!document.cookie){return null;}
var cookie=_parseCookie(document.cookie);if(cookie&&cookie.version!==COOKIE_VERSION){_updateCookie(cookie);cookie=_parseCookie(document.cookie);}
return cookie;};utils.cookie.update=function(cfg){_updateCookie(utils.cookie.load(),cfg);};function _updateCookie(oldCookie,cfg){oldCookie=oldCookie||{};cfg=cfg||{};var newCookie={version:COOKIE_VERSION};for(var i=0,n=COOKIE_PROPS.length;i<n;++i){var prop=COOKIE_PROPS[i];if(prop in cfg){newCookie[prop]=cfg[prop];}else if(prop in oldCookie){newCookie[prop]=oldCookie[prop];}else{newCookie[prop]=COOKIE_DEFAULTS[prop];}}
document.cookie=COOKIE_NAME+'='+
encodeURIComponent(JSON.stringify(newCookie))+';expires='+EXPIRATION_DATE;}
utils.cookie.getDefault=function(prop){return COOKIE_DEFAULTS(prop);};})();;'use strict';var utils=window.utils||{};if(!utils.extractParams){utils.extractParams=function extractParams(url){if(!url){return-1;}
var ret={};var params=url.split('&');for(var i=0;i<params.length;i++){var currentParam=params[i].split('=');ret[currentParam[0]]=currentParam[1];}
return ret;};};'use strict';(function(){window.utils=window.utils||{};var PerformanceHelper={domLoaded:function(){window.performance.mark('navigationLoaded');window.dispatchEvent(new CustomEvent('moz-chrome-dom-loaded'));},chromeInteractive:function(){window.performance.mark('navigationInteractive');window.dispatchEvent(new CustomEvent('moz-chrome-interactive'));},visuallyComplete:function(){window.performance.mark('visuallyLoaded');window.dispatchEvent(new CustomEvent('moz-app-visually-complete'));},contentInteractive:function(){window.performance.mark('contentInteractive');window.dispatchEvent(new CustomEvent('moz-content-interactive'));},loadEnd:function(){window.performance.mark('fullyLoaded');window.dispatchEvent(new CustomEvent('moz-app-loaded'));}};window.utils.PerformanceHelper=PerformanceHelper;})();;window.COMPONENTS_BASE_URL='/shared/elements/';;(function(exports){'use strict';exports.ComponentUtils={style:function(baseUrl){var style=document.createElement('style');var url=baseUrl+'style.css';var self=this;style.setAttribute('scoped','');style.innerHTML='@import url('+url+');';this.appendChild(style);this.style.visibility='hidden';style.addEventListener('load',function(){if(self.shadowRoot){self.shadowRoot.appendChild(style.cloneNode(true));}
self.style.visibility='';});}};}(window));;'use strict';window.GaiaSubheader=(function(win){var proto=Object.create(HTMLElement.prototype);var baseurl=window.GaiaSubheaderBaseurl||'/shared/elements/gaia_subheader/';proto.createdCallback=function(){ComponentUtils.style.call(this,baseurl);};return document.registerElement('gaia-subheader',{prototype:proto});})(window);;!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var f;"undefined"!=typeof window?f=window:"undefined"!=typeof global?f=global:"undefined"!=typeof self&&(f=self),f.GaiaHeader=e()}}(function(){var define,module,exports;return(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){;(function(define){define(function(require,exports,module){'use strict';var textContent=Object.getOwnPropertyDescriptor(Node.prototype,'textContent');var removeAttribute=HTMLElement.prototype.removeAttribute;var setAttribute=HTMLElement.prototype.setAttribute;var noop=function(){};var hasShadowCSS=(function(){var div=document.createElement('div');try{div.querySelector(':host');return true;}
catch(e){return false;}})();module.exports.register=function(name,props){injectGlobalCss(props.globalCss);delete props.globalCSS;var proto=Object.assign(Object.create(base),props);var output=extractLightDomCSS(proto.template,name);var _attrs=Object.assign(props.attrs||{},attrs);proto.template=output.template;proto.lightCss=output.lightCss;Object.defineProperties(proto,_attrs);var El=document.registerElement(name,{prototype:proto});return El;};var base=Object.assign(Object.create(HTMLElement.prototype),{attributeChanged:noop,attached:noop,detached:noop,created:noop,template:'',createdCallback:function(){this.injectLightCss(this);this.created();},attributeChangedCallback:function(name,from,to){if(this.attrs&&this.attrs[name]){this[name]=to;}
this.attributeChanged(name,from,to);},attachedCallback:function(){this.attached();},detachedCallback:function(){this.detached();},setAttr:function(name,value){var internal=this.shadowRoot.firstElementChild;setAttribute.call(internal,name,value);setAttribute.call(this,name,value);},removeAttr:function(){var internal=this.shadowRoot.firstElementChild;removeAttribute.call(internal,name,value);removeAttribute.call(this,name,value);},injectLightCss:function(el){if(hasShadowCSS){return;}
this.lightStyle=document.createElement('style');this.lightStyle.setAttribute('scoped','');this.lightStyle.innerHTML=el.lightCss;el.appendChild(this.lightStyle);}});var attrs={textContent:{set:function(value){var node=firstChildTextNode(this);if(node){node.nodeValue=value;}},get:function(){var node=firstChildTextNode(this);return node&&node.nodeValue;}}};function firstChildTextNode(el){for(var i=0;i<el.childNodes.length;i++){var node=el.childNodes[i];if(node&&node.nodeType===3){return node;}}}
function extractLightDomCSS(template,name){var regex=/(?::host|::content)[^{]*\{[^}]*\}/g;var lightCss='';if(!hasShadowCSS){template=template.replace(regex,function(match){lightCss+=match.replace(/::content|:host/g,name);return'';});}
return{template:template,lightCss:lightCss};}
function injectGlobalCss(css){if(!css)return;var style=document.createElement('style');style.innerHTML=css;document.head.appendChild(style);}});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-component',this));},{}],2:[function(require,module,exports){(function(define){define(function(require,exports,module){var base=window.GAIA_ICONS_BASE_URL||window.COMPONENTS_BASE_URL||'bower_components/';if(!isLoaded()){load(base+'gaia-icons/gaia-icons.css');}
function load(href){var link=document.createElement('link');link.rel='stylesheet';link.type='text/css';link.href=href;document.head.appendChild(link);exports.loaded=true;}
function isLoaded(){return exports.loaded||document.querySelector('link[href*=gaia-icons]')||document.documentElement.classList.contains('gaia-icons-loaded');}});})(typeof define=='function'&&define.amd?define:(function(n,w){return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-icons',this));},{}],3:[function(require,module,exports){;(function(define){'use strict';define(function(require,exports,module){var Component=require('gaia-component');var fontFit=require('./lib/font-fit');require('gaia-icons');var actionTypes={menu:1,back:1,close:1};module.exports=Component.register('gaia-header',{created:function(){this.createShadowRoot().innerHTML=this.template;this.els={actionButton:this.shadowRoot.querySelector('.action-button'),headings:this.querySelectorAll('h1,h2,h3,h4'),inner:this.shadowRoot.querySelector('.inner')};this.els.actionButton.addEventListener('click',e=>this.onActionButtonClick(e));this.configureActionButton();this.runFontFit();},attached:function(){this.rerunFontFit();},attributeChanged:function(attr){if(attr==='action'){this.configureActionButton();this.rerunFontFit();}},runFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);fontFit.observeHeadingChanges(this.els.headings[i]);}},rerunFontFit:function(){for(var i=0;i<this.els.headings.length;i++){fontFit.reformatHeading(this.els.headings[i]);}},triggerAction:function(){if(this.isSupportedAction(this.getAttribute('action'))){this.els.actionButton.click();}},configureActionButton:function(){var old=this.els.actionButton.getAttribute('icon');var type=this.getAttribute('action');var supported=this.isSupportedAction(type);this.els.actionButton.classList.remove('icon-'+old);this.els.actionButton.setAttribute('icon',type);this.els.inner.classList.toggle('supported-action',supported);if(supported){this.els.actionButton.classList.add('icon-'+type);}},isSupportedAction:function(action){return action&&actionTypes[action];},onActionButtonClick:function(e){var config={detail:{type:this.getAttribute('action')}};var actionEvent=new CustomEvent('action',config);setTimeout(this.dispatchEvent.bind(this,actionEvent));},template:`
  <style>

  :host {
    display: block;

    --gaia-header-button-color:
      var(--header-button-color,
      var(--header-color,
      var(--link-color,
      inherit)));
  }

  /**
   * [hidden]
   */

  :host[hidden] {
    display: none;
  }

  /** Reset
   ---------------------------------------------------------*/

  ::-moz-focus-inner { border: 0; }

  /** Inner
   ---------------------------------------------------------*/

  .inner {
    display: flex;
    min-height: 50px;
    direction: ltr;

    background:
      var(--header-background,
      var(--background,
      #fff));
  }

  /** Action Button
   ---------------------------------------------------------*/

  /**
   * 1. Hidden by default
   */

  .action-button {
    display: none; /* 1 */
    position: relative;
    width: 50px;
    font-size: 30px;
    margin: 0;
    padding: 0;
    border: 0;
    align-items: center;
    background: none;
    cursor: pointer;
    transition: opacity 200ms 280ms;

    color:
      var(--header-action-button-color,
      var(--header-icon-color,
      var(--gaia-header-button-color)));
  }

  /**
   * .action-supported
   *
   * 1. For icon vertical-alignment
   */

  .supported-action .action-button {
    display: flex; /* 1 */
  }

  /**
   * :active
   */

  .action-button:active {
    transition: none;
    opacity: 0.2;
  }

  /** Action Button Icon
   ---------------------------------------------------------*/

  /**
   * 1. To enable vertical alignment.
   */

  .action-button:before {
    display: block;
  }

  /** Action Button Text
   ---------------------------------------------------------*/

  /**
   * To provide custom localized content for
   * the action-button, we allow the user
   * to provide an element with the class
   * .l10n-action. This node is then
   * pulled inside the real action-button.
   *
   * Example:
   *
   *   <gaia-header action="back">
   *     <span class="l10n-action" aria-label="Back">Localized text</span>
   *     <h1>title</h1>
   *   </gaia-header>
   */

  ::content .l10n-action {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    font-size: 0;
  }

  /** Title
   ---------------------------------------------------------*/

  /**
   * 1. Vertically center text. We can't use flexbox
   *    here as it breaks text-overflow ellipsis
   *    without an inner div.
   */

  ::content h1 {
    flex: 1;
    margin: 0;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    text-align: center;
    line-height: 50px; /* 1 */
    font-weight: 300;
    font-style: italic;
    font-size: 24px;
    -moz-user-select: none;

    color:
      var(--header-title-color,
      var(--header-color,
      var(--title-color,
      var(--text-color,
      inherit))));
  }

  /**
   * .flush-left
   *
   * When the fitted text is flush with the
   * edge of the left edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-left {
    padding-left: 10px;
  }

  /**
   * .flush-right
   *
   * When the fitted text is flush with the
   * edge of the right edge of the container
   * we pad it in a bit.
   */

  ::content h1.flush-right {
    padding-right: 10px; /* 1 */
  }

  /** Buttons
   ---------------------------------------------------------*/

  ::content a,
  ::content button {
    box-sizing: border-box;
    display: flex;
    border: none;
    width: auto;
    height: auto;
    margin: 0;
    padding: 0 10px;
    font-size: 14px;
    line-height: 1;
    min-width: 50px;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    text-align: center;
    background: none;
    border-radius: 0;
    font-style: italic;
    cursor: pointer;

    transition: opacity 200ms 280ms;

    color:
      var(--gaia-header-button-color);
  }

  /**
   * :active
   */

  ::content a:active,
  ::content button:active {
    transition: none;
    opacity: 0.2;
  }

  /**
   * [hidden]
   */

  ::content a[hidden],
  ::content button[hidden] {
    display: none;
  }

  /**
   * [disabled]
   */

  ::content a[disabled],
  ::content button[disabled] {
    pointer-events: none;
    color: var(--header-disabled-button-color);
  }

  /** Icon Buttons
   ---------------------------------------------------------*/

  /**
   * Icons are a different color to text
   */

  ::content .icon,
  ::content [data-icon] {
    color:
      var(--header-icon-color,
      var(--gaia-header-button-color));
  }

  /** Icons
   ---------------------------------------------------------*/

  [class^="icon-"]:before,
  [class*="icon-"]:before {
    font-family: 'gaia-icons';
    font-style: normal;
    text-rendering: optimizeLegibility;
    font-weight: 500;
  }

  .icon-menu:before { content: 'menu'; }
  .icon-close:before { content: 'close'; }
  .icon-back:before { content: 'back'; }

  </style>

  <div class="inner">
    <button class="action-button">
      <content select=".l10n-action"></content>
    </button>
    <content select="h1,h2,h3,h4,a,button"></content>
  </div>`});});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('gaia-header',this));},{"./lib/font-fit":4,"gaia-component":1,"gaia-icons":2}],4:[function(require,module,exports){;(function(define){'use strict';define(function(require,exports,module){var GaiaHeaderFontFit={_HEADER_SIZES:[16,17,18,19,20,21,22,23,24],observeHeadingChanges:function(heading){var observer=this._getTextChangeObserver();observer.observe(heading,{childList:true});},reformatHeading:function(heading){if(!heading||heading.textContent.trim()===''){return;}
this._resetCentering(heading);var style=this._getStyleProperties(heading);if(!style){return;}
style.textWidth=this._autoResizeElement(heading,style);this._centerTextToScreen(heading,style);},resetCache:function(){this._cachedContexts={};},_cachedContexts:{},_getCachedContext:function(fontSize,fontFamily,fontStyle){fontStyle=fontStyle||'italic';var cache=this._cachedContexts;var ctx=cache[fontSize]&&cache[fontSize][fontFamily]?cache[fontSize][fontFamily][fontStyle]:null;if(!ctx){var canvas=document.createElement('canvas');canvas.setAttribute('moz-opaque','true');canvas.setAttribute('width','1');canvas.setAttribute('height','1');ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.font=fontStyle+' '+fontSize+'px '+fontFamily;if(!cache[fontSize]){cache[fontSize]={};}
if(!cache[fontSize][fontFamily]){cache[fontSize][fontFamily]={};}
cache[fontSize][fontFamily][fontStyle]=ctx;}
return ctx;},_textChangeObserver:null,_handleTextChanges:function(mutations){var targets=new Set();for(var i=0;i<mutations.length;i++){targets.add(mutations[i].target);}
for(var target of targets){this.reformatHeading(target);}},_getTextChangeObserver:function(){if(!this._textChangeObserver){this._textChangeObserver=new MutationObserver(this._handleTextChanges.bind(this));}
return this._textChangeObserver;},_getFontWidth:function(string,fontSize,fontFamily,fontStyle){var ctx=this._getCachedContext(fontSize,fontFamily,fontStyle);return ctx.measureText(string).width;},_getMaxFontSizeInfo:function(string,allowedSizes,fontFamily,maxWidth){var fontSize;var resultWidth;var i=allowedSizes.length-1;do{fontSize=allowedSizes[i];resultWidth=this._getFontWidth(string,fontSize,fontFamily);i--;}while(resultWidth>maxWidth&&i>=0);return{fontSize:fontSize,overflow:resultWidth>maxWidth,textWidth:resultWidth};},_getContentWidth:function(style){var width=parseInt(style.width,10);if(style.boxSizing==='border-box'){width-=(parseInt(style.paddingRight,10)+
parseInt(style.paddingLeft,10));}
return width;},_getStyleProperties:function(heading){var style=getComputedStyle(heading)||{};var contentWidth=this._getContentWidth(style);if(isNaN(contentWidth)){contentWidth=0;}
return{fontFamily:style.fontFamily||'unknown',contentWidth:contentWidth,paddingRight:parseInt(style.paddingRight,10),paddingLeft:parseInt(style.paddingLeft,10),offsetLeft:heading.offsetLeft};},_autoResizeElement:function(heading,styleOptions){var contentWidth=styleOptions.contentWidth||this._getContentWidth(heading);var fontFamily=styleOptions.fontFamily||getComputedStyle(heading).fontFamily;var text=heading.textContent.replace(/\s+/g,' ').trim();var info=this._getMaxFontSizeInfo(text,this._HEADER_SIZES,fontFamily,contentWidth);heading.style.fontSize=info.fontSize+'px';return info.textWidth;},_resetCentering:function(heading){heading.style.marginLeft=heading.style.marginRight='0';},_centerTextToScreen:function(heading,styleOptions){var minHeaderWidth=styleOptions.textWidth+styleOptions.paddingRight+
styleOptions.paddingLeft;var tightText=styleOptions.textWidth>(styleOptions.contentWidth-30);var sideSpaceLeft=styleOptions.offsetLeft;var sideSpaceRight=this._getWindowWidth()-sideSpaceLeft-
styleOptions.contentWidth-styleOptions.paddingRight-
styleOptions.paddingLeft;heading.classList.toggle('flush-left',tightText&&!sideSpaceLeft);heading.classList.toggle('flush-right',tightText&&!sideSpaceRight);if(sideSpaceLeft===sideSpaceRight){return;}
var margin=Math.max(sideSpaceLeft,sideSpaceRight);if(minHeaderWidth+(margin*2)<this._getWindowWidth()-1){if(sideSpaceLeft<sideSpaceRight){heading.style.marginLeft=(sideSpaceRight-sideSpaceLeft)+'px';}
if(sideSpaceRight<sideSpaceLeft){heading.style.marginRight=(sideSpaceLeft-sideSpaceRight)+'px';}}},_getWindowWidth:function(){return window.innerWidth;}};module.exports=GaiaHeaderFontFit;});})(typeof define=='function'&&define.amd?define:(function(n,w){'use strict';return typeof module=='object'?function(c){c(require,exports,module);}:function(c){var m={exports:{}};c(function(n){return w[n];},m.exports,m);w[n]=m.exports;};})('./lib/font-fit',this));},{}]},{},[3])(3)});;'use strict';var fb=window.fb||{};var config=window.config||{};if(typeof fb.init==='undefined'){(function(){var initialized=false;var initializing=false;var EV_FB_INIT='fb_init_initialized';fb.isEnabled=false;fb.init=function(callback){if(initialized){callback();return;}
if(initializing){document.addEventListener(EV_FB_INIT,function handler(e){initializing=false;document.removeEventListener(EV_FB_INIT,handler);callback();});return;}
initializing=true;utils.config.load('/contacts/config.json').then(function cLoaded(configData){if(configData.facebookEnabled===true){fb.isEnabled=true;}
fb.operationsTimeout=config.operationsTimeout=configData.operationsTimeout;fb.logLevel=configData.logLevel||'none';fb.syncPeriod=configData.facebookSyncPeriod||24;fb.testToken=configData.testToken;initialized=true;document.dispatchEvent(new CustomEvent(EV_FB_INIT));callback();},function loadError(err){console.error('Error while loading config.json',err);});};})();};'use strict';var utils=window.utils||{};if(!utils.listeners){(function(document){var Listeners=utils.listeners={};Listeners.add=function(config){try{for(var id in config){var handler=config[id];var nodes=document.querySelectorAll(id);for(var i=0;i<nodes.length;i++){var node=nodes[i];if(Array.isArray(handler)){handler.forEach(function handle(item){if(!item.hasOwnProperty('event')&&!item.hasOwnProperty('handler')){return;}
node.addEventListener(item.event,item.handler);});}else{node.addEventListener('click',handler);}}}}
catch(e){window.console.error('Error while registering listener for: ',id,e);}};})(document);};'use strict';function navigationStack(currentView){this.transitions={'none':{forwards:{},backwards:{}},'right-left':{forwards:{next:'app-go-left-in'},backwards:{current:'app-go-left-back-out'}},'popup':{forwards:{next:'app-go-up-in'},backwards:{current:'app-go-up-back-out'}},'activity-popup':{forwards:{next:'app-go-up-in'},backwards:{}},'fade-in':{forwards:{next:'fade-in'},backwards:{current:'fade-out'}},'go-deeper':{forwards:{current:'app-go-deeper-out',next:'app-go-deeper-in'},backwards:{current:'app-go-deeper-back-out',next:'app-go-deeper-back-in'}},'go-deeper-search':{forwards:{current:'move-left-out',next:'move-left-in'},backwards:{current:'move-right-out',next:'move-right-in'}}};var COMMS_APP_ORIGIN=location.origin;var screenshotViewId='view-screenshot';var _currentView=currentView;document.getElementById(currentView).classList.add('current');this.stack=[];navigationStack._zIndex=navigationStack._zIndex||0;this.stack.push({view:_currentView,transition:'popup',zIndex:++navigationStack._zIndex});var waitForAnimation=function ng_waitForAnimation(view,callback){if(!callback){return;}
view.addEventListener('animationend',function ng_onAnimationEnd(){view.removeEventListener('animationend',ng_onAnimationEnd);setTimeout(callback,0);});};this.go=function go(nextView,transition,callback){if(_currentView===nextView){if(callback){callback();}
return;}
var parent=window.parent;if(nextView=='view-contact-form'){parent.postMessage({type:'hide-navbar'},COMMS_APP_ORIGIN);}
this.stack=this.stack.filter(function(item){return item.view!=nextView;});var current;var currentClassList;if(transition.indexOf('go-deeper')===0){current=document.getElementById(screenshotViewId);LazyLoader.load([current]);current.style.zIndex=this.stack[this.stack.length-1].zIndex;currentClassList=current.classList;if(transition.indexOf('search')!==-1){currentClassList.add('search');}else{currentClassList.add('contact-list');}
currentClassList.remove('hide');}else{current=document.getElementById(_currentView);currentClassList=current.classList;}
var forwardsClasses=this.transitions[transition].forwards;currentClassList.add('block-item');if(forwardsClasses.current){currentClassList.add(forwardsClasses.current);}
var next=document.getElementById(nextView);if(forwardsClasses.next){next.classList.add('block-item');next.classList.add(forwardsClasses.next);next.addEventListener('animationend',function ng_onNextBackwards(ev){next.removeEventListener('animationend',ng_onNextBackwards);next.classList.remove('block-item');});}
next.classList.add('current');var realCurrentView=document.getElementById(_currentView);var _callbackInner=function _callback(){next.classList.add('current');realCurrentView.classList.remove('current');if(callback){callback();}};if(transition==='none'){setTimeout(_callbackInner,0);}else{waitForAnimation(next,_callbackInner);}
var zIndex=++navigationStack._zIndex;this.stack.push({view:nextView,transition:transition,zIndex:zIndex});next.style.zIndex=zIndex;_currentView=nextView;};this.back=function back(callback){if(this.stack.length<2){if(typeof callback==='function'){setTimeout(callback,0);}
return;}
var currentView=this.stack.pop();var current=document.getElementById(currentView.view);var currentClassList=current.classList;var nextView=this.stack[this.stack.length-1];var transition=currentView.transition;var next=document.getElementById(nextView.view);var nextClassList;if(transition.indexOf('go-deeper')===0){next=document.getElementById(screenshotViewId);}else{next=document.getElementById(nextView.view);}
nextClassList=next.classList;var forwardsClasses=this.transitions[transition].forwards;var backwardsClasses=this.transitions[transition].backwards;if(currentView.view=='view-contact-form'){parent.postMessage({type:'show-navbar'},COMMS_APP_ORIGIN);}
if(backwardsClasses.current){currentClassList.add('block-item');currentClassList.add(backwardsClasses.current);current.addEventListener('animationend',function ng_onCurrentBackwards(){current.removeEventListener('animationend',ng_onCurrentBackwards);currentClassList.remove(forwardsClasses.next);currentClassList.remove(backwardsClasses.current);current.style.zIndex=null;currentClassList.remove('block-item');if(!backwardsClasses.next){nextClassList.remove('block-item');}});}else{current.style.zIndex=null;currentClassList.remove('block-item');if(!backwardsClasses.next){nextClassList.remove('block-item');}}
next.style.zIndex=nextView.zIndex;if(backwardsClasses.next){nextClassList.add(backwardsClasses.next);next.addEventListener('animationend',function ng_onNextBackwards(){next.removeEventListener('animationend',ng_onNextBackwards);nextClassList.remove(forwardsClasses.current);nextClassList.remove(backwardsClasses.next);if(transition.indexOf('go-deeper')===0){nextClassList.add('hide');nextClassList.remove('search');nextClassList.remove('contact-list');}
nextClassList.remove('block-item');});}
document.getElementById(nextView.view).classList.add('current');var _callbackInner=function _callbackInner(){document.getElementById(nextView.view).classList.add('current');currentClassList.remove('current');if(callback){callback();}};if((!backwardsClasses.current&&!backwardsClasses.next)||transition==='none'){setTimeout(_callbackInner,0);}else{waitForAnimation(current,_callbackInner);}
_currentView=nextView.view;navigationStack._zIndex=nextView.zIndex;};this.home=function home(callback){if(this.stack.length<2){if(typeof callback==='function'){setTimeout(callback,0);}
return;}
while(this.stack.length>1){this.back(callback);}};this.currentView=function currentView(){return _currentView!=null?_currentView:'';};};'use strict';var contacts=window.contacts||{};contacts.List=(function(){var _,groupsList,loaded=false,cancel,contactsListView,fastScroll,scrollable,settingsView,noContacts,imgLoader=null,needImgLoaderReload=false,orderByLastName=null,defaultImage=null,photoTemplate,headers={},loadedContacts={},viewHeight=-1,rowsPerPage=-1,monitor=null,loading=false,cancelLoadCB=null,photosById={},clonableSelectCheck=null,deselectAll=null,selectAll=null,selectAllPending=false,inSelectMode=false,selectForm=null,selectActionButton=null,groupList=null,searchList=null,currentlySelected=0,selectNavigationController=null,boundSelectAction4Select=null,rowsOnScreen={},selectedContacts={},_notifyRowOnScreenCallback=null,_notifyRowOnScreenUUID=null,iceContacts=[],iceGroup=null,forceICEGroupToBeHidden=false;var ORDER_BY_FAMILY_NAME='familyName';var EXPORT_TRANSITION_LEVEL=2;var isDangerSelectList=false;var MAX_INT=0x7fffffff;var GROUP_LETTERS={'favorites':'','und':'#'};var GROUP_ORDER=(function getGroupOrder(){var letters='ABCDEFGHIJKLMNOPQRSTUVWXYZ'+'ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ'+'АБВГДЂЕЁЖЗИЙЈКЛЉМНЊОПРСТЋУФХЦЧЏШЩЭЮЯ';var order={'ice':0,'favorites':1};var presetsLength=Object.keys(order).length;for(var i=0;i<letters.length;i++){order[letters[i]]=i+presetsLength;}
order.und=i+1;return order;})();var NOP_FUNCTION=function(){};var onscreen=function(row){var id=row.dataset.uuid;var group=row.dataset.group;if(!id||!group){return;}
rowsOnScreen[id]=rowsOnScreen[id]||{};rowsOnScreen[id][group]=row;monitor&&monitor.pauseMonitoringMutations();renderLoadedContact(row,id);updateRowStyle(row,true);renderPhoto(row,id,false,group);updateSingleRowSelection(row,id);if(imgLoader&&needImgLoaderReload){needImgLoaderReload=false;imgLoader.reload();}
if(_notifyRowOnScreenUUID===id){_notifyRowOnScreenCallback(row);_clearNotifyRowOnScreenByUUID();}
monitor&&monitor.resumeMonitoringMutations(false);};var renderLoadedContact=function(el,id){if(el.dataset.rendered){return;}
id=id||el.dataset.uuid;var group=el.dataset.group;var contact=loadedContacts[id]?loadedContacts[id][group]:null;if(!contact){return;}
renderContact(contact,el);clearLoadedContact(el,id,group);};var clearLoadedContact=function(el,id,group){if(!el.dataset.rendered||!el.dataset.order||!el.dataset.search){return;}
id=id||el.dataset.uuid;group=group||el.dataset.group;if(loadedContacts[id]){loadedContacts[id][group]=null;}};var offscreen=function(row){var id=row.dataset.uuid;var group=row.dataset.group;if(!id||!group){return;}
if(rowsOnScreen[id]){delete rowsOnScreen[id][group];}
monitor&&monitor.pauseMonitoringMutations();updateRowStyle(row,false);var search=contacts.Search;if(!search||!search.isInSearchMode()){releasePhoto(row);}
monitor&&monitor.resumeMonitoringMutations(false);};var init=function load(element,reset){_=navigator.mozL10n.get;cancel=document.getElementById('cancel-search'),contactsListView=document.getElementById('view-contacts-list'),fastScroll=document.querySelector('nav[data-type="scrollbar"]'),scrollable=document.querySelector('#groups-container');settingsView=document.querySelector('#view-settings .view-body-inner');noContacts=document.querySelector('#no-contacts');groupsList=document.getElementById('groups-list');groupsList.addEventListener('click',onClickHandler);initConfiguration();if(reset){resetDom();}
createPhotoTemplate();};function hide(){contactsListView.classList.add('hide');if(monitor){monitor.pauseMonitoringMutations();}}
function show(){contactsListView.classList.remove('hide');needImgLoaderReload=true;if(monitor){monitor.resumeMonitoringMutations(true);}}
var NODE_SELECTOR='section:not([data-nonsearchable="true"]) > ol > li';var searchSource={getNodes:function(){var domNodes=contactsListView.querySelectorAll(NODE_SELECTOR);return Array.prototype.slice.call(domNodes);},getFirstNode:function(){return contactsListView.querySelector(NODE_SELECTOR);},getNextNode:function(contact){var out=contact.nextElementSibling;var nextParent=contact.parentNode.parentNode.nextElementSibling;while(!out&&nextParent){out=nextParent.querySelector('ol > li:first-child');nextParent=nextParent.nextElementSibling;}
return out;},expectMoreNodes:function(){return loading;},clone:function(node){var id=node.dataset.uuid;renderLoadedContact(node,id);updateRowStyle(node,true);updateSingleRowSelection(node,id);var out=node.cloneNode(true);renderPhoto(out,id,true,node.dataset.group);return out;},getNodeById:function(id){return contactsListView.querySelector('[data-uuid="'+id+'"]');},getSearchText:function(node){renderSearchString(node);return node.dataset.search;},click:onClickHandler};var initSearch=function initSearch(callback){contacts.Search.init(searchSource,true,selectNavigationController);if(callback){callback();}};var initAlphaScroll=function initAlphaScroll(){var overlay=document.querySelector('nav[data-type="scrollbar"] p');var jumper=document.querySelector('nav[data-type="scrollbar"] ol');var params={overlay:overlay,jumper:jumper,groupSelector:'#group-',scrollToCb:scrollToCb};utils.alphaScroll.init(params);if(iceContacts.length>0){utils.alphaScroll.showGroup('ice');}else{utils.alphaScroll.hideGroup('ice');}};var scrollToCb=function scrollCb(domTarget,group){if(domTarget.offsetTop>0){scrollable.scrollTop=domTarget.offsetTop;}else if(group==='search-container'){scrollable.scrollTop=0;}};var load=function load(contacts,forceReset,callback){var onError=function(){console.log('ERROR Retrieving contacts');};var complete=function complete(){initConfiguration(function onInitConfiguration(){getContactsByGroup(onError,contacts);if(typeof callback==='function'){callback();}});};if(loaded||forceReset){resetDom(complete);return;}
complete();};function getFbUid(devContact){var out;if(Array.isArray(devContact.category)){var idx=devContact.category.indexOf('facebook');if(idx!==-1){out=devContact.category[idx+2];}}
return out;}
var initConfiguration=function initConfiguration(callback){callback=callback||function(){};if(orderByLastName!==null&&defaultImage!==null){callback();return;}
var config=utils.cookie.load();if(config){orderByLastName=config.order;defaultImage=config.defaultImage;callback();return;}
utils.config.load('/contacts/config.json').then(function ready(configData){orderByLastName=(configData.defaultContactsOrder===ORDER_BY_FAMILY_NAME?true:false);defaultImage=configData.defaultImage===true;utils.cookie.update({order:orderByLastName,defaultImage:defaultImage});callback();},function configError(err){window.console.error('Error while reading configuration file');orderByLastName=utils.cookie.getDefault('order');defaultImage=utils.cookie.getDefault('defaultImage');utils.cookie.update({order:orderByLastName,defaultImage:defaultImage});callback();});};var renderGroupHeader=function renderGroupHeader(group,letter){var letteredSection=document.createElement('section');letteredSection.id='section-group-'+group;letteredSection.className='group-section';var title=document.createElement('header');title.id='group-'+group;title.className='hide';if(group==='favorites'){letteredSection.dataset.nonsearchable=true;}
var letterAbbr=document.createElement('abbr');var letterAbbrId='contacts-listed-abbr-'+group;letterAbbr.setAttribute('title','Contacts listed '+group);letterAbbr.setAttribute('aria-hidden',true);letterAbbr.id=letterAbbrId;letterAbbr.textContent=letter;title.setAttribute('aria-labelledby',letterAbbrId);title.appendChild(letterAbbr);var contactsContainer=document.createElement('ol');contactsContainer.setAttribute('role','listbox');contactsContainer.setAttribute('aria-labelledby',letterAbbrId);contactsContainer.id='contacts-list-'+group;contactsContainer.dataset.group=group;letteredSection.appendChild(title);letteredSection.appendChild(contactsContainer);headers[group]=contactsContainer;if(groupsList.children.length===0){groupsList.appendChild(letteredSection);return;}
var order=GROUP_ORDER[group];if(typeof order!=='number'){groupsList.appendChild(letteredSection);return;}
for(var i=groupsList.children.length-1;i>=0;--i){var node=groupsList.children[i];var cmpGroup=node.lastChild.dataset.group;var cmpOrder=GROUP_ORDER[cmpGroup];if(cmpOrder<=order){var next=node.nextSibling;if(next){groupsList.insertBefore(letteredSection,next);}else{groupsList.appendChild(letteredSection);}
break;}}
if(i<0){groupsList.insertBefore(letteredSection,groupsList.firstChild);}};function getGroupList(group){var list=headers[group];if(list){return list;}
var letter=GROUP_LETTERS[group];if(typeof letter!=='string'){letter=group;}
renderGroupHeader(group,letter);return headers[group];}
var renderContact=function renderContact(contact,container){container=container||createPlaceholder(contact);var fbUid=getFbUid(contact);if(fbUid){container.dataset.fbUid=fbUid;}
container.className='contact-item';container.setAttribute('role','option');var timestampDate=contact.updated||contact.published||new Date();container.dataset.updated=timestampDate.getTime();var check=getSelectCheck(contact.id);container.appendChild(check);var display=getDisplayName(contact);var nameElement=getHighlightedName(display);container.appendChild(nameElement);renderOrg(contact,container,true);container.dataset.rendered=true;return container;};var renderSearchString=function renderSearchString(node,contact){if(node.dataset.search){return;}
contact=contact||loadedContacts[node.dataset.uuid][node.dataset.group];if(!contact){return;}
var display=getDisplayName(contact);node.dataset.search=getSearchString(contact,display);clearLoadedContact(node,contact.id,node.dataset.group);};var renderOrderString=function renderOrderString(node,contact){if(node.dataset.order){return;}
contact=contact||loadedContacts[node.dataset.uuid][node.dataset.group];if(!contact){return;}
var display=getDisplayName(contact);node.dataset.order=getStringToBeOrdered(contact,display);clearLoadedContact(node,contact.id,node.dataset.group);};var createPlaceholder=function createPlaceholder(contact,group){var ph=document.createElement('li');ph.dataset.uuid=contact.id;group=group||getFastGroupName(contact);var order=null;if(!group){order=getStringToBeOrdered(contact);group=getGroupNameByOrderString(order);}
ph.setAttribute('role','option');ph.dataset.group=group;var display=getDisplayName(contact);if(!display.modified&&order){ph.dataset.order=order;}
return ph;};var getStringValue=function getStringValue(contact,field){if(contact[field]&&contact[field][0]){return String(contact[field][0]).trim();}
return null;};var getSearchString=function getSearchString(contact,display){display=display||contact;var searchInfo=[];var searchable=['givenName','familyName'];searchable.forEach(function(field){var value=getStringValue(display,field);if(value){searchInfo.push(value);}});var value=getStringValue(contact,'org');if(value){searchInfo.push(value);}
if(contact.tel&&contact.tel.length){for(var i=contact.tel.length-1;i>=0;i--){var current=contact.tel[i];searchInfo.push(current.value);}}
var escapedValue=Normalizer.escapeHTML(searchInfo.join(' '),true);return Normalizer.toAscii(escapedValue);};function getHighlightedName(contact,ele){if(!ele){ele=document.createElement('p');}
ele.classList.add('contact-text');var givenName=(contact.givenName&&contact.givenName[0])||'';var familyName=(contact.familyName&&contact.familyName[0])||'';function createStrongTag(content){var fs=document.createElement('strong');fs.textContent=content;return fs;}
if(orderByLastName){ele.appendChild(document.createTextNode(givenName+' '));ele.appendChild(createStrongTag(familyName));}else{ele.appendChild(createStrongTag(givenName));ele.appendChild(document.createTextNode(' '+familyName));}
return ele;}
function createSocialMark(){var span=document.createElement('span');span.classList.add('icon-social');return span;}
function markAsFb(ele){ele.classList.add('icon-fb');return ele;}
var CHUNK_SIZE=20;function loadChunk(chunk){var nodes=[];for(var i=0,n=chunk.length;i<n;++i){if(i===getRowsPerPage()){notifyAboveTheFold();}
var newNodes=appendToLists(chunk[i]);nodes.push.apply(nodes,newNodes);}
if(i<getRowsPerPage()){notifyAboveTheFold();}
if(contacts.Search&&contacts.Search.appendNodes){contacts.Search.appendNodes(nodes);}}
var notifiedAboveTheFold=false;function notifyAboveTheFold(){if(notifiedAboveTheFold){return;}
notifiedAboveTheFold=true;utils.PerformanceHelper.contentInteractive();var vm_file='/shared/js/tag_visibility_monitor.js';LazyLoader.load([vm_file],function(){var scrollMargin=~~(getViewHeight()*1.5);var scrollDelta=~~(scrollMargin/15);monitor=monitorTagVisibility(scrollable,'li',scrollMargin,scrollDelta,onscreen,offscreen);});}
function getViewHeight(config){if(viewHeight<0){config=config||utils.cookie.load();if(config&&config.viewHeight>-1){viewHeight=config.viewHeight;}else{viewHeight=scrollable.getBoundingClientRect().height;utils.cookie.update({viewHeight:viewHeight});}}
return viewHeight;}
function getRowsPerPage(){if(rowsPerPage<0){var config=utils.cookie.load();if(config&&config.rowsPerPage>-1){rowsPerPage=config.rowsPerPage;}}
if(rowsPerPage<0){return MAX_INT;}
return rowsPerPage;}
function setRowsPerPage(row){if(rowsPerPage>-1){return;}
var rowHeight=row.getBoundingClientRect().height;rowsPerPage=Math.ceil(getViewHeight()/rowHeight);utils.cookie.update({rowsPerPage:rowsPerPage});}
function appendToLists(contact){updatePhoto(contact);var ph=createPlaceholder(contact);var groups=[ph.dataset.group];if(isFavorite(contact)){groups.push('favorites');}
var nodes=[];for(var i=0,n=groups.length;i<n;++i){ph=appendToList(contact,groups[i],ph);nodes.push(ph);ph=null;}
selectedContacts[contact.id]=selectAllPending;return nodes;}
function appendToList(contact,group,ph){ph=ph||createPlaceholder(contact,group);var list=getGroupList(group);if(list.children.length<getRowsPerPage()){renderContact(contact,ph);}
if(!loadedContacts[contact.id]){loadedContacts[contact.id]={};}
loadedContacts[contact.id][group]=contact;list.appendChild(ph);if(list.children.length===1){showGroupByList(list);setRowsPerPage(list.firstChild);}
return ph;}
var onListRendered=function onListRendered(){selectAllPending=false;notifyAboveTheFold();utils.PerformanceHelper.loadEnd();fb.init(function contacts_init(){if(fb.isEnabled){Contacts.loadFacebook(NOP_FUNCTION);}
lazyLoadImages();loaded=true;});loadICE();};function loadICE(){LazyLoader.load(['/contacts/js/utilities/ice_data.js','/shared/js/contacts/utilities/ice_store.js'],function(){ICEStore.getContacts().then(displayICEIndicator);ICEStore.onChange(function(){ICEStore.getContacts().then(displayICEIndicator);});});}
function displayICEIndicator(ids){if(!iceGroup){buildICEGroup();}
if(!ids||ids.length===0){hideICEGroup();return;}
iceContacts=ids;showICEGroup();}
function toggleICEGroup(show){if(!iceGroup){return;}
forceICEGroupToBeHidden=!(!!show);forceICEGroupToBeHidden?hideICEGroup():showICEGroup();}
function showICEGroup(){if(forceICEGroupToBeHidden){return;}
iceGroup.classList.remove('hide');utils.alphaScroll.showGroup('ice');}
function hideICEGroup(){iceGroup.classList.add('hide');utils.alphaScroll.hideGroup('ice');}
function buildICEGroup(){iceGroup=document.createElement('section');iceGroup.classList.add('group-section');iceGroup.id='section-group-ice';iceGroup.dataset.nonsearchable=true;var list=document.createElement('ol');list.dataset.group='ice';list.id='contact-list-ice';list.role='listbox';var elem=document.createElement('li');elem.classList.add('contact-item');elem.dataset.group='ice';var icon=document.createElement('span');icon.src='/contacts/style/images/icon_ice.png';var p=document.createElement('p');p.classList.add('contact-text');p.setAttribute('data-l10n-id','ICEContactsGroup');groupsList.insertBefore(iceGroup,groupsList.firstChild).appendChild(list).appendChild(elem);elem.appendChild(icon);elem.appendChild(p);iceGroup.addEventListener('click',onICEGroupClicked);ICEData.listenForChanges(function(data){if(!Array.isArray(data)||data.length===0){hideICEGroup();}});}
function onICEGroupClicked(){Contacts.view('Ice',function(){function rowBuilder(id,node){renderLoadedContact(node,id);updateRowStyle(node,true);updateSingleRowSelection(node,id);var out=node.cloneNode(true);renderPhoto(out,id,true,out.dataset.group);return out;}
contacts.ICEView.init(iceContacts,rowBuilder,onClickHandler);contacts.ICEView.showICEList();});}
var isFavorite=function isFavorite(contact){return contact.category&&contact.category.indexOf('favorite')!=-1;};var lazyLoadImages=function lazyLoadImages(){LazyLoader.load(['/shared/js/contacts/utilities/image_loader.js','/contacts/js/fb_resolver.js'],function(){if(!imgLoader){imgLoader=new ImageLoader('#groups-container','li:not([data-group="ice"])');imgLoader.setResolver(fb.resolver);}
imgLoader.reload();});};var dispatchCustomEvent=function dispatchCustomEvent(eventName){var event=new CustomEvent(eventName);window.dispatchEvent(event);};var updatePhoto=function updatePhoto(contact,id){id=id||contact.id;var prevPhoto=photosById[id];var newPhoto=ContactPhotoHelper.getThumbnail(contact);if((!prevPhoto&&!newPhoto)||(prevPhoto===newPhoto)){return false;}
if(newPhoto){photosById[id]=newPhoto;}
else{delete photosById[id];}
return true;};var hasPhoto=function hasPhoto(id){return!!photosById[id];};function setImageURL(img,photo,asClone){var oldURL=img.dataset.src;if(oldURL){if(!asClone){window.URL.revokeObjectURL(oldURL);}
img.dataset.src='';}
if(photo){try{img.dataset.src=window.URL.createObjectURL(photo);}catch(err){console.warn('Failed to create URL for contacts image blob: '+photo+', error: '+err);}}}
var renderPhoto=function renderPhoto(link,id,asClone,group){id=id||link.dataset.uuid;var img=link.querySelector('aside > span[data-type=img]');var photo=photosById[id];if(!photo){if(defaultImage){renderDefaultPhoto(img,link,group);}
return;}
if(img){delete img.dataset.group;img.style.backgroundPosition=img.dataset.backgroundPosition||'';setImageURL(img,photo,asClone);return;}
var figure=photoTemplate.cloneNode(true);img=figure.children[0];setImageURL(img,photo);link.insertBefore(figure,link.children[0]);return;};function createPhotoTemplate(){if(photoTemplate){return;}
photoTemplate=document.createElement('aside');photoTemplate.setAttribute('aria-hidden',true);photoTemplate.className='pack-end';var img=document.createElement('span');img.dataset.type='img';photoTemplate.appendChild(img);}
var renderDefaultPhoto=function renderDefaultPhoto(img,link,group){if(!img){var figure=photoTemplate.cloneNode(true);img=figure.children[0];img.dataset.backgroundPosition=img.style.backgroundPosition;var posH=['left','center','right'];var posV=['top','center','bottom'];var position=posH[Math.floor(Math.random()*3)]+' '+
posV[Math.floor(Math.random()*3)];img.style.backgroundPosition=position;link.insertBefore(figure,link.children[0]);}
if(group==='favorites'){var contact=loadedContacts[link.dataset.uuid][group];var order=getStringToBeOrdered(contact);group=getGroupNameByOrderString(order);}
if(group==='und'){group='#';}
img.dataset.group=group;};var releasePhoto=function releasePhoto(el){if(!imgLoader){return;}
var img=imgLoader.releaseImage(el);if(!img){return;}
setImageURL(img,null);};var renderOrg=function renderOrg(contact,link,add){if(!contact.org||!contact.org.length||contact.org[0]===''||contact.org[0]===contact.givenName){return;}
if(add){addOrgMarkup(link,contact.org[0]);return;}
var org=link.lastElementChild.querySelector('span.org');org.textContent=contact.org[0];};function renderFbData(contact,link){var meta;var elements=link.getElementsByTagName('p');if(elements.length==1){meta=addOrgMarkup(link);}else{meta=elements[1];}
var mark=markAsFb(createSocialMark());var org=meta.querySelector('span.org');meta.insertBefore(mark,org);if(!contact.org||!contact.org.length){mark.classList.add('notorg');}else{renderOrg(contact,link);}}
var addOrgMarkup=function addOrgMarkup(link,content){var span=document.createElement('span');span.className='org';if(content){span.textContent=content;}
var meta=document.createElement('p');meta.classList.add('contact-text');meta.appendChild(span);link.appendChild(meta);return meta;};var toggleNoContactsScreen=function cl_toggleNoContacs(show){if(show){if(!ActivityHandler.currentlyHandling){noContacts.classList.remove('hide');fastScroll.classList.add('hide');scrollable.classList.add('hide');return;}
if(ActivityHandler.currentActivityIs(['pick','update'])){showNoContactsAlert();return;}}
noContacts.classList.add('hide');fastScroll.classList.remove('hide');scrollable.classList.remove('hide');};var showNoContactsAlert=function showNoContactsAlert(){var msg='noContactsActivity';var noObject={title:'ok',isDanger:false,callback:function onNoClicked(){ConfirmDialog.hide();ActivityHandler.postCancel();}};Contacts.confirmDialog(null,msg,noObject);};var getContactsByGroup=function gCtByGroup(errorCb,contacts){if(!Contacts.asyncScriptsLoaded){window.addEventListener('asyncScriptsLoaded',function listener(){window.removeEventListener('asyncScriptsLoaded',listener);getContactsByGroup(errorCb,contacts);});return;}
notifiedAboveTheFold=false;if(contacts){if(!contacts.length){toggleNoContactsScreen(true);dispatchCustomEvent('listRendered');return;}
toggleNoContactsScreen(false);loadChunk(contacts);onListRendered();dispatchCustomEvent('listRendered');return;}
getAllContacts(errorCb,loadChunk);};var getContactById=function(contactID,successCb,errorCb){if(!contactID){successCb();return;}
var options={filterBy:['id'],filterOp:'equals',filterValue:contactID};var request=navigator.mozContacts.find(options);request.onsuccess=function findCallback(e){var result=e.target.result[0];if(!fb.isFbContact(result)){successCb(result);return;}
var fbContact=new fb.Contact(result);var fbReq=fbContact.getData();fbReq.onsuccess=function(){successCb(result,fbReq.result);};fbReq.onerror=successCb.bind(null,result);};if(typeof errorCb==='function'){request.onerror=errorCb;}};var getAllContacts=function cl_getAllContacts(errorCb,successCb){loading=true;initConfiguration(function onInitConfiguration(){var sortBy=(orderByLastName===true?'familyName':'givenName');var options={sortBy:sortBy,sortOrder:'ascending'};var cursor=navigator.mozContacts.getAll(options);var successCb=successCb||loadChunk;var num=0;var chunk=[];cursor.onsuccess=function onsuccess(evt){if(cancelLoadCB){loading=false;var cb=cancelLoadCB;cancelLoadCB=null;return cb();}
var contact=evt.target.result;if(contact){chunk.push(contact);if(num&&(num%CHUNK_SIZE===0)){successCb(chunk);chunk=[];}
num++;cursor.continue();}else{if(chunk.length){successCb(chunk);}
var showNoContacs=(num===0);toggleNoContactsScreen(showNoContacs);onListRendered();dispatchCustomEvent('listRendered');loading=false;}};cursor.onerror=errorCb;});};var addToList=function addToList(contact){var renderedNode=renderContact(contact);renderSearchString(renderedNode,contact);renderOrderString(renderedNode,contact);if(updatePhoto(contact)){renderPhoto(renderedNode,contact.id);}
var list=getGroupList(renderedNode.dataset.group);addToGroup(renderedNode,list);if(!loadedContacts[contact.id]){loadedContacts[contact.id]={};}
loadedContacts[contact.id][renderedNode.dataset.group]=contact;if(isFavorite(contact)){list=getGroupList('favorites');loadedContacts[contact.id].favorites=contact;var cloned=renderedNode.cloneNode(true);cloned.dataset.group='favorites';renderPhoto(cloned,contact.id,false,'favorites');addToGroup(cloned,list);}
toggleNoContactsScreen(false);if(imgLoader){needImgLoaderReload=true;}
selectedContacts[contact.id]=selectAllPending||(selectAll&&selectAll.disabled);};var hasName=function hasName(contact){return(Array.isArray(contact.givenName)&&contact.givenName[0]&&contact.givenName[0].trim())||(Array.isArray(contact.familyName)&&contact.familyName[0]&&contact.familyName[0].trim());};var getDisplayName=function getDisplayName(contact){if(hasName(contact)){return{givenName:contact.givenName,familyName:contact.familyName};}
var givenName=[];if(contact.org&&contact.org.length>0){givenName.push(contact.org[0]);}else if(contact.tel&&contact.tel.length>0){givenName.push(contact.tel[0].value);}else if(contact.email&&contact.email.length>0){givenName.push(contact.email[0].value);}else{givenName.push(_('noName'));}
return{givenName:givenName,modified:true};};function searchNodes(nodes,name){var len=nodes.length;var begin=0;var end=len;var comp=0;var target=len;while(begin<=end){target=~~((begin+end)/2);if(target>=len){break;}
var targetNode=nodes[target];renderOrderString(targetNode);var targetName=targetNode.dataset.order;comp=name.localeCompare(targetName);if(comp<0){end=target-1;}else if(comp>0){begin=target+1;}else{return target;}}
if(target>=len){return len;}
if(comp<=0){return target;}
return target+1;}
var addToGroup=function addToGroup(renderedNode,list){renderOrderString(renderedNode);var newLi=renderedNode;var cName=newLi.dataset.order;var liElems=list.getElementsByTagName('li');var insertAt=searchNodes(liElems,cName);if(insertAt<liElems.length){list.insertBefore(newLi,liElems[insertAt]);}else{list.appendChild(newLi);}
if(list.children.length===1){showGroupByList(list);}
return list.children.length;};var hideGroup=function hideGroup(group){var groupTitle=getGroupList(group).parentNode.children[0];groupTitle.classList.add('hide');};var showGroupByList=function showGroupByList(current){var groupTitle=current.parentNode.children[0];groupTitle.classList.remove('hide');};var remove=function remove(id){if(!(id in selectedContacts)){return;}
var items=groupsList.querySelectorAll('li[data-uuid=\"'+id+'\"]');Array.prototype.forEach.call(items,function removeItem(item){var ol=item.parentNode;ol.removeChild(item);if(ol.children.length<1){hideGroup(ol.dataset.group);}});delete photosById[id];var selector='section header:not(.hide)';var visibleElements=groupsList.querySelectorAll(selector);var showNoContacts=visibleElements.length===0;toggleNoContactsScreen(showNoContacts);delete selectedContacts[id];};var getStringToBeOrdered=function getStringToBeOrdered(contact,display){var ret=[];display=display||contact;var familyName,givenName;familyName=getStringValue(display,'familyName')||'';givenName=getStringValue(display,'givenName')||'';var first=givenName,second=familyName;if(orderByLastName){first=familyName;second=givenName;}
ret.push(first);ret.push(second);if(first!==''||second!==''){return Normalizer.toAscii(ret.join('')).toUpperCase().trim();}
ret.push(contact.org);ret.push(contact.tel&&contact.tel.length>0?contact.tel[0].value.trim():'');ret.push(contact.email&&contact.email.length>0?contact.email[0].value.trim():'');ret.push('#');return Normalizer.toAscii(ret.join('')).toUpperCase().trim();};var getFastGroupName=function getFastGroupName(contact){var field=orderByLastName?'familyName':'givenName';var value=contact[field]?contact[field][0]:null;if(!value||!value.length){return null;}
var ret=value.charAt(0).toUpperCase();if(!(ret in GROUP_ORDER)){return null;}
return ret;};var getGroupNameByOrderString=function getGroupNameByOrderString(order){var ret=order.charAt(0);if(!(ret in GROUP_ORDER)){ret='und';}
return ret;};var refresh=function refresh(idOrContact,callback){if(typeof(idOrContact)!=='string'){refreshContact(idOrContact,null,callback);return;}
getContactById(idOrContact,function(contact,fbData){var enrichedContact=null;if(fb.isFbContact(contact)){var fbContact=new fb.Contact(contact);enrichedContact=fbContact.merge(fbData);}
refreshContact(contact,enrichedContact,callback);});};function refreshContact(contact,enriched,callback){remove(contact.id);addToList(contact,enriched);if(contacts.Search){contacts.Search.updateSearchList(function(){if(callback){callback(contact.id);}});}else if(callback){callback(contact.id);}}
var callbacks=[];var handleClick=function handleClick(callback){callbacks.push(callback);};var clearClickHandlers=function clearClickHandlers(){callbacks=[];};function onClickHandler(evt){var target=evt.target;var dataset=target.dataset||{};var parentDataset=target.parentNode?(target.parentNode.dataset||{}):{};var uuid=dataset.uuid||parentDataset.uuid;if(uuid){callbacks.forEach(function(callback){callback(uuid);});}
evt.preventDefault();}
var resetDom=function resetDom(cb){if(loading){cancelLoadCB=resetDom.bind(null,cb);return;}
iceGroup=null;utils.dom.removeChildNodes(groupsList);headers={};loadedContacts={};loaded=false;if(cb){cb();}};var setOrderByLastName=function setOrderByLastName(value){orderByLastName=value;};var getSelectCheck=function getSelectCheck(uuid){if(clonableSelectCheck===null){clonableSelectCheck=buildSelectCheck();}
var result=clonableSelectCheck.cloneNode(true);var check=result.firstChild;check.setAttribute('value',uuid);return result;};var buildSelectCheck=function buildSelectCheck(){var label=document.createElement('label');label.classList.add('contact-checkbox');label.classList.add('pack-checkbox');var input=document.createElement('input');input.name='selectIds[]';input.type='checkbox';label.appendChild(input);var span=document.createElement('span');label.appendChild(span);return label;};var selectAction=function selectAction(action){updateSelectCount(0);if(action==null){exitSelectMode();return;}
var selectionPromise=createSelectPromise();if(selectAllPending){action(selectionPromise,exitSelectMode);selectionPromise.resolve();return;}
var ids=[];for(var id in selectedContacts){if(selectedContacts[id]){ids.push(id);}}
if(ids.length===0){return;}
action(selectionPromise,exitSelectMode);selectionPromise.resolve(ids);};var handleSelection=function handleSelection(evt){var action=null;if(evt){evt.preventDefault();action=evt.target.id;}
var selectAllDisabled=false;var deselectAllDisabled=false;currentlySelected=countSelectedContacts();switch(action){case'deselect-all':selectAllPending=false;deselectAllContacts();currentlySelected=0;deselectAllDisabled=true;break;case'select-all':selectAllPending=true&&!loaded;selectAllContacts();currentlySelected=contacts.List.total;selectAllDisabled=true;break;default:selectAllDisabled=currentlySelected==contacts.List.total;deselectAllDisabled=currentlySelected===0;break;}
updateRowsOnScreen();selectActionButton.disabled=currentlySelected===0;selectAll.disabled=selectAllDisabled;deselectAll.disabled=deselectAllDisabled;updateSelectCount(currentlySelected);};var createSelectPromise=function createSelectPromise(){var promise={canceled:false,_selected:[],resolved:false,successCb:null,errorCb:null,resolve:function resolve(values){var self=this;setTimeout(function onResolve(){if(values){self._selected=values;self.resolved=true;if(self.successCb){self.successCb(values);}
return;}
var notSelectedIds={};for(var id in selectedContacts){if(!selectedContacts[id]){notSelectedIds[id]=true;}}
var notSelectedCount=Object.keys(notSelectedIds).length;var request=navigator.mozContacts.find({});request.onsuccess=function onAllContacts(){request.result.forEach(function onContact(contact){if(notSelectedCount===0||notSelectedIds[contact.id]===undefined){self._selected.push(contact.id);}});self.resolved=true;if(self.successCb){self.successCb(self._selected);}};request.onerror=function onError(){self.reject();};},0);},reject:function reject(){this.canceled=true;if(this.errorCb){this.errorCb();}},set onsuccess(callback){if(this.resolved){callback(this._selected);}else{this.successCb=callback;}},set onerror(callback){if(this.canceled){callback();}else{this.errorCb=callback;}}};return promise;};function doSelectFromList(title,action,callback,options){if(selectForm===null){selectForm=document.getElementById('selectable-form');selectActionButton=document.getElementById('select-action');selectActionButton.disabled=true;selectAll=document.getElementById('select-all');selectAll.addEventListener('click',handleSelection);deselectAll=document.getElementById('deselect-all');deselectAll.addEventListener('click',handleSelection);selectForm.querySelector('#selectable-form-header').addEventListener('action',exitSelectMode.bind(null,true));}
isDangerSelectList=options&&options.isDanger;scrollable.classList.add('selecting');fastScroll.classList.add('selecting');utils.alphaScroll.toggleFormat('short');selectActionButton.textContent=title;selectActionButton.removeEventListener('click',boundSelectAction4Select);boundSelectAction4Select=selectAction.bind(null,action);selectActionButton.addEventListener('click',boundSelectAction4Select);updateSelectCount(0);selectForm.classList.remove('hide');selectForm.addEventListener('transitionend',function handler(){selectForm.removeEventListener('transitionend',handler);selectForm.classList.add('in-edit-mode');});window.setTimeout(function(){selectForm.classList.add('contacts-select');});if(groupList==null){groupList=document.getElementById('groups-list');}
groupList.classList.add('selecting');if(searchList==null){searchList=document.getElementById('search-list');}
searchList.classList.add('selecting');updateRowsOnScreen();clearClickHandlers();handleClick(function handleSelectClick(id,row){selectedContacts[id]=!selectedContacts[id];updateRowSelection([id]);handleSelection(null);if(contacts.Search&&contacts.Search.isInSearchMode()){contacts.Search.selectRow(id,selectedContacts[id]);}});if(callback){callback();}
if(contacts.List.total===0){var emptyPromise=createSelectPromise();emptyPromise.resolve([]);}}
var selectFromList=function selectFromList(title,action,callback,navigationController,options){inSelectMode=true;selectNavigationController=navigationController;document.getElementById('settings-button').classList.add('hide');document.getElementById('settings-close').disabled=true;document.getElementById('add-contact-button').classList.add('hide');if(options&&options.transitionLevel===EXPORT_TRANSITION_LEVEL){selectNavigationController.back(function(){Contacts.goBack(function(){doSelectFromList(title,action,callback,options);});});}
else{Contacts.goBack(function(){doSelectFromList(title,action,callback,options);});}};var updateRowsOnScreen=function updateRowsOnScreen(){if(monitor!=null){monitor.pauseMonitoringMutations();}
var row;for(var id in rowsOnScreen){for(var group in rowsOnScreen[id]){row=rowsOnScreen[id][group];updateRowStyle(row,true);updateSingleRowSelection(row,id);}}
if(monitor!=null){monitor.resumeMonitoringMutations(false);}};var updateRowStyle=function updateRowStyle(row,onscreen){if(inSelectMode&&onscreen){if(!row.dataset.selectStyleSet){utils.dom.addClassToNodes(row,'.contact-checkbox','contact-checkbox-selecting');utils.dom.addClassToNodes(row,'.contact-text','contact-text-selecting');row.dataset.selectStyleSet=true;}
var label=row.querySelector('label');if(isDangerSelectList){label.classList.add('danger');}
else{label.classList.remove('danger');}}else if(row.dataset.selectStyleSet){utils.dom.removeClassFromNodes(row,'.contact-checkbox-selecting','contact-checkbox-selecting');utils.dom.removeClassFromNodes(row,'.contact-text-selecting','contact-text-selecting');delete row.dataset.selectStyleSet;}};var updateRowSelection=function updateRowSelection(idToUpdate){for(var id in rowsOnScreen){for(var group in rowsOnScreen[id]){var row=rowsOnScreen[id][group];if(idToUpdate===id){updateSingleRowSelection(row,id);}}}};var updateSingleRowSelection=function updateSingleRowSelection(row,id){id=id||row.dataset.uuid;var check=row.querySelector('input[value="'+id+'"]');if(!check){return;}
check.checked=!!selectedContacts[id];};var selectAllContacts=function selectAllContacts(){for(var id in selectedContacts){selectedContacts[id]=true;}};var deselectAllContacts=function deselectAllContacts(){for(var id in selectedContacts){selectedContacts[id]=false;}};var countSelectedContacts=function countSelectedContacts(){var counter=0;for(var id in selectedContacts){if(selectedContacts[id]){counter++;}}
return counter;};var exitSelectMode=function exitSelectMode(canceling){isDangerSelectList=false;document.getElementById('settings-button').classList.remove('hide');document.getElementById('add-contact-button').classList.remove('hide');document.getElementById('settings-close').disabled=false;selectForm.addEventListener('transitionend',function handler(){selectForm.removeEventListener('transitionend',handler);window.setTimeout(function(){selectForm.classList.add('hide');});});selectForm.classList.remove('in-edit-mode');selectForm.classList.remove('contacts-select');inSelectMode=false;selectAllPending=false;currentlySelected=0;deselectAllContacts();deselectAll.disabled=true;selectAll.disabled=false;selectActionButton.disabled=true;groupList.classList.remove('selecting');searchList.classList.remove('selecting');scrollable.classList.remove('selecting');fastScroll.classList.remove('selecting');utils.alphaScroll.toggleFormat('normal');updateRowsOnScreen();clearClickHandlers();handleClick(Contacts.showContactDetail);};var refreshFb=function resfreshFb(uid){var selector='[data-fb-uid="'+uid+'"]';var node=document.querySelector(selector);if(node){if(node.dataset.uuid in rowsOnScreen){contacts.List.refresh(node.dataset.uuid);}}};function updateSelectCount(count){Contacts.updateSelectCountTitle(count);}
var notifyRowOnScreenByUUID=function notifyRowOnScreenByUUID(uuid,callback){if(typeof callback!=='function'||!uuid){return;}
if(rowsOnScreen[uuid]){var groups=Object.keys(rowsOnScreen[uuid]);var group=groups.length>1?groups[1]:groups[0];callback(rowsOnScreen[uuid][group]);_clearNotifyRowOnScreenByUUID();return;}
_notifyRowOnScreenCallback=callback;_notifyRowOnScreenUUID=uuid;};function _clearNotifyRowOnScreenByUUID(){_notifyRowOnScreenCallback=null;_notifyRowOnScreenUUID=null;}
return{'init':init,'load':load,'refresh':refresh,'refreshFb':refreshFb,'getContactById':getContactById,'getAllContacts':getAllContacts,'handleClick':handleClick,'hide':hide,'show':show,'initAlphaScroll':initAlphaScroll,'initSearch':initSearch,'remove':remove,'loaded':loaded,'clearClickHandlers':clearClickHandlers,'setOrderByLastName':setOrderByLastName,'renderPhoto':renderPhoto,'updatePhoto':updatePhoto,'hasPhoto':hasPhoto,'renderFbData':renderFbData,'getHighlightedName':getHighlightedName,'selectFromList':selectFromList,'exitSelectMode':exitSelectMode,get chunkSize(){return CHUNK_SIZE;},get total(){return Object.keys(selectedContacts).length;},get isSelecting(){return inSelectMode;},'notifyRowOnScreenByUUID':notifyRowOnScreenByUUID,'toggleICEGroup':toggleICEGroup};})();;'use strict';var COMMS_APP_ORIGIN=location.origin;var SCALE_RATIO=window.devicePixelRatio||1;var Contacts=(function(){var SHARED='shared';var SHARED_PATH='/'+SHARED+'/'+'js';var SHARED_UTILS='sharedUtilities';var SHARED_UTILS_PATH=SHARED_PATH+'/contacts/import/utilities';var SHARED_CONTACTS='sharedContacts';var SHARED_CONTACTS_PATH=SHARED_PATH+'/'+'contacts';var navigation=new navigationStack('view-contacts-list');var goToForm=function edit(){var transition=ActivityHandler.currentlyHandling?'activity-popup':'fade-in';navigation.go('view-contact-form',transition);};var contactTag,settings,settingsButton,header,addButton,appTitleElement,editModeTitleElement,asyncScriptsLoaded=false;var settingsReady=false;var detailsReady=false;var formReady=false;var displayed=false;var currentContact={},currentFbContact;var contactsList;var contactsDetails;var contactsForm;var customTag,customTagReset,tagDone,tagHeader,lazyLoadedTagsDom=false;function showEditForm(facebookData,params){contactsForm.render(currentContact,goToForm,facebookData,params.fromUpdateActivity);showApp();}
var checkUrl=function checkUrl(){var hasParams=window.location.hash.split('?');var hash=hasParams[0];var sectionId=hash.substr(1,hash.length)||'';var cList=contacts.List;var params=hasParams.length>1?utils.extractParams(hasParams[1]):-1;switch(sectionId){case'view-contact-list':initContactsList();showApp();break;case'view-contact-details':initContactsList();initDetails(function onInitDetails(){if(params==-1||!('id'in params)){console.error('Param missing');return;}
var id=params.id;cList.getContactById(id,function onSuccess(savedContact){currentContact=savedContact;if('mozNfc'in navigator){contacts.NFC.startListening(currentContact);}
contactsDetails.render(currentContact);navigation.go(sectionId,'right-left');showApp();},function onError(){console.error('Error retrieving contact');});});break;case'view-contact-form':initForm(function onInitForm(){if(params.mozContactParam){contactsForm.render(ActivityHandler.mozContactParam,goToForm);ActivityHandler.mozContactParam=null;}else if(params==-1||!(params.id)){contactsForm.render(params,goToForm);showApp();}else{if(params.id){var id=params.id;cList.getContactById(id,function onSuccess(savedContact){currentContact=savedContact;if('extras'in params){addExtrasToContact(params.extras);}
if(fb.isFbContact(savedContact)){var fbContact=new fb.Contact(savedContact);var req=fbContact.getDataAndValues();req.onsuccess=function(){showEditForm(req.result,params);};req.onerror=function(){console.error('Error retrieving FB information');showEditForm(null,params);};}
else{showEditForm(null,params);}},function onError(){console.error('Error retrieving contact to be edited');contactsForm.render(null,goToForm);showApp();});}}});break;case'add-parameters':initContactsList();initForm(function onInitForm(){navigation.home();if(ActivityHandler.currentlyHandling){selectList(params,true);}
showApp();});break;case'home':navigation.home();showApp();break;default:showApp();}};var showApp=function showApp(){if(displayed){return;}
document.body.classList.remove('hide');displayed=true;utils.PerformanceHelper.visuallyComplete();};var addExtrasToContact=function addExtrasToContact(extrasString){try{var extras=JSON.parse(decodeURIComponent(extrasString));for(var type in extras){var extra=extras[type];if(currentContact[type]){if(Array.isArray(currentContact[type])){var joinArray=currentContact[type].concat(extra);currentContact[type]=joinArray;}else{currentContact[type]=extra;}}else{currentContact[type]=Array.isArray(extra)?extra:[extra];}}}catch(e){console.error('Extras malformed');return null;}};var initContainers=function initContainers(){settings=document.getElementById('view-settings');settingsButton=document.getElementById('settings-button');header=document.getElementById('contacts-list-header');addButton=document.getElementById('add-contact-button');editModeTitleElement=document.getElementById('edit-title');appTitleElement=document.getElementById('app-title');};var onLocalized=function onLocalized(){init();addAsyncScripts();window.addEventListener('asyncScriptsLoaded',function onAsyncLoad(){asyncScriptsLoaded=true;window.removeEventListener('asyncScriptsLoaded',onAsyncLoad);if(contactsList){contactsList.initAlphaScroll();}
checkUrl();asyncScriptsLoaded=true;});};var loadDeferredActions=function loadDeferredActions(){window.removeEventListener('listRendered',loadDeferredActions);LazyLoader.load('js/deferred_actions.js',function(){DeferredActions.execute();});};var init=function init(){initContainers();initEventListeners();utils.PerformanceHelper.chromeInteractive();window.addEventListener('hashchange',checkUrl);window.addEventListener('listRendered',loadDeferredActions);};var initContactsList=function initContactsList(){if(contactsList){return;}
contactsList=contactsList||contacts.List;var list=document.getElementById('groups-list');contactsList.init(list);getFirstContacts();contactsList.initAlphaScroll();contactsList.handleClick(contactListClickHandler);checkCancelableActivity();};function setupCancelableHeader(alternativeTitle){header.setAttribute('action','close');settingsButton.hidden=true;addButton.hidden=true;if(alternativeTitle){appTitleElement.setAttribute('data-l10n-id',alternativeTitle);}
appTitleElement.textContent=appTitleElement.textContent;}
function setupActionableHeader(){header.removeAttribute('action');settingsButton.hidden=false;addButton.hidden=false;appTitleElement.setAttribute('data-l10n-id','contacts');}
var lastCustomHeaderCallback;var setCancelableHeader=function setCancelableHeader(cb,titleId){setupCancelableHeader(titleId);header.removeEventListener('action',handleCancel);lastCustomHeaderCallback=cb;header.addEventListener('action',cb);};var setNormalHeader=function setNormalHeader(){setupActionableHeader();header.removeEventListener('action',lastCustomHeaderCallback);header.addEventListener('action',handleCancel);};var checkCancelableActivity=function cancelableActivity(){if(ActivityHandler.currentlyHandling){var alternativeTitle=null;var activityName=ActivityHandler.activityName;if(activityName==='pick'||activityName==='update'){alternativeTitle='selectContact';}
setupCancelableHeader(alternativeTitle);}else{setupActionableHeader();}};var contactListClickHandler=function originalHandler(id){initDetails(function onDetailsReady(){contacts.List.getContactById(id,function findCb(contact,fbContact){if('mozNfc'in navigator){contacts.NFC.startListening(contact);}
currentContact=contact;currentFbContact=fbContact;if(ActivityHandler.currentActivityIsNot(['import'])){if(ActivityHandler.currentActivityIs(['pick'])){ActivityHandler.dataPickHandler(currentFbContact||currentContact);}
return;}
contactsDetails.render(currentContact,currentFbContact);if(contacts.Search&&contacts.Search.isInSearchMode()){navigation.go('view-contact-details','go-deeper-search');}else{navigation.go('view-contact-details','go-deeper');}});});};var updateContactDetail=function updateContactDetail(id){contactsList.getContactById(id,function findCallback(contact){currentContact=contact;contactsDetails.render(currentContact);});};var selectList=function selectList(params,fromUpdateActivity){addButton.classList.add('hide');contactsList.clearClickHandlers();contactsList.handleClick(function addToContactHandler(id){var data={};if(params.hasOwnProperty('tel')){var phoneNumber=params.tel;data.tel=[{'value':phoneNumber,'carrier':null,'type':[TAG_OPTIONS['phone-type'][0].type]}];}
if(params.hasOwnProperty('email')){var email=params.email;data.email=[{'value':email,'type':[TAG_OPTIONS['email-type'][0].type]}];}
var hash='#view-contact-form?extras='+
encodeURIComponent(JSON.stringify(data))+'&id='+id;if(fromUpdateActivity){hash+='&fromUpdateActivity=1';}
window.location.hash=hash;});};var getLength=function getLength(prop){if(!prop||!prop.length){return 0;}
return prop.length;};var updatePhoto=function updatePhoto(photo,dest){var background='';if(photo!=null){background='url('+URL.createObjectURL(photo)+')';}
dest.style.backgroundImage=background;dest.dataset.photoReady='true';};var isEmpty=function isEmpty(obj,fields){if(obj==null||typeof(obj)!='object'||!fields||!fields.length){return true;}
var attr;for(var i=0;i<fields.length;i++){attr=fields[i];if(obj[attr]){if(Array.isArray(obj[attr])){if(obj[attr].length>0){return false;}}else{return false;}}}
return true;};function showSelectTag(){var tagsList=document.getElementById('tags-list');var selectedTagType=contactTag.dataset.taglist;var options=TAG_OPTIONS[selectedTagType];var type=selectedTagType.split('-')[0];var isCustomTagVisible=(document.querySelector('[data-template]'+'.'+type+'-'+'template').dataset.custom!='false');options=ContactsTag.filterTags(type,contactTag,options);if(!customTag){customTag=document.querySelector('#custom-tag');customTag.addEventListener('keydown',handleCustomTag);customTag.addEventListener('touchend',handleCustomTag);}
if(!customTagReset){customTagReset=document.getElementById('custom-tag-reset');customTagReset.addEventListener('touchstart',handleCustomTagReset);}
if(!tagDone){tagDone=document.querySelector('#settings-done');tagDone.addEventListener('click',handleSelectTagDone);}
if(!tagHeader){tagHeader=document.querySelector('#settings-header');tagHeader.addEventListener('action',handleBack);}
ContactsTag.setCustomTag(customTag);ContactsTag.setCustomTagVisibility(isCustomTagVisible);ContactsTag.fillTagOptions(tagsList,contactTag,options);navigation.go('view-select-tag','right-left');if(document.activeElement){document.activeElement.blur();}}
var goToSelectTag=function goToSelectTag(event){contactTag=event.currentTarget.children[0];var tagViewElement=document.getElementById('view-select-tag');if(!lazyLoadedTagsDom){LazyLoader.load(tagViewElement,function(){showSelectTag();lazyLoadedTagsDom=true;});}
else{showSelectTag();}};var sendSms=function sendSms(number){if(!ActivityHandler.currentlyHandling||ActivityHandler.currentActivityIs(['open'])){SmsIntegration.sendSms(number);}};var handleBack=function handleBack(cb){navigation.back(cb);};var handleCancel=function handleCancel(){if(ActivityHandler.currentlyHandling){ActivityHandler.postCancel();navigation.home();}else{handleBack();}};var handleSelectTagDone=function handleSelectTagDone(){var prevValue=contactTag.textContent;ContactsTag.clickDone(function(){var valueModifiedEvent=new CustomEvent('ValueModified',{bubbles:true,detail:{prevValue:prevValue,newValue:contactTag.textContent}});contactTag.dispatchEvent(valueModifiedEvent);handleBack();});};var handleCustomTag=function handleCustomTag(ev){if(ev.keyCode===13){ev.preventDefault();}
ContactsTag.touchCustomTag();};var handleCustomTagReset=function handleCustomTagReset(ev){ev.preventDefault();if(customTag){customTag.value='';}};var sendEmailOrPick=function sendEmailOrPick(address){try{new MozActivity({name:'new',data:{type:'mail',URI:'mailto:'+address}});}catch(e){console.error('WebActivities unavailable? : '+e);}};var showAddContact=function showAddContact(){showForm();};var loadFacebook=function loadFacebook(callback){if(!fbLoader.loaded){fb.init(function onInitFb(){window.addEventListener('facebookLoaded',function onFbLoaded(){window.removeEventListener('facebookLoaded',onFbLoaded);callback();});fbLoader.load();});}else{callback();}};var initForm=function c_initForm(callback){if(formReady){callback();}else{initDetails(function onDetails(){LazyLoader.load([SHARED_UTILS_PATH+'/misc.js','/shared/js/contacts/utilities/image_thumbnail.js'],function(){Contacts.view('Form',function viewLoaded(){formReady=true;contactsForm=contacts.Form;contactsForm.init(TAG_OPTIONS);callback();});});});}};var initSettings=function c_initSettings(callback){if(settingsReady){callback();}else{Contacts.view('Settings',function viewLoaded(){LazyLoader.load(['/contacts/js/utilities/sim_dom_generator.js','/contacts/js/utilities/normalizer.js',SHARED_UTILS_PATH+'/misc.js','/shared/js/mime_mapper.js',SHARED_UTILS_PATH+'/vcard_parser.js','/contacts/js/utilities/icc_handler.js',SHARED_UTILS_PATH+'/sdcard.js','/shared/js/date_time_helper.js'],function(){settingsReady=true;contacts.Settings.init();callback();});});}};var initDetails=function c_initDetails(callback){if(detailsReady){callback();}else{Contacts.view('Details',function viewLoaded(){LazyLoader.load([SHARED_UTILS_PATH+'/misc.js','/dialer/js/telephony_helper.js','/shared/js/contacts/sms_integration.js','/shared/js/contacts/contacts_buttons.js'],function(){detailsReady=true;contactsDetails=contacts.Details;contactsDetails.init();callback();});});}};var showForm=function c_showForm(edit,contact){currentContact=contact||currentContact;initForm(function onInit(){doShowForm(edit);});};var doShowForm=function c_doShowForm(edit){var contact=edit?currentContact:null;if(contact&&fb.isFbContact(contact)){var fbContact=new fb.Contact(contact);var req=fbContact.getDataAndValues();req.onsuccess=function(){contactsForm.render(contact,goToForm,req.result);};req.onerror=function(){contactsForm.render(contact,goToForm);};}
else{contactsForm.render(contact,goToForm);}};var setCurrent=function c_setCurrent(contact){currentContact=contact;if('mozNfc'in navigator&&contacts.NFC){contacts.NFC.startListening(contact);}
if(contacts.Details){contacts.Details.setContact(contact);}};var showOverlay=function c_showOverlay(messageId,progressClass,textId){var out=utils.overlay.show(messageId,progressClass,textId);contacts.List.hide();return out;};var hideOverlay=function c_hideOverlay(){Contacts.utility('Overlay',function _loaded(){contacts.List.show();utils.overlay.hide();},SHARED_UTILS);};var showStatus=function c_showStatus(messageId,additionalId){utils.status.show(messageId,additionalId);};var showSettings=function showSettings(){initSettings(function onSettingsReady(){contacts.Settings.refresh();navigation.go('view-settings','fade-in');});};var stopPropagation=function stopPropagation(evt){evt.preventDefault();};var enterSearchMode=function enterSearchMode(evt){Contacts.view('Search',function viewLoaded(){contacts.List.initSearch(function onInit(){contacts.Search.enterSearchMode(evt);});},SHARED_CONTACTS);};var initEventListeners=function initEventListener(){utils.listeners.add({'#contacts-list-header':[{event:'action',handler:handleCancel}],'#add-contact-button':showAddContact,'#settings-button':showSettings,'#search-start':[{event:'click',handler:enterSearchMode}],'#search-start > input':[{event:'focus',handler:enterSearchMode}],'button[type="reset"]':stopPropagation});};var getFirstContacts=function c_getFirstContacts(){var onerror=function(){console.error('Error getting first contacts');};contactsList=contactsList||contacts.List;contactsList.getAllContacts(onerror);};var addAsyncScripts=function addAsyncScripts(){var lazyLoadFiles=['/shared/js/contacts/utilities/templates.js','/shared/js/contacts/contacts_shortcuts.js','/contacts/js/contacts_tag.js','/contacts/js/tag_options.js','/shared/js/text_normalizer.js',SHARED_UTILS_PATH+'/status.js','/shared/js/contacts/utilities/dom.js'];if('mozNfc'in navigator){lazyLoadFiles.push('/contacts/js/nfc.js');}
LazyLoader.load(lazyLoadFiles,function(){if(!ActivityHandler.currentlyHandling||ActivityHandler.currentActivityIs(['pick','update'])){initContactsList();checkUrl();}else{navigator.mozContacts.oncontactchange=null;}
window.dispatchEvent(new CustomEvent('asyncScriptsLoaded'));});};var pendingChanges={};var checkPendingChanges=function checkPendingChanges(id){var changes=pendingChanges[id];if(!changes){return;}
pendingChanges[id].shift();if(pendingChanges[id].length>=1){performOnContactChange(pendingChanges[id][0]);}};navigator.mozContacts.oncontactchange=function oncontactchange(event){if(typeof pendingChanges[event.contactID]!=='undefined'){pendingChanges[event.contactID].push({contactID:event.contactID,reason:event.reason});}else{pendingChanges[event.contactID]=[{contactID:event.contactID,reason:event.reason}];}
if(pendingChanges[event.contactID].length>1){return;}
performOnContactChange(event);};var performOnContactChange=function performOnContactChange(event){initContactsList();var currView=navigation.currentView();switch(event.reason){case'update':if(currView=='view-contact-details'&&currentContact!=null&&currentContact.id==event.contactID){contactsList.getContactById(event.contactID,function success(contact,enrichedContact){currentContact=contact;if(contactsDetails){contactsDetails.render(currentContact,enrichedContact);}
if(contactsList){contactsList.refresh(enrichedContact||currentContact,checkPendingChanges,event.reason);}
notifyContactChanged(event.contactID,event.reason);});}else{refreshContactInList(event.contactID);}
break;case'create':refreshContactInList(event.contactID);break;case'remove':if(currentContact!=null&&currentContact.id==event.contactID&&(currView=='view-contact-details'||currView=='view-contact-form')){navigation.home();}
contactsList.remove(event.contactID,event.reason);currentContact={};checkPendingChanges(event.contactID);notifyContactChanged(event.contactID,event.reason);break;}};function refreshContactInList(id){contactsList.refresh(id,function(){notifyContactChanged(id);checkPendingChanges(id);});}
function notifyContactChanged(id,reason){document.dispatchEvent(new CustomEvent('contactChanged',{detail:{contactID:id,reason:reason}}));}
var close=function close(){window.removeEventListener('localized',initContacts);};var initContacts=function initContacts(evt){window.setTimeout(Contacts.onLocalized);if(window.navigator.mozSetMessageHandler&&window.self==window.top){LazyLoader.load([SHARED_UTILS_PATH+'/misc.js',SHARED_UTILS_PATH+'/vcard_reader.js',SHARED_UTILS_PATH+'/vcard_parser.js'],function(){var actHandler=ActivityHandler.handle.bind(ActivityHandler);window.navigator.mozSetMessageHandler('activity',actHandler);});}
document.addEventListener('visibilitychange',function visibility(e){Contacts.checkCancelableActivity();if(document.hidden===false&&navigation.currentView()==='view-settings'){Contacts.view('Settings',function viewLoaded(){contacts.Settings.updateTimestamps();});}});};navigator.mozL10n.once(initContacts);function loadConfirmDialog(){var args=Array.slice(arguments);Contacts.utility('Confirm',function viewLoaded(){ConfirmDialog.show.apply(ConfirmDialog,args);},SHARED);}
var dependencies={views:{Settings:loadFacebook,Details:loadFacebook,Form:loadFacebook},utilities:{},sharedUtilities:{}};var elementMapping={details:'view-contact-details',form:'view-contact-form',settings:'settings-wrapper',search:'search-view',overlay:'loading-overlay',confirm:'confirmation-message',ice:'ice-view'};function load(type,file,callback,path){function doLoad(){var name=file.toLowerCase();var finalPath='js'+'/'+type;switch(path){case SHARED:finalPath=SHARED_PATH;break;case SHARED_UTILS:finalPath=SHARED_UTILS_PATH;break;case SHARED_CONTACTS:finalPath=SHARED_CONTACTS_PATH;break;default:finalPath='js'+'/'+type;}
var toLoad=[finalPath+'/'+name+'.js'];var node=document.getElementById(elementMapping[name]);if(node){toLoad.unshift(node);}
LazyLoader.load(toLoad,function(){if(callback){callback();}});}
if(dependencies[type][file]){return dependencies[type][file](doLoad);}
doLoad();}
function loadView(view,callback,type){load('views',view,callback,type);}
function loadUtility(utility,callback,type){load('utilities',utility,callback,type);}
var updateSelectCountTitle=function updateSelectCountTitle(count){navigator.mozL10n.setAttributes(editModeTitleElement,'SelectedTxt',{n:count});};window.addEventListener('DOMContentLoaded',function onLoad(){utils.PerformanceHelper.domLoaded();window.removeEventListener('DOMContentLoaded',onLoad);});return{'goBack':handleBack,'cancel':handleCancel,'goToSelectTag':goToSelectTag,'sendSms':sendSms,'navigation':navigation,'sendEmailOrPick':sendEmailOrPick,'updatePhoto':updatePhoto,'checkCancelableActivity':checkCancelableActivity,'isEmpty':isEmpty,'getLength':getLength,'showForm':showForm,'setCurrent':setCurrent,'onLocalized':onLocalized,'init':init,'showOverlay':showOverlay,'hideOverlay':hideOverlay,'showContactDetail':contactListClickHandler,'updateContactDetail':updateContactDetail,'showStatus':showStatus,'loadFacebook':loadFacebook,'confirmDialog':loadConfirmDialog,'close':close,'view':loadView,'utility':loadUtility,'updateSelectCountTitle':updateSelectCountTitle,'setCancelableHeader':setCancelableHeader,'setNormalHeader':setNormalHeader,get asyncScriptsLoaded(){return asyncScriptsLoaded;},get SHARED_UTILITIES(){return SHARED_UTILS;},get SHARED_CONTACTS(){return SHARED_CONTACTS;}};})();;'use strict';if(!window.ImageLoader){var ImageLoader=function ImageLoader(pContainer,pItems){var container,items,itemsSelector,lastScrollTime,scrollLatency=100,scrollTimer,itemHeight,total,imgsLoading=0,loadImage=defaultLoadImage,self=this;init(pContainer,pItems);function init(pContainer,pItems){itemsSelector=pItems;container=document.querySelector(pContainer);attachHandlers();window.addEventListener('image-loader-resume',resuming);window.addEventListener('image-loader-pause',unload);load();}
function resuming(){window.clearTimeout(scrollTimer);attachHandlers();update();}
function onUpdate(evt){evt.stopPropagation();onScroll();}
function load(){window.clearTimeout(scrollTimer);scrollTimer=null;items=container.querySelectorAll(itemsSelector);itemHeight=items[0]?items[0].offsetHeight:1;total=items.length;window.setTimeout(update,0);}
function attachHandlers(){container.addEventListener('scroll',onScroll);document.addEventListener('onupdate',onUpdate);}
function unload(){container.removeEventListener('scroll',onScroll);document.removeEventListener('onupdate',onUpdate);window.clearTimeout(scrollTimer);scrollTimer=null;}
function setResolver(pResolver){loadImage=pResolver;}
function onScroll(){if(imgsLoading>0){window.stop();imgsLoading=0;}
lastScrollTime=Date.now();if(!scrollTimer){scrollTimer=window.setTimeout(updateFromScroll,scrollLatency);}}
function updateFromScroll(){scrollTimer=null;var deltaLatency=lastScrollTime-Date.now()+scrollLatency;if(deltaLatency>0){scrollTimer=window.setTimeout(updateFromScroll,deltaLatency);}else{update();}}
function defaultLoadImage(item){var image=item.querySelector('span[data-type=img][data-src]');if(!image){image=item.querySelector('img[data-src]');if(!image){image=item.querySelector('span[data-type=img][data-group]');if(image){item.dataset.visited='true';}
return;}}
++imgsLoading;var tmp=new Image();var src=tmp.src=image.dataset.src;tmp.onload=function onload(){--imgsLoading;image.style.backgroundImage='url('+src+')';if(tmp.complete){item.dataset.visited='true';}
tmp=null;};tmp.onabort=tmp.onerror=function onerror(){--imgsLoading;item.dataset.visited='false';tmp=null;};}
function update(){if(total===0){return;}
var viewTop=container.scrollTop;var index=Math.floor(viewTop/itemHeight);var containerHeight=container.offsetHeight;for(var i=index;i>=0;i--){var item=items[i];if(item){if(item.offsetTop+itemHeight<viewTop){break;}
if(item.dataset.visited!=='true'&&item.offsetTop<=viewTop+containerHeight){loadImage(item,self);}}}
for(var j=index+1;j<total;j++){var theItem=items[j];if(!theItem){return;}
if(theItem.offsetTop>viewTop+containerHeight){return;}
if(theItem.dataset.visited!=='true'){loadImage(theItem,self);}}}
function releaseImage(item){var image=item.querySelector('span[data-type=img][data-src]');if(!image){image=item.querySelector('span[data-type=img][data-group]');if(image){item.dataset.visited='false';}
return null;}
image.style.backgroundImage='none';item.dataset.visited='false';return image;}
function destroy(){unload();window.removeEventListener('image-loader-pause',unload);window.removeEventListener('image-loader-resume',resuming);container=items=itemsSelector=lastScrollTime=scrollLatency=null;scrollTimer=itemHeight=total=imgsLoading=loadImage=null;}
this.reload=load;this.unload=unload;this.setResolver=setResolver;this.defaultLoad=defaultLoadImage;this.releaseImage=releaseImage;this.destroy=destroy;};};'use strict';(function(window){window.mozPerformance={timing:{}};function dispatch(name){if(!window.mozPerfHasListener){return;}
var now=window.performance.now();var epoch=Date.now();setTimeout(function(){var detail={name:name,timestamp:now,epoch:epoch};var event=new CustomEvent('x-moz-perf',{detail:detail});window.dispatchEvent(event);});}
['moz-chrome-dom-loaded','moz-chrome-interactive','moz-app-visually-complete','moz-content-interactive','moz-app-loaded'].forEach(function(eventName){window.addEventListener(eventName,function mozPerfLoadHandler(){dispatch(eventName);},false);});window.PerformanceTestingHelper={dispatch:dispatch};})(window);;'use strict';var fbLoader=(function(){var loaded=false;var loadFb=function loadFb(){if(loaded){return;}
loaded=true;var iframesFragment=document.createDocumentFragment();var curtain=document.createElement('iframe');curtain.id='fb-curtain';curtain.src='/shared/pages/import/curtain.html';iframesFragment.appendChild(curtain);var oauth=document.createElement('iframe');oauth.id='fb-oauth';oauth.hidden=true;iframesFragment.appendChild(oauth);var extensions=document.createElement('iframe');extensions.id='fb-extensions';iframesFragment.appendChild(extensions);document.body.appendChild(iframesFragment);var scripts=['/shared/js/contacts/import/utilities/misc.js','/shared/js/contacts/import/import_status_data.js','/contacts/js/service_extensions.js','/shared/pages/import/js/parameters.js','/shared/js/fb/fb_request.js','/shared/js/contacts/import/facebook/fb_data.js','/shared/js/contacts/import/facebook/fb_utils.js','/shared/js/contacts/import/facebook/fb_query.js','/shared/js/fb/fb_reader_utils.js','/shared/js/contacts/import/facebook/fb_contact_utils.js','/shared/js/contacts/import/facebook/fb_contact.js','/contacts/js/fb/fb_link.js','/contacts/js/fb/fb_messaging.js'];LazyLoader.load(scripts,function(){var event=new CustomEvent('facebookLoaded');window.dispatchEvent(event);});};return{load:loadFb,get loaded(){return loaded;}};})();